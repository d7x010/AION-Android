package com.aion.mobile.feature.chat

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.aion.mobile.core.ai.AionCloudSettings
import com.aion.mobile.core.ai.GatewayActivity
import com.aion.mobile.core.run.AionRunBus
import com.aion.mobile.core.run.AionRunCoordinator
import com.aion.mobile.core.run.AionRunSnapshot
import com.aion.mobile.core.storage.ChatSessionStore
import com.aion.mobile.model.ChatAttachment
import com.aion.mobile.model.ChatMessage
import com.aion.mobile.model.ConversationSummary
import com.aion.mobile.model.MessageRole
import kotlinx.coroutines.launch

data class AiModelOption(
    val key: String,
    val label: String,
    val provider: String,
    val enabled: Boolean,
    val modelId: String? = null,
    val badge: String? = null
)

class ChatViewModel(application: Application) : AndroidViewModel(application) {
    private val _messages = mutableStateListOf<ChatMessage>()
    val messages: SnapshotStateList<ChatMessage> = _messages

    private val _pendingAttachments = mutableStateListOf<ChatAttachment>()
    val pendingAttachments: SnapshotStateList<ChatAttachment> = _pendingAttachments

    private val _conversations = mutableStateListOf<ConversationSummary>()
    val conversations: SnapshotStateList<ConversationSummary> = _conversations

    private var nextId = 1L
    private var activeRunId: String? = null
    var activeConversationId by mutableStateOf("")
        private set

    var cloudEndpoint by mutableStateOf(AionCloudSettings.loadEndpoint(application))
        private set
    var isSending by mutableStateOf(false)
        private set
    var selectedModelKey by mutableStateOf(ChatSessionStore.loadSelectedModel(application))
        private set
    var activity by mutableStateOf<GatewayActivity?>(null)
        private set
    var draft by mutableStateOf(ChatSessionStore.loadDraft(application))
        private set

    init {
        val savedConversations = ChatSessionStore.loadConversations(application)
        if (savedConversations.isEmpty()) {
            val legacy = ChatSessionStore.loadMessages(application)
            val initialId = "chat-${System.currentTimeMillis()}"
            val initial = ConversationSummary(
                id = initialId,
                title = legacy.firstOrNull { it.role == MessageRole.USER }?.text?.compactTitle() ?: "محادثة جديدة",
                updatedAt = System.currentTimeMillis()
            )
            _conversations += initial
            ChatSessionStore.saveConversations(application, _conversations)
            ChatSessionStore.saveActiveConversationId(application, initialId)
            if (legacy.isNotEmpty()) ChatSessionStore.saveMessages(application, initialId, legacy)
        } else {
            _conversations.addAll(savedConversations)
        }
        activeConversationId = ChatSessionStore.loadActiveConversationId(application)
            .takeIf { saved -> _conversations.any { it.id == saved } }
            ?: _conversations.first().id
        val restored = ChatSessionStore.loadMessages(application, activeConversationId)
        val activeSnapshot = AionRunBus.snapshot.value
        _messages.addAll(
            if (activeSnapshot == null) {
                restored.map { message ->
                    if (message.isStreaming) message.copy(isStreaming = false, wasStopped = true) else message
                }
            } else restored
        )
        nextId = (_messages.maxOfOrNull { it.id } ?: 0L) + 1L

        activeSnapshot?.let { applyRunSnapshot(it) }

        viewModelScope.launch {
            AionRunBus.snapshot.collect { snapshot ->
                snapshot?.let { applyRunSnapshot(it) }
            }
        }
    }

    val isConfigured: Boolean get() = cloudEndpoint.isNotBlank()

    val modelOptions: List<AiModelOption>
        get() = listOf(
            AiModelOption(
                key = "auto",
                label = "AION Auto",
                provider = "يتكيف تلقائيًا مع طلبك",
                enabled = true,
                modelId = "auto",
                badge = "تلقائي"
            ),
            AiModelOption(
                key = "fast",
                label = "سريع",
                provider = "رد مباشر بزمن أقل",
                enabled = true,
                modelId = "fast",
                badge = "خفيف"
            ),
            AiModelOption(
                key = "deep",
                label = "عميق",
                provider = "تحليل واستدلال أكبر",
                enabled = true,
                modelId = "deep",
                badge = "عميق"
            ),
            AiModelOption(
                key = "research",
                label = "بحث",
                provider = "ويب حي مع مصادر",
                enabled = true,
                modelId = "research",
                badge = "ويب"
            ),
            AiModelOption("direct", "صريح", "حازم بلا مجاملة", true, "direct", "واضح"),
            AiModelOption("creative", "إبداعي", "خيال وصياغة حية", true, "creative", "مبدع"),
            AiModelOption("code", "برمجي", "حلول هندسية وكود", true, "code", "كود"),
            AiModelOption("claude", "Claude", "Anthropic", false, badge = "قريبًا"),
            AiModelOption("gemini", "Gemini", "Google", false, badge = "قريبًا"),
            AiModelOption("grok", "Grok", "xAI", false, badge = "قريبًا")
        )

    val selectedModel: AiModelOption
        get() = modelOptions.firstOrNull { it.key == selectedModelKey } ?: modelOptions.first()

    fun selectModel(key: String) {
        val option = modelOptions.firstOrNull { it.key == key } ?: return
        if (option.enabled && !isSending) {
            selectedModelKey = option.key
            ChatSessionStore.saveSelectedModel(getApplication(), option.key)
        }
    }

    fun updateDraft(value: String) {
        draft = value
        ChatSessionStore.saveDraft(getApplication(), value)
    }

    fun saveSettings(endpoint: String) {
        AionCloudSettings.saveEndpoint(getApplication(), endpoint)
        cloudEndpoint = AionCloudSettings.loadEndpoint(getApplication())
    }

    fun addAttachments(items: List<ChatAttachment>) {
        if (isSending) return
        items.forEach { attachment ->
            if (_pendingAttachments.none { it.id == attachment.id }) {
                _pendingAttachments += attachment
            }
        }
    }

    fun removeAttachment(id: Long) {
        if (!isSending) _pendingAttachments.removeAll { it.id == id }
    }

    fun clearAttachments() {
        if (!isSending) _pendingAttachments.clear()
    }

    fun send(text: String) {
        val clean = text.trim()
        val attachments = _pendingAttachments.toList()
        if ((clean.isEmpty() && attachments.isEmpty()) || isSending) return

        val chosen = selectedModel
        val resolvedModel = chosen.modelId.orEmpty()
        val userMessage = ChatMessage(
            id = nextId++,
            role = MessageRole.USER,
            text = clean,
            modelId = resolvedModel,
            modelLabel = chosen.label,
            attachments = attachments
        )
        _messages += userMessage
        touchConversation(userMessage.text)
        _pendingAttachments.clear()
        updateDraft("")

        if (!isConfigured) {
            _messages += ChatMessage(
                id = nextId++,
                role = MessageRole.AION,
                text = "اربط عنوان AION Cloud من الإعدادات أولًا، ثم أرسل الرسالة من جديد.",
                modelId = resolvedModel,
                modelLabel = chosen.label,
                isError = true
            )
            persistMessages()
            return
        }

        requestAssistantResponse(chosen = chosen, resolvedModel = resolvedModel)
    }

    fun stopGeneration() {
        AionRunCoordinator.stop(getApplication(), activeRunId)
    }

    fun retryLastResponse() {
        if (isSending || !isConfigured) return
        val lastUserIndex = _messages.indexOfLast { it.role == MessageRole.USER }
        if (lastUserIndex < 0) return

        while (_messages.size > lastUserIndex + 1) {
            _messages.removeAt(_messages.lastIndex)
        }

        val lastUser = _messages[lastUserIndex]
        val chosen = modelOptions.firstOrNull { it.label == lastUser.modelLabel }
            ?: modelOptions.firstOrNull { it.modelId == lastUser.modelId }
            ?: if (selectedModel.enabled) selectedModel else modelOptions.first()
        val resolvedModel = lastUser.modelId?.takeIf { it.isNotBlank() } ?: chosen.modelId.orEmpty()

        persistMessages()
        requestAssistantResponse(chosen = chosen, resolvedModel = resolvedModel)
    }

    fun newConversation() {
        if (!isSending) {
            persistMessages()
            val newId = "chat-${System.currentTimeMillis()}"
            activeConversationId = newId
            _conversations.add(0, ConversationSummary(newId, "محادثة جديدة", System.currentTimeMillis()))
            persistConversations()
            _messages.clear()
            _pendingAttachments.clear()
            activity = null
            updateDraft("")
            ChatSessionStore.saveMessages(getApplication(), newId, emptyList())
            AionRunBus.publish(null)
        }
    }

    fun openConversation(id: String) {
        if (isSending || id == activeConversationId || _conversations.none { it.id == id }) return
        persistMessages()
        activeConversationId = id
        ChatSessionStore.saveActiveConversationId(getApplication(), id)
        _messages.clear()
        _messages.addAll(ChatSessionStore.loadMessages(getApplication(), id))
        nextId = (_messages.maxOfOrNull { it.id } ?: 0L) + 1L
        _pendingAttachments.clear()
        updateDraft("")
    }

    fun deleteConversation(id: String) {
        if (isSending || _conversations.size <= 1) return
        _conversations.removeAll { it.id == id }
        ChatSessionStore.deleteConversation(getApplication(), id)
        if (id == activeConversationId) {
            activeConversationId = _conversations.first().id
            _messages.clear()
            _messages.addAll(ChatSessionStore.loadMessages(getApplication(), activeConversationId))
            nextId = (_messages.maxOfOrNull { it.id } ?: 0L) + 1L
        }
        persistConversations()
    }

    private fun requestAssistantResponse(chosen: AiModelOption, resolvedModel: String) {
        val placeholderId = nextId++
        _messages += ChatMessage(
            id = placeholderId,
            role = MessageRole.AION,
            text = "",
            modelId = resolvedModel,
            modelLabel = chosen.label,
            isStreaming = true
        )
        isSending = true
        activity = GatewayActivity.THINKING

        val sessionMessages = _messages.filter { it.id != placeholderId }.toList()
        val requestMessages = sessionMessages
            .filter { !it.isError && !it.wasStopped }
            .map { message ->
                // المرفقات المستعادة بعد إعادة تشغيل التطبيق لا تحمل base64؛ لا نرسل عناصر فارغة للـAPI.
                if (message.attachments.any { it.base64Data.isBlank() }) {
                    message.copy(attachments = message.attachments.filter { it.base64Data.isNotBlank() })
                } else message
            }
            .toList()

        persistMessages()
        activeRunId = AionRunCoordinator.start(
            context = getApplication(),
            placeholderId = placeholderId,
            modelId = resolvedModel,
            modelLabel = chosen.label,
            conversationId = activeConversationId,
            messages = requestMessages,
            sessionMessages = sessionMessages,
            forceWebSearch = chosen.key == "research" || shouldForceWebSearch(requestMessages)
        )
    }

    private fun shouldForceWebSearch(messages: List<ChatMessage>): Boolean {
        val text = messages.lastOrNull { it.role == MessageRole.USER }?.text
            ?.lowercase()
            ?.replace("إ", "ا")
            ?.replace("أ", "ا")
            ?.replace("آ", "ا")
            .orEmpty()

        if (text.isBlank()) return false

        val explicitSearch = listOf(
            "ابحث", "بحث في الويب", "ابحث في الويب", "فتش في الويب",
            "دور في الويب", "دور بالويب", "من الانترنت", "من الإنترنت",
            "على الانترنت", "على الإنترنت", "مصادر حديثة", "اخر الاخبار",
            "آخر الأخبار", "احدث الاخبار", "أحدث الأخبار"
        ).any { phrase ->
            val normalized = phrase.lowercase()
                .replace("إ", "ا")
                .replace("أ", "ا")
                .replace("آ", "ا")
            text.contains(normalized)
        }

        return explicitSearch
    }

    private fun applyRunSnapshot(snapshot: AionRunSnapshot) {
        activeRunId = if (snapshot.isRunning) snapshot.runId else null
        isSending = snapshot.isRunning
        activity = if (snapshot.isRunning) snapshot.activity else null

        val index = _messages.indexOfFirst { it.id == snapshot.placeholderId }
        val updated = ChatMessage(
            id = snapshot.placeholderId,
            role = MessageRole.AION,
            text = snapshot.text,
            modelId = snapshot.modelId,
            modelLabel = snapshot.modelLabel,
            sources = snapshot.sources,
            isError = snapshot.errorText != null,
            isStreaming = snapshot.isRunning,
            wasStopped = snapshot.wasStopped
        )

        when {
            index >= 0 && snapshot.wasStopped && snapshot.text.isBlank() -> _messages.removeAt(index)
            index >= 0 -> _messages[index] = updated
            snapshot.text.isNotBlank() || snapshot.isRunning -> _messages += updated
        }

        if (!snapshot.isRunning) {
            persistMessages()
        }
    }

    private fun persistMessages() {
        if (activeConversationId.isNotBlank()) {
            ChatSessionStore.saveMessages(getApplication(), activeConversationId, _messages)
        }
    }

    private fun touchConversation(firstUserText: String? = null) {
        val index = _conversations.indexOfFirst { it.id == activeConversationId }
        if (index < 0) return
        val existing = _conversations.removeAt(index)
        val title = if (existing.title == "محادثة جديدة" && !firstUserText.isNullOrBlank()) firstUserText.compactTitle() else existing.title
        _conversations.add(0, existing.copy(title = title, updatedAt = System.currentTimeMillis()))
        persistConversations()
    }

    private fun persistConversations() {
        ChatSessionStore.saveConversations(getApplication(), _conversations)
        ChatSessionStore.saveActiveConversationId(getApplication(), activeConversationId)
    }
}

private fun String.compactTitle(): String = trim().replace(Regex("\\s+"), " ").take(42).ifBlank { "محادثة جديدة" }
