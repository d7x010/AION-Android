import assert from "node:assert/strict";
import worker from "./src/index.js";

function sseStream(parts) {
  const encoder = new TextEncoder();
  return new ReadableStream({
    start(controller) {
      for (const part of parts) controller.enqueue(encoder.encode(part));
      controller.close();
    },
  });
}

async function testTrueStreaming() {
  const calls = [];
  const env = {
    AI: {
      run: async (model, payload) => {
        calls.push({ model, payload });
        assert.equal(payload.stream, true);
        return sseStream([
          'data: {"response":"مرح"}\n\n',
          'data: {"response":"مرحبا"}\n\n',
          'data: [DONE]\n\n',
        ]);
      },
      toMarkdown: async () => { throw new Error("not expected"); },
    },
  };
  const request = new Request("https://aion.test/v1/chat/stream", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ mode: "auto", messages: [{ role: "user", content: "هلا" }] }),
  });
  const response = await worker.fetch(request, env);
  const text = await response.text();
  assert.equal(response.status, 200);
  assert.match(text, /event: delta/);
  assert.match(text, /"text":"مرح"/);
  assert.match(text, /"text":"با"/);
  assert.match(text, /"trueStreaming":true/);
  assert.equal(calls.length, 1);
}

async function testTextAttachmentContext() {
  let capturedMessages;
  const env = {
    AI: {
      run: async (_model, payload) => {
        capturedMessages = payload.messages;
        return { response: "قرأت الملف" };
      },
      toMarkdown: async () => { throw new Error("text files should decode locally"); },
    },
  };
  const data = Buffer.from("alpha beta gamma", "utf8").toString("base64");
  const request = new Request("https://aion.test/v1/chat", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({
      mode: "deep",
      messages: [{
        role: "user",
        content: "حلل الملف",
        attachments: [{ name: "notes.txt", mimeType: "text/plain", kind: "FILE", sizeBytes: 16, data }],
      }],
    }),
  });
  const response = await worker.fetch(request, env);
  const body = await response.json();
  assert.equal(response.status, 200);
  assert.equal(body.response, "قرأت الملف");
  assert.ok(capturedMessages.some((m) => m.content.includes("alpha beta gamma")));
}

async function testBinaryAttachmentConversion() {
  let converted = false;
  let capturedMessages;
  const env = {
    AI: {
      run: async (_model, payload) => {
        capturedMessages = payload.messages;
        return { response: "تم" };
      },
      toMarkdown: async (input) => {
        converted = true;
        assert.equal(input.name, "sample.pdf");
        assert.equal(input.blob.type, "application/pdf");
        return { name: "sample.pdf", format: "markdown", data: "# عنوان\nمحتوى PDF" };
      },
    },
  };
  const data = Buffer.from("fake-pdf", "utf8").toString("base64");
  const request = new Request("https://aion.test/v1/chat", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({
      messages: [{ role: "user", content: "", attachments: [{ name: "sample.pdf", mimeType: "application/pdf", kind: "FILE", sizeBytes: 8, data }] }],
    }),
  });
  const response = await worker.fetch(request, env);
  const body = await response.json();
  assert.equal(body.response, "تم");
  assert.equal(converted, true);
  assert.ok(capturedMessages.some((m) => m.content.includes("محتوى PDF")));
}

async function testStreamingFallbackBeforeFirstToken() {
  let call = 0;
  const env = {
    AI: {
      run: async () => {
        call += 1;
        if (call === 1) throw new Error("primary unavailable");
        return sseStream(['data: {"response":"بديل"}\n\ndata: [DONE]\n\n']);
      },
      toMarkdown: async () => ({ data: "" }),
    },
  };
  const response = await worker.fetch(new Request("https://aion.test/v1/chat/stream", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ messages: [{ role: "user", content: "اختبار" }] }),
  }), env);
  const text = await response.text();
  assert.equal(call, 2);
  assert.match(text, /بديل/);
}


async function testModelRouting() {
  const models = [];
  const env = {
    AI: {
      run: async (model, payload) => {
        models.push({ model, payload });
        return { response: "ok" };
      },
      toMarkdown: async () => ({ data: "" }),
    },
  };

  const deep = await worker.fetch(new Request("https://aion.test/v1/chat", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ mode: "deep", messages: [{ role: "user", content: "حلل بعمق" }] }),
  }), env);
  assert.equal(deep.status, 200);
  assert.equal(models.at(-1).model, "@cf/openai/gpt-oss-120b");
  assert.equal(models.at(-1).payload.max_tokens, 6000);

  const research = await worker.fetch(new Request("https://aion.test/v1/chat", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ mode: "research", messages: [{ role: "user", content: "بحث" }] }),
  }), { ...env, FIRECRAWL_API_KEY: undefined });
  assert.equal(research.status, 200);
  assert.equal(models.at(-1).model, "@cf/google/gemma-4-26b-a4b-it");
  assert.deepEqual(models.at(-1).payload.web_search_options, {});
}




async function testNativeVisionRouting() {
  let capturedModel = null;
  let capturedMessages = null;
  const env = {
    AI: {
      run: async (model, payload) => {
        capturedModel = model;
        capturedMessages = payload.messages;
        return { response: "قطة" };
      },
      toMarkdown: async () => { throw new Error("image should not use markdown conversion"); },
    },
  };
  const imageData = Buffer.from("fake-image", "utf8").toString("base64");
  const response = await worker.fetch(new Request("https://aion.test/v1/chat", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({
      mode: "auto",
      messages: [{
        role: "user",
        content: "ما هذه الصورة؟",
        attachments: [{ name: "cat.jpg", mimeType: "image/jpeg", kind: "IMAGE", sizeBytes: 10, data: imageData }],
      }],
    }),
  }), env);
  assert.equal(response.status, 200);
  assert.equal(capturedModel, "@cf/google/gemma-4-26b-a4b-it");
  const last = capturedMessages.at(-1);
  assert.ok(Array.isArray(last.content));
  assert.equal(last.content[0].type, "text");
  assert.equal(last.content[1].type, "image_url");
  assert.match(last.content[1].image_url.url, /^data:image\/jpeg;base64,/);
}

async function testNoFallbackAfterPartialToken() {
  let calls = 0;
  const encoder = new TextEncoder();
  const env = {
    AI: {
      run: async () => {
        calls += 1;
        return new ReadableStream({
          start(controller) {
            controller.enqueue(encoder.encode('data: {"response":"جزء"}\n\n'));
            controller.enqueue(encoder.encode('data: {bad-json}\n\n'));
            controller.close();
          },
        });
      },
      toMarkdown: async () => ({ data: "" }),
    },
  };
  const response = await worker.fetch(new Request("https://aion.test/v1/chat/stream", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ mode: "fast", messages: [{ role: "user", content: "اختبار" }] }),
  }), env);
  const body = await response.text();
  assert.equal(calls, 1);
  assert.match(body, /جزء/);
  assert.match(body, /event: error/);
}

async function testPersonalizationAndLongContext() {
  let capturedMessages;
  const env = {
    AI: {
      run: async (_model, payload) => {
        capturedMessages = payload.messages;
        return { response: "ok" };
      },
      toMarkdown: async () => ({ data: "" }),
    },
  };
  const messages = Array.from({ length: 140 }, (_, i) => ({
    role: i % 2 === 0 ? "user" : "assistant",
    content: `message-${i}`,
  }));
  const response = await worker.fetch(new Request("https://aion.test/v1/chat", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({
      mode: "fast",
      customInstructions: "تكلم بالعربية فقط",
      memoryContext: "اسم المشروع AION",
      messages,
    }),
  }), env);
  assert.equal(response.status, 200);
  assert.ok(capturedMessages[0].content.includes("تكلم بالعربية فقط"));
  assert.ok(capturedMessages[0].content.includes("اسم المشروع AION"));
  assert.ok(capturedMessages.length <= 97); // system + up to 96 conversation messages
  assert.ok(capturedMessages.at(-1).content.includes("message-139"));
}

await testTrueStreaming();
await testTextAttachmentContext();
await testBinaryAttachmentConversion();
await testStreamingFallbackBeforeFirstToken();
await testModelRouting();
await testPersonalizationAndLongContext();
await testNativeVisionRouting();
await testNoFallbackAfterPartialToken();
console.log("AION worker tests: PASS");
