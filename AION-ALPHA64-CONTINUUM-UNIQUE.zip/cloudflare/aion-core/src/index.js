const PRIMARY_MODEL = "@cf/zai-org/glm-4.7-flash";
const FALLBACK_MODEL = "@cf/google/gemma-4-26b-a4b-it";
const MAX_MESSAGES = 28;
const MAX_MESSAGE_CHARS = 12_000;
const MAX_BODY_BYTES = 420_000;
const MAX_REQUESTS_PER_WINDOW = 24;
const WINDOW_MS = 10 * 60 * 1000;
const buckets = new Map();

const AION_SYSTEM_PROMPT = `
أنت AION، رفيق ذكاء شخصي حي ودقيق داخل تطبيق AION.
أجب بالعربية افتراضيًا، وافهم العربية الفصحى واللهجات العربية ومنها العراقية، وانتقل إلى لغة أخرى عندما يطلب المستخدم ذلك.

قواعد الحوار:
- لا تكرر سؤال المستخدم ولا تبدأ بمقدمات فارغة أو مديح تلقائي.
- اجعل طول الجواب متكيفًا مع النية: القصير للطلب البسيط، والتفصيل عندما يحتاج الموضوع فعلًا. لا ترسل إجابة مبتورة أو نصف جملة.
- تعامل مع الرسائل كسياق متصل، واعتمد تصحيح المستخدم فورًا بدل إعادة الحوار من الصفر.
- ميّز الحقيقة عن الرأي والافتراض وعدم اليقين عندما يكون الفرق مهمًا.
- لا تدّعِ أنك بحثت في الويب ما لم تستلم مصادر بحث فعلية في هذه المحادثة.
- إذا زوّدك النظام بمصادر حية، اربط الادعاءات المهمة بها باستخدام [1] و[2]... ولا تخترع مصادر أو روابط.
- لا تكشف سلسلة التفكير الداخلية. أعطِ الخلاصة والأسباب المفيدة فقط.
- إذا كان المستخدم مخطئًا في حقيقة قابلة للتحقق، صححها باختصار ووضوح.
- لا تختم كل رد بسؤال آلي أو عرض عام للمساعدة.
- عندما يكون الطلب برمجيًا، أعطِ نتيجة قابلة للتنفيذ وحافظ على الاتساق مع القرارات السابقة في الحوار.
`;

function headers(extra = {}) {
  return {
    "cache-control": "no-store",
    "access-control-allow-origin": "*",
    "access-control-allow-methods": "GET, POST, OPTIONS",
    "access-control-allow-headers": "content-type",
    ...extra,
  };
}

function json(value, status = 200) {
  return new Response(JSON.stringify(value), {
    status,
    headers: headers({ "content-type": "application/json; charset=utf-8" }),
  });
}

function allowRequest(request) {
  const ip = request.headers.get("CF-Connecting-IP") || "unknown";
  const now = Date.now();
  const bucket = buckets.get(ip);
  if (!bucket || now - bucket.startedAt >= WINDOW_MS) {
    buckets.set(ip, { startedAt: now, count: 1 });
    return true;
  }
  if (bucket.count >= MAX_REQUESTS_PER_WINDOW) return false;
  bucket.count += 1;
  return true;
}

function cleanMessages(input) {
  if (!Array.isArray(input) || input.length === 0) throw new Error("messages مطلوبة.");
  if (input.length > MAX_MESSAGES) throw new Error("عدد الرسائل أكبر من الحد المسموح.");
  return input.map((message) => {
    const role = message?.role === "assistant" ? "assistant" : message?.role === "system" ? "system" : "user";
    const content = typeof message?.content === "string" ? message.content.trim() : "";
    if (!content) throw new Error("كل رسالة تحتاج نصًا.");
    if (content.length > MAX_MESSAGE_CHARS) throw new Error("إحدى الرسائل طويلة جدًا.");
    return { role, content };
  });
}

function normalizeArabic(text) {
  return String(text || "")
    .toLowerCase()
    .replace(/[إأآ]/g, "ا")
    .replace(/ى/g, "ي")
    .replace(/ة/g, "ه");
}

function requestedMode(payload) {
  const value = String(payload?.mode || payload?.model || "auto").toLowerCase();
  return ["auto", "fast", "deep", "research", "direct", "creative", "code"].includes(value) ? value : "auto";
}

function chooseMode(payload, messages) {
  const requested = requestedMode(payload);
  if (requested !== "auto") return requested;

  const last = [...messages].reverse().find((m) => m.role === "user")?.content || "";
  const text = normalizeArabic(last);
  const deepSignals = [
    "عميق", "تحليل نفسي", "فلسفي", "حلل", "حلّل", "بالتفصيل", "من كل الجوانب",
    "اختبر الافتراضات", "قارن بعمق", "اشرح الاسباب", "لماذا الانسان"
  ];
  if (deepSignals.some((phrase) => text.includes(normalizeArabic(phrase)))) return "deep";

  const fastSignals = ["بجمله", "بجملتين", "باختصار", "بكلمه", "جواب سريع", "اختصر"];
  if (fastSignals.some((phrase) => text.includes(normalizeArabic(phrase)))) return "fast";
  return "auto";
}

function shouldSearch(payload, messages, mode) {
  if (mode === "research" || payload?.forceWebSearch === true) return true;
  const last = [...messages].reverse().find((m) => m.role === "user")?.content || "";
  const text = normalizeArabic(last);
  const explicit = [
    "ابحث", "بحث في الويب", "فتش في الويب", "دور بالويب", "دور في الويب", "من الانترنت",
    "على الانترنت", "مصادر حديثه", "تحقق من الويب"
  ];
  if (explicit.some((phrase) => text.includes(normalizeArabic(phrase)))) return true;

  const freshness = [
    "اخر الاخبار", "احدث الاخبار", "اخر تحديث", "سعر اليوم", "الطقس", "موعد اليوم",
    "نتيجه المباراه", "نتائج اليوم", "من فاز", "احدث اصدار", "احدث نسخه", "متوفر حاليا"
  ];
  return freshness.some((phrase) => text.includes(normalizeArabic(phrase)));
}

function modeInstruction(mode, researched) {
  const base = {
    fast: "وضع سريع: أعطِ أقل جواب كافٍ ومباشر، وتجنب التفصيل غير الضروري.",
    deep: "وضع عميق: حلل المسألة بصرامة، اختبر الافتراضات، واشرح النتيجة بعمق منظم من دون حشو.",
    research: "وضع بحث: ابنِ الجواب على الأدلة الحية، قارن المصادر عند الاختلاف، واذكر حدود ما يمكن التحقق منه.",
    direct: "وضع صريح: كن حازمًا ومحترمًا، لا تجامل، وقل النتيجة بوضوح مع أسبابها العملية.",
    creative: "وضع إبداعي: استخدم خيالًا وصياغة حية وأفكارًا غير سطحية مع الحفاظ على التماسك.",
    code: "وضع برمجي: تصرف كمهندس برمجيات، أعطِ حلاً قابلًا للتنفيذ، وافحص الأخطاء والحالات الطرفية.",
    auto: "وضع تلقائي: اختر بنفسك مقدار العمق والطول المناسبين للطلب.",
  }[mode] || "";
  return researched ? `${base}\nلديك مصادر ويب حية أدناه. لا تنسب إليها ما لا تقوله.` : base;
}

function arabicCount(value) {
  const normalized = normalizeArabic(value);
  const counts = {
    "واحد": 1, "واحده": 1, "رساله": 1,
    "رسالتين": 2, "رسالتان": 2, "اثنين": 2, "اثنتين": 2,
    "ثلاث": 3, "ثلاثه": 3, "اربع": 4, "اربعه": 4,
    "خمس": 5, "خمسه": 5, "ست": 6, "سته": 6,
  };
  return Number(normalized) || counts[normalized] || 0;
}

/** ينفذ الوعد المؤجل مرة واحدة عند وصول عدد رسائل المستخدم المطلوب. */
function dueCommitment(messages) {
  for (let index = messages.length - 1; index >= 0; index -= 1) {
    const item = messages[index];
    if (item.role !== "user") continue;
    const match = item.content.match(/بعد\s+(رسالتين|رسالتان|اثنتين|اثنين|ثلاث(?:ه|ة)?|اربع(?:ه|ة)?|أربع(?:ه|ة)?|خمس(?:ه|ة)?|ست(?:ه|ة)?|\d+)\s*(?:رسائل|رساله|رسالة)?/i);
    if (!match) continue;
    const required = arabicCount(match[1]);
    const laterUserMessages = messages.slice(index + 1).filter((message) => message.role === "user").length;
    if (required > 0 && laterUserMessages === required) {
      return `التزام مؤجل مستحق الآن. طلب المستخدم سابقًا: «${item.content}». نفّذ المطلوب الآن مباشرة قبل الرد على أي موضوع آخر. لا تقل إنك ستفعله لاحقًا.`;
    }
  }
  return "";
}

async function searchWeb(query, apiKey) {
  if (!apiKey) throw Object.assign(new Error("web_search_not_configured"), { status: 503 });
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 22_000);
  try {
    const response = await fetch("https://api.firecrawl.dev/v2/search", {
      method: "POST",
      headers: {
        "content-type": "application/json",
        "authorization": `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        query,
        limit: 5,
        sources: ["web"],
        scrapeOptions: {
          formats: ["markdown"],
          onlyMainContent: true,
        },
      }),
      signal: controller.signal,
    });
    if (!response.ok) throw new Error(`web_search_${response.status}`);
    const body = await response.json();
    const raw = Array.isArray(body?.data?.web)
      ? body.data.web
      : Array.isArray(body?.data)
        ? body.data
        : [];
    return raw.slice(0, 5).map((item, index) => ({
      index: index + 1,
      title: String(item?.title || item?.metadata?.title || item?.url || `مصدر ${index + 1}`).slice(0, 240),
      url: String(item?.url || item?.metadata?.sourceURL || "").slice(0, 1200),
      snippet: String(item?.description || item?.markdown || item?.content || "").replace(/\s+/g, " ").trim().slice(0, 2800),
    })).filter((item) => item.url);
  } finally {
    clearTimeout(timeout);
  }
}

function researchContext(sources) {
  if (!sources.length) return "";
  return sources.map((source) =>
    `[${source.index}] ${source.title}\nURL: ${source.url}\nالمحتوى: ${source.snippet}`
  ).join("\n\n");
}

function buildModelMessages(messages, mode, sources, searchUnavailable = false) {
  const commitment = dueCommitment(messages);
  const system = [
    AION_SYSTEM_PROMPT.trim(),
    modeInstruction(mode, sources.length > 0),
    commitment,
    searchUnavailable
      ? "تعذر الوصول إلى البحث الحي في هذه اللحظة. لا تقل إنك بحثت أو تملك أحدث المعلومات. إذا كان السؤال يمكن الإجابة عنه معرفةً عامة فأجب بوضوح مع التنبيه أن الجواب غير مُتحقق حيًا؛ وإذا كان يتطلب معلومة لحظية فاشرح الحد بدقة."
      : "",
    sources.length
      ? `\nمصادر البحث الحية:\n${researchContext(sources)}\n\nاستخدم أرقام المصادر بين أقواس مربعة في مواضع الادعاءات المدعومة.`
      : "",
  ].filter(Boolean).join("\n\n");
  return [{ role: "system", content: system }, ...messages.filter((m) => m.role !== "system")];
}

function modelOptions(mode, stream, model) {
  const max = mode === "fast" ? 700 : mode === "deep" ? 2400 : mode === "research" ? 2200 : mode === "code" ? 2200 : 1400;
  const options = {
    stream,
    max_completion_tokens: max,
    temperature: mode === "research" ? 0.3 : mode === "deep" ? 0.4 : 0.6,
  };
  // Gemma قد يستهلك كامل الحد في التفكير الداخلي من دون نص نهائي؛ نعطله في مسار الإنقاذ.
  if (model === FALLBACK_MODEL) options.chat_template_kwargs = { enable_thinking: false };
  return options;
}

function extractText(result) {
  if (typeof result?.response === "string") return result.response.trim();
  if (typeof result?.choices?.[0]?.message?.content === "string") return result.choices[0].message.content.trim();
  if (typeof result?.result?.response === "string") return result.result.response.trim();
  return "";
}

function extractDelta(payload, emitted) {
  const candidate =
    typeof payload?.response === "string" ? payload.response :
    typeof payload?.choices?.[0]?.delta?.content === "string" ? payload.choices[0].delta.content :
    typeof payload?.delta?.content === "string" ? payload.delta.content :
    typeof payload?.text === "string" ? payload.text : "";
  if (!candidate) return "";
  if (candidate.startsWith(emitted)) return candidate.slice(emitted.length);
  return candidate;
}

async function runSync(env, model, messages, mode) {
  return env.AI.run(model, { messages, ...modelOptions(mode, false, model) });
}

async function runSyncWithFallback(env, messages, mode) {
  try {
    const result = await runSync(env, PRIMARY_MODEL, messages, mode);
    const text = extractText(result);
    if (!text) throw new Error("primary_empty_text");
    return { result, text, model: PRIMARY_MODEL };
  } catch (primaryError) {
    console.warn("aion-primary-failed", primaryError);
    const result = await runSync(env, FALLBACK_MODEL, messages, mode);
    const text = extractText(result);
    if (!text) throw Object.assign(new Error("كلا النموذجين أنهيا الطلب من دون جواب نصي."), { status: 502 });
    return { result, text, model: FALLBACK_MODEL };
  }
}

function chunkText(text, size = 64) {
  const chunks = [];
  let rest = String(text || "");
  while (rest.length) {
    if (rest.length <= size) { chunks.push(rest); break; }
    let cut = rest.lastIndexOf(" ", size);
    if (cut < Math.floor(size * 0.55)) cut = size;
    chunks.push(rest.slice(0, cut));
    rest = rest.slice(cut);
  }
  return chunks.filter(Boolean);
}

function event(name, value) {
  return `event: ${name}\ndata: ${JSON.stringify(value)}\n\n`;
}

async function prepare(request) {
  const length = Number(request.headers.get("content-length") || "0");
  if (length > MAX_BODY_BYTES) throw Object.assign(new Error("الطلب كبير جدًا."), { status: 413 });
  const payload = await request.json();
  const messages = cleanMessages(payload.messages);
  const mode = chooseMode(payload, messages);
  const useSearch = shouldSearch(payload, messages, mode);
  return { payload, messages, mode, requestedMode: requestedMode(payload), useSearch };
}

async function syncChat(request, env) {
  const { messages, mode, useSearch } = await prepare(request);
  let sources = [];
  let searchUnavailable = false;
  if (useSearch) {
    const query = [...messages].reverse().find((m) => m.role === "user")?.content || "";
    try {
      sources = await searchWeb(query, env.FIRECRAWL_API_KEY);
    } catch (error) {
      console.error("aion-search", error);
      searchUnavailable = true;
    }
    if (!sources.length) {
      searchUnavailable = true;
    }
  }

  const modelMessages = buildModelMessages(messages, mode, sources, searchUnavailable);
  const { text: response, model } = await runSyncWithFallback(env, modelMessages, mode);
  return json({ response, model, mode, usedWebSearch: sources.length > 0, searchUnavailable, sources });
}

async function streamChat(request, env) {
  const prepared = await prepare(request);
  const encoder = new TextEncoder();

  const stream = new ReadableStream({
    async start(controller) {
      let sources = [];
      let searchUnavailable = false;
      const send = (name, value) => controller.enqueue(encoder.encode(event(name, value)));
      try {
        if (prepared.useSearch) {
          send("activity", { activity: "searching_web" });
          const query = [...prepared.messages].reverse().find((m) => m.role === "user")?.content || "";
          try {
            sources = await searchWeb(query, env.FIRECRAWL_API_KEY);
            if (!sources.length) searchUnavailable = true;
            else send("sources", { sources });
          } catch (error) {
            console.error("aion-search", error);
            searchUnavailable = true;
          }
          if (searchUnavailable) send("notice", { message: "البحث الحي غير متاح الآن؛ سيجيب AION من المعرفة العامة من دون ادعاء البحث." });
        } else {
          send("activity", { activity: "thinking" });
        }

        const modelMessages = buildModelMessages(prepared.messages, prepared.mode, sources, searchUnavailable);
        const { text, model } = await runSyncWithFallback(env, modelMessages, prepared.mode);
        if (!text.trim()) throw Object.assign(new Error("النموذج لم يُرجع نصًا."), { status: 502 });

        send("activity", { activity: "writing" });
        for (const piece of chunkText(text)) {
          send("delta", { text: piece });
          await new Promise((resolve) => setTimeout(resolve, 6));
        }
        send("done", {
          model,
          mode: prepared.mode,
          requestedMode: prepared.requestedMode,
          usedWebSearch: sources.length > 0,
          searchUnavailable,
          characters: text.length,
        });
      } catch (error) {
        console.error("aion-stream", error);
        const message = String(error?.message || "تعذر تنفيذ الطلب.");
        send("error", {
          status: Number(error?.status || 500),
          error: message === "web_search_not_configured"
            ? "البحث الحي يحتاج مفتاح Firecrawl المجاني على الخادم. المحادثة العادية ما زالت تعمل."
            : message.startsWith("web_search_")
              ? "تعذر تنفيذ البحث الحي الآن."
              : message,
        });
      } finally {
        controller.close();
      }
    },
  });

  return new Response(stream, {
    headers: headers({
      "content-type": "text/event-stream; charset=utf-8",
      "connection": "keep-alive",
      "x-accel-buffering": "no",
    }),
  });
}

export default {
  async fetch(request, env) {
    if (request.method === "OPTIONS") return new Response(null, { status: 204, headers: headers() });
    const url = new URL(request.url);

    if (request.method === "GET" && (url.pathname === "/" || url.pathname === "/health")) {
      return json({
        ok: true,
        service: "AION α6.2 Living Core",
        primaryModel: PRIMARY_MODEL,
        fallbackModel: FALLBACK_MODEL,
        capabilities: ["chat", "streaming", "web-research", "sources", "modes", "fallback", "deferred-commitments"],
      });
    }

    if (request.method === "GET" && url.pathname === "/v1/status") {
      return json({ ok: true, version: "6.2", research: env.FIRECRAWL_API_KEY ? "firecrawl" : "not-configured", modes: ["auto", "fast", "deep", "research", "direct", "creative", "code"] });
    }

    if (request.method !== "POST") return json({ error: "المسار غير موجود." }, 404);
    if (!allowRequest(request)) return json({ error: "تم بلوغ حد الحماية المؤقت. حاول بعد بضع دقائق." }, 429);

    try {
      if (url.pathname === "/v1/chat/stream") return await streamChat(request, env);
      if (url.pathname === "/v1/chat") return await syncChat(request, env);
      return json({ error: "المسار غير موجود." }, 404);
    } catch (error) {
      console.error("aion-core", error);
      return json({ error: error?.message || "تعذر تنفيذ طلب AION." }, Number(error?.status || 500));
    }
  },
};
