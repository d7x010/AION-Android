const FAST_MODEL = "@cf/zai-org/glm-4.7-flash";
const DEEP_MODEL = "@cf/openai/gpt-oss-120b";
const RESEARCH_MODEL = "@cf/google/gemma-4-26b-a4b-it";
const MAX_INPUT_MESSAGES = 200;
const MAX_CONTEXT_MESSAGES = 96;
const MAX_CONTEXT_CHARS = 180_000;
const MAX_MESSAGE_CHARS = 16_000;
const MAX_BODY_BYTES = 8_000_000;
const MAX_ATTACHMENTS_PER_MESSAGE = 4;
const MAX_ATTACHMENT_BYTES = 5_000_000;
const MAX_ATTACHMENT_TEXT_CHARS = 24_000;
const MAX_ATTACHMENT_CONTEXT_CHARS = 64_000;
const MAX_REQUESTS_PER_WINDOW = 180;
const WINDOW_MS = 10 * 60 * 1000;
const buckets = new Map();

const TEXT_EXTENSIONS = new Set([
  "txt", "md", "json", "xml", "html", "htm", "csv", "kt", "kts", "java", "py",
  "js", "ts", "tsx", "jsx", "css", "c", "cpp", "h", "hpp", "cs", "go", "rs",
  "swift", "rb", "php", "sql", "yaml", "yml", "toml", "ini", "log"
]);

const AION_SYSTEM_PROMPT = `
أنت AION، رفيق ذكاء شخصي حي ودقيق داخل تطبيق AION.
أجب بالعربية افتراضيًا، وافهم العربية الفصحى واللهجات العربية ومنها العراقية، وانتقل إلى لغة أخرى عندما يطلب المستخدم ذلك.

قواعد الحوار:
- لا تكرر سؤال المستخدم ولا تبدأ بمقدمات فارغة أو مديح تلقائي.
- اجعل طول الجواب متكيفًا مع النية: القصير للطلب البسيط، والتفصيل عندما يحتاج الموضوع فعلًا. لا ترسل إجابة مبتورة أو نصف جملة.
- تعامل مع الرسائل كسياق متصل، واعتمد تصحيح المستخدم فورًا بدل إعادة الحوار من الصفر.
- ميّز الحقيقة عن الرأي والافتراض وعدم اليقين عندما يكون الفرق مهمًا.
- لا تدّعِ أنك بحثت في الويب إلا إذا فعّل الخادم بحثًا حيًا فعليًا أو زوّدك بمصادر بحث فعلية.
- إذا زوّدك النظام بمصادر حية، اربط الادعاءات المهمة بها باستخدام [1] و[2]... ولا تخترع مصادر أو روابط.
- إذا زوّدك النظام بمحتوى ملفات أو صور مرفقة، استخدمه مباشرة واذكر حدود القراءة بوضوح إن كان التحويل ناقصًا.
- لا تكشف سلسلة التفكير الداخلية. أعطِ الخلاصة والأسباب المفيدة فقط.
- إذا كان المستخدم مخطئًا في حقيقة قابلة للتحقق، صححها باختصار ووضوح.
- لا تختم كل رد بسؤال آلي أو عرض عام للمساعدة.
- عندما يكون الطلب برمجيًا، أعطِ نتيجة قابلة للتنفيذ وحافظ على الاتساق مع القرارات السابقة في الحوار.
`;

function headers(extra = {}) {
  return {
    "cache-control": "no-store",
    "access-control-allow-origin": "*",
    "access-control-allow-methods": "GET, POST, OPTIONS",
    "access-control-allow-headers": "content-type, x-aion-client",
    ...extra,
  };
}

function json(value, status = 200) {
  return new Response(JSON.stringify(value), {
    status,
    headers: headers({ "content-type": "application/json; charset=utf-8" }),
  });
}

function pruneBuckets(now) {
  if (buckets.size < 512) return;
  for (const [key, value] of buckets) {
    if (now - value.startedAt >= WINDOW_MS) buckets.delete(key);
  }
}

function allowRequest(request) {
  const ip = request.headers.get("CF-Connecting-IP") || "unknown";
  const now = Date.now();
  pruneBuckets(now);
  const bucket = buckets.get(ip);
  if (!bucket || now - bucket.startedAt >= WINDOW_MS) {
    buckets.set(ip, { startedAt: now, count: 1 });
    return true;
  }
  if (bucket.count >= MAX_REQUESTS_PER_WINDOW) return false;
  bucket.count += 1;
  return true;
}

function safeName(value) {
  return String(value || "مرفق").replace(/[\r\n\0]/g, " ").trim().slice(0, 180) || "مرفق";
}

function cleanAttachments(input) {
  if (!Array.isArray(input)) return [];
  return input.slice(0, MAX_ATTACHMENTS_PER_MESSAGE).map((attachment) => {
    const name = safeName(attachment?.name);
    const mimeType = String(attachment?.mimeType || "application/octet-stream").toLowerCase().slice(0, 160);
    const kind = attachment?.kind === "IMAGE" || attachment?.kind === "image" ? "image" : "file";
    const data = typeof attachment?.data === "string"
      ? attachment.data
      : typeof attachment?.base64Data === "string"
        ? attachment.base64Data
        : "";
    const sizeBytes = Math.max(0, Number(attachment?.sizeBytes || 0));
    if (!data) throw new Error(`المرفق ${name} لا يحتوي بيانات قابلة للقراءة.`);
    if (sizeBytes > MAX_ATTACHMENT_BYTES) {
      throw Object.assign(new Error(`المرفق ${name} أكبر من الحد المسموح.`), { status: 413 });
    }
    // Base64 يضيف قرابة الثلث للحجم. هذا الفحص يمنع حمولات مصطنعة كبيرة حتى عند غياب sizeBytes.
    if (data.length > Math.ceil(MAX_ATTACHMENT_BYTES * 1.4)) {
      throw Object.assign(new Error(`المرفق ${name} أكبر من الحد المسموح.`), { status: 413 });
    }
    return { name, mimeType, kind, data, sizeBytes };
  });
}

function cleanOptionalText(value, maxChars) {
  if (typeof value !== "string") return "";
  return value.replace(/\u0000/g, "").trim().slice(0, maxChars);
}

function cleanMessages(input) {
  if (!Array.isArray(input) || input.length === 0) throw new Error("messages مطلوبة.");
  if (input.length > MAX_INPUT_MESSAGES) throw new Error("عدد الرسائل أكبر من الحد المسموح.");
  return input.map((message) => {
    const role = message?.role === "assistant" ? "assistant" : message?.role === "system" ? "system" : "user";
    const content = typeof message?.content === "string" ? message.content.trim() : "";
    const attachments = role === "user" ? cleanAttachments(message?.attachments) : [];
    if (!content && attachments.length === 0) throw new Error("كل رسالة تحتاج نصًا أو مرفقًا.");
    if (content.length > MAX_MESSAGE_CHARS) throw new Error("إحدى الرسائل طويلة جدًا.");
    return { role, content, attachments };
  });
}

function trimConversationContext(messages) {
  const selected = [];
  let chars = 0;
  for (let i = messages.length - 1; i >= 0 && selected.length < MAX_CONTEXT_MESSAGES; i -= 1) {
    const message = messages[i];
    const cost = message.content.length + 24;
    if (selected.length > 0 && chars + cost > MAX_CONTEXT_CHARS) break;
    selected.push(message);
    chars += cost;
  }
  return selected.reverse();
}

function normalizeArabic(text) {
  return String(text || "")
    .toLowerCase()
    .replace(/[إأآ]/g, "ا")
    .replace(/ى/g, "ي")
    .replace(/ة/g, "ه");
}

function requestedMode(payload) {
  const value = String(payload?.mode || payload?.model || "auto").toLowerCase();
  return ["auto", "fast", "deep", "research"].includes(value) ? value : "auto";
}

function chooseMode(payload, messages) {
  const requested = requestedMode(payload);
  if (requested !== "auto") return requested;

  const last = [...messages].reverse().find((m) => m.role === "user")?.content || "";
  const text = normalizeArabic(last);
  const deepSignals = [
    "عميق", "تحليل نفسي", "فلسفي", "حلل", "حلّل", "بالتفصيل", "من كل الجوانب",
    "اختبر الافتراضات", "قارن بعمق", "اشرح الاسباب", "لماذا الانسان"
  ];
  if (deepSignals.some((phrase) => text.includes(normalizeArabic(phrase)))) return "deep";

  const fastSignals = ["بجمله", "بجملتين", "باختصار", "بكلمه", "جواب سريع", "اختصر"];
  if (fastSignals.some((phrase) => text.includes(normalizeArabic(phrase)))) return "fast";
  return "auto";
}

function shouldSearch(payload, messages, mode) {
  if (mode === "research" || payload?.forceWebSearch === true) return true;
  const last = [...messages].reverse().find((m) => m.role === "user")?.content || "";
  const text = normalizeArabic(last);
  const explicit = [
    "ابحث", "بحث في الويب", "فتش في الويب", "دور بالويب", "دور في الويب", "من الانترنت",
    "على الانترنت", "مصادر حديثه", "تحقق من الويب"
  ];
  if (explicit.some((phrase) => text.includes(normalizeArabic(phrase)))) return true;

  const freshness = [
    "اخر الاخبار", "احدث الاخبار", "اخر تحديث", "سعر اليوم", "الطقس", "موعد اليوم",
    "نتيجه المباراه", "نتائج اليوم", "من فاز", "احدث اصدار", "احدث نسخه", "متوفر حاليا"
  ];
  return freshness.some((phrase) => text.includes(normalizeArabic(phrase)));
}

function modeInstruction(mode, researched) {
  const base = {
    fast: "وضع سريع: أعطِ أقل جواب كافٍ ومباشر، وتجنب التفصيل غير الضروري.",
    deep: "وضع عميق: حلل المسألة بصرامة، اختبر الافتراضات، واشرح النتيجة بعمق منظم من دون حشو.",
    research: "وضع بحث: ابنِ الجواب على الأدلة الحية، قارن المصادر عند الاختلاف، واذكر حدود ما يمكن التحقق منه.",
    auto: "وضع تلقائي: اختر بنفسك مقدار العمق والطول المناسبين للطلب.",
  }[mode] || "";
  return researched ? `${base}\nلديك مصادر ويب حية أدناه. لا تنسب إليها ما لا تقوله.` : base;
}

async function searchWeb(query, apiKey) {
  if (!apiKey) throw Object.assign(new Error("web_search_not_configured"), { status: 503 });
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 22_000);
  try {
    const response = await fetch("https://api.firecrawl.dev/v2/search", {
      method: "POST",
      headers: {
        "content-type": "application/json",
        "authorization": `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        query,
        limit: 5,
        sources: ["web"],
        scrapeOptions: {
          formats: ["markdown"],
          onlyMainContent: true,
        },
      }),
      signal: controller.signal,
    });
    if (!response.ok) throw new Error(`web_search_${response.status}`);
    const body = await response.json();
    const raw = Array.isArray(body?.data?.web)
      ? body.data.web
      : Array.isArray(body?.data)
        ? body.data
        : [];
    return raw.slice(0, 5).map((item, index) => ({
      index: index + 1,
      title: String(item?.title || item?.metadata?.title || item?.url || `مصدر ${index + 1}`).slice(0, 240),
      url: String(item?.url || item?.metadata?.sourceURL || "").slice(0, 1200),
      snippet: String(item?.description || item?.markdown || item?.content || "").replace(/\s+/g, " ").trim().slice(0, 2800),
    })).filter((item) => item.url);
  } finally {
    clearTimeout(timeout);
  }
}

function researchContext(sources) {
  if (!sources.length) return "";
  return sources.map((source) =>
    `[${source.index}] ${source.title}\nURL: ${source.url}\nالمحتوى: ${source.snippet}`
  ).join("\n\n");
}

function extensionOf(name) {
  const match = String(name || "").toLowerCase().match(/\.([a-z0-9]+)$/);
  return match ? match[1] : "";
}

function base64ToBytes(data) {
  const normalized = String(data || "").replace(/^data:[^;]+;base64,/, "").replace(/\s/g, "");
  const binary = atob(normalized);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i += 1) bytes[i] = binary.charCodeAt(i);
  return bytes;
}

function isTextAttachment(attachment) {
  return attachment.mimeType.startsWith("text/") || TEXT_EXTENSIONS.has(extensionOf(attachment.name));
}

function decodeTextAttachment(attachment) {
  const bytes = base64ToBytes(attachment.data);
  return new TextDecoder("utf-8", { fatal: false }).decode(bytes).replace(/\u0000/g, "").trim();
}

async function convertAttachment(env, attachment) {
  if (isTextAttachment(attachment) && !attachment.mimeType.startsWith("image/")) {
    return decodeTextAttachment(attachment).slice(0, MAX_ATTACHMENT_TEXT_CHARS);
  }

  const bytes = base64ToBytes(attachment.data);
  const result = await env.AI.toMarkdown({
    name: attachment.name,
    blob: new Blob([bytes], { type: attachment.mimeType || "application/octet-stream" }),
  }, {
    conversionOptions: {
      output: { format: "markdown" },
      pdf: { metadata: false },
    },
  });

  const item = Array.isArray(result) ? result[0] : result;
  if (!item) throw new Error("لم يرجع محول الملفات نتيجة.");
  if (item.error || item.format === "error") throw new Error(String(item.error || "تعذر تحويل الملف."));
  const text = String(item.data || "").trim();
  if (!text) throw new Error("تمت قراءة الملف لكن لم يُستخرج منه محتوى نصي قابل للاستخدام.");
  return text.slice(0, MAX_ATTACHMENT_TEXT_CHARS);
}

function normalizedBase64(data) {
  return String(data || "").replace(/^data:[^;]+;base64,/, "").replace(/\s/g, "");
}

function messageNeedsVision(message) {
  return Array.isArray(message?.attachments) && message.attachments.some((attachment) =>
    attachment?.kind === "image" || String(attachment?.mimeType || "").startsWith("image/")
  );
}

function conversationNeedsVision(messages) {
  return messages.some(messageNeedsVision);
}

async function hydrateAttachments(env, messages, onActivity = null) {
  let totalChars = 0;
  const hydrated = [];
  let announced = false;

  for (const message of messages) {
    if (!message.attachments?.length) {
      hydrated.push({ role: message.role, content: message.content });
      continue;
    }

    if (!announced && onActivity) {
      announced = true;
      onActivity("reading_files");
    }

    const blocks = [];
    const imageParts = [];

    for (const attachment of message.attachments) {
      const isImage = attachment.kind === "image" || attachment.mimeType.startsWith("image/");
      if (isImage) {
        const base64 = normalizedBase64(attachment.data);
        if (!base64) {
          blocks.push(`### الصورة: ${attachment.name}\nتعذر قراءة بيانات الصورة.`);
          continue;
        }
        imageParts.push({
          type: "image_url",
          image_url: { url: `data:${attachment.mimeType || "image/jpeg"};base64,${base64}` },
        });
        continue;
      }

      if (totalChars >= MAX_ATTACHMENT_CONTEXT_CHARS) break;
      try {
        const converted = await convertAttachment(env, attachment);
        const remaining = MAX_ATTACHMENT_CONTEXT_CHARS - totalChars;
        const body = converted.slice(0, remaining);
        totalChars += body.length;
        blocks.push(`### المرفق: ${attachment.name}\nنوعه: ${attachment.mimeType}\n\n${body}`);
      } catch (error) {
        console.warn("aion-attachment-conversion", attachment.name, error);
        blocks.push(`### المرفق: ${attachment.name}\nتعذر استخراج محتواه: ${String(error?.message || "خطأ غير معروف")}`);
      }
    }

    const userText = message.content || "حلّل المرفقات المرفقة واستجب وفق محتواها والسياق.";
    const textContent = blocks.length
      ? `${userText}\n\n---\nمحتوى المرفقات المقروء آليًا:\n${blocks.join("\n\n")}`.trim()
      : userText;

    if (imageParts.length) {
      hydrated.push({
        role: message.role,
        content: [{ type: "text", text: textContent }, ...imageParts],
      });
    } else {
      hydrated.push({ role: message.role, content: textContent });
    }
  }

  return hydrated;
}

function buildModelMessages(messages, mode, sources, customInstructions = "", memoryContext = "") {
  const system = [
    AION_SYSTEM_PROMPT.trim(),
    modeInstruction(mode, sources.length > 0),
    customInstructions
      ? `تعليمات المستخدم الثابتة:\n${customInstructions}\nطبّقها ما لم تتعارض مع الأمان أو مع طلب أحدث وصريح من المستخدم.`
      : "",
    memoryContext
      ? `ذاكرة محلية اختار المستخدم الاحتفاظ بها:\n${memoryContext}\nاستخدمها فقط عندما تكون ذات صلة، ولا تكررها بلا حاجة.`
      : "",
    sources.length
      ? `\nمصادر البحث الحية:\n${researchContext(sources)}\n\nاستخدم أرقام المصادر بين أقواس مربعة في مواضع الادعاءات المدعومة.`
      : "",
  ].filter(Boolean).join("\n\n");
  return [{ role: "system", content: system }, ...messages.filter((m) => m.role !== "system")];
}

function modelOrder(mode, visionRequired = false, nativeWebSearch = false) {
  // الصور تحتاج نموذجًا يدعم Vision، والبحث المدمج يُنفذ عبر النموذج الأقوى في هذا المسار.
  if (visionRequired || nativeWebSearch) return [RESEARCH_MODEL];
  if (mode === "deep") return [DEEP_MODEL, FAST_MODEL, RESEARCH_MODEL];
  if (mode === "research") return [RESEARCH_MODEL, FAST_MODEL, DEEP_MODEL];
  return [FAST_MODEL, RESEARCH_MODEL];
}

function modelOptions(mode, stream, model, nativeWebSearch = false) {
  const max = mode === "fast" ? 1000 : mode === "deep" ? 6000 : mode === "research" ? 5000 : 3000;
  const options = {
    stream,
    temperature: mode === "research" ? 0.25 : mode === "deep" ? 0.35 : 0.6,
  };

  // gpt-oss uses the classic max_tokens schema while GLM/Gemma expose the
  // chat-completions style max_completion_tokens field on Workers AI.
  if (model === DEEP_MODEL) options.max_tokens = max;
  else options.max_completion_tokens = max;

  if (model === FAST_MODEL) {
    options.reasoning_effort = mode === "fast" ? "low" : mode === "deep" ? "high" : "medium";
  }
  if (model === RESEARCH_MODEL) {
    options.chat_template_kwargs = { enable_thinking: mode === "research" || mode === "deep" };
    if (nativeWebSearch) options.web_search_options = {};
  }
  return options;
}

function extractText(result) {
  if (typeof result?.response === "string") return result.response.trim();
  if (typeof result?.choices?.[0]?.message?.content === "string") return result.choices[0].message.content.trim();
  if (typeof result?.result?.response === "string") return result.result.response.trim();
  return "";
}

function extractDelta(payload, emitted) {
  const candidate =
    typeof payload?.response === "string" ? payload.response :
    typeof payload?.choices?.[0]?.delta?.content === "string" ? payload.choices[0].delta.content :
    typeof payload?.delta?.content === "string" ? payload.delta.content :
    typeof payload?.delta === "string" ? payload.delta :
    typeof payload?.text === "string" ? payload.text : "";
  if (!candidate) return "";
  if (candidate.startsWith(emitted)) return candidate.slice(emitted.length);
  return candidate;
}

async function runSync(env, model, messages, mode, nativeWebSearch = false) {
  return env.AI.run(model, { messages, ...modelOptions(mode, false, model, nativeWebSearch) });
}

async function runSyncWithFallback(env, messages, mode, { visionRequired = false, nativeWebSearch = false } = {}) {
  let lastError = null;
  for (const model of modelOrder(mode, visionRequired, nativeWebSearch)) {
    try {
      const result = await runSync(env, model, messages, mode, nativeWebSearch);
      const text = extractText(result);
      if (!text) throw new Error(`${model}_empty_text`);
      return { result, text, model };
    } catch (error) {
      lastError = error;
      console.warn("aion-model-failed", model, error);
    }
  }
  throw Object.assign(new Error(lastError?.message || "كل النماذج أنهت الطلب من دون جواب نصي."), { status: 502 });
}

function event(name, value) {
  return `event: ${name}\ndata: ${JSON.stringify(value)}\n\n`;
}

async function consumeAiStream(aiResult, onDelta) {
  const stream = aiResult instanceof Response ? aiResult.body : aiResult;
  if (!stream || typeof stream.getReader !== "function") {
    const text = extractText(aiResult);
    if (!text) throw new Error("model_stream_unavailable");
    await onDelta(text);
    return text;
  }

  const reader = stream.getReader();
  const decoder = new TextDecoder();
  let buffer = "";
  let emitted = "";

  async function consumeBlock(block) {
    for (const rawLine of block.split("\n")) {
      const line = rawLine.trim();
      if (!line.startsWith("data:")) continue;
      const data = line.slice(5).trim();
      if (!data || data === "[DONE]") continue;
      const payload = JSON.parse(data);
      const delta = extractDelta(payload, emitted);
      if (delta) {
        emitted += delta;
        await onDelta(delta);
      }
    }
  }

  while (true) {
    const { value, done } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true }).replace(/\r\n/g, "\n");
    let boundary;
    while ((boundary = buffer.indexOf("\n\n")) >= 0) {
      const block = buffer.slice(0, boundary);
      buffer = buffer.slice(boundary + 2);
      await consumeBlock(block);
    }
  }
  buffer += decoder.decode();
  if (buffer.trim()) await consumeBlock(buffer);
  return emitted;
}

async function runStreamingWithFallback(env, messages, mode, onDelta, { visionRequired = false, nativeWebSearch = false } = {}) {
  let lastError = null;
  for (const model of modelOrder(mode, visionRequired, nativeWebSearch)) {
    let emitted = "";
    try {
      const result = await env.AI.run(model, { messages, ...modelOptions(mode, true, model, nativeWebSearch) });
      await consumeAiStream(result, async (delta) => {
        emitted += delta;
        await onDelta(delta);
      });
      if (!emitted.trim()) throw new Error(`${model}_empty_stream`);
      return { text: emitted, model };
    } catch (error) {
      lastError = error;
      console.warn("aion-model-stream-failed", model, error);
      // بعد وصول أول جزء للمستخدم لا نبدأ نموذجًا آخر من الصفر، لأن ذلك يكرر الرد.
      if (emitted.trim()) throw error;
    }
  }
  throw Object.assign(new Error(lastError?.message || "كل النماذج أنهت الطلب من دون جواب نصي."), { status: 502 });
}

async function prepare(request) {
  const length = Number(request.headers.get("content-length") || "0");
  if (length > MAX_BODY_BYTES) throw Object.assign(new Error("الطلب كبير جدًا."), { status: 413 });
  const rawText = await request.text();
  if (new TextEncoder().encode(rawText).byteLength > MAX_BODY_BYTES) {
    throw Object.assign(new Error("الطلب كبير جدًا."), { status: 413 });
  }
  const payload = JSON.parse(rawText || "{}");
  const cleanedMessages = cleanMessages(payload.messages);
  const messages = trimConversationContext(cleanedMessages);
  const mode = chooseMode(payload, messages);
  const useSearch = shouldSearch(payload, messages, mode);
  const customInstructions = cleanOptionalText(payload.customInstructions, 5_000);
  const memoryContext = cleanOptionalText(payload.memoryContext, 12_000);
  return {
    payload, messages, mode, requestedMode: requestedMode(payload), useSearch,
    customInstructions, memoryContext,
  };
}

async function syncChat(request, env) {
  const prepared = await prepare(request);
  let sources = [];
  let nativeWebSearch = false;

  if (prepared.useSearch) {
    const query = [...prepared.messages].reverse().find((m) => m.role === "user")?.content || "";
    if (env.FIRECRAWL_API_KEY) {
      try {
        sources = await searchWeb(query, env.FIRECRAWL_API_KEY);
      } catch (error) {
        console.warn("aion-firecrawl-failed", error);
        nativeWebSearch = true;
      }
    } else {
      nativeWebSearch = true;
    }
    if (!nativeWebSearch && !sources.length) nativeWebSearch = true;
  }

  const visionRequired = conversationNeedsVision(prepared.messages);
  const hydratedMessages = await hydrateAttachments(env, prepared.messages);
  const modelMessages = buildModelMessages(
    hydratedMessages,
    prepared.mode,
    sources,
    prepared.customInstructions,
    prepared.memoryContext
  );
  if (nativeWebSearch) {
    modelMessages[0].content += "\n\nتم تفعيل بحث الويب المدمج الحي في Workers AI لهذا الطلب. استخدمه فعليًا قبل الإجابة عن المعلومات الحديثة، ولا تدّعِ وجود مصادر لم تستلمها.";
  }

  const { text: response, model } = await runSyncWithFallback(env, modelMessages, prepared.mode, {
    visionRequired,
    nativeWebSearch,
  });
  return json({
    response,
    model,
    mode: prepared.mode,
    usedWebSearch: prepared.useSearch,
    webSearchProvider: prepared.useSearch ? (nativeWebSearch ? "workers-ai" : "firecrawl") : null,
    sources,
  });
}

async function streamChat(request, env) {
  const prepared = await prepare(request);
  const encoder = new TextEncoder();

  const stream = new ReadableStream({
    async start(controller) {
      let sources = [];
      let nativeWebSearch = false;
      let wroteText = false;
      const send = (name, value) => controller.enqueue(encoder.encode(event(name, value)));
      try {
        if (prepared.useSearch) {
          send("activity", { activity: "searching_web" });
          const query = [...prepared.messages].reverse().find((m) => m.role === "user")?.content || "";
          if (env.FIRECRAWL_API_KEY) {
            try {
              sources = await searchWeb(query, env.FIRECRAWL_API_KEY);
              if (sources.length) send("sources", { sources });
              else nativeWebSearch = true;
            } catch (error) {
              console.warn("aion-firecrawl-failed", error);
              nativeWebSearch = true;
            }
          } else {
            nativeWebSearch = true;
          }
        } else {
          send("activity", { activity: "thinking" });
        }

        const visionRequired = conversationNeedsVision(prepared.messages);
        const hydratedMessages = await hydrateAttachments(env, prepared.messages, (activity) => {
          send("activity", { activity });
        });
        const modelMessages = buildModelMessages(
          hydratedMessages,
          prepared.mode,
          sources,
          prepared.customInstructions,
          prepared.memoryContext
        );
        if (nativeWebSearch) {
          modelMessages[0].content += "\n\nتم تفعيل بحث الويب المدمج الحي في Workers AI لهذا الطلب. استخدمه فعليًا قبل الإجابة عن المعلومات الحديثة، ولا تدّعِ وجود مصادر لم تستلمها.";
        }

        send("activity", { activity: prepared.useSearch ? "searching_web" : "thinking" });
        const { text, model } = await runStreamingWithFallback(
          env,
          modelMessages,
          prepared.mode,
          async (delta) => {
            if (!wroteText) {
              wroteText = true;
              send("activity", { activity: "writing" });
            }
            send("delta", { text: delta });
          },
          { visionRequired, nativeWebSearch }
        );

        send("done", {
          model,
          mode: prepared.mode,
          requestedMode: prepared.requestedMode,
          usedWebSearch: prepared.useSearch,
          webSearchProvider: prepared.useSearch ? (nativeWebSearch ? "workers-ai" : "firecrawl") : null,
          usedVision: visionRequired,
          characters: text.length,
          trueStreaming: true,
        });
      } catch (error) {
        console.error("aion-stream", error);
        const message = String(error?.message || "تعذر تنفيذ الطلب.");
        send("error", {
          status: Number(error?.status || 500),
          error: message.startsWith("web_search_")
            ? "تعذر تنفيذ البحث الحي الآن."
            : message,
        });
      } finally {
        controller.close();
      }
    },
  });

  return new Response(stream, {
    headers: headers({
      "content-type": "text/event-stream; charset=utf-8",
      "connection": "keep-alive",
      "x-accel-buffering": "no",
    }),
  });
}

export default {
  async fetch(request, env) {
    if (request.method === "OPTIONS") return new Response(null, { status: 204, headers: headers() });
    const url = new URL(request.url);

    if (request.method === "GET" && (url.pathname === "/" || url.pathname === "/health")) {
      return json({
        ok: true,
        service: "AION α7 Living Core",
        fastModel: FAST_MODEL,
        deepModel: DEEP_MODEL,
        researchModel: RESEARCH_MODEL,
        capabilities: [
          "chat", "true-streaming", "web-research", "sources", "modes", "fallback",
          "attachments", "pdf", "documents", "native-vision", "native-web-search", "source-code"
        ],
      });
    }

    if (request.method === "GET" && url.pathname === "/v1/status") {
      return json({
        ok: true,
        version: "7.1.0",
        research: env.FIRECRAWL_API_KEY ? "firecrawl+workers-ai-fallback" : "workers-ai-native",
        modes: ["auto", "fast", "deep", "research"],
        routing: { fast: FAST_MODEL, deep: DEEP_MODEL, research: RESEARCH_MODEL },
        trueStreaming: true,
        attachments: "workers-ai-markdown-conversion",
      });
    }

    if (request.method !== "POST") return json({ error: "المسار غير موجود." }, 404);
    if (!allowRequest(request)) return json({ error: "تم بلوغ حد الحماية المؤقت. حاول بعد بضع دقائق." }, 429);

    try {
      if (url.pathname === "/v1/chat/stream") return await streamChat(request, env);
      if (url.pathname === "/v1/chat") return await syncChat(request, env);
      return json({ error: "المسار غير موجود." }, 404);
    } catch (error) {
      console.error("aion-core", error);
      if (error instanceof SyntaxError) return json({ error: "صيغة JSON في الطلب غير صالحة." }, 400);
      return json({ error: error?.message || "تعذر تنفيذ طلب AION." }, Number(error?.status || 500));
    }
  },
};
