package com.aion.mobile.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

val AionPurple = Color(0xFF8B5CF6)
val AionPurpleStrong = Color(0xFF7C3AED)
val AionPurpleSoft = Color(0xFFC2A9FF)
val AionBlueSoft = Color(0xFF7FA7E8)
val AionBlack = Color(0xFF0D0D10)
val AionSurface = Color(0xFF131317)
val AionSurfaceRaised = Color(0xFF1A191F)

private val AionDarkColors = darkColorScheme(
    primary = AionPurple,
    onPrimary = Color.White,
    primaryContainer = Color(0xFF2A184A),
    onPrimaryContainer = Color(0xFFE9DDFF),
    secondary = AionBlueSoft,
    onSecondary = Color(0xFF07101F),
    background = AionBlack,
    onBackground = Color(0xFFF4F2F6),
    surface = AionSurface,
    onSurface = Color(0xFFF4F2F6),
    surfaceVariant = AionSurfaceRaised,
    onSurfaceVariant = Color(0xFFB9B5BF),
    outline = Color(0xFF35323A),
    error = Color(0xFFFF6B7A),
    onError = Color(0xFF240308)
)

private val AionTypography = Typography(
    bodyLarge = TextStyle(
        fontSize = 15.sp,
        lineHeight = 24.sp,
        fontWeight = FontWeight.Normal
    ),
    bodyMedium = TextStyle(
        fontSize = 13.sp,
        lineHeight = 21.sp,
        fontWeight = FontWeight.Normal
    ),
    bodySmall = TextStyle(
        fontSize = 11.sp,
        lineHeight = 17.sp,
        fontWeight = FontWeight.Normal
    ),
    titleLarge = TextStyle(
        fontSize = 21.sp,
        lineHeight = 28.sp,
        fontWeight = FontWeight.Bold
    ),
    titleMedium = TextStyle(
        fontSize = 17.sp,
        lineHeight = 24.sp,
        fontWeight = FontWeight.SemiBold
    )
)

@Composable
fun AionTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = AionDarkColors,
        typography = AionTypography,
        content = content
    )
}
