package com.aion.mobile.core.run

import android.content.Context
import android.content.Intent
import com.aion.mobile.core.ai.GatewayActivity
import com.aion.mobile.model.ChatMessage
import com.aion.mobile.model.ChatSource
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

internal data class AionRunRequest(
    val runId: String,
    val placeholderId: Long,
    val modelId: String,
    val modelLabel: String,
    val conversationId: String,
    val messages: List<ChatMessage>,
    val sessionMessages: List<ChatMessage>,
    val forceWebSearch: Boolean
)

data class AionRunSnapshot(
    val runId: String,
    val placeholderId: Long,
    val modelId: String,
    val modelLabel: String,
    val text: String = "",
    val activity: GatewayActivity = GatewayActivity.THINKING,
    val isRunning: Boolean = true,
    val sources: List<ChatSource> = emptyList(),
    val errorText: String? = null,
    val wasStopped: Boolean = false
)

internal object AionRunRegistry {
    private val requests = ConcurrentHashMap<String, AionRunRequest>()

    fun register(request: AionRunRequest) {
        requests[request.runId] = request
    }

    fun get(runId: String): AionRunRequest? = requests[runId]

    fun remove(runId: String) {
        requests.remove(runId)
    }
}

object AionRunBus {
    private val _snapshot = MutableStateFlow<AionRunSnapshot?>(null)
    val snapshot: StateFlow<AionRunSnapshot?> = _snapshot.asStateFlow()

    fun publish(snapshot: AionRunSnapshot?) {
        _snapshot.value = snapshot
    }
}

object AionRunCoordinator {
    fun start(
        context: Context,
        placeholderId: Long,
        modelId: String,
        modelLabel: String,
        conversationId: String,
        messages: List<ChatMessage>,
        sessionMessages: List<ChatMessage>,
        forceWebSearch: Boolean
    ): String {
        val runId = UUID.randomUUID().toString()
        val request = AionRunRequest(
            runId = runId,
            placeholderId = placeholderId,
            modelId = modelId,
            modelLabel = modelLabel,
            conversationId = conversationId,
            messages = messages,
            sessionMessages = sessionMessages,
            forceWebSearch = forceWebSearch
        )
        AionRunRegistry.register(request)
        AionRunBus.publish(
            AionRunSnapshot(
                runId = runId,
                placeholderId = placeholderId,
                modelId = modelId,
                modelLabel = modelLabel
            )
        )

        val intent = Intent(context, AionRunService::class.java).apply {
            action = AionRunService.ACTION_START
            putExtra(AionRunService.EXTRA_RUN_ID, runId)
        }
        context.startForegroundService(intent)
        return runId
    }

    fun stop(context: Context, runId: String?) {
        if (runId.isNullOrBlank()) return
        context.startService(
            Intent(context, AionRunService::class.java).apply {
                action = AionRunService.ACTION_STOP
                putExtra(AionRunService.EXTRA_RUN_ID, runId)
            }
        )
    }
}
