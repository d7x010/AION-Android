package com.aion.mobile.feature.chat

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.aion.mobile.core.ai.AionCloudSettings
import com.aion.mobile.core.ai.GatewayActivity
import com.aion.mobile.core.memory.LocalMemoryStore
import com.aion.mobile.core.run.AionRunBus
import com.aion.mobile.core.run.AionRunCoordinator
import com.aion.mobile.core.run.AionRunSnapshot
import com.aion.mobile.core.storage.ChatSessionStore
import com.aion.mobile.core.storage.ConversationSummary
import com.aion.mobile.model.ChatAttachment
import com.aion.mobile.model.ChatMessage
import com.aion.mobile.model.MessageRole
import kotlinx.coroutines.launch

data class AiModelOption(
    val key: String,
    val label: String,
    val provider: String,
    val enabled: Boolean,
    val modelId: String? = null,
    val badge: String? = null
)

class ChatViewModel(application: Application) : AndroidViewModel(application) {
    private val _messages = mutableStateListOf<ChatMessage>()
    val messages: SnapshotStateList<ChatMessage> = _messages

    private val _pendingAttachments = mutableStateListOf<ChatAttachment>()
    val pendingAttachments: SnapshotStateList<ChatAttachment> = _pendingAttachments

    private val _conversations = mutableStateListOf<ConversationSummary>()
    val conversations: SnapshotStateList<ConversationSummary> = _conversations

    private var nextId = 1L
    private var activeRunId: String? = null

    var activeConversationId by mutableStateOf("")
        private set
    var cloudEndpoint by mutableStateOf(AionCloudSettings.loadEndpoint(application))
        private set
    var isSending by mutableStateOf(false)
        private set
    var selectedModelKey by mutableStateOf(ChatSessionStore.loadSelectedModel(application))
        private set
    var activity by mutableStateOf<GatewayActivity?>(null)
        private set
    var draft by mutableStateOf("")
        private set

    private val initialPersonalization = LocalMemoryStore.load(application)
    var customInstructions by mutableStateOf(initialPersonalization.instructions)
        private set
    var memoryNotes by mutableStateOf(initialPersonalization.memory)
        private set

    init {
        val activeSnapshot = AionRunBus.snapshot.value
        activeConversationId = activeSnapshot?.conversationId?.takeIf { it.isNotBlank() }
            ?: ChatSessionStore.ensureActiveConversation(application)
        loadConversation(activeConversationId, preserveDraft = true)
        refreshConversations()

        if (activeSnapshot != null && activeSnapshot.conversationId == activeConversationId) {
            applyRunSnapshot(activeSnapshot)
        } else {
            normalizeInterruptedStreamingMessages()
        }

        viewModelScope.launch {
            AionRunBus.snapshot.collect { snapshot ->
                snapshot?.let(::applyRunSnapshot)
            }
        }
    }

    val isConfigured: Boolean get() = cloudEndpoint.isNotBlank()

    val currentConversationTitle: String
        get() = _conversations.firstOrNull { it.id == activeConversationId }?.title ?: "محادثة جديدة"

    val modelOptions: List<AiModelOption>
        get() = listOf(
            AiModelOption(
                key = "auto",
                label = "AION Auto",
                provider = "يتكيف تلقائيًا مع طلبك",
                enabled = true,
                modelId = "auto",
                badge = "تلقائي"
            ),
            AiModelOption(
                key = "fast",
                label = "سريع",
                provider = "GLM — زمن استجابة أقل",
                enabled = true,
                modelId = "fast",
                badge = "خفيف"
            ),
            AiModelOption(
                key = "deep",
                label = "عميق",
                provider = "GPT-OSS 120B — استدلال أعمق",
                enabled = true,
                modelId = "deep",
                badge = "عميق"
            ),
            AiModelOption(
                key = "research",
                label = "بحث",
                provider = "ويب حي مع مصادر",
                enabled = true,
                modelId = "research",
                badge = "ويب"
            ),
            AiModelOption("claude", "Claude", "Anthropic", false, badge = "قريبًا"),
            AiModelOption("gemini", "Gemini", "Google", false, badge = "قريبًا"),
            AiModelOption("grok", "Grok", "xAI", false, badge = "قريبًا")
        )

    val selectedModel: AiModelOption
        get() = modelOptions.firstOrNull { it.key == selectedModelKey } ?: modelOptions.first()

    fun selectModel(key: String) {
        val option = modelOptions.firstOrNull { it.key == key } ?: return
        if (option.enabled && !isSending) {
            selectedModelKey = option.key
            ChatSessionStore.saveSelectedModel(getApplication(), option.key)
        }
    }

    fun updateDraft(value: String) {
        draft = value
        if (activeConversationId.isNotBlank()) {
            ChatSessionStore.saveDraft(getApplication(), activeConversationId, value)
        }
    }

    fun saveSettings(endpoint: String) {
        AionCloudSettings.saveEndpoint(getApplication(), endpoint)
        cloudEndpoint = AionCloudSettings.loadEndpoint(getApplication())
    }

    fun savePersonalization(instructions: String, memory: String) {
        LocalMemoryStore.save(getApplication(), instructions, memory)
        val snapshot = LocalMemoryStore.load(getApplication())
        customInstructions = snapshot.instructions
        memoryNotes = snapshot.memory
    }

    fun addAttachments(items: List<ChatAttachment>) {
        if (isSending) return
        items.forEach { attachment ->
            if (_pendingAttachments.none { it.id == attachment.id }) _pendingAttachments += attachment
        }
    }

    fun removeAttachment(id: Long) {
        if (!isSending) _pendingAttachments.removeAll { it.id == id }
    }

    fun clearAttachments() {
        if (!isSending) _pendingAttachments.clear()
    }

    fun send(text: String) {
        val clean = text.trim()
        val attachments = _pendingAttachments.toList()
        if ((clean.isEmpty() && attachments.isEmpty()) || isSending) return

        if (activeConversationId.isBlank()) {
            activeConversationId = ChatSessionStore.createConversation(getApplication())
        }

        val chosen = selectedModel
        val resolvedModel = chosen.modelId.orEmpty()
        _messages += ChatMessage(
            id = nextId++,
            role = MessageRole.USER,
            text = clean,
            modelId = resolvedModel,
            modelLabel = chosen.label,
            attachments = attachments
        )
        _pendingAttachments.clear()
        updateDraft("")
        persistMessages()

        if (!isConfigured) {
            _messages += ChatMessage(
                id = nextId++,
                role = MessageRole.AION,
                text = "اربط عنوان AION Cloud من الإعدادات أولًا، ثم أرسل الرسالة من جديد.",
                modelId = resolvedModel,
                modelLabel = chosen.label,
                isError = true
            )
            persistMessages()
            return
        }

        requestAssistantResponse(chosen = chosen, resolvedModel = resolvedModel)
    }

    fun stopGeneration() {
        AionRunCoordinator.stop(getApplication(), activeRunId)
    }

    fun retryLastResponse() {
        val lastAssistant = _messages.lastOrNull { it.role == MessageRole.AION } ?: return
        retryResponse(lastAssistant.id)
    }

    /** يعيد التوليد من الرد المحدد بدل إعادة آخر رد خطأً عند الضغط على رد أقدم. */
    fun retryResponse(messageId: Long) {
        if (isSending || !isConfigured || activeConversationId.isBlank()) return
        val assistantIndex = _messages.indexOfFirst { it.id == messageId && it.role == MessageRole.AION }
        if (assistantIndex < 0) return
        val userIndex = (assistantIndex - 1 downTo 0).firstOrNull { _messages[it].role == MessageRole.USER } ?: return

        val assistant = _messages[assistantIndex]
        val user = _messages[userIndex]
        while (_messages.size > assistantIndex) _messages.removeAt(_messages.lastIndex)

        val chosen = modelOptions.firstOrNull { it.label == assistant.modelLabel }
            ?: modelOptions.firstOrNull { it.modelId == assistant.modelId }
            ?: modelOptions.firstOrNull { it.label == user.modelLabel }
            ?: modelOptions.firstOrNull { it.modelId == user.modelId }
            ?: selectedModel
        val resolvedModel = assistant.modelId?.takeIf { it.isNotBlank() }
            ?: user.modelId?.takeIf { it.isNotBlank() }
            ?: chosen.modelId.orEmpty()

        persistMessages()
        requestAssistantResponse(chosen = chosen, resolvedModel = resolvedModel)
    }

    /**
     * يعدّل رسالة مستخدم سابقة ثم يعيد توليد المسار من تلك النقطة.
     * هذا سلوك branch-by-truncation متعمد في α7؛ حفظ عدة فروع مرئية يأتي لاحقًا.
     */
    fun editAndResend(messageId: Long, newText: String) {
        if (isSending || activeConversationId.isBlank()) return
        val index = _messages.indexOfFirst { it.id == messageId && it.role == MessageRole.USER }
        if (index < 0) return

        val original = _messages[index]
        val clean = newText.trim()
        if (clean.isBlank() && original.attachments.isEmpty()) return

        while (_messages.size > index + 1) _messages.removeAt(_messages.lastIndex)
        _messages[index] = original.copy(text = clean)
        persistMessages()

        val chosen = modelOptions.firstOrNull { it.label == original.modelLabel }
            ?: modelOptions.firstOrNull { it.modelId == original.modelId }
            ?: selectedModel
        val resolvedModel = original.modelId?.takeIf { it.isNotBlank() } ?: chosen.modelId.orEmpty()

        if (!isConfigured) {
            _messages += ChatMessage(
                id = nextId++,
                role = MessageRole.AION,
                text = "اربط عنوان AION Cloud من الإعدادات أولًا، ثم أعد المحاولة.",
                modelId = resolvedModel,
                modelLabel = chosen.label,
                isError = true
            )
            persistMessages()
            return
        }

        requestAssistantResponse(chosen = chosen, resolvedModel = resolvedModel)
    }

    fun newConversation() {
        if (isSending) return
        val id = ChatSessionStore.createConversation(getApplication())
        switchConversation(id)
    }

    fun switchConversation(conversationId: String) {
        if (isSending || conversationId.isBlank() || conversationId == activeConversationId) return
        activeConversationId = conversationId
        ChatSessionStore.setActiveConversation(getApplication(), conversationId)
        loadConversation(conversationId, preserveDraft = true)
        normalizeInterruptedStreamingMessages()
        refreshConversations()
    }

    fun renameConversation(conversationId: String, title: String) {
        if (conversationId.isBlank()) return
        ChatSessionStore.renameConversation(getApplication(), conversationId, title)
        refreshConversations()
    }

    fun deleteConversation(conversationId: String) {
        if (isSending || conversationId.isBlank()) return
        val nextId = ChatSessionStore.deleteConversation(getApplication(), conversationId)
        activeConversationId = nextId
        loadConversation(nextId, preserveDraft = true)
        refreshConversations()
    }

    private fun loadConversation(conversationId: String, preserveDraft: Boolean) {
        _messages.clear()
        _pendingAttachments.clear()
        val restored = ChatSessionStore.loadMessages(getApplication(), conversationId)
        _messages.addAll(restored)
        nextId = (_messages.maxOfOrNull { it.id } ?: 0L) + 1L
        draft = ChatSessionStore.loadDraft(getApplication(), conversationId)
        if (!preserveDraft && draft.isNotEmpty()) updateDraft("")
    }

    private fun normalizeInterruptedStreamingMessages() {
        var changed = false
        for (index in _messages.indices) {
            val message = _messages[index]
            if (message.isStreaming) {
                _messages[index] = message.copy(isStreaming = false, wasStopped = true)
                changed = true
            }
        }
        if (changed) persistMessages()
    }

    private fun requestAssistantResponse(chosen: AiModelOption, resolvedModel: String) {
        val placeholderId = nextId++
        _messages += ChatMessage(
            id = placeholderId,
            role = MessageRole.AION,
            text = "",
            modelId = resolvedModel,
            modelLabel = chosen.label,
            isStreaming = true
        )
        isSending = true
        activity = GatewayActivity.THINKING

        val sessionMessages = _messages.filter { it.id != placeholderId }.toList()
        val eligibleMessages = sessionMessages
            .filter { !it.isError && !it.wasStopped }
            .takeLast(120)
        val latestUserMessageId = eligibleMessages.lastOrNull { it.role == MessageRole.USER }?.id
        val requestMessages = eligibleMessages.map { message ->
            // لا نعيد إرسال ملفات كل السجل مع كل طلب. نرسل مرفقات آخر رسالة مستخدم فقط؛
            // وهذا يمنع تضخم الحمولة ويتيح استعادتها من النسخة المحلية عند Retry.
            if (message.id == latestUserMessageId) message
            else if (message.attachments.isNotEmpty()) message.copy(attachments = emptyList())
            else message
        }

        persistMessages()
        activeRunId = AionRunCoordinator.start(
            context = getApplication(),
            conversationId = activeConversationId,
            placeholderId = placeholderId,
            modelId = resolvedModel,
            modelLabel = chosen.label,
            messages = requestMessages,
            sessionMessages = sessionMessages,
            forceWebSearch = chosen.key == "research" || shouldForceWebSearch(requestMessages),
            customInstructions = customInstructions,
            memoryContext = memoryNotes
        )
    }

    private fun shouldForceWebSearch(messages: List<ChatMessage>): Boolean {
        val text = messages.lastOrNull { it.role == MessageRole.USER }?.text
            ?.lowercase()
            ?.replace("إ", "ا")
            ?.replace("أ", "ا")
            ?.replace("آ", "ا")
            .orEmpty()
        if (text.isBlank()) return false

        return listOf(
            "ابحث", "بحث في الويب", "ابحث في الويب", "فتش في الويب", "دور في الويب", "دور بالويب",
            "من الانترنت", "من الإنترنت", "على الانترنت", "على الإنترنت", "مصادر حديثة", "اخر الاخبار",
            "آخر الأخبار", "احدث الاخبار", "أحدث الأخبار", "اليوم", "حاليا", "حاليًا", "احدث اصدار",
            "أحدث إصدار", "سعر اليوم", "الطقس", "نتيجة المباراة"
        ).any { phrase ->
            val normalized = phrase.lowercase().replace("إ", "ا").replace("أ", "ا").replace("آ", "ا")
            text.contains(normalized)
        }
    }

    private fun applyRunSnapshot(snapshot: AionRunSnapshot) {
        if (snapshot.conversationId.isNotBlank() && snapshot.conversationId != activeConversationId) {
            if (!snapshot.isRunning) refreshConversations()
            return
        }

        activeRunId = if (snapshot.isRunning) snapshot.runId else null
        isSending = snapshot.isRunning
        activity = if (snapshot.isRunning) snapshot.activity else null

        val index = _messages.indexOfFirst { it.id == snapshot.placeholderId }
        val updated = ChatMessage(
            id = snapshot.placeholderId,
            role = MessageRole.AION,
            text = snapshot.text,
            modelId = snapshot.modelId,
            modelLabel = snapshot.modelLabel,
            sources = snapshot.sources,
            isError = snapshot.errorText != null,
            isStreaming = snapshot.isRunning,
            wasStopped = snapshot.wasStopped
        )

        when {
            index >= 0 && snapshot.wasStopped && snapshot.text.isBlank() -> _messages.removeAt(index)
            index >= 0 -> _messages[index] = updated
            snapshot.text.isNotBlank() || snapshot.isRunning -> _messages += updated
        }

        if (!snapshot.isRunning) {
            persistMessages()
            refreshConversations()
        }
    }

    private fun persistMessages() {
        if (activeConversationId.isBlank()) return
        ChatSessionStore.saveMessages(getApplication(), activeConversationId, _messages)
        refreshConversations()
    }

    private fun refreshConversations() {
        _conversations.clear()
        _conversations.addAll(ChatSessionStore.loadConversations(getApplication()))
    }
}
