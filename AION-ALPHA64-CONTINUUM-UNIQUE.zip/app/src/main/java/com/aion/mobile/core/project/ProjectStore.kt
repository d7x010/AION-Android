package com.aion.mobile.core.project

import android.content.Context
import android.util.AtomicFile
import java.io.File
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID
import com.aion.mobile.core.memory.ProjectMemoryPolicy

data class AionProject(
    val id: String,
    val name: String,
    val instructions: String = "",
    val memoryNotes: String = "",
    val projectOnlyMemory: Boolean = true,
    val createdAt: Long,
    val updatedAt: Long
)

/**
 * تخزين محلي خفيف للمشاريع. المشروع يجمع محادثات وتعليمات وسياقًا مستقلًا.
 * لا يحتوي أسرارًا أو مفاتيح API، ويمكن حذف المشروع من دون حذف المحادثات نفسها.
 */
object ProjectStore {
    private const val PREFS = "aion_projects"
    private const val KEY_PROJECTS = "projects_v1"
    private const val MAX_PROJECTS = 100

    fun load(context: Context): List<AionProject> {
        val fileRaw = readProjectFile(context)
        if (!fileRaw.isNullOrBlank()) return decode(fileRaw).sortedByDescending { it.updatedAt }

        // ترحيل تلقائي من SharedPreferences لإصدارات α7.1 وما قبلها.
        val legacyRaw = prefs(context).getString(KEY_PROJECTS, "[]").orEmpty()
        val projects = decode(legacyRaw).sortedByDescending { it.updatedAt }
        if (projects.isNotEmpty() && writeProjectFile(context, encodeProjects(projects).toString())) {
            prefs(context).edit().remove(KEY_PROJECTS).apply()
        }
        return projects
    }

    fun get(context: Context, id: String?): AionProject? {
        if (id.isNullOrBlank()) return null
        return load(context).firstOrNull { it.id == id }
    }

    fun create(context: Context, name: String, instructions: String = ""): AionProject {
        val now = System.currentTimeMillis()
        val project = AionProject(
            id = UUID.randomUUID().toString(),
            name = cleanName(name),
            instructions = cleanInstructions(instructions),
            createdAt = now,
            updatedAt = now
        )
        save(context, (listOf(project) + load(context)).take(MAX_PROJECTS))
        return project
    }

    fun update(context: Context, project: AionProject) {
        val updated = load(context).map {
            if (it.id == project.id) project.copy(
                name = cleanName(project.name),
                instructions = cleanInstructions(project.instructions),
                memoryNotes = cleanMemory(project.memoryNotes),
                updatedAt = System.currentTimeMillis()
            ) else it
        }
        save(context, updated)
    }

    /** يضيف ذكرى صريحة إلى مشروع واحد فقط، مع منع التكرار وحدّ الحجم. */
    fun appendMemory(context: Context, projectId: String, text: String): AionProject? {
        if (projectId.isBlank()) return null
        val projects = load(context)
        val current = projects.firstOrNull { it.id == projectId } ?: return null
        val merged = ProjectMemoryPolicy.append(current.memoryNotes, text)
        if (merged == current.memoryNotes.trim()) return current
        val updatedProject = current.copy(memoryNotes = merged, updatedAt = System.currentTimeMillis())
        save(context, projects.map { if (it.id == projectId) updatedProject else it })
        return updatedProject
    }

    /** مسح ذاكرة مشروع لا يمس الذاكرة العامة ولا محادثات المشروع. */
    fun clearMemory(context: Context, projectId: String): AionProject? {
        if (projectId.isBlank()) return null
        val projects = load(context)
        val current = projects.firstOrNull { it.id == projectId } ?: return null
        if (current.memoryNotes.isBlank()) return current
        val updatedProject = current.copy(memoryNotes = "", updatedAt = System.currentTimeMillis())
        save(context, projects.map { if (it.id == projectId) updatedProject else it })
        return updatedProject
    }

    fun delete(context: Context, id: String) {
        save(context, load(context).filterNot { it.id == id })
    }

    private fun cleanName(value: String): String =
        value.replace(Regex("\\s+"), " ").trim().take(60).ifBlank { "مشروع جديد" }

    private fun cleanInstructions(value: String): String =
        value.replace("\u0000", "").trim().take(6_000)

    private fun cleanMemory(value: String): String =
        value.replace("\u0000", "").trim().take(16_000)

    private fun save(context: Context, projects: List<AionProject>) {
        val array = encodeProjects(projects)
        if (writeProjectFile(context, array.toString())) {
            // لا نحتفظ بنسختين قد تتباعدان بعد نجاح الترحيل.
            prefs(context).edit().remove(KEY_PROJECTS).apply()
        } else {
            // fallback نادر إذا تعذر الوصول إلى filesDir لأي سبب.
            prefs(context).edit().putString(KEY_PROJECTS, array.toString()).apply()
        }
    }

    private fun encodeProjects(projects: List<AionProject>): JSONArray = JSONArray().apply {
        projects.sortedByDescending { it.updatedAt }.take(MAX_PROJECTS).forEach { project ->
            put(JSONObject().apply {
                put("id", project.id)
                put("name", project.name)
                put("instructions", project.instructions)
                put("memoryNotes", project.memoryNotes)
                put("projectOnlyMemory", project.projectOnlyMemory)
                put("createdAt", project.createdAt)
                put("updatedAt", project.updatedAt)
            })
        }
    }

    private fun projectFile(context: Context): File {
        val dir = File(context.filesDir, "aion_projects")
        if (!dir.exists()) dir.mkdirs()
        return File(dir, "projects.json")
    }

    private fun readProjectFile(context: Context): String? = runCatching {
        val file = projectFile(context)
        if (!file.exists()) return@runCatching null
        AtomicFile(file).openRead().bufferedReader(Charsets.UTF_8).use { it.readText() }
    }.getOrNull()

    private fun writeProjectFile(context: Context, raw: String): Boolean = runCatching {
        val atomic = AtomicFile(projectFile(context))
        val output = atomic.startWrite()
        try {
            output.write(raw.toByteArray(Charsets.UTF_8))
            atomic.finishWrite(output)
        } catch (error: Throwable) {
            atomic.failWrite(output)
            throw error
        }
        true
    }.getOrDefault(false)

    private fun decode(raw: String): List<AionProject> = runCatching {
        val array = JSONArray(raw)
        buildList {
            for (i in 0 until array.length()) {
                val item = array.optJSONObject(i) ?: continue
                val id = item.optString("id").trim()
                if (id.isBlank()) continue
                add(
                    AionProject(
                        id = id,
                        name = item.optString("name").ifBlank { "مشروع" },
                        instructions = item.optString("instructions"),
                        memoryNotes = item.optString("memoryNotes"),
                        projectOnlyMemory = item.optBoolean("projectOnlyMemory", true),
                        createdAt = item.optLong("createdAt"),
                        updatedAt = item.optLong("updatedAt")
                    )
                )
            }
        }
    }.getOrDefault(emptyList())

    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
}
