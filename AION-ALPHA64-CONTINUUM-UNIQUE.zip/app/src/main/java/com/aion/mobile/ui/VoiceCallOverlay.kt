package com.aion.mobile.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.AudioFormat
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.CallEnd
import androidx.compose.material.icons.outlined.Mic
import androidx.compose.material.icons.outlined.MicOff
import androidx.compose.material.icons.outlined.Stop
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import com.aion.mobile.core.ai.GatewayActivity
import com.aion.mobile.core.voice.SpeechText
import com.aion.mobile.core.voice.VoiceAmplitude
import com.aion.mobile.core.voice.VoiceTurnPolicy
import com.aion.mobile.model.ChatMessage
import com.aion.mobile.model.MessageRole
import com.aion.mobile.ui.theme.AionPurpleSoft
import com.aion.mobile.ui.theme.AionPurpleStrong
import kotlinx.coroutines.delay
import java.util.Locale
import java.util.concurrent.atomic.AtomicInteger

private enum class VoiceCallState {
    INITIALIZING,
    LISTENING,
    THINKING,
    SEARCHING,
    SPEAKING,
    RECONNECTING,
    ERROR
}

/**
 * مكالمة صوتية داخل المحادثة: استماع -> إرسال -> رد -> كلام -> استماع.
 *
 * ليست WebRTC full-duplex بعد، لكن الحركة أثناء كلام AION تعتمد على PCM الحقيقي الذي يولده TTS
 * عبر UtteranceProgressListener.onAudioAvailable بدل نبضة زمنية وهمية. ويمكن للمستخدم مقاطعة
 * كلام AION فورًا بالضغط على الدائرة أو زر الإيقاف لبدء الاستماع إلى دوره الجديد.
 */
@Composable
internal fun VoiceCallOverlay(
    messages: List<ChatMessage>,
    isSending: Boolean,
    activity: GatewayActivity?,
    onSend: (String) -> Unit,
    onStop: () -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val mainHandler = remember { Handler(Looper.getMainLooper()) }
    val latestSending by rememberUpdatedState(isSending)
    var state by remember { mutableStateOf(VoiceCallState.INITIALIZING) }
    var partialText by remember { mutableStateOf("") }
    var rms by remember { mutableFloatStateOf(0f) }
    var assistantLevel by remember { mutableFloatStateOf(0f) }
    var muted by remember { mutableStateOf(false) }
    var recognizer by remember { mutableStateOf<SpeechRecognizer?>(null) }
    var tts by remember { mutableStateOf<TextToSpeech?>(null) }
    var ttsReady by remember { mutableStateOf(false) }
    var requestListenTick by remember { mutableIntStateOf(0) }
    var recognitionFailures by remember { mutableIntStateOf(0) }
    var networkFailures by remember { mutableIntStateOf(0) }
    var suppressRecognizerErrorsUntil by remember { mutableLongStateOf(0L) }
    val synthesisFormat = remember { AtomicInteger(AudioFormat.ENCODING_PCM_16BIT) }
    var lastHandledAssistantId by remember {
        mutableStateOf(messages.lastOrNull { it.role == MessageRole.AION }?.id)
    }

    fun cancelRecognizerSilently() {
        suppressRecognizerErrorsUntil = SystemClock.uptimeMillis() + 650L
        runCatching { recognizer?.cancel() }
        rms = 0f
    }

    fun scheduleListen(delayMs: Long = 180L) {
        mainHandler.postDelayed({
            if (!muted && !latestSending && state != VoiceCallState.SPEAKING) {
                requestListenTick += 1
            }
        }, delayMs)
    }

    fun stopAudio() {
        cancelRecognizerSilently()
        runCatching { tts?.stop() }
        assistantLevel = 0f
    }

    fun interruptAssistantAndListen() {
        runCatching { tts?.stop() }
        assistantLevel = 0f
        if (!muted) {
            state = VoiceCallState.LISTENING
            scheduleListen(90L)
        }
    }

    fun startListeningNow() {
        if (muted || latestSending || state == VoiceCallState.SPEAKING) return
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return
        val r = recognizer ?: return
        partialText = ""
        rms = 0f
        state = VoiceCallState.LISTENING
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag())
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, false)
            // فواصل صمت أقصر من الوضع القديم لتقليل التأخير بعد انتهاء المستخدم من الكلام.
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 900L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 520L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 350L)
        }
        runCatching { r.startListening(intent) }
            .onFailure {
                state = VoiceCallState.RECONNECTING
                recognitionFailures += 1
                scheduleListen(VoiceTurnPolicy.retryDelayMs(recognitionFailures, networkRelated = false))
            }
    }

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) {
            requestListenTick += 1
        } else {
            state = VoiceCallState.ERROR
            Toast.makeText(context, "يحتاج AION إذن الميكروفون لبدء المكالمة.", Toast.LENGTH_SHORT).show()
        }
    }

    DisposableEffect(context) {
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            state = VoiceCallState.ERROR
        } else {
            val speech = SpeechRecognizer.createSpeechRecognizer(context)
            speech.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {
                    if (!muted) state = VoiceCallState.LISTENING
                }

                override fun onBeginningOfSpeech() {
                    recognitionFailures = 0
                    networkFailures = 0
                    if (!muted) state = VoiceCallState.LISTENING
                }

                override fun onRmsChanged(rmsdB: Float) {
                    // SpeechRecognizer يعطي RMS فعليًا للميكروفون؛ لا توجد حركة زمنية مصطنعة هنا.
                    rms = rmsdB.coerceIn(0f, 12f)
                }

                override fun onBufferReceived(buffer: ByteArray?) = Unit
                override fun onEndOfSpeech() {
                    rms = 0f
                    if (!latestSending && !muted) state = VoiceCallState.THINKING
                }

                override fun onError(error: Int) {
                    rms = 0f
                    if (SystemClock.uptimeMillis() <= suppressRecognizerErrorsUntil) return
                    if (muted || latestSending || state == VoiceCallState.SPEAKING) return

                    val networkRelated = error == SpeechRecognizer.ERROR_NETWORK ||
                        error == SpeechRecognizer.ERROR_NETWORK_TIMEOUT ||
                        error == SpeechRecognizer.ERROR_SERVER

                    when (error) {
                        SpeechRecognizer.ERROR_NO_MATCH,
                        SpeechRecognizer.ERROR_SPEECH_TIMEOUT,
                        SpeechRecognizer.ERROR_RECOGNIZER_BUSY,
                        SpeechRecognizer.ERROR_NETWORK,
                        SpeechRecognizer.ERROR_NETWORK_TIMEOUT,
                        SpeechRecognizer.ERROR_SERVER -> {
                            recognitionFailures += 1
                            if (networkRelated) networkFailures += 1 else networkFailures = 0
                            if (VoiceTurnPolicy.shouldRequireManualResume(networkFailures)) {
                                state = VoiceCallState.ERROR
                            } else {
                                state = if (networkRelated) VoiceCallState.RECONNECTING else VoiceCallState.LISTENING
                                scheduleListen(VoiceTurnPolicy.retryDelayMs(recognitionFailures, networkRelated))
                            }
                        }
                        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> state = VoiceCallState.ERROR
                        else -> state = VoiceCallState.ERROR
                    }
                }

                override fun onResults(results: Bundle?) {
                    rms = 0f
                    recognitionFailures = 0
                    networkFailures = 0
                    val spoken = results
                        ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.firstOrNull()
                        ?.trim()
                        .orEmpty()
                    if (spoken.isNotBlank()) {
                        partialText = spoken
                        state = VoiceCallState.THINKING
                        onSend(spoken)
                    } else if (!muted) {
                        partialText = ""
                        scheduleListen(260L)
                    }
                }

                override fun onPartialResults(partialResults: Bundle?) {
                    partialText = partialResults
                        ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.firstOrNull()
                        .orEmpty()
                }

                override fun onEvent(eventType: Int, params: Bundle?) = Unit
            })
            recognizer = speech
        }

        lateinit var engine: TextToSpeech
        engine = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                configureNaturalTts(engine, Locale.getDefault())
                engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {
                        mainHandler.post {
                            assistantLevel = 0f
                            state = VoiceCallState.SPEAKING
                        }
                    }

                    override fun onBeginSynthesis(utteranceId: String?, sampleRateInHz: Int, audioFormat: Int, channelCount: Int) {
                        synthesisFormat.set(audioFormat)
                    }

                    override fun onAudioAvailable(utteranceId: String?, audio: ByteArray?) {
                        val bytes = audio ?: return
                        val rawLevel = when (synthesisFormat.get()) {
                            AudioFormat.ENCODING_PCM_8BIT -> VoiceAmplitude.pcm8Unsigned(bytes)
                            AudioFormat.ENCODING_PCM_16BIT -> VoiceAmplitude.pcm16LittleEndian(bytes)
                            AudioFormat.ENCODING_PCM_FLOAT -> VoiceAmplitude.pcmFloatLittleEndian(bytes)
                            else -> 0f
                        }
                        mainHandler.post {
                            if (state == VoiceCallState.SPEAKING) {
                                assistantLevel = VoiceAmplitude.smooth(assistantLevel, rawLevel)
                            }
                        }
                    }

                    override fun onDone(utteranceId: String?) {
                        if (utteranceId?.endsWith(":last") != true) return
                        mainHandler.post {
                            assistantLevel = 0f
                            partialText = ""
                            if (!muted) {
                                state = VoiceCallState.LISTENING
                                scheduleListen(230L)
                            }
                        }
                    }

                    override fun onStop(utteranceId: String?, interrupted: Boolean) {
                        mainHandler.post { assistantLevel = 0f }
                    }

                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        mainHandler.post {
                            assistantLevel = 0f
                            state = VoiceCallState.ERROR
                            if (!muted) scheduleListen(700L)
                        }
                    }
                })
                tts = engine
                ttsReady = true
                if (state == VoiceCallState.INITIALIZING) state = VoiceCallState.LISTENING
            } else {
                ttsReady = false
                if (state == VoiceCallState.INITIALIZING) state = VoiceCallState.LISTENING
            }
        }

        onDispose {
            runCatching { speechRecognizerSafeDestroy(recognizer) }
            runCatching { engine.stop() }
            runCatching { engine.shutdown() }
            mainHandler.removeCallbacksAndMessages(null)
            recognizer = null
            tts = null
            ttsReady = false
        }
    }

    LaunchedEffect(Unit) {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            requestListenTick += 1
        } else {
            permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    LaunchedEffect(requestListenTick) {
        if (requestListenTick > 0 && !muted && !isSending && state != VoiceCallState.SPEAKING) {
            delay(90)
            startListeningNow()
        }
    }

    LaunchedEffect(isSending, activity) {
        if (isSending) {
            assistantLevel = 0f
            cancelRecognizerSilently()
            state = if (activity == GatewayActivity.SEARCHING_WEB) VoiceCallState.SEARCHING else VoiceCallState.THINKING
        }
    }

    LaunchedEffect(messages.lastOrNull()?.id, isSending, ttsReady) {
        if (isSending) return@LaunchedEffect
        val last = messages.lastOrNull() ?: return@LaunchedEffect
        if (last.role != MessageRole.AION || last.id == lastHandledAssistantId) return@LaunchedEffect

        if (last.isError || last.text.isBlank()) {
            lastHandledAssistantId = last.id
            state = VoiceCallState.ERROR
            delay(650)
            if (!muted) scheduleListen(0L)
            return@LaunchedEffect
        }

        val engine = tts
        if (engine == null || !ttsReady) {
            if (!muted) scheduleListen(150L)
            return@LaunchedEffect
        }

        lastHandledAssistantId = last.id
        state = VoiceCallState.SPEAKING
        val chunks = SpeechText.chunks(last.text)
        if (chunks.isEmpty()) {
            if (!muted) scheduleListen(120L)
        } else {
            chunks.forEachIndexed { index, chunk ->
                val isLast = index == chunks.lastIndex
                engine.speak(
                    chunk,
                    if (index == 0) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD,
                    null,
                    "aion-call-${last.id}-$index${if (isLast) ":last" else ""}"
                )
            }
        }
    }

    val liveLevel = when (state) {
        VoiceCallState.LISTENING -> (rms / 12f).coerceIn(0f, 1f)
        VoiceCallState.SPEAKING -> assistantLevel.coerceIn(0f, 1f)
        else -> 0f
    }
    val requestedScale = 1f + (liveLevel * if (state == VoiceCallState.SPEAKING) 0.16f else 0.18f)
    val pulseScale by animateFloatAsState(
        targetValue = requestedScale,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium),
        label = "voice-reactive-scale"
    )
    val glowAlpha by animateFloatAsState(
        targetValue = 0.08f + (liveLevel * 0.22f),
        animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
        label = "voice-reactive-glow"
    )

    val status = when (state) {
        VoiceCallState.INITIALIZING -> "تهيئة الصوت…"
        VoiceCallState.LISTENING -> "أسمعك…"
        VoiceCallState.THINKING -> "يفهم كلامك…"
        VoiceCallState.SEARCHING -> "يبحث في الويب…"
        VoiceCallState.SPEAKING -> "AION يتحدث"
        VoiceCallState.RECONNECTING -> "إعادة الاتصال بالصوت…"
        VoiceCallState.ERROR -> "الصوت متوقف — اضغط للمتابعة"
    }
    val helper = when {
        muted -> "الميكروفون مكتوم"
        state == VoiceCallState.SPEAKING -> "اضغط على الدائرة لمقاطعة AION والتحدث"
        state == VoiceCallState.LISTENING -> "تحدث بشكل طبيعي؛ سأرسل كلامك عند انتهاء الجملة"
        state == VoiceCallState.THINKING || state == VoiceCallState.SEARCHING -> "يمكنك إيقاف الرد من الزر السفلي"
        state == VoiceCallState.ERROR -> "اضغط على الدائرة لإعادة تشغيل الاستماع"
        else -> ""
    }

    Dialog(
        onDismissRequest = {
            stopAudio()
            onDismiss()
        },
        properties = DialogProperties(
            usePlatformDefaultWidth = false,
            dismissOnBackPress = true,
            dismissOnClickOutside = false
        )
    ) {
        Surface(modifier = Modifier.fillMaxSize(), color = Color(0xFF08080D)) {
            Column(
                modifier = Modifier.fillMaxSize().padding(horizontal = 28.dp, vertical = 34.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("AION Voice", fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
                    Spacer(Modifier.height(6.dp))
                    Text("مكالمة داخل المحادثة نفسها", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(
                        modifier = Modifier
                            .size(184.dp)
                            .scale(pulseScale)
                            .background(AionPurpleStrong.copy(alpha = glowAlpha), CircleShape)
                            .clickable {
                                when (state) {
                                    VoiceCallState.SPEAKING -> interruptAssistantAndListen()
                                    VoiceCallState.THINKING, VoiceCallState.SEARCHING -> {
                                        onStop()
                                        if (!muted) scheduleListen(220L)
                                    }
                                    VoiceCallState.ERROR, VoiceCallState.RECONNECTING, VoiceCallState.INITIALIZING -> {
                                        recognitionFailures = 0
                                        networkFailures = 0
                                        if (!muted) {
                                            state = VoiceCallState.LISTENING
                                            scheduleListen(50L)
                                        }
                                    }
                                    VoiceCallState.LISTENING -> Unit
                                }
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = Color(0xFF1C112B),
                            border = BorderStroke(1.dp + (liveLevel * 1.1f).dp, AionPurpleSoft.copy(alpha = 0.48f + liveLevel * 0.42f)),
                            modifier = Modifier.size(116.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text("A", fontSize = 42.sp, fontWeight = FontWeight.Black, color = AionPurpleSoft)
                            }
                        }
                    }
                    Spacer(Modifier.height(28.dp))
                    Text(status, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center)
                    if (helper.isNotBlank()) {
                        Spacer(Modifier.height(8.dp))
                        Text(
                            helper,
                            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp),
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center
                        )
                    }
                    if (partialText.isNotBlank()) {
                        Spacer(Modifier.height(14.dp))
                        Text(
                            partialText,
                            modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp),
                            fontSize = 15.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center,
                            maxLines = 4
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        onClick = {
                            muted = !muted
                            if (muted) {
                                rms = 0f
                                cancelRecognizerSilently()
                            } else if (!isSending && state != VoiceCallState.SPEAKING) {
                                recognitionFailures = 0
                                networkFailures = 0
                                state = VoiceCallState.LISTENING
                                scheduleListen(80L)
                            }
                        },
                        shape = CircleShape,
                        color = if (muted) Color(0xFF48242B) else Color(0xFF1A1A22),
                        modifier = Modifier.size(58.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(if (muted) Icons.Outlined.MicOff else Icons.Outlined.Mic, contentDescription = "الميكروفون")
                        }
                    }

                    Surface(
                        onClick = {
                            stopAudio()
                            if (isSending) onStop()
                            onDismiss()
                        },
                        shape = CircleShape,
                        color = Color(0xFF8D2735),
                        modifier = Modifier.size(68.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(Icons.Outlined.CallEnd, contentDescription = "إنهاء المكالمة", tint = Color.White, modifier = Modifier.size(30.dp))
                        }
                    }

                    Surface(
                        onClick = {
                            when {
                                state == VoiceCallState.SPEAKING -> interruptAssistantAndListen()
                                isSending -> {
                                    onStop()
                                    if (!muted) scheduleListen(220L)
                                }
                                else -> {
                                    cancelRecognizerSilently()
                                    if (!muted) scheduleListen(100L)
                                }
                            }
                        },
                        shape = CircleShape,
                        color = Color(0xFF1A1A22),
                        modifier = Modifier.size(58.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(Icons.Outlined.Stop, contentDescription = "إيقاف/مقاطعة")
                        }
                    }
                }
            }
        }
    }
}

internal fun configureNaturalTts(engine: TextToSpeech, locale: Locale): Boolean {
    // كل خطوة اختيارية. بعض محركات TTS على أجهزة OEM لا تنفذ جميع الخصائص
    // القياسية بصورة سليمة؛ فشل تحسين واحد يجب ألا يغلق التطبيق أو المكالمة.
    val selectedLocale = runCatching {
        val available = engine.isLanguageAvailable(locale) >= TextToSpeech.LANG_AVAILABLE
        if (available) locale else Locale.forLanguageTag(locale.language.ifBlank { "ar" })
    }.getOrDefault(locale)

    val languageResult = runCatching { engine.setLanguage(selectedLocale) }
        .getOrDefault(TextToSpeech.LANG_NOT_SUPPORTED)

    runCatching {
        engine.setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ASSISTANT)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build()
        )
    }
    runCatching { engine.setSpeechRate(if (selectedLocale.language == "ar") 0.94f else 0.97f) }
    runCatching { engine.setPitch(1.0f) }

    runCatching {
        val bestVoice = engine.voices
            ?.asSequence()
            ?.filter { it.locale.language == selectedLocale.language }
            ?.maxByOrNull { voice ->
                (voice.quality * 100) - (voice.latency * 6) + if (voice.isNetworkConnectionRequired) 12 else 0
            }
        if (bestVoice != null) engine.voice = bestVoice
    }

    return languageResult != TextToSpeech.LANG_MISSING_DATA &&
        languageResult != TextToSpeech.LANG_NOT_SUPPORTED
}

private fun speechRecognizerSafeDestroy(recognizer: SpeechRecognizer?) {
    recognizer?.cancel()
    recognizer?.destroy()
}
