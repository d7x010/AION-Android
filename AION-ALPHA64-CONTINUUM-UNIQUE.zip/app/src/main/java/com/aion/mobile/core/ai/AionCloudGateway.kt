package com.aion.mobile.core.ai

import com.aion.mobile.model.ChatMessage
import com.aion.mobile.model.ChatSource
import com.aion.mobile.model.MessageRole
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL

class AionCloudException(val statusCode: Int, message: String) : Exception(message)

/**
 * عميل AION Cloud. يدعم Streaming حقيقي وحالات تشغيل ومصادر بحث.
 * لا يحتوي APK على أي مفتاح مزود.
 */
class AionCloudGateway {
    suspend fun streamComplete(
        endpoint: String,
        mode: String,
        messages: List<ChatMessage>,
        forceWebSearch: Boolean,
        customInstructions: String = "",
        memoryContext: String = "",
        onDelta: suspend (String) -> Unit,
        onActivity: suspend (GatewayActivity) -> Unit
    ): GatewayResult = withContext(Dispatchers.IO) {
        if (endpoint.isBlank()) throw AionCloudException(400, "لم يتم ربط AION Cloud بعد.")

        val connection = openConnection("${endpoint.trimEnd('/')}/v1/chat/stream")
        val body = buildPayload(mode, messages, forceWebSearch, customInstructions, memoryContext)
        val sources = linkedMapOf<String, ChatSource>()
        val text = StringBuilder()
        var eventName = "message"
        var dataLines = mutableListOf<String>()
        var receivedDelta = false

        val cancellationHandle = currentCoroutineContext()[Job]?.invokeOnCompletion { cause ->
            if (cause is CancellationException) connection.disconnect()
        }

        suspend fun processEvent() {
            if (dataLines.isEmpty()) return
            val raw = dataLines.joinToString("\n")
            dataLines = mutableListOf()
            if (raw == "[DONE]") return
            val json = runCatching { JSONObject(raw) }.getOrNull() ?: return
            when (eventName) {
                "activity" -> when (json.optString("activity")) {
                    "searching_web" -> onActivity(GatewayActivity.SEARCHING_WEB)
                    "reading_files" -> onActivity(GatewayActivity.READING_FILES)
                    "writing" -> onActivity(GatewayActivity.WRITING)
                    else -> onActivity(GatewayActivity.THINKING)
                }
                "sources" -> {
                    val array = json.optJSONArray("sources") ?: JSONArray()
                    for (i in 0 until array.length()) {
                        val source = array.optJSONObject(i) ?: continue
                        val url = source.optString("url").trim()
                        if (url.isBlank()) continue
                        val title = source.optString("title").trim().ifBlank { url }
                        sources.putIfAbsent(url, ChatSource(title = title, url = url))
                    }
                }

                "delta" -> {
                    val delta = json.optString("text")
                    if (delta.isNotEmpty()) {
                        currentCoroutineContext().ensureActive()
                        receivedDelta = true
                        text.append(delta)
                        onDelta(delta)
                    }
                }

                "error" -> {
                    val status = json.optInt("status", 500)
                    throw AionCloudException(status, json.optString("error").ifBlank { "تعذر تنفيذ الطلب." })
                }
            }
        }

        try {
            onActivity(if (forceWebSearch || mode == "research") GatewayActivity.SEARCHING_WEB else GatewayActivity.THINKING)
            connection.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = connection.responseCode
            if (code !in 200..299) {
                val raw = connection.errorStream?.let {
                    BufferedReader(InputStreamReader(it, Charsets.UTF_8)).use { reader -> reader.readText() }
                }.orEmpty()
                val error = runCatching { JSONObject(raw).optString("error") }.getOrNull().orEmpty()
                throw AionCloudException(code, error.ifBlank { "تعذر الاتصال بـ AION Cloud." })
            }

            BufferedReader(InputStreamReader(connection.inputStream, Charsets.UTF_8)).use { reader ->
                while (true) {
                    currentCoroutineContext().ensureActive()
                    val line = reader.readLine() ?: break
                    when {
                        line.startsWith("event:") -> eventName = line.substringAfter("event:").trim()
                        line.startsWith("data:") -> dataLines += line.substringAfter("data:").trim()
                        line.isBlank() -> {
                            processEvent()
                            eventName = "message"
                        }
                    }
                }
            }
            processEvent()

            if (!receivedDelta || text.isBlank()) {
                return@withContext complete(
                    endpoint = endpoint,
                    mode = mode,
                    messages = messages,
                    forceWebSearch = forceWebSearch,
                    customInstructions = customInstructions,
                    memoryContext = memoryContext,
                    onActivity = onActivity
                ).also { fallback ->
                    if (fallback.text.isNotBlank()) onDelta(fallback.text)
                }
            }

            GatewayResult(text = text.toString(), sources = sources.values.take(12))
        } finally {
            cancellationHandle?.dispose()
            connection.disconnect()
        }
    }

    suspend fun complete(
        endpoint: String,
        mode: String,
        messages: List<ChatMessage>,
        forceWebSearch: Boolean,
        customInstructions: String = "",
        memoryContext: String = "",
        onActivity: suspend (GatewayActivity) -> Unit
    ): GatewayResult = withContext(Dispatchers.IO) {
        if (endpoint.isBlank()) throw AionCloudException(400, "لم يتم ربط AION Cloud بعد.")
        val connection = openConnection("${endpoint.trimEnd('/')}/v1/chat")
        val body = buildPayload(mode, messages, forceWebSearch, customInstructions, memoryContext)

        try {
            onActivity(if (forceWebSearch || mode == "research") GatewayActivity.SEARCHING_WEB else GatewayActivity.THINKING)
            connection.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val raw = stream?.let {
                BufferedReader(InputStreamReader(it, Charsets.UTF_8)).use { reader -> reader.readText() }
            }.orEmpty()
            val response = runCatching { JSONObject(raw) }.getOrNull()
            if (code !in 200..299) {
                throw AionCloudException(
                    code,
                    response?.optString("error").orEmpty().ifBlank { "تعذر الاتصال بـ AION Cloud." }
                )
            }
            val text = response?.optString("response").orEmpty().trim()
            if (text.isBlank()) throw AionCloudException(502, "أنهى الخادم الطلب من دون نص.")
            val sources = parseSources(response?.optJSONArray("sources"))
            onActivity(GatewayActivity.WRITING)
            GatewayResult(text = text, sources = sources)
        } finally {
            connection.disconnect()
        }
    }

    private fun openConnection(url: String): HttpURLConnection =
        (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 30_000
            readTimeout = 180_000
            doOutput = true
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            setRequestProperty("Accept", "application/json, text/event-stream")
        }

    private fun buildPayload(
        mode: String,
        messages: List<ChatMessage>,
        forceWebSearch: Boolean,
        customInstructions: String,
        memoryContext: String
    ): JSONObject = JSONObject().apply {
            put("mode", mode.ifBlank { "auto" })
            put("forceWebSearch", forceWebSearch)
            put("client", "AION-Android/alpha7")
            if (customInstructions.isNotBlank()) put("customInstructions", customInstructions.take(5_000))
            if (memoryContext.isNotBlank()) put("memoryContext", memoryContext.take(12_000))
            put("messages", JSONArray().apply {
                messages.takeLast(120).forEach { message ->
                    val usableAttachments = if (message.role == MessageRole.USER) {
                        message.attachments.filter { it.base64Data.isNotBlank() }.take(4)
                    } else {
                        emptyList()
                    }
                    val content = message.text.take(16_000)
                    if (content.isNotBlank() || usableAttachments.isNotEmpty()) {
                        put(JSONObject().apply {
                            put("role", if (message.role == MessageRole.USER) "user" else "assistant")
                            put("content", content)
                            if (usableAttachments.isNotEmpty()) {
                                put("attachments", JSONArray().apply {
                                    usableAttachments.forEach { attachment ->
                                        put(JSONObject().apply {
                                            put("name", attachment.name)
                                            put("mimeType", attachment.mimeType)
                                            put("kind", attachment.kind.name)
                                            put("sizeBytes", attachment.sizeBytes)
                                            put("data", attachment.base64Data)
                                        })
                                    }
                                })
                            }
                        })
                    }
                }
            })
        }

    private fun parseSources(array: JSONArray?): List<ChatSource> {
        if (array == null) return emptyList()
        val seen = linkedMapOf<String, ChatSource>()
        for (i in 0 until array.length()) {
            val item = array.optJSONObject(i) ?: continue
            val url = item.optString("url").trim()
            if (url.isBlank()) continue
            val title = item.optString("title").trim().ifBlank { url }
            seen.putIfAbsent(url, ChatSource(title = title, url = url))
        }
        return seen.values.take(12)
    }
}
