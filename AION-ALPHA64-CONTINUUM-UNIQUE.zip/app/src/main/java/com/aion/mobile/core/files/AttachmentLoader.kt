package com.aion.mobile.core.files

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.provider.OpenableColumns
import android.util.Base64
import com.aion.mobile.model.AttachmentKind
import com.aion.mobile.model.ChatAttachment
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.Locale
import java.util.UUID
import kotlin.math.max
import kotlin.math.roundToInt

object AttachmentLoader {
    private const val MAX_ATTACHMENT_BYTES = 5L * 1024L * 1024L
    private const val MAX_SOURCE_IMAGE_BYTES = 12L * 1024L * 1024L
    private const val MAX_IMAGE_DIMENSION = 2048

    private val fileExtensions = setOf(
        "pdf", "txt", "md", "json", "html", "htm", "xml", "csv",
        "doc", "docx", "rtf", "odt", "ppt", "pptx", "xls", "xlsx",
        "kt", "kts", "java", "py", "js", "ts", "tsx", "jsx", "css",
        "c", "cpp", "h", "hpp", "cs", "go", "rs", "swift", "rb", "php",
        "sql", "yaml", "yml", "toml", "ini", "log"
    )

    fun load(context: Context, uri: Uri): Result<ChatAttachment> = runCatching {
        val resolver = context.contentResolver
        val name = queryName(context, uri) ?: "مرفق"
        val extension = name.substringAfterLast('.', "").lowercase(Locale.ROOT)
        var mime = resolver.getType(uri)?.lowercase(Locale.ROOT).orEmpty()
        if (mime.isBlank() || mime == "application/octet-stream") mime = fallbackMime(extension)

        val isImage = mime.startsWith("image/") && mime in setOf(
            "image/png", "image/jpeg", "image/jpg", "image/webp", "image/gif"
        )
        val isSupportedFile = mime.startsWith("text/") || extension in fileExtensions || mime in setOf(
            "application/pdf", "application/json", "application/xml", "application/rtf", "application/msword",
            "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            "application/vnd.ms-powerpoint", "application/vnd.openxmlformats-officedocument.presentationml.presentation",
            "application/vnd.ms-excel", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            "application/vnd.oasis.opendocument.text"
        )
        if (!isImage && !isSupportedFile) error("نوع الملف غير مدعوم حاليًا: $name")

        val sourceLimit = if (isImage) MAX_SOURCE_IMAGE_BYTES else MAX_ATTACHMENT_BYTES
        val reportedSize = querySize(context, uri)
        if (reportedSize != null && reportedSize > sourceLimit) {
            error(if (isImage) "الصورة أكبر من 12 MB. اختر صورة أصغر." else "الملف أكبر من 5 MB.")
        }

        val sourceBytes = resolver.openInputStream(uri)?.use { input ->
            val output = ByteArrayOutputStream()
            val buffer = ByteArray(64 * 1024)
            var total = 0L
            while (true) {
                val read = input.read(buffer)
                if (read <= 0) break
                total += read
                if (total > sourceLimit) error(if (isImage) "الصورة أكبر من 12 MB." else "الملف أكبر من 5 MB.")
                output.write(buffer, 0, read)
            }
            output.toByteArray()
        } ?: error("تعذر قراءة الملف المحدد.")

        val optimized = if (isImage) optimizeImage(sourceBytes, mime) else OptimizedPayload(sourceBytes, mime, extension)
        if (optimized.bytes.size > MAX_ATTACHMENT_BYTES) error("تعذر ضغط المرفق إلى الحجم الآمن للإرسال (5 MB).")

        val localPath = persistInternalCopy(context, optimized.bytes, optimized.extension)
        ChatAttachment(
            id = System.nanoTime(),
            name = if (isImage && optimized.extension == "jpg" && extension !in setOf("jpg", "jpeg")) {
                name.substringBeforeLast('.', name) + ".jpg"
            } else name,
            mimeType = if (optimized.mimeType == "image/jpg") "image/jpeg" else optimized.mimeType,
            base64Data = Base64.encodeToString(optimized.bytes, Base64.NO_WRAP),
            kind = if (isImage) AttachmentKind.IMAGE else AttachmentKind.FILE,
            sizeBytes = optimized.bytes.size.toLong(),
            localPath = localPath
        )
    }

    fun restoreData(attachment: ChatAttachment): ChatAttachment? {
        if (attachment.base64Data.isNotBlank()) return attachment
        val path = attachment.localPath.takeIf { it.isNotBlank() } ?: return null
        val file = File(path)
        if (!file.isFile || file.length() > MAX_ATTACHMENT_BYTES) return null
        return runCatching { attachment.copy(base64Data = Base64.encodeToString(file.readBytes(), Base64.NO_WRAP)) }.getOrNull()
    }

    private data class OptimizedPayload(val bytes: ByteArray, val mimeType: String, val extension: String)

    private fun optimizeImage(bytes: ByteArray, mimeType: String): OptimizedPayload {
        // الصور الصغيرة لا تحتاج إعادة ترميز؛ نحافظ على جودتها الأصلية.
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        val width = bounds.outWidth
        val height = bounds.outHeight
        if (width <= 0 || height <= 0) return OptimizedPayload(bytes, mimeType, extensionForMime(mimeType))
        if (bytes.size <= 2_200_000 && max(width, height) <= MAX_IMAGE_DIMENSION && mimeType != "image/gif") {
            return OptimizedPayload(bytes, mimeType, extensionForMime(mimeType))
        }

        val ratio = max(width, height).toFloat() / MAX_IMAGE_DIMENSION.toFloat()
        var sample = 1
        while (sample * 2 <= ratio) sample *= 2
        val decoded = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = sample })
            ?: return OptimizedPayload(bytes, mimeType, extensionForMime(mimeType))

        val scale = (MAX_IMAGE_DIMENSION.toFloat() / max(decoded.width, decoded.height)).coerceAtMost(1f)
        val bitmap = if (scale < 1f) {
            Bitmap.createScaledBitmap(
                decoded,
                (decoded.width * scale).roundToInt().coerceAtLeast(1),
                (decoded.height * scale).roundToInt().coerceAtLeast(1),
                true
            ).also { if (it !== decoded) decoded.recycle() }
        } else decoded

        fun compress(quality: Int): ByteArray = ByteArrayOutputStream().use { out ->
            bitmap.compress(Bitmap.CompressFormat.JPEG, quality, out)
            out.toByteArray()
        }

        var result = compress(88)
        if (result.size > 4_500_000) result = compress(78)
        if (result.size > 4_500_000) result = compress(68)
        bitmap.recycle()
        return OptimizedPayload(result, "image/jpeg", "jpg")
    }

    private fun persistInternalCopy(context: Context, bytes: ByteArray, extension: String): String {
        val dir = File(context.filesDir, "aion_attachments").apply { mkdirs() }
        val safeExtension = extension.takeIf { it.matches(Regex("[a-z0-9]{1,8}")) } ?: "bin"
        val file = File(dir, "${UUID.randomUUID()}.$safeExtension")
        file.writeBytes(bytes)
        return file.absolutePath
    }

    private fun queryName(context: Context, uri: Uri): String? =
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
            val index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (index >= 0 && cursor.moveToFirst()) cursor.getString(index) else null
        }

    private fun querySize(context: Context, uri: Uri): Long? =
        context.contentResolver.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)?.use { cursor ->
            val index = cursor.getColumnIndex(OpenableColumns.SIZE)
            if (index >= 0 && cursor.moveToFirst() && !cursor.isNull(index)) cursor.getLong(index) else null
        }

    private fun extensionForMime(mime: String): String = when (mime) {
        "image/png" -> "png"
        "image/webp" -> "webp"
        "image/gif" -> "gif"
        else -> "jpg"
    }

    private fun fallbackMime(extension: String): String = when (extension) {
        "png" -> "image/png"
        "jpg", "jpeg" -> "image/jpeg"
        "webp" -> "image/webp"
        "gif" -> "image/gif"
        "pdf" -> "application/pdf"
        "json" -> "application/json"
        "xml" -> "application/xml"
        "doc" -> "application/msword"
        "docx" -> "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
        "ppt" -> "application/vnd.ms-powerpoint"
        "pptx" -> "application/vnd.openxmlformats-officedocument.presentationml.presentation"
        "xls" -> "application/vnd.ms-excel"
        "xlsx" -> "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        "rtf" -> "application/rtf"
        else -> "text/plain"
    }
}
