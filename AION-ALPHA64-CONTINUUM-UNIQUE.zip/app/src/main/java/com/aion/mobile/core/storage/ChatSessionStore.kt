package com.aion.mobile.core.storage

import android.content.Context
import com.aion.mobile.model.AttachmentKind
import com.aion.mobile.model.ChatAttachment
import com.aion.mobile.model.ChatMessage
import com.aion.mobile.model.ChatSource
import com.aion.mobile.model.ConversationSummary
import com.aion.mobile.model.MessageRole
import org.json.JSONArray
import org.json.JSONObject

/**
 * تخزين محلي خفيف للمحادثة الحالية والمسودة.
 * لا نخزن base64 للمرفقات حتى لا نضخم SharedPreferences؛ نحفظ بياناتها الوصفية فقط.
 */
object ChatSessionStore {
    private const val PREFS = "aion_chat_session"
    private const val KEY_MESSAGES = "messages"
    private const val KEY_DRAFT = "draft"
    private const val KEY_SELECTED_MODEL = "selected_model"
    private const val KEY_CONVERSATIONS = "conversations_v2"
    private const val KEY_ACTIVE_CONVERSATION = "active_conversation_v2"

    private fun messagesKey(conversationId: String) = "messages_v2_$conversationId"

    fun saveMessages(context: Context, messages: List<ChatMessage>) {
        saveMessages(context, "legacy", messages)
    }

    fun saveMessages(context: Context, conversationId: String, messages: List<ChatMessage>) {
        val array = JSONArray()
        messages.takeLast(150).forEach { message ->
            array.put(
                JSONObject().apply {
                    put("id", message.id)
                    put("role", message.role.name)
                    put("text", message.text)
                    put("modelId", message.modelId ?: JSONObject.NULL)
                    put("modelLabel", message.modelLabel ?: JSONObject.NULL)
                    put("isError", message.isError)
                    put("isStreaming", message.isStreaming)
                    put("wasStopped", message.wasStopped)

                    put("sources", JSONArray().apply {
                        message.sources.forEach { source ->
                            put(JSONObject().apply {
                                put("title", source.title)
                                put("url", source.url)
                            })
                        }
                    })

                    put("attachments", JSONArray().apply {
                        message.attachments.forEach { attachment ->
                            put(JSONObject().apply {
                                put("id", attachment.id)
                                put("name", attachment.name)
                                put("mimeType", attachment.mimeType)
                                put("kind", attachment.kind.name)
                                put("sizeBytes", attachment.sizeBytes)
                            })
                        }
                    })
                }
            )
        }

        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putString(messagesKey(conversationId), array.toString())
            .commit()
    }

    fun loadMessages(context: Context): List<ChatMessage> {
        return loadMessages(context, "legacy")
    }

    fun loadMessages(context: Context, conversationId: String): List<ChatMessage> {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(messagesKey(conversationId), null)
            ?: if (conversationId == "legacy") context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_MESSAGES, null) else null
            ?: return emptyList()

        return runCatching {
            val array = JSONArray(raw)
            buildList {
                for (i in 0 until array.length()) {
                    val item = array.optJSONObject(i) ?: continue
                    val role = runCatching { MessageRole.valueOf(item.optString("role")) }.getOrDefault(MessageRole.AION)
                    val sources = buildList {
                        val sourceArray = item.optJSONArray("sources") ?: JSONArray()
                        for (j in 0 until sourceArray.length()) {
                            val source = sourceArray.optJSONObject(j) ?: continue
                            add(ChatSource(source.optString("title"), source.optString("url")))
                        }
                    }
                    val attachments = buildList {
                        val attachmentArray = item.optJSONArray("attachments") ?: JSONArray()
                        for (j in 0 until attachmentArray.length()) {
                            val attachment = attachmentArray.optJSONObject(j) ?: continue
                            add(
                                ChatAttachment(
                                    id = attachment.optLong("id"),
                                    name = attachment.optString("name"),
                                    mimeType = attachment.optString("mimeType"),
                                    base64Data = "",
                                    kind = runCatching { AttachmentKind.valueOf(attachment.optString("kind")) }
                                        .getOrDefault(AttachmentKind.FILE),
                                    sizeBytes = attachment.optLong("sizeBytes")
                                )
                            )
                        }
                    }
                    add(
                        ChatMessage(
                            id = item.optLong("id"),
                            role = role,
                            text = item.optString("text"),
                            modelId = item.optString("modelId").takeIf { it.isNotBlank() && it != "null" },
                            modelLabel = item.optString("modelLabel").takeIf { it.isNotBlank() && it != "null" },
                            attachments = attachments,
                            sources = sources,
                            isError = item.optBoolean("isError"),
                            isStreaming = item.optBoolean("isStreaming"),
                            wasStopped = item.optBoolean("wasStopped")
                        )
                    )
                }
            }
        }.getOrDefault(emptyList())
    }

    fun clearMessages(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .remove(KEY_MESSAGES)
            .apply()
    }

    fun saveConversations(context: Context, conversations: List<ConversationSummary>) {
        val value = JSONArray().apply {
            conversations.take(80).forEach { conversation ->
                put(JSONObject().apply {
                    put("id", conversation.id)
                    put("title", conversation.title)
                    put("updatedAt", conversation.updatedAt)
                })
            }
        }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(KEY_CONVERSATIONS, value.toString())
            .commit()
    }

    fun loadConversations(context: Context): List<ConversationSummary> {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val raw = prefs.getString(KEY_CONVERSATIONS, null)
        val saved = raw?.let {
            runCatching {
            val array = JSONArray(raw)
            buildList {
                for (index in 0 until array.length()) {
                    val item = array.optJSONObject(index) ?: continue
                    val id = item.optString("id")
                    if (id.isNotBlank()) add(
                        ConversationSummary(
                            id = id,
                            title = item.optString("title").ifBlank { "محادثة جديدة" },
                            updatedAt = item.optLong("updatedAt")
                        )
                    )
                }
            }.sortedByDescending { it.updatedAt }
            }.getOrDefault(emptyList())
        }.orEmpty()

        // إن فقد فهرس المحادثات (مثلاً بعد إيقاف التطبيق أثناء الحفظ)، لا نفقد
        // الرسائل الموجودة فعلًا: نبني الفهرس من مفاتيح المحادثات المحفوظة.
        return saved.ifEmpty { recoverConversations(context, prefs) }
    }

    private fun recoverConversations(
        context: Context,
        prefs: android.content.SharedPreferences
    ): List<ConversationSummary> {
        val ids = prefs.all.keys
            .filter { it.startsWith("messages_v2_") && it != messagesKey("legacy") }
            .map { it.removePrefix("messages_v2_") }
            .filter { it.isNotBlank() }

        return ids.mapIndexedNotNull { index, id ->
            val messages = loadMessages(context, id)
            if (messages.isEmpty()) null else ConversationSummary(
                id = id,
                title = messages.firstOrNull { it.role == MessageRole.USER }
                    ?.text?.trim()?.replace(Regex("\\s+"), " ")?.take(42)
                    ?.ifBlank { "محادثة جديدة" } ?: "محادثة جديدة",
                updatedAt = System.currentTimeMillis() - index
            )
        }
    }

    fun saveActiveConversationId(context: Context, id: String) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(KEY_ACTIVE_CONVERSATION, id)
            .commit()
    }

    fun loadActiveConversationId(context: Context): String =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_ACTIVE_CONVERSATION, "")
            .orEmpty()

    fun deleteConversation(context: Context, id: String) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .remove(messagesKey(id))
            .apply()
    }

    fun saveDraft(context: Context, draft: String) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_DRAFT, draft)
            .apply()
    }

    fun loadDraft(context: Context): String =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_DRAFT, "")
            .orEmpty()

    fun saveSelectedModel(context: Context, key: String) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_SELECTED_MODEL, key)
            .apply()
    }

    fun loadSelectedModel(context: Context): String =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_SELECTED_MODEL, "auto")
            .orEmpty()
            .ifBlank { "auto" }
}
