package com.aion.mobile.core.storage

import android.content.Context
import com.aion.mobile.model.AttachmentKind
import com.aion.mobile.model.ChatAttachment
import com.aion.mobile.model.ChatMessage
import com.aion.mobile.model.ChatSource
import com.aion.mobile.model.MessageRole
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/** وصف خفيف يظهر في درج المحادثات من دون تحميل سجل كل محادثة. */
data class ConversationSummary(
    val id: String,
    val title: String,
    val preview: String = "",
    val updatedAt: Long,
    val messageCount: Int,
    val customTitle: Boolean = false
)

/**
 * تخزين محلي للمحادثات والمسودات.
 * لا نخزن Base64 للمرفقات حتى لا يتضخم التخزين؛ نحفظ بياناتها الوصفية فقط.
 * يدعم ترحيل الجلسة الوحيدة من α6 إلى سجل محادثات متعدد من دون فقدها.
 */
object ChatSessionStore {
    private const val PREFS = "aion_chat_session"
    private const val KEY_LEGACY_MESSAGES = "messages"
    private const val KEY_LEGACY_DRAFT = "draft"
    private const val KEY_SELECTED_MODEL = "selected_model"
    private const val KEY_ACTIVE_CONVERSATION = "active_conversation_id"
    private const val KEY_CONVERSATIONS = "conversation_index_v2"
    private const val MAX_CONVERSATIONS = 40
    private const val MAX_MESSAGES_PER_CONVERSATION = 200

    fun ensureActiveConversation(context: Context): String {
        migrateLegacyIfNeeded(context)
        val prefs = prefs(context)
        val indexed = loadConversationsInternal(prefs)
        val savedActive = prefs.getString(KEY_ACTIVE_CONVERSATION, null)
        if (!savedActive.isNullOrBlank() && indexed.any { it.id == savedActive }) return savedActive
        if (indexed.isNotEmpty()) {
            val id = indexed.first().id
            prefs.edit().putString(KEY_ACTIVE_CONVERSATION, id).apply()
            return id
        }
        return createConversation(context)
    }

    fun createConversation(context: Context): String {
        migrateLegacyIfNeeded(context)
        val prefs = prefs(context)
        val id = UUID.randomUUID().toString()
        val summary = ConversationSummary(
            id = id,
            title = "محادثة جديدة",
            preview = "",
            updatedAt = System.currentTimeMillis(),
            messageCount = 0
        )
        val updated = (listOf(summary) + loadConversationsInternal(prefs))
            .distinctBy { it.id }
            .take(MAX_CONVERSATIONS)
        prefs.edit()
            .putString(KEY_CONVERSATIONS, encodeSummaries(updated).toString())
            .putString(KEY_ACTIVE_CONVERSATION, id)
            .putString(messageKey(id), "[]")
            .putString(draftKey(id), "")
            .apply()
        return id
    }

    fun setActiveConversation(context: Context, conversationId: String) {
        migrateLegacyIfNeeded(context)
        if (loadConversationsInternal(prefs(context)).none { it.id == conversationId }) return
        prefs(context).edit().putString(KEY_ACTIVE_CONVERSATION, conversationId).apply()
    }

    fun loadConversations(context: Context): List<ConversationSummary> {
        migrateLegacyIfNeeded(context)
        return loadConversationsInternal(prefs(context)).sortedByDescending { it.updatedAt }
    }

    fun saveMessages(context: Context, conversationId: String, messages: List<ChatMessage>) {
        migrateLegacyIfNeeded(context)
        val prefs = prefs(context)
        val trimmed = messages.takeLast(MAX_MESSAGES_PER_CONVERSATION)
        val array = encodeMessages(trimmed)
        val existing = loadConversationsInternal(prefs)
        val old = existing.firstOrNull { it.id == conversationId }
        val derivedTitle = deriveTitle(trimmed)
        val summary = ConversationSummary(
            id = conversationId,
            title = if (old?.customTitle == true) old.title else derivedTitle.ifBlank { old?.title ?: "محادثة جديدة" },
            preview = derivePreview(trimmed),
            updatedAt = System.currentTimeMillis(),
            messageCount = trimmed.size,
            customTitle = old?.customTitle == true
        )
        val updated = (listOf(summary) + existing.filterNot { it.id == conversationId })
            .sortedByDescending { it.updatedAt }
            .take(MAX_CONVERSATIONS)

        prefs.edit()
            .putString(messageKey(conversationId), array.toString())
            .putString(KEY_CONVERSATIONS, encodeSummaries(updated).toString())
            .apply()
    }

    fun loadMessages(context: Context, conversationId: String): List<ChatMessage> {
        migrateLegacyIfNeeded(context)
        val raw = prefs(context).getString(messageKey(conversationId), null) ?: return emptyList()
        return decodeMessages(raw)
    }

    fun clearMessages(context: Context, conversationId: String) {
        saveMessages(context, conversationId, emptyList())
    }

    fun deleteConversation(context: Context, conversationId: String): String {
        migrateLegacyIfNeeded(context)
        val prefs = prefs(context)
        loadMessages(context, conversationId)
            .flatMap { it.attachments }
            .map { it.localPath }
            .filter { it.isNotBlank() }
            .forEach { path ->
                runCatching {
                    val root = java.io.File(context.filesDir, "aion_attachments").canonicalFile
                    val file = java.io.File(path).canonicalFile
                    if (file.path.startsWith(root.path + java.io.File.separator)) file.delete()
                }
            }
        val remaining = loadConversationsInternal(prefs).filterNot { it.id == conversationId }
        val currentActive = prefs.getString(KEY_ACTIVE_CONVERSATION, null)
        val editor = prefs.edit()
            .remove(messageKey(conversationId))
            .remove(draftKey(conversationId))

        if (remaining.isEmpty()) {
            editor.putString(KEY_CONVERSATIONS, "[]").remove(KEY_ACTIVE_CONVERSATION).apply()
            return createConversation(context)
        }

        val next = if (!currentActive.isNullOrBlank() && currentActive != conversationId && remaining.any { it.id == currentActive }) {
            currentActive
        } else {
            remaining.maxByOrNull { it.updatedAt }!!.id
        }
        editor
            .putString(KEY_CONVERSATIONS, encodeSummaries(remaining).toString())
            .putString(KEY_ACTIVE_CONVERSATION, next)
            .apply()
        return next
    }

    fun renameConversation(context: Context, conversationId: String, title: String) {
        migrateLegacyIfNeeded(context)
        val prefs = prefs(context)
        val clean = title.replace(Regex("\\s+"), " ").trim().take(60)
        if (clean.isBlank()) return
        val items = loadConversationsInternal(prefs)
        val updated = items.map { item ->
            if (item.id == conversationId) item.copy(title = clean, customTitle = true, updatedAt = System.currentTimeMillis()) else item
        }.sortedByDescending { it.updatedAt }
        prefs.edit().putString(KEY_CONVERSATIONS, encodeSummaries(updated).toString()).apply()
    }

    fun saveDraft(context: Context, conversationId: String, draft: String) {
        prefs(context).edit().putString(draftKey(conversationId), draft).apply()
    }

    fun loadDraft(context: Context, conversationId: String): String =
        prefs(context).getString(draftKey(conversationId), "").orEmpty()

    fun saveSelectedModel(context: Context, key: String) {
        prefs(context).edit().putString(KEY_SELECTED_MODEL, key).apply()
    }

    fun loadSelectedModel(context: Context): String =
        prefs(context).getString(KEY_SELECTED_MODEL, "auto").orEmpty().ifBlank { "auto" }

    private fun deriveTitle(messages: List<ChatMessage>): String {
        val firstUser = messages.firstOrNull { it.role == MessageRole.USER }
        val source = firstUser?.text?.trim().orEmpty().ifBlank {
            firstUser?.attachments?.firstOrNull()?.name.orEmpty()
        }
        return source.replace(Regex("\\s+"), " ").trim().take(46)
    }

    private fun derivePreview(messages: List<ChatMessage>): String {
        val last = messages.lastOrNull { it.text.isNotBlank() } ?: return ""
        val clean = last.text.replace(Regex("\\s+"), " ").trim()
        return if (clean.length <= 74) clean else clean.take(73).trimEnd() + "…"
    }

    private fun encodeMessages(messages: List<ChatMessage>): JSONArray = JSONArray().apply {
        messages.forEach { message ->
            put(
                JSONObject().apply {
                    put("id", message.id)
                    put("role", message.role.name)
                    put("text", message.text)
                    put("modelId", message.modelId ?: JSONObject.NULL)
                    put("modelLabel", message.modelLabel ?: JSONObject.NULL)
                    put("isError", message.isError)
                    put("isStreaming", message.isStreaming)
                    put("wasStopped", message.wasStopped)

                    put("sources", JSONArray().apply {
                        message.sources.forEach { source ->
                            put(JSONObject().apply {
                                put("title", source.title)
                                put("url", source.url)
                            })
                        }
                    })

                    put("attachments", JSONArray().apply {
                        message.attachments.forEach { attachment ->
                            put(JSONObject().apply {
                                put("id", attachment.id)
                                put("name", attachment.name)
                                put("mimeType", attachment.mimeType)
                                put("kind", attachment.kind.name)
                                put("sizeBytes", attachment.sizeBytes)
                                put("localPath", attachment.localPath)
                            })
                        }
                    })
                }
            )
        }
    }

    private fun decodeMessages(raw: String): List<ChatMessage> = runCatching {
        val array = JSONArray(raw)
        buildList {
            for (i in 0 until array.length()) {
                val item = array.optJSONObject(i) ?: continue
                val role = runCatching { MessageRole.valueOf(item.optString("role")) }
                    .getOrDefault(MessageRole.AION)
                val sources = buildList {
                    val sourceArray = item.optJSONArray("sources") ?: JSONArray()
                    for (j in 0 until sourceArray.length()) {
                        val source = sourceArray.optJSONObject(j) ?: continue
                        add(ChatSource(source.optString("title"), source.optString("url")))
                    }
                }
                val attachments = buildList {
                    val attachmentArray = item.optJSONArray("attachments") ?: JSONArray()
                    for (j in 0 until attachmentArray.length()) {
                        val attachment = attachmentArray.optJSONObject(j) ?: continue
                        add(
                            ChatAttachment(
                                id = attachment.optLong("id"),
                                name = attachment.optString("name"),
                                mimeType = attachment.optString("mimeType"),
                                base64Data = "",
                                kind = runCatching { AttachmentKind.valueOf(attachment.optString("kind")) }
                                    .getOrDefault(AttachmentKind.FILE),
                                sizeBytes = attachment.optLong("sizeBytes"),
                                localPath = attachment.optString("localPath")
                            )
                        )
                    }
                }
                add(
                    ChatMessage(
                        id = item.optLong("id"),
                        role = role,
                        text = item.optString("text"),
                        modelId = item.optString("modelId").takeIf { it.isNotBlank() && it != "null" },
                        modelLabel = item.optString("modelLabel").takeIf { it.isNotBlank() && it != "null" },
                        attachments = attachments,
                        sources = sources,
                        isError = item.optBoolean("isError"),
                        isStreaming = item.optBoolean("isStreaming"),
                        wasStopped = item.optBoolean("wasStopped")
                    )
                )
            }
        }
    }.getOrDefault(emptyList())

    private fun encodeSummaries(items: List<ConversationSummary>): JSONArray = JSONArray().apply {
        items.forEach { item ->
            put(JSONObject().apply {
                put("id", item.id)
                put("title", item.title)
                put("preview", item.preview)
                put("updatedAt", item.updatedAt)
                put("messageCount", item.messageCount)
                put("customTitle", item.customTitle)
            })
        }
    }

    private fun loadConversationsInternal(prefs: android.content.SharedPreferences): List<ConversationSummary> {
        val raw = prefs.getString(KEY_CONVERSATIONS, null) ?: return emptyList()
        return runCatching {
            val array = JSONArray(raw)
            buildList {
                for (i in 0 until array.length()) {
                    val item = array.optJSONObject(i) ?: continue
                    val id = item.optString("id").trim()
                    if (id.isBlank()) continue
                    add(
                        ConversationSummary(
                            id = id,
                            title = item.optString("title").ifBlank { "محادثة" },
                            preview = item.optString("preview"),
                            updatedAt = item.optLong("updatedAt"),
                            messageCount = item.optInt("messageCount"),
                            customTitle = item.optBoolean("customTitle", false)
                        )
                    )
                }
            }
        }.getOrDefault(emptyList())
    }

    private fun migrateLegacyIfNeeded(context: Context) {
        val prefs = prefs(context)
        if (prefs.contains(KEY_CONVERSATIONS)) return
        val legacyRaw = prefs.getString(KEY_LEGACY_MESSAGES, null)
        val legacyDraft = prefs.getString(KEY_LEGACY_DRAFT, "").orEmpty()
        if (legacyRaw.isNullOrBlank()) {
            prefs.edit().putString(KEY_CONVERSATIONS, "[]").apply()
            return
        }

        val id = "migrated-alpha6"
        val messages = decodeMessages(legacyRaw)
        val summary = ConversationSummary(
            id = id,
            title = deriveTitle(messages).ifBlank { "المحادثة السابقة" },
            preview = derivePreview(messages),
            updatedAt = System.currentTimeMillis(),
            messageCount = messages.size
        )
        prefs.edit()
            .putString(KEY_CONVERSATIONS, encodeSummaries(listOf(summary)).toString())
            .putString(KEY_ACTIVE_CONVERSATION, id)
            .putString(messageKey(id), legacyRaw)
            .putString(draftKey(id), legacyDraft)
            .remove(KEY_LEGACY_MESSAGES)
            .remove(KEY_LEGACY_DRAFT)
            .apply()
    }

    private fun messageKey(id: String) = "messages_v2_$id"
    private fun draftKey(id: String) = "draft_v2_$id"
    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
}
