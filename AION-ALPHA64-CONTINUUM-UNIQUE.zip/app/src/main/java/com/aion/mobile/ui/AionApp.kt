package com.aion.mobile.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.widget.Toast
import android.util.Base64
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.ArrowUpward
import androidx.compose.material.icons.outlined.Build
import androidx.compose.material.icons.outlined.Call
import androidx.compose.material.icons.outlined.Check
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.ContentCopy
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.Folder
import androidx.compose.material.icons.outlined.Image
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.KeyboardArrowDown
import androidx.compose.material.icons.outlined.Memory
import androidx.compose.material.icons.outlined.Menu
import androidx.compose.material.icons.outlined.Mic
import androidx.compose.material.icons.outlined.MoreHoriz
import androidx.compose.material.icons.outlined.Psychology
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.SmartToy
import androidx.compose.material.icons.outlined.Stop
import androidx.compose.material.icons.outlined.VolumeUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.produceState
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import com.aion.mobile.core.AionCapability
import com.aion.mobile.core.CapabilityState
import com.aion.mobile.core.FeatureRegistry
import com.aion.mobile.core.ai.GatewayActivity
import com.aion.mobile.core.files.AttachmentLoader
import com.aion.mobile.core.project.AionProject
import com.aion.mobile.core.storage.ConversationSummary
import com.aion.mobile.core.voice.SpeechText
import com.aion.mobile.feature.chat.AiModelOption
import com.aion.mobile.feature.chat.ChatViewModel
import com.aion.mobile.model.AttachmentKind
import com.aion.mobile.model.ChatAttachment
import com.aion.mobile.model.ChatMessage
import com.aion.mobile.model.ChatSource
import com.aion.mobile.model.MessageRole
import com.aion.mobile.ui.theme.AionBlueSoft
import com.aion.mobile.ui.theme.AionPurple
import com.aion.mobile.ui.theme.AionPurpleSoft
import com.aion.mobile.ui.theme.AionPurpleStrong
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Locale

@Composable
fun AionApp(chatViewModel: ChatViewModel = viewModel()) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
        val scope = rememberCoroutineScope()
        var selectedCapability by remember { mutableStateOf<AionCapability?>(null) }
        var showSettings by remember { mutableStateOf(false) }
        var showModelPicker by remember { mutableStateOf(false) }
        var showContext by remember { mutableStateOf(false) }
        var showVoiceCall by remember { mutableStateOf(false) }

        ModalNavigationDrawer(
            drawerState = drawerState,
            drawerContent = {
                AionDrawer(
                    conversations = chatViewModel.conversations,
                    archivedConversations = chatViewModel.archivedConversations,
                    projects = chatViewModel.projects,
                    activeConversationId = chatViewModel.activeConversationId,
                    activeProjectId = chatViewModel.activeProject?.id,
                    isSending = chatViewModel.isSending,
                    onConversationClick = { conversationId ->
                        chatViewModel.switchConversation(conversationId)
                        scope.launch { drawerState.close() }
                    },
                    onConversationRename = chatViewModel::renameConversation,
                    onConversationShare = chatViewModel::shareConversation,
                    onConversationDelete = chatViewModel::deleteConversation,
                    onConversationPin = chatViewModel::togglePinned,
                    onConversationArchive = chatViewModel::archiveConversation,
                    onConversationRestore = chatViewModel::restoreConversation,
                    onConversationMove = chatViewModel::moveConversationToProject,
                    onProjectClick = { projectId ->
                        chatViewModel.openProject(projectId)
                        scope.launch { drawerState.close() }
                    },
                    onProjectCreate = chatViewModel::createProject,
                    onProjectUpdate = chatViewModel::updateProject,
                    onProjectDelete = chatViewModel::deleteProject,
                    onCapabilityClick = { capability ->
                        if (capability.key == "memory") showSettings = true
                        else selectedCapability = capability
                        scope.launch { drawerState.close() }
                    },
                    onNewChat = { projectId ->
                        chatViewModel.newConversation(projectId)
                        scope.launch { drawerState.close() }
                    },
                    onContext = {
                        showContext = true
                        scope.launch { drawerState.close() }
                    },
                    onSettings = {
                        showSettings = true
                        scope.launch { drawerState.close() }
                    }
                )
            }
        ) {
            AionChatScreen(
                messages = chatViewModel.messages,
                pendingAttachments = chatViewModel.pendingAttachments,
                onSend = chatViewModel::send,
                onStop = chatViewModel::stopGeneration,
                onRetry = chatViewModel::retryResponse,
                onEditMessage = chatViewModel::editAndResend,
                onRememberMessage = chatViewModel::rememberText,
                onAddAttachments = chatViewModel::addAttachments,
                onRemoveAttachment = chatViewModel::removeAttachment,
                onMenu = { scope.launch { drawerState.open() } },
                onNewChat = { chatViewModel.newConversation() },
                onModelPicker = { showModelPicker = true },
                onStartVoiceCall = { showVoiceCall = true },
                selectedModel = chatViewModel.selectedModel,
                activeProjectName = chatViewModel.activeProject?.name,
                isConfigured = chatViewModel.isConfigured,
                isSending = chatViewModel.isSending,
                activity = chatViewModel.activity,
                draft = chatViewModel.draft,
                onDraftChange = chatViewModel::updateDraft
            )
        }

        selectedCapability?.let { capability ->
            CapabilityDialog(capability = capability, onDismiss = { selectedCapability = null })
        }

        if (showSettings) {
            SettingsDialog(
                initialEndpoint = chatViewModel.cloudEndpoint,
                initialInstructions = chatViewModel.customInstructions,
                initialMemory = chatViewModel.memoryNotes,
                cloudHealthLabel = chatViewModel.cloudHealthLabel,
                cloudHealthOk = chatViewModel.cloudHealthOk,
                isCheckingCloud = chatViewModel.isCheckingCloud,
                onCheckCloud = chatViewModel::checkCloudConnection,
                onSave = { endpoint, instructions, memory ->
                    chatViewModel.saveSettings(endpoint)
                    chatViewModel.savePersonalization(instructions, memory)
                    showSettings = false
                },
                onDismiss = { showSettings = false }
            )
        }

        if (showModelPicker) {
            ModelPickerSheet(
                options = chatViewModel.modelOptions,
                selectedKey = chatViewModel.selectedModelKey,
                onSelect = {
                    chatViewModel.selectModel(it)
                    showModelPicker = false
                },
                onDismiss = { showModelPicker = false }
            )
        }

        if (showContext) {
            ContextSheet(
                messageCount = chatViewModel.messages.size,
                selectedModel = chatViewModel.selectedModel,
                isConfigured = chatViewModel.isConfigured,
                cloudHealthLabel = chatViewModel.cloudHealthLabel,
                cloudHealthOk = chatViewModel.cloudHealthOk,
                pendingAttachments = chatViewModel.pendingAttachments.size,
                memoryEnabled = chatViewModel.customInstructions.isNotBlank() || chatViewModel.memoryNotes.isNotBlank(),
                projectName = chatViewModel.activeProject?.name,
                onDismiss = { showContext = false }
            )
        }

        if (showVoiceCall) {
            VoiceCallOverlay(
                messages = chatViewModel.messages,
                isSending = chatViewModel.isSending,
                activity = chatViewModel.activity,
                onSend = chatViewModel::send,
                onStop = chatViewModel::stopGeneration,
                onDismiss = { showVoiceCall = false }
            )
        }
    }
}

private fun normalizeLocalSearch(value: String): String = value
    .trim()
    .lowercase()
    .replace(Regex("[\u064B-\u065F\u0670]"), "")
    .replace('إ', 'ا')
    .replace('أ', 'ا')
    .replace('آ', 'ا')
    .replace('ى', 'ي')
    .replace('ة', 'ه')
    .replace(Regex("\\s+"), " ")

@Composable
private fun AionDrawer(
    conversations: List<ConversationSummary>,
    archivedConversations: List<ConversationSummary>,
    projects: List<AionProject>,
    activeConversationId: String,
    activeProjectId: String?,
    isSending: Boolean,
    onConversationClick: (String) -> Unit,
    onConversationRename: (String, String) -> Unit,
    onConversationShare: (String) -> Unit,
    onConversationDelete: (String) -> Unit,
    onConversationPin: (String) -> Unit,
    onConversationArchive: (String) -> Unit,
    onConversationRestore: (String) -> Unit,
    onConversationMove: (String, String?) -> Unit,
    onProjectClick: (String) -> Unit,
    onProjectCreate: (String, String) -> Unit,
    onProjectUpdate: (AionProject) -> Unit,
    onProjectDelete: (String) -> Unit,
    onCapabilityClick: (AionCapability) -> Unit,
    onNewChat: (String?) -> Unit,
    onContext: () -> Unit,
    onSettings: () -> Unit
) {
    var query by remember { mutableStateOf("") }
    var showCreateProject by remember { mutableStateOf(false) }
    var showArchived by remember { mutableStateOf(false) }
    var newProjectName by remember { mutableStateOf("") }
    var newProjectInstructions by remember { mutableStateOf("") }

    val normalizedQuery = normalizeLocalSearch(query)
    val projectSnapshot = projects.toList()
    val conversationSnapshot = conversations.toList()
    val projectNames = remember(projectSnapshot) { projectSnapshot.associate { it.id to it.name } }
    val normalizedProjectNames = remember(projectSnapshot) {
        projectSnapshot.associate { it.id to normalizeLocalSearch(it.name) }
    }
    // التطبيع العربي لنصوص آلاف الأحرف مكلف إذا تكرر مع كل ضغطة مفتاح.
    // نحسب مفتاح البحث مرة عند تغير قائمة المحادثات ثم نبحث داخله فقط أثناء الكتابة.
    val conversationSearchKeys = remember(conversationSnapshot) {
        conversationSnapshot.associate { conversation ->
            conversation.id to normalizeLocalSearch(
                buildString {
                    append(conversation.title).append('\n')
                    append(conversation.preview).append('\n')
                    append(conversation.searchText)
                }
            )
        }
    }
    val filtered = remember(conversationSnapshot, normalizedProjectNames, conversationSearchKeys, normalizedQuery) {
        if (normalizedQuery.isBlank()) conversationSnapshot
        else conversationSnapshot.filter { conversation ->
            conversationSearchKeys[conversation.id].orEmpty().contains(normalizedQuery) ||
                conversation.projectId?.let { normalizedProjectNames[it] }?.contains(normalizedQuery) == true
        }
    }

    ModalDrawerSheet(
        modifier = Modifier.fillMaxHeight().width(336.dp),
        drawerContainerColor = Color(0xFF0F0F13)
    ) {
        Spacer(Modifier.height(10.dp))
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            AionMark(size = 32.dp)
            Spacer(Modifier.width(10.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text("AION", fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
                Text(
                    activeProjectId?.let { projectNames[it] } ?: "المساعد الذكي",
                    color = if (activeProjectId != null) AionPurpleSoft else MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 10.sp,
                    maxLines = 1
                )
            }
            Surface(
                onClick = { onNewChat(activeProjectId) },
                enabled = !isSending,
                shape = CircleShape,
                color = Color(0xFF1B1921),
                modifier = Modifier.size(38.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(Icons.Outlined.Add, contentDescription = "محادثة جديدة", modifier = Modifier.size(20.dp))
                }
            }
        }

        Surface(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp),
            shape = RoundedCornerShape(17.dp),
            color = Color(0xFF17171C),
            border = BorderStroke(1.dp, Color(0xFF29272F))
        ) {
            Row(
                modifier = Modifier.fillMaxWidth().defaultMinSize(minHeight = 44.dp).padding(start = 11.dp, end = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    Icons.Outlined.Search,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp),
                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.width(8.dp))
                BasicTextField(
                    value = query,
                    onValueChange = { query = it },
                    modifier = Modifier.weight(1f),
                    singleLine = true,
                    textStyle = MaterialTheme.typography.bodyMedium.copy(color = MaterialTheme.colorScheme.onSurface),
                    decorationBox = { inner ->
                        Box {
                            if (query.isBlank()) {
                                Text("ابحث في المحادثات", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            inner()
                        }
                    }
                )
                if (query.isNotBlank()) {
                    IconButton(onClick = { query = "" }, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Outlined.Close, contentDescription = "مسح البحث", modifier = Modifier.size(15.dp))
                    }
                }
            }
        }

        if (normalizedQuery.isBlank()) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(start = 18.dp, end = 10.dp, top = 8.dp, bottom = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "المشاريع",
                    modifier = Modifier.weight(1f),
                    fontSize = 10.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                IconButton(
                    onClick = { showCreateProject = true },
                    enabled = !isSending,
                    modifier = Modifier.size(30.dp)
                ) {
                    Icon(Icons.Outlined.Add, contentDescription = "مشروع جديد", modifier = Modifier.size(17.dp))
                }
            }

            if (projects.isEmpty()) {
                Surface(
                    onClick = { showCreateProject = true },
                    shape = RoundedCornerShape(14.dp),
                    color = Color(0xFF13131A),
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 2.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Outlined.Folder, contentDescription = null, modifier = Modifier.size(18.dp), tint = AionPurpleSoft)
                        Spacer(Modifier.width(8.dp))
                        Column {
                            Text("أنشئ مشروعًا", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                            Text("محادثات + تعليمات + ذاكرة مستقلة", fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            } else {
                projects.take(6).forEach { project ->
                    ProjectDrawerEntry(
                        project = project,
                        selected = project.id == activeProjectId,
                        enabled = !isSending,
                        onOpen = { onProjectClick(project.id) },
                        onNewChat = { onNewChat(project.id) },
                        onUpdate = onProjectUpdate,
                        onDelete = { onProjectDelete(project.id) }
                    )
                }
            }
        }

        Text(
            if (normalizedQuery.isBlank()) "المحادثات" else "نتائج البحث",
            modifier = Modifier.padding(horizontal = 18.dp, vertical = 7.dp),
            fontSize = 10.sp,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        if (filtered.isEmpty()) {
            Column(
                modifier = Modifier.weight(1f).fillMaxWidth().padding(horizontal = 22.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Icon(Icons.Outlined.Search, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(8.dp))
                Text(
                    if (conversations.isEmpty()) "ابدأ محادثة وسيظهر سجلها هنا" else "لا توجد نتائج مطابقة",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 12.sp,
                    textAlign = TextAlign.Center
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f).fillMaxWidth(),
                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                verticalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                items(filtered, key = { it.id }) { conversation ->
                    ConversationDrawerEntry(
                        conversation = conversation,
                        projectName = conversation.projectId?.let { projectNames[it] },
                        projects = projects,
                        selected = conversation.id == activeConversationId,
                        enabled = !isSending,
                        onClick = { onConversationClick(conversation.id) },
                        onRename = { title -> onConversationRename(conversation.id, title) },
                        onShare = { onConversationShare(conversation.id) },
                        onPin = { onConversationPin(conversation.id) },
                        onArchive = { onConversationArchive(conversation.id) },
                        onMove = { projectId -> onConversationMove(conversation.id, projectId) },
                        onDelete = { onConversationDelete(conversation.id) }
                    )
                }
            }
        }

        HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.35f))
        DrawerEntry(
            Icons.Outlined.Description,
            "الأرشيف",
            if (archivedConversations.isEmpty()) "لا توجد محادثات مؤرشفة" else "${archivedConversations.size} محادثة",
            onClick = { showArchived = true }
        )
        DrawerEntry(Icons.Outlined.SmartToy, "الوكلاء", "مهام متعددة الخطوات", onClick = {
            FeatureRegistry.capabilities.firstOrNull { it.key == "agent" }?.let(onCapabilityClick)
        })
        DrawerEntry(Icons.Outlined.Memory, "الذاكرة", "تفضيلات وقرارات وسياق", onClick = {
            FeatureRegistry.capabilities.firstOrNull { it.key == "memory" }?.let(onCapabilityClick)
        })
        DrawerEntry(Icons.Outlined.Info, "سياق المحادثة", "ما الذي يستخدمه AION الآن", onContext)
        HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.25f))
        DrawerEntry(Icons.Outlined.Settings, "الإعدادات", null, onSettings)
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 9.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("AION Mobile", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 10.sp)
            Text("α7.2.1", color = AionPurpleSoft, fontSize = 10.sp)
        }
    }

    if (showArchived) {
        AlertDialog(
            onDismissRequest = { showArchived = false },
            title = { Text("الأرشيف") },
            text = {
                if (archivedConversations.isEmpty()) {
                    Text("لا توجد محادثات مؤرشفة حاليًا.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                } else {
                    LazyColumn(
                        modifier = Modifier.fillMaxWidth().height(360.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        items(archivedConversations, key = { it.id }) { conversation ->
                            Surface(
                                shape = RoundedCornerShape(14.dp),
                                color = Color(0xFF15151C),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(conversation.title, fontSize = 12.sp, maxLines = 1, fontWeight = FontWeight.SemiBold)
                                        if (conversation.preview.isNotBlank()) {
                                            Text(
                                                conversation.preview,
                                                fontSize = 9.sp,
                                                maxLines = 1,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }
                                    TextButton(
                                        enabled = !isSending,
                                        onClick = { onConversationRestore(conversation.id) }
                                    ) { Text("استعادة") }
                                    IconButton(
                                        enabled = !isSending,
                                        onClick = { onConversationDelete(conversation.id) },
                                        modifier = Modifier.size(34.dp)
                                    ) {
                                        Icon(Icons.Outlined.DeleteOutline, contentDescription = "حذف", modifier = Modifier.size(18.dp))
                                    }
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showArchived = false }) { Text("إغلاق") } }
        )
    }

    if (showCreateProject) {
        AlertDialog(
            onDismissRequest = { showCreateProject = false },
            title = { Text("مشروع جديد") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = newProjectName,
                        onValueChange = { newProjectName = it.take(60) },
                        label = { Text("اسم المشروع") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = newProjectInstructions,
                        onValueChange = { newProjectInstructions = it.take(6_000) },
                        label = { Text("تعليمات المشروع") },
                        minLines = 3,
                        maxLines = 6,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        if (newProjectName.isNotBlank()) {
                            onProjectCreate(newProjectName, newProjectInstructions)
                            newProjectName = ""
                            newProjectInstructions = ""
                            showCreateProject = false
                        }
                    }
                ) { Text("إنشاء") }
            },
            dismissButton = { TextButton(onClick = { showCreateProject = false }) { Text("إلغاء") } }
        )
    }
}

@Composable
private fun ProjectDrawerEntry(
    project: AionProject,
    selected: Boolean,
    enabled: Boolean,
    onOpen: () -> Unit,
    onNewChat: () -> Unit,
    onUpdate: (AionProject) -> Unit,
    onDelete: () -> Unit
) {
    var menuExpanded by remember(project.id) { mutableStateOf(false) }
    var showEdit by remember(project.id) { mutableStateOf(false) }
    var showDeleteConfirm by remember(project.id) { mutableStateOf(false) }
    var name by remember(project.id, project.name) { mutableStateOf(project.name) }
    var instructions by remember(project.id, project.instructions) { mutableStateOf(project.instructions) }
    var projectMemory by remember(project.id, project.memoryNotes) { mutableStateOf(project.memoryNotes) }
    var projectOnlyMemory by remember(project.id, project.projectOnlyMemory) { mutableStateOf(project.projectOnlyMemory) }

    Surface(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 1.dp).clickable(enabled = enabled, onClick = onOpen),
        shape = RoundedCornerShape(13.dp),
        color = if (selected) Color(0xFF1B1527) else Color.Transparent,
        border = if (selected) BorderStroke(1.dp, AionPurple.copy(alpha = 0.22f)) else null
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(start = 10.dp, end = 2.dp, top = 7.dp, bottom = 7.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Outlined.Folder, contentDescription = null, modifier = Modifier.size(18.dp), tint = if (selected) AionPurpleSoft else MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.width(8.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(project.name, fontSize = 12.sp, maxLines = 1, fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal)
                val memoryCount = project.memoryNotes.lineSequence().count { it.isNotBlank() }
                val scopeLabel = if (project.projectOnlyMemory) "ذاكرة معزولة" else "ذاكرة مشتركة"
                Text(
                    buildString {
                        append(scopeLabel)
                        if (memoryCount > 0) append(" • ").append(memoryCount).append(" محفوظات")
                        else if (project.instructions.isNotBlank()) append(" • تعليمات مفعّلة")
                    },
                    fontSize = 9.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            IconButton(onClick = onNewChat, enabled = enabled, modifier = Modifier.size(30.dp)) {
                Icon(Icons.Outlined.Add, contentDescription = "محادثة جديدة داخل المشروع", modifier = Modifier.size(16.dp))
            }
            Box {
                IconButton(onClick = { menuExpanded = true }, enabled = enabled, modifier = Modifier.size(30.dp)) {
                    Icon(Icons.Outlined.MoreHoriz, contentDescription = "خيارات المشروع", modifier = Modifier.size(16.dp))
                }
                DropdownMenu(expanded = menuExpanded, onDismissRequest = { menuExpanded = false }) {
                    DropdownMenuItem(
                        text = { Text("إعدادات المشروع") },
                        leadingIcon = { Icon(Icons.Outlined.Settings, contentDescription = null) },
                        onClick = {
                            menuExpanded = false
                            name = project.name
                            instructions = project.instructions
                            projectMemory = project.memoryNotes
                            projectOnlyMemory = project.projectOnlyMemory
                            showEdit = true
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("حذف المشروع") },
                        leadingIcon = { Icon(Icons.Outlined.DeleteOutline, contentDescription = null) },
                        onClick = {
                            menuExpanded = false
                            showDeleteConfirm = true
                        }
                    )
                }
            }
        }
    }

    if (showEdit) {
        AlertDialog(
            onDismissRequest = { showEdit = false },
            title = { Text("إعدادات المشروع") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it.take(60) },
                        label = { Text("الاسم") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = instructions,
                        onValueChange = { instructions = it.take(6_000) },
                        label = { Text("تعليمات المشروع") },
                        minLines = 3,
                        maxLines = 7,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = projectMemory,
                        onValueChange = { projectMemory = it.take(16_000) },
                        label = { Text("ذاكرة المشروع") },
                        supportingText = {
                            Text("زر «تذكّر» داخل أي محادثة في هذا المشروع يضيف هنا، حتى لو كانت الذاكرة العامة مسموحة أيضًا.")
                        },
                        minLines = 3,
                        maxLines = 7,
                        modifier = Modifier.fillMaxWidth()
                    )
                    if (projectMemory.isNotBlank()) {
                        TextButton(onClick = { projectMemory = "" }) {
                            Text("مسح ذاكرة المشروع", color = MaterialTheme.colorScheme.error)
                        }
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("ذاكرة خاصة بالمشروع", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                            Text(
                                "عند تفعيلها لا تستخدم الذاكرة العامة داخل هذا المشروع.",
                                fontSize = 9.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(
                            checked = projectOnlyMemory,
                            onCheckedChange = { projectOnlyMemory = it }
                        )
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (name.isNotBlank()) onUpdate(
                        project.copy(
                            name = name,
                            instructions = instructions,
                            memoryNotes = projectMemory,
                            projectOnlyMemory = projectOnlyMemory
                        )
                    )
                    showEdit = false
                }) { Text("حفظ") }
            },
            dismissButton = { TextButton(onClick = { showEdit = false }) { Text("إلغاء") } }
        )
    }

    if (showDeleteConfirm) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirm = false },
            title = { Text("حذف المشروع؟") },
            text = { Text("لن تُحذف المحادثات؛ ستعود إلى قائمة المحادثات العامة.") },
            confirmButton = {
                TextButton(onClick = {
                    showDeleteConfirm = false
                    onDelete()
                }) { Text("حذف", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = { TextButton(onClick = { showDeleteConfirm = false }) { Text("إلغاء") } }
        )
    }
}

@Composable
private fun ConversationDrawerEntry(
    conversation: ConversationSummary,
    projectName: String?,
    projects: List<AionProject>,
    selected: Boolean,
    enabled: Boolean,
    onClick: () -> Unit,
    onRename: (String) -> Unit,
    onShare: () -> Unit,
    onPin: () -> Unit,
    onArchive: () -> Unit,
    onMove: (String?) -> Unit,
    onDelete: () -> Unit
) {
    var menuExpanded by remember(conversation.id) { mutableStateOf(false) }
    var showRename by remember(conversation.id) { mutableStateOf(false) }
    var showDeleteConfirm by remember(conversation.id) { mutableStateOf(false) }
    var showMove by remember(conversation.id) { mutableStateOf(false) }
    var renameValue by remember(conversation.id, conversation.title) { mutableStateOf(conversation.title) }

    Surface(
        modifier = Modifier.fillMaxWidth().clickable(enabled = enabled, onClick = onClick),
        shape = RoundedCornerShape(14.dp),
        color = if (selected) Color(0xFF1D1826) else Color.Transparent,
        border = if (selected) BorderStroke(1.dp, AionPurple.copy(alpha = 0.18f)) else null
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(start = 11.dp, end = 3.dp, top = 8.dp, bottom = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(
                    if (projectName != null) Icons.Outlined.Folder else Icons.Outlined.ChatBubbleOutline,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp),
                    tint = if (selected) AionPurpleSoft else MaterialTheme.colorScheme.onSurfaceVariant
                )
                if (conversation.pinned) {
                    Box(
                        Modifier
                            .align(Alignment.TopStart)
                            .size(6.dp)
                            .clip(CircleShape)
                            .background(AionPurple)
                    )
                }
            }
            Spacer(Modifier.width(8.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(conversation.title, fontSize = 12.sp, maxLines = 1, fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal)
                val subtitle = when {
                    projectName != null && conversation.preview.isNotBlank() -> "$projectName • ${conversation.preview}"
                    projectName != null -> projectName
                    else -> conversation.preview
                }
                if (subtitle.isNotBlank()) {
                    Text(
                        subtitle,
                        fontSize = 9.sp,
                        maxLines = 1,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            Box {
                IconButton(onClick = { menuExpanded = true }, enabled = enabled, modifier = Modifier.size(32.dp)) {
                    Icon(
                        Icons.Outlined.MoreHoriz,
                        contentDescription = "خيارات المحادثة",
                        modifier = Modifier.size(17.dp),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                DropdownMenu(expanded = menuExpanded, onDismissRequest = { menuExpanded = false }) {
                    DropdownMenuItem(
                        text = { Text(if (conversation.pinned) "إلغاء التثبيت" else "تثبيت") },
                        leadingIcon = { Icon(Icons.Outlined.Check, contentDescription = null) },
                        onClick = {
                            menuExpanded = false
                            onPin()
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("نقل إلى مشروع") },
                        leadingIcon = { Icon(Icons.Outlined.Folder, contentDescription = null) },
                        onClick = {
                            menuExpanded = false
                            showMove = true
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("إعادة التسمية") },
                        leadingIcon = { Icon(Icons.Outlined.Edit, contentDescription = null) },
                        onClick = {
                            menuExpanded = false
                            renameValue = conversation.title
                            showRename = true
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("مشاركة") },
                        leadingIcon = { Icon(Icons.Outlined.Description, contentDescription = null) },
                        onClick = {
                            menuExpanded = false
                            onShare()
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("أرشفة") },
                        leadingIcon = { Icon(Icons.Outlined.Close, contentDescription = null) },
                        onClick = {
                            menuExpanded = false
                            onArchive()
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("حذف") },
                        leadingIcon = { Icon(Icons.Outlined.DeleteOutline, contentDescription = null) },
                        onClick = {
                            menuExpanded = false
                            showDeleteConfirm = true
                        }
                    )
                }
            }
        }
    }

    if (showRename) {
        AlertDialog(
            onDismissRequest = { showRename = false },
            title = { Text("إعادة تسمية المحادثة") },
            text = {
                OutlinedTextField(
                    value = renameValue,
                    onValueChange = { renameValue = it.take(60) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        if (renameValue.isNotBlank()) onRename(renameValue)
                        showRename = false
                    }
                ) { Text("حفظ") }
            },
            dismissButton = { TextButton(onClick = { showRename = false }) { Text("إلغاء") } }
        )
    }

    if (showMove) {
        AlertDialog(
            onDismissRequest = { showMove = false },
            title = { Text("نقل إلى مشروع") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Surface(
                        onClick = {
                            onMove(null)
                            showMove = false
                        },
                        shape = RoundedCornerShape(12.dp),
                        color = if (conversation.projectId == null) Color(0xFF21172F) else Color(0xFF15151B)
                    ) {
                        Text("بدون مشروع", modifier = Modifier.fillMaxWidth().padding(12.dp), fontSize = 12.sp)
                    }
                    projects.forEach { project ->
                        Surface(
                            onClick = {
                                onMove(project.id)
                                showMove = false
                            },
                            shape = RoundedCornerShape(12.dp),
                            color = if (conversation.projectId == project.id) Color(0xFF21172F) else Color(0xFF15151B)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Outlined.Folder, contentDescription = null, modifier = Modifier.size(16.dp), tint = AionPurpleSoft)
                                Spacer(Modifier.width(8.dp))
                                Text(project.name, fontSize = 12.sp)
                            }
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { showMove = false }) { Text("إلغاء") } }
        )
    }

    if (showDeleteConfirm) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirm = false },
            title = { Text("حذف المحادثة؟") },
            text = { Text("سيُحذف سجل هذه المحادثة من الجهاز.") },
            confirmButton = {
                TextButton(
                    onClick = {
                        showDeleteConfirm = false
                        onDelete()
                    }
                ) { Text("حذف", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = { TextButton(onClick = { showDeleteConfirm = false }) { Text("إلغاء") } }
        )
    }
}

@Composable
private fun DrawerEntry(icon: ImageVector, title: String, subtitle: String?, onClick: () -> Unit) {
    NavigationDrawerItem(
        label = {
            Column {
                Text(title, fontSize = 14.sp)
                if (!subtitle.isNullOrBlank()) {
                    Text(subtitle, fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        },
        selected = false,
        onClick = onClick,
        icon = { Icon(icon, contentDescription = null, modifier = Modifier.size(21.dp)) },
        modifier = Modifier.padding(horizontal = 8.dp, vertical = 1.dp)
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AionChatScreen(
    messages: List<ChatMessage>,
    pendingAttachments: List<ChatAttachment>,
    onSend: (String) -> Unit,
    onStop: () -> Unit,
    onRetry: (Long) -> Unit,
    onEditMessage: (Long, String) -> Unit,
    onRememberMessage: (String) -> Unit,
    onAddAttachments: (List<ChatAttachment>) -> Unit,
    onRemoveAttachment: (Long) -> Unit,
    onMenu: () -> Unit,
    onNewChat: () -> Unit,
    onModelPicker: () -> Unit,
    onStartVoiceCall: () -> Unit,
    selectedModel: AiModelOption,
    activeProjectName: String?,
    isConfigured: Boolean,
    isSending: Boolean,
    activity: GatewayActivity?,
    draft: String,
    onDraftChange: (String) -> Unit
) {
    val context = LocalContext.current
    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }

    LaunchedEffect(isSending) {
        if (
            isSending &&
            Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    var ttsEngine by remember { mutableStateOf<TextToSpeech?>(null) }

    DisposableEffect(context) {
        var engine: TextToSpeech? = null
        engine = runCatching {
            TextToSpeech(context.applicationContext) { status ->
                val ready = engine ?: return@TextToSpeech
                if (status == TextToSpeech.SUCCESS) {
                    // بعض محركات TTS المخصصة من الشركات ترمي RuntimeException عند
                    // الاستعلام عن الأصوات أو AudioAttributes. لا نسمح للصوت بإسقاط الدردشة.
                    runCatching { configureNaturalTts(ready, Locale.getDefault()) }
                    ttsEngine = ready
                }
            }
        }.getOrNull()
        onDispose {
            engine?.let { current ->
                runCatching { current.stop() }
                runCatching { current.shutdown() }
            }
            ttsEngine = null
        }
    }

    val speak: (String) -> Unit = { text ->
        if (text.isNotBlank()) {
            val engine = ttsEngine
            if (engine == null) {
                Toast.makeText(context, "خدمة قراءة النص ما زالت تتهيأ أو غير متاحة على الجهاز.", Toast.LENGTH_SHORT).show()
            } else {
                val chunks = SpeechText.chunks(text)
                chunks.forEachIndexed { index, chunk ->
                    engine.speak(
                        chunk,
                        if (index == 0) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD,
                        null,
                        "aion-${System.currentTimeMillis()}-$index"
                    )
                }
            }
        }
    }

    var voiceReplyPending by remember { mutableStateOf(false) }
    var lastAutoSpokenMessageId by remember { mutableStateOf<Long?>(null) }

    val sendVoiceTurn: (String) -> Unit = { spoken ->
        val clean = spoken.trim()
        if (clean.isNotBlank()) {
            voiceReplyPending = true
            onSend(clean)
        }
    }

    LaunchedEffect(messages.lastOrNull()?.id, isSending, voiceReplyPending) {
        val last = messages.lastOrNull()
        if (voiceReplyPending && !isSending && last?.role == MessageRole.AION) {
            if (!last.isError && last.text.isNotBlank() && last.id != lastAutoSpokenMessageId) {
                speak(last.text)
                lastAutoSpokenMessageId = last.id
            }
            voiceReplyPending = false
        }
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            CenterAlignedTopAppBar(
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                ),
                navigationIcon = {
                    IconButton(onClick = onMenu) {
                        Icon(Icons.Outlined.Menu, contentDescription = "القائمة")
                    }
                },
                title = {
                    Surface(
                        onClick = onModelPicker,
                        shape = RoundedCornerShape(14.dp),
                        color = Color.Transparent
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("AION", fontWeight = FontWeight.ExtraBold, fontSize = 17.sp)
                                    Spacer(Modifier.width(6.dp))
                                    Text(
                                        selectedModel.label.removePrefix("AION "),
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                                if (!activeProjectName.isNullOrBlank()) {
                                    Text(
                                        activeProjectName,
                                        color = AionPurpleSoft,
                                        fontSize = 9.sp,
                                        maxLines = 1
                                    )
                                }
                            }
                            Icon(
                                Icons.Outlined.KeyboardArrowDown,
                                contentDescription = "اختيار النموذج",
                                modifier = Modifier.size(16.dp),
                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                },
                actions = {
                    IconButton(onClick = onStartVoiceCall) {
                        Icon(Icons.Outlined.Call, contentDescription = "مكالمة صوتية")
                    }
                    IconButton(onClick = onNewChat, enabled = !isSending) {
                        Icon(Icons.Outlined.Add, contentDescription = "محادثة جديدة")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
                if (messages.isEmpty()) {
                    WelcomeContent(onSuggestion = onSend)
                } else {
                    MessagesList(
                        messages = messages,
                        activity = activity,
                        onSpeak = speak,
                        onRetry = onRetry,
                        onEditMessage = onEditMessage,
                        onRememberMessage = onRememberMessage
                    )
                }
            }
            ChatComposer(
                onSend = onSend,
                onVoiceSend = sendVoiceTurn,
                onStop = onStop,
                onAddAttachments = onAddAttachments,
                onRemoveAttachment = onRemoveAttachment,
                pendingAttachments = pendingAttachments,
                isConfigured = isConfigured,
                isSending = isSending,
                draft = draft,
                onDraftChange = onDraftChange
            )
        }
    }
}

@Composable
private fun WelcomeContent(onSuggestion: (String) -> Unit) {
    val suggestions = listOf(
        Triple(Icons.Outlined.Search, "ابحث في الويب", "اعثر على معلومات حديثة مع المصادر"),
        Triple(Icons.Outlined.Psychology, "حلّل بعمق", "فكّر في فكرة أو قرار خطوة بخطوة"),
        Triple(Icons.Outlined.Edit, "اكتب وصُغ", "رسائل، نصوص، أفكار ومحتوى"),
        Triple(Icons.Outlined.Build, "أنجز مهمة", "خطط، راجع، وبرمج بطريقة منظمة")
    )
    val prompts = listOf(
        "ابحث في الويب عن أهم الأخبار التقنية اليوم",
        "حلّل هذه الفكرة معي بعمق",
        "ساعدني في كتابة نص احترافي",
        "راجع مشروعي خطوة بخطوة"
    )

    Column(
        modifier = Modifier.fillMaxSize().padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        AionMark(size = 52.dp)
        Spacer(Modifier.height(16.dp))
        Text(
            "ماذا تريد أن ننجز؟",
            fontSize = 25.sp,
            fontWeight = FontWeight.ExtraBold,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(6.dp))
        Text(
            "فكّر، ابحث، أنشئ، أو اعمل على مشروعك مع AION.",
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
            fontSize = 12.sp,
            lineHeight = 18.sp
        )
        Spacer(Modifier.height(24.dp))

        Column(
            modifier = Modifier.widthIn(max = 640.dp).fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(9.dp)
        ) {
            suggestions.chunked(2).forEachIndexed { rowIndex, rowItems ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(9.dp)
                ) {
                    rowItems.forEachIndexed { columnIndex, suggestion ->
                        val promptIndex = rowIndex * 2 + columnIndex
                        WelcomeSuggestionCard(
                            icon = suggestion.first,
                            title = suggestion.second,
                            subtitle = suggestion.third,
                            modifier = Modifier.weight(1f),
                            onClick = { onSuggestion(prompts[promptIndex]) }
                        )
                    }
                    if (rowItems.size == 1) Spacer(Modifier.weight(1f))
                }
            }
        }
    }
}

@Composable
private fun WelcomeSuggestionCard(
    icon: ImageVector,
    title: String,
    subtitle: String,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        modifier = modifier.defaultMinSize(minHeight = 104.dp),
        shape = RoundedCornerShape(20.dp),
        color = Color(0xFF141419),
        border = BorderStroke(1.dp, Color(0xFF2A2730))
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 13.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Surface(
                shape = CircleShape,
                color = AionPurple.copy(alpha = 0.12f),
                modifier = Modifier.size(31.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(icon, contentDescription = null, tint = AionPurpleSoft, modifier = Modifier.size(16.dp))
                }
            }
            Spacer(Modifier.height(10.dp))
            Text(title, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(2.dp))
            Text(
                subtitle,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = 10.sp,
                lineHeight = 15.sp,
                maxLines = 2
            )
        }
    }
}

@Composable
private fun MessagesList(
    messages: List<ChatMessage>,
    activity: GatewayActivity?,
    onSpeak: (String) -> Unit,
    onRetry: (Long) -> Unit,
    onEditMessage: (Long, String) -> Unit,
    onRememberMessage: (String) -> Unit
) {
    val state = rememberLazyListState()
    val scope = rememberCoroutineScope()
    val lastText = messages.lastOrNull()?.text.orEmpty()
    var autoFollow by remember { mutableStateOf(true) }
    var programmaticScroll by remember { mutableStateOf(false) }
    var previousCount by remember { mutableStateOf(messages.size) }
    var previousPosition by remember { mutableStateOf(0L) }
    var unreadWhilePaused by remember { mutableStateOf(0) }

    val isNearBottom by remember {
        derivedStateOf {
            if (messages.isEmpty()) true
            else {
                val lastVisible = state.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: -1
                lastVisible >= (messages.lastIndex - 1).coerceAtLeast(0)
            }
        }
    }

    suspend fun goToBottom(animated: Boolean) {
        if (messages.isEmpty()) return
        programmaticScroll = true
        try {
            if (animated) state.animateScrollToItem(messages.lastIndex)
            else state.scrollToItem(messages.lastIndex)
        } finally {
            programmaticScroll = false
        }
    }

    LaunchedEffect(messages.size) {
        val growth = (messages.size - previousCount).coerceAtLeast(0)
        val last = messages.lastOrNull()
        when {
            growth > 0 && last?.role == MessageRole.USER -> {
                autoFollow = true
                unreadWhilePaused = 0
                goToBottom(animated = true)
            }
            growth > 0 && autoFollow && last?.isStreaming == true -> goToBottom(animated = true)
            growth > 0 && !autoFollow -> unreadWhilePaused += growth
        }
        previousCount = messages.size
    }

    LaunchedEffect(lastText.length, autoFollow) {
        if (autoFollow && messages.isNotEmpty()) {
            unreadWhilePaused = 0
            goToBottom(animated = false)
        }
    }

    LaunchedEffect(state, messages.size) {
        snapshotFlow {
            val index = state.firstVisibleItemIndex
            val offset = state.firstVisibleItemScrollOffset
            val packed = index.toLong() * 1_000_000L + offset.toLong()
            Triple(state.isScrollInProgress, packed, isNearBottom)
        }.collect { (scrolling, position, nearBottom) ->
            if (!programmaticScroll) {
                if (nearBottom) {
                    autoFollow = true
                    unreadWhilePaused = 0
                } else if (scrolling && position < previousPosition) {
                    autoFollow = false
                }
            }
            previousPosition = position
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        LazyColumn(
            state = state,
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            itemsIndexed(messages, key = { _, message -> message.id }) { _, message ->
                Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.TopCenter) {
                    Box(modifier = Modifier.widthIn(max = 820.dp).fillMaxWidth()) {
                        MessageBubble(
                            message = message,
                            activity = activity,
                            onSpeak = onSpeak,
                            onRetry = onRetry,
                            onEditMessage = onEditMessage,
                            onRememberMessage = onRememberMessage
                        )
                    }
                }
            }
        }

        AnimatedVisibility(
            visible = !autoFollow && messages.isNotEmpty(),
            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 8.dp)
        ) {
            Surface(
                onClick = {
                    autoFollow = true
                    unreadWhilePaused = 0
                    scope.launch { goToBottom(animated = true) }
                },
                shape = CircleShape,
                color = Color(0xFF21172F),
                border = BorderStroke(1.dp, Color(0xFF3A2851))
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Outlined.KeyboardArrowDown, contentDescription = null, modifier = Modifier.size(16.dp), tint = AionPurpleSoft)
                    Spacer(Modifier.width(5.dp))
                    Text(
                        if (unreadWhilePaused > 0) "$unreadWhilePaused جديدة" else "العودة لآخر رد",
                        fontSize = 10.sp,
                        color = AionPurpleSoft,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun MessageBubble(
    message: ChatMessage,
    activity: GatewayActivity?,
    onSpeak: (String) -> Unit,
    onRetry: (Long) -> Unit,
    onEditMessage: (Long, String) -> Unit,
    onRememberMessage: (String) -> Unit
) {
    val isUser = message.role == MessageRole.USER
    val clipboard = LocalClipboardManager.current
    val context = LocalContext.current
    var actionsVisible by remember(message.id, message.isStreaming) { mutableStateOf(!isUser && !message.isStreaming) }
    var showSources by remember(message.id) { mutableStateOf(false) }
    var showEdit by remember(message.id) { mutableStateOf(false) }
    var editText by remember(message.id, message.text) { mutableStateOf(message.text) }

    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = if (isUser) Arrangement.Start else Arrangement.End,
            verticalAlignment = Alignment.Top
        ) {
            Column(modifier = Modifier.fillMaxWidth(if (isUser) 0.82f else 1f)) {
                if (message.attachments.isNotEmpty()) {
                    MessageAttachmentRow(message.attachments, isUser)
                    if (message.text.isNotBlank()) Spacer(Modifier.height(6.dp))
                }

                val showLiveIndicator = !isUser && message.isStreaming && message.text.isBlank()
                if (showLiveIndicator) {
                    LiveThinkingIndicator(
                        modelLabel = message.modelLabel ?: "AION",
                        activity = activity ?: GatewayActivity.THINKING
                    )
                } else Surface(
                    modifier = if (isUser && !message.isStreaming) {
                        Modifier.clickable { actionsVisible = !actionsVisible }.animateContentSize()
                    } else Modifier.animateContentSize(),
                    shape = RoundedCornerShape(if (isUser) 20.dp else 12.dp),
                    color = when {
                        isUser -> Color(0xFF25202D)
                        message.isError -> Color(0xFF251116)
                        else -> Color.Transparent
                    }
                ) {
                    Column {
                        if (message.text.isNotBlank()) {
                            if (isUser) {
                                RichMessageText(
                                    text = message.text,
                                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                                    color = if (message.isError) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface
                                )
                            } else {
                                SelectionContainer {
                                    RichMessageText(
                                        text = message.text,
                                        modifier = Modifier.padding(
                                            horizontal = if (message.isError) 14.dp else 2.dp,
                                            vertical = if (message.isError) 10.dp else 2.dp
                                        ),
                                        color = if (message.isError) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface
                                    )
                                }
                            }
                        }
                    }
                }

                if (!isUser && message.sources.isNotEmpty() && !message.isStreaming) {
                    Spacer(Modifier.height(7.dp))
                    Surface(
                        onClick = { showSources = true },
                        shape = RoundedCornerShape(13.dp),
                        color = Color(0xFF15131D),
                        border = BorderStroke(1.dp, Color(0xFF30283E))
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(Modifier.size(6.dp).clip(CircleShape).background(AionBlueSoft))
                            Spacer(Modifier.width(6.dp))
                            val hosts = remember(message.sources) {
                                message.sources.mapNotNull { source ->
                                    runCatching { Uri.parse(source.url).host?.removePrefix("www.") }.getOrNull()
                                }.filter { it.isNotBlank() }.distinct()
                            }
                            val sourceLabel = when {
                                hosts.isEmpty() -> "${message.sources.size} مصادر"
                                hosts.size == 1 -> hosts.first()
                                else -> "${hosts.first()} +${hosts.size - 1}"
                            }
                            Text(
                                "المصادر • $sourceLabel",
                                fontSize = 10.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1
                            )
                        }
                    }
                }

                if (!isUser && message.wasStopped) {
                    Surface(
                        modifier = Modifier.padding(top = 7.dp),
                        shape = CircleShape,
                        color = Color(0xFF17171D),
                        border = BorderStroke(1.dp, Color(0xFF2D2B34))
                    ) {
                        Text(
                            "تم إيقاف الرد",
                            modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp),
                            fontSize = 9.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                AnimatedVisibility(visible = !message.isStreaming && actionsVisible) {
                    if (isUser) {
                        Row(
                            modifier = Modifier.padding(top = 5.dp),
                            horizontalArrangement = Arrangement.spacedBy(2.dp)
                        ) {
                            SmallAction(
                                icon = Icons.Outlined.ContentCopy,
                                description = "نسخ",
                                onClick = { clipboard.setText(AnnotatedString(message.text)) }
                            )
                            SmallAction(
                                icon = Icons.Outlined.Edit,
                                description = "تعديل",
                                onClick = {
                                    editText = message.text
                                    showEdit = true
                                }
                            )
                            if (message.text.isNotBlank()) {
                                SmallAction(
                                    icon = Icons.Outlined.Memory,
                                    description = "حفظ في الذاكرة",
                                    onClick = {
                                        onRememberMessage(message.text)
                                        Toast.makeText(context, "تمت إضافتها إلى ذاكرة AION المحلية.", Toast.LENGTH_SHORT).show()
                                    }
                                )
                            }
                        }
                    } else {
                        ResponseActions(
                            isError = message.isError,
                            onCopy = { clipboard.setText(AnnotatedString(message.text)) },
                            onSpeak = { onSpeak(message.text) },
                            onRetry = { onRetry(message.id) },
                            onShare = {
                                val shareText = buildString {
                                    append(message.text)
                                    if (message.sources.isNotEmpty()) {
                                        append("\n\nالمصادر:\n")
                                        message.sources.forEachIndexed { index, source ->
                                            append(index + 1).append(". ").append(source.title).append("\n")
                                            append(source.url).append("\n")
                                        }
                                    }
                                }.trim()
                                runCatching {
                                    context.startActivity(
                                        Intent.createChooser(
                                            Intent(Intent.ACTION_SEND).apply {
                                                type = "text/plain"
                                                putExtra(Intent.EXTRA_TEXT, shareText)
                                            },
                                            "مشاركة رد AION"
                                        )
                                    )
                                }
                            }
                        )
                    }
                }
            }
        }
    }

    if (showEdit) {
        AlertDialog(
            onDismissRequest = { showEdit = false },
            title = { Text("تعديل الرسالة") },
            text = {
                OutlinedTextField(
                    value = editText,
                    onValueChange = { editText = it },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 3,
                    maxLines = 10
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        val clean = editText.trim()
                        if (clean.isNotBlank() || message.attachments.isNotEmpty()) {
                            showEdit = false
                            onEditMessage(message.id, clean)
                        }
                    }
                ) { Text("حفظ وإعادة الإرسال") }
            },
            dismissButton = {
                TextButton(onClick = { showEdit = false }) { Text("إلغاء") }
            }
        )
    }

    if (showSources) {
        SourcesSheet(
            sources = message.sources,
            onOpen = { source ->
                runCatching {
                    context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(source.url)))
                }
            },
            onDismiss = { showSources = false }
        )
    }
}

private data class MessageSegment(val text: String, val code: Boolean, val language: String = "")

private fun splitMessageSegments(text: String): List<MessageSegment> {
    val regex = Regex("```([^\\n`]*)\\n([\\s\\S]*?)```")
    val result = mutableListOf<MessageSegment>()
    var cursor = 0
    regex.findAll(text).forEach { match ->
        if (match.range.first > cursor) {
            result += MessageSegment(text.substring(cursor, match.range.first), code = false)
        }
        result += MessageSegment(
            text = match.groupValues[2].trimEnd(),
            code = true,
            language = match.groupValues[1].trim()
        )
        cursor = match.range.last + 1
    }
    if (cursor < text.length) result += MessageSegment(text.substring(cursor), code = false)
    return result.ifEmpty { listOf(MessageSegment(text, code = false)) }
}

private enum class MarkdownBlockKind { PARAGRAPH, HEADING, BULLET, NUMBERED, QUOTE, DIVIDER, TABLE }

private data class MarkdownBlock(
    val kind: MarkdownBlockKind,
    val text: String,
    val level: Int = 0,
    val rows: List<List<String>> = emptyList()
)

private fun parseMarkdownTableRow(line: String): List<String> = line
    .trim()
    .trim('|')
    .split('|')
    .map { it.trim() }

private fun isMarkdownTableSeparator(line: String): Boolean {
    val cells = parseMarkdownTableRow(line)
    return cells.isNotEmpty() && cells.all { it.matches(Regex(":?-{3,}:?")) }
}

private fun parseMarkdownBlocks(text: String): List<MarkdownBlock> {
    val blocks = mutableListOf<MarkdownBlock>()
    val paragraph = mutableListOf<String>()
    val lines = text.replace("\r\n", "\n").lines()

    fun flushParagraph() {
        if (paragraph.isNotEmpty()) {
            blocks += MarkdownBlock(MarkdownBlockKind.PARAGRAPH, paragraph.joinToString("\n").trim())
            paragraph.clear()
        }
    }

    var index = 0
    while (index < lines.size) {
        val line = lines[index].trimEnd()
        val trimmed = line.trim()

        if (
            trimmed.contains('|') &&
            index + 1 < lines.size &&
            isMarkdownTableSeparator(lines[index + 1])
        ) {
            flushParagraph()
            val rows = mutableListOf(parseMarkdownTableRow(trimmed))
            index += 2 // نتجاوز سطر الفصل |---|---|
            while (index < lines.size) {
                val candidate = lines[index].trim()
                if (candidate.isBlank() || !candidate.contains('|')) break
                rows += parseMarkdownTableRow(candidate)
                index++
            }
            blocks += MarkdownBlock(MarkdownBlockKind.TABLE, text = "", rows = rows)
            continue
        }

        when {
            trimmed.isBlank() -> flushParagraph()
            trimmed.matches(Regex("^#{1,4}\\s+.*")) -> {
                flushParagraph()
                val level = trimmed.takeWhile { it == '#' }.length
                blocks += MarkdownBlock(MarkdownBlockKind.HEADING, trimmed.drop(level).trim(), level)
            }
            trimmed.matches(Regex("^[-*_]{3,}$")) -> {
                flushParagraph()
                blocks += MarkdownBlock(MarkdownBlockKind.DIVIDER, "")
            }
            trimmed.startsWith("> ") -> {
                flushParagraph()
                blocks += MarkdownBlock(MarkdownBlockKind.QUOTE, trimmed.removePrefix("> ").trim())
            }
            trimmed.matches(Regex("^[-*+]\\s+.*")) -> {
                flushParagraph()
                blocks += MarkdownBlock(MarkdownBlockKind.BULLET, trimmed.replaceFirst(Regex("^[-*+]\\s+"), ""))
            }
            trimmed.matches(Regex("^\\d+[.)]\\s+.*")) -> {
                flushParagraph()
                val marker = Regex("^(\\d+[.)])\\s+(.*)$").find(trimmed)
                blocks += MarkdownBlock(
                    MarkdownBlockKind.NUMBERED,
                    marker?.groupValues?.getOrNull(2).orEmpty(),
                    marker?.groupValues?.getOrNull(1)?.filter(Char::isDigit)?.toIntOrNull() ?: 1
                )
            }
            else -> paragraph += line
        }
        index++
    }
    flushParagraph()
    return blocks
}

private fun inlineMarkdown(text: String, color: Color): AnnotatedString = buildAnnotatedString {
    var index = 0
    while (index < text.length) {
        when {
            text.startsWith("**", index) -> {
                val end = text.indexOf("**", index + 2)
                if (end > index + 2) {
                    withStyle(SpanStyle(fontWeight = FontWeight.Bold, color = color)) {
                        append(text.substring(index + 2, end))
                    }
                    index = end + 2
                } else {
                    append(text[index])
                    index++
                }
            }
            text[index] == '`' -> {
                val end = text.indexOf('`', index + 1)
                if (end > index + 1) {
                    withStyle(
                        SpanStyle(
                            fontFamily = FontFamily.Monospace,
                            color = AionPurpleSoft,
                            background = Color(0xFF1A1720)
                        )
                    ) {
                        append(text.substring(index + 1, end))
                    }
                    index = end + 1
                } else {
                    append(text[index])
                    index++
                }
            }
            else -> {
                append(text[index])
                index++
            }
        }
    }
}

@Composable
private fun MarkdownTextBlocks(text: String, color: Color) {
    val blocks = remember(text) { parseMarkdownBlocks(text) }
    Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
        blocks.forEach { block ->
            when (block.kind) {
                MarkdownBlockKind.PARAGRAPH -> Text(
                    inlineMarkdown(block.text, color),
                    lineHeight = 24.sp,
                    fontSize = 15.sp,
                    color = color
                )
                MarkdownBlockKind.HEADING -> Text(
                    inlineMarkdown(block.text, color),
                    lineHeight = if (block.level <= 2) 28.sp else 24.sp,
                    fontSize = when (block.level) {
                        1 -> 21.sp
                        2 -> 18.sp
                        else -> 16.sp
                    },
                    fontWeight = FontWeight.Bold,
                    color = color
                )
                MarkdownBlockKind.BULLET -> Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.Top
                ) {
                    Text("•", modifier = Modifier.width(18.dp), fontSize = 15.sp, color = AionPurpleSoft)
                    Text(
                        inlineMarkdown(block.text, color),
                        modifier = Modifier.weight(1f),
                        lineHeight = 23.sp,
                        fontSize = 15.sp,
                        color = color
                    )
                }
                MarkdownBlockKind.NUMBERED -> Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.Top
                ) {
                    Text("${block.level}.", modifier = Modifier.width(26.dp), fontSize = 14.sp, color = AionPurpleSoft)
                    Text(
                        inlineMarkdown(block.text, color),
                        modifier = Modifier.weight(1f),
                        lineHeight = 23.sp,
                        fontSize = 15.sp,
                        color = color
                    )
                }
                MarkdownBlockKind.QUOTE -> Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = Color(0xFF121218),
                    border = BorderStroke(1.dp, Color(0xFF2A2632))
                ) {
                    Text(
                        inlineMarkdown(block.text, color),
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 9.dp),
                        lineHeight = 22.sp,
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                MarkdownBlockKind.TABLE -> Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = Color(0xFF101116),
                    border = BorderStroke(1.dp, Color(0xFF292B34))
                ) {
                    Row(modifier = Modifier.horizontalScroll(rememberScrollState())) {
                        val columnCount = block.rows.maxOfOrNull { it.size } ?: 0
                        repeat(columnCount) { columnIndex ->
                            Column(modifier = Modifier.width(150.dp)) {
                                block.rows.forEachIndexed { rowIndex, row ->
                                    val cell = row.getOrNull(columnIndex).orEmpty()
                                    Surface(
                                        color = if (rowIndex == 0) Color(0xFF191821) else Color.Transparent,
                                        border = BorderStroke(0.5.dp, Color(0xFF292B34))
                                    ) {
                                        Text(
                                            inlineMarkdown(cell, color),
                                            modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp),
                                            fontSize = 12.sp,
                                            lineHeight = 18.sp,
                                            fontWeight = if (rowIndex == 0) FontWeight.SemiBold else FontWeight.Normal,
                                            color = color
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
                MarkdownBlockKind.DIVIDER -> HorizontalDivider(
                    modifier = Modifier.padding(vertical = 3.dp),
                    color = MaterialTheme.colorScheme.outline.copy(alpha = 0.45f)
                )
            }
        }
    }
}

@Composable
private fun RichMessageText(text: String, modifier: Modifier = Modifier, color: Color) {
    val clipboard = LocalClipboardManager.current
    val segments = remember(text) { splitMessageSegments(text) }
    Column(modifier = modifier, verticalArrangement = Arrangement.spacedBy(9.dp)) {
        segments.forEach { segment ->
            if (!segment.code) {
                if (segment.text.isNotBlank()) MarkdownTextBlocks(segment.text, color)
            } else {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    color = Color(0xFF101116),
                    border = BorderStroke(1.dp, Color(0xFF292B34))
                ) {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(start = 12.dp, end = 5.dp, top = 5.dp, bottom = 2.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                segment.language.ifBlank { "code" },
                                fontSize = 9.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            IconButton(
                                onClick = { clipboard.setText(AnnotatedString(segment.text)) },
                                modifier = Modifier.size(30.dp)
                            ) {
                                Icon(
                                    Icons.Outlined.ContentCopy,
                                    contentDescription = "نسخ الكود",
                                    modifier = Modifier.size(14.dp),
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                            Text(
                                segment.text,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .horizontalScroll(rememberScrollState())
                                    .padding(start = 12.dp, end = 12.dp, bottom = 12.dp),
                                fontFamily = FontFamily.Monospace,
                                fontSize = 12.sp,
                                lineHeight = 19.sp,
                                color = MaterialTheme.colorScheme.onSurface,
                                textAlign = TextAlign.Start
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun rememberAttachmentPreview(attachment: ChatAttachment): Bitmap? {
    val bitmap by produceState<Bitmap?>(
        initialValue = null,
        key1 = attachment.localPath,
        key2 = attachment.base64Data
    ) {
        value = withContext(Dispatchers.IO) { decodeAttachmentPreview(attachment, 720, 540) }
    }
    return bitmap
}

private fun decodeAttachmentPreview(attachment: ChatAttachment, requestedWidth: Int, requestedHeight: Int): Bitmap? = runCatching {
    val path = attachment.localPath.takeIf { it.isNotBlank() && File(it).isFile }
    if (path != null) {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(path, bounds)
        val options = BitmapFactory.Options().apply {
            inSampleSize = calculateImageSample(bounds.outWidth, bounds.outHeight, requestedWidth, requestedHeight)
        }
        return@runCatching BitmapFactory.decodeFile(path, options)
    }

    if (attachment.base64Data.isBlank()) return@runCatching null
    val bytes = Base64.decode(attachment.base64Data, Base64.DEFAULT)
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
    val options = BitmapFactory.Options().apply {
        inSampleSize = calculateImageSample(bounds.outWidth, bounds.outHeight, requestedWidth, requestedHeight)
    }
    BitmapFactory.decodeByteArray(bytes, 0, bytes.size, options)
}.getOrNull()

private fun calculateImageSample(width: Int, height: Int, requestedWidth: Int, requestedHeight: Int): Int {
    if (width <= 0 || height <= 0) return 1
    var sample = 1
    while (width / (sample * 2) >= requestedWidth && height / (sample * 2) >= requestedHeight) {
        sample *= 2
    }
    return sample.coerceAtLeast(1)
}

@Composable
private fun MessageAttachmentRow(attachments: List<ChatAttachment>, isUser: Boolean) {
    var previewAttachment by remember { mutableStateOf<ChatAttachment?>(null) }

    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items(attachments, key = { it.id }) { attachment ->
            if (attachment.kind == AttachmentKind.IMAGE) {
                val bitmap = rememberAttachmentPreview(attachment)
                if (bitmap != null) {
                    Surface(
                        onClick = { previewAttachment = attachment },
                        modifier = Modifier.width(176.dp).height(132.dp),
                        shape = RoundedCornerShape(18.dp),
                        color = if (isUser) Color(0xFF302141) else Color(0xFF17151E),
                        border = BorderStroke(1.dp, Color(0xFF3A3047))
                    ) {
                        Image(
                            bitmap = bitmap.asImageBitmap(),
                            contentDescription = attachment.name,
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                    }
                } else {
                    CompactAttachmentChip(attachment, isUser)
                }
            } else {
                CompactAttachmentChip(attachment, isUser)
            }
        }
    }

    previewAttachment?.let { attachment ->
        val bitmap = rememberAttachmentPreview(attachment)
        if (bitmap != null) {
            Dialog(onDismissRequest = { previewAttachment = null }) {
                Surface(
                    shape = RoundedCornerShape(22.dp),
                    color = Color(0xFF0D0D11),
                    border = BorderStroke(1.dp, Color(0xFF302C37))
                ) {
                    Column(modifier = Modifier.padding(8.dp)) {
                        Box {
                            Image(
                                bitmap = bitmap.asImageBitmap(),
                                contentDescription = attachment.name,
                                modifier = Modifier.fillMaxWidth().height(420.dp).clip(RoundedCornerShape(17.dp)),
                                contentScale = ContentScale.Fit
                            )
                            Surface(
                                onClick = { previewAttachment = null },
                                shape = CircleShape,
                                color = Color(0xCC17171C),
                                modifier = Modifier.align(Alignment.TopEnd).padding(8.dp).size(36.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(Icons.Outlined.Close, contentDescription = "إغلاق", modifier = Modifier.size(18.dp))
                                }
                            }
                        }
                        Text(
                            attachment.name,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 8.dp),
                            fontSize = 10.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun CompactAttachmentChip(attachment: ChatAttachment, isUser: Boolean) {
    Surface(
        shape = RoundedCornerShape(13.dp),
        color = if (isUser) Color(0xFF302141) else Color(0xFF17151E),
        border = BorderStroke(1.dp, Color(0xFF3A3047))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 9.dp, vertical = 7.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                if (attachment.kind == AttachmentKind.IMAGE) Icons.Outlined.Image else Icons.Outlined.Description,
                contentDescription = null,
                modifier = Modifier.size(15.dp),
                tint = if (attachment.kind == AttachmentKind.IMAGE) AionPurpleSoft else AionBlueSoft
            )
            Spacer(Modifier.width(5.dp))
            Text(attachment.name, fontSize = 10.sp, maxLines = 1)
        }
    }
}

@Composable
private fun ResponseActions(
    isError: Boolean,
    onCopy: () -> Unit,
    onSpeak: () -> Unit,
    onRetry: () -> Unit,
    onShare: () -> Unit
) {
    Row(
        modifier = Modifier.padding(top = 5.dp),
        horizontalArrangement = Arrangement.spacedBy(2.dp)
    ) {
        SmallAction(Icons.Outlined.ContentCopy, "نسخ", onCopy)
        if (!isError) SmallAction(Icons.Outlined.VolumeUp, "استماع", onSpeak)
        SmallAction(Icons.Outlined.Refresh, "إعادة", onRetry)
        if (!isError) SmallAction(Icons.Outlined.Share, "مشاركة", onShare)
    }
}

@Composable
private fun SmallAction(icon: ImageVector, description: String, onClick: () -> Unit) {
    IconButton(onClick = onClick, modifier = Modifier.size(32.dp)) {
        Icon(
            icon,
            contentDescription = description,
            modifier = Modifier.size(16.dp),
            tint = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun LiveThinkingIndicator(modelLabel: String, activity: GatewayActivity) {
    val transition = rememberInfiniteTransition(label = "aion-thinking")
    val pulse by transition.animateFloat(
        initialValue = 0.92f,
        targetValue = 1.06f,
        animationSpec = infiniteRepeatable(animation = tween(720), repeatMode = RepeatMode.Reverse),
        label = "pulse"
    )
    val fade by transition.animateFloat(
        initialValue = 0.58f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(animation = tween(920), repeatMode = RepeatMode.Reverse),
        label = "fade"
    )

    val activityText = when (activity) {
        GatewayActivity.SEARCHING_WEB -> "يبحث في الويب"
        GatewayActivity.READING_FILES -> "يقرأ المرفقات"
        GatewayActivity.WRITING -> "يصيغ الرد"
        GatewayActivity.THINKING -> "يفكر"
    }
    val activityIcon = when (activity) {
        GatewayActivity.SEARCHING_WEB -> Icons.Outlined.Search
        GatewayActivity.READING_FILES -> Icons.Outlined.Description
        GatewayActivity.WRITING -> Icons.Outlined.Edit
        GatewayActivity.THINKING -> Icons.Outlined.Psychology
    }
    val cleanModel = modelLabel.removePrefix("AION ").ifBlank { "Auto" }

    Surface(
        shape = RoundedCornerShape(18.dp),
        color = Color(0xFF131218),
        border = BorderStroke(1.dp, Color(0xFF2C2734))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                shape = CircleShape,
                color = AionPurple.copy(alpha = 0.13f),
                modifier = Modifier.size(27.dp).scale(pulse)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(activityIcon, contentDescription = null, modifier = Modifier.size(14.dp), tint = AionPurpleSoft)
                }
            }
            Spacer(Modifier.width(8.dp))
            Column {
                Text(
                    "AION • $activityText",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = AionPurpleSoft,
                    modifier = Modifier.alpha(fade)
                )
                Text(cleanModel, fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Spacer(Modifier.width(8.dp))
            ThinkingDots()
        }
    }
}

@Composable
private fun ThinkingDots() {
    val transition = rememberInfiniteTransition(label = "thinking-dots")
    val p1 by transition.animateFloat(0.3f, 1f, infiniteRepeatable(tween(600), RepeatMode.Reverse), label = "p1")
    val p2 by transition.animateFloat(1f, 0.3f, infiniteRepeatable(tween(750), RepeatMode.Reverse), label = "p2")
    val p3 by transition.animateFloat(0.45f, 1f, infiniteRepeatable(tween(900), RepeatMode.Reverse), label = "p3")
    Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
        listOf(p1, p2, p3).forEach { alpha ->
            Box(Modifier.size(4.dp).alpha(alpha).clip(CircleShape).background(AionPurpleSoft))
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ChatComposer(
    onSend: (String) -> Unit,
    onVoiceSend: (String) -> Unit,
    onStop: () -> Unit,
    onAddAttachments: (List<ChatAttachment>) -> Unit,
    onRemoveAttachment: (Long) -> Unit,
    pendingAttachments: List<ChatAttachment>,
    isConfigured: Boolean,
    isSending: Boolean,
    draft: String,
    onDraftChange: (String) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var showAttachSheet by remember { mutableStateOf(false) }
    var isListening by remember { mutableStateOf(false) }
    var inputFocused by remember { mutableStateOf(false) }
    var rms by remember { mutableFloatStateOf(0f) }
    var voiceBase by remember { mutableStateOf("") }
    var liveTranscript by remember { mutableStateOf("") }

    val speechRecognizer = remember(context) {
        if (SpeechRecognizer.isRecognitionAvailable(context)) SpeechRecognizer.createSpeechRecognizer(context) else null
    }

    fun mergeVoiceText(base: String, spoken: String): String {
        return listOf(base.trim(), spoken.trim()).filter { it.isNotBlank() }.joinToString(" ")
    }

    DisposableEffect(speechRecognizer) {
        speechRecognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { isListening = true }
            override fun onBeginningOfSpeech() { isListening = true }
            override fun onRmsChanged(rmsdB: Float) { rms = rmsdB.coerceIn(0f, 12f) }
            override fun onBufferReceived(buffer: ByteArray?) = Unit
            override fun onEndOfSpeech() = Unit

            override fun onError(error: Int) {
                isListening = false
                rms = 0f
                liveTranscript = ""
                if (error != SpeechRecognizer.ERROR_NO_MATCH && error != SpeechRecognizer.ERROR_SPEECH_TIMEOUT) {
                    Toast.makeText(context, "تعذر التقاط الصوت. حاول مرة أخرى.", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onResults(results: Bundle?) {
                val spoken = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                val turnText = mergeVoiceText(voiceBase, spoken)
                isListening = false
                rms = 0f
                liveTranscript = ""
                if (turnText.isNotBlank()) {
                    onDraftChange("")
                    onVoiceSend(turnText)
                }
            }

            override fun onPartialResults(partialResults: Bundle?) {
                liveTranscript = partialResults
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull()
                    .orEmpty()
            }

            override fun onEvent(eventType: Int, params: Bundle?) = Unit
        })
        onDispose {
            speechRecognizer?.cancel()
            speechRecognizer?.destroy()
        }
    }

    fun startListeningNow() {
        val recognizer = speechRecognizer
        if (recognizer == null) {
            Toast.makeText(context, "خدمة التعرف على الصوت غير متاحة على هذا الجهاز.", Toast.LENGTH_SHORT).show()
            return
        }
        voiceBase = draft
        liveTranscript = ""
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag())
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 900L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 520L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 350L)
        }
        runCatching { recognizer.startListening(intent) }
            .onFailure { Toast.makeText(context, "تعذر تشغيل الميكروفون.", Toast.LENGTH_SHORT).show() }
    }

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) startListeningNow()
        else Toast.makeText(context, "يحتاج AION إذن الميكروفون لتحويل كلامك إلى نص.", Toast.LENGTH_SHORT).show()
    }

    fun toggleListening() {
        if (isListening) {
            speechRecognizer?.stopListening()
            return
        }
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            startListeningNow()
        } else {
            permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    fun loadUris(uris: List<Uri>) {
        if (uris.isEmpty()) return
        if (pendingAttachments.size + uris.size > 4) {
            Toast.makeText(context, "يمكن إرفاق حتى 4 عناصر في الرسالة الواحدة حاليًا.", Toast.LENGTH_SHORT).show()
            return
        }
        scope.launch {
            val loaded = withContext(Dispatchers.IO) { uris.map { AttachmentLoader.load(context, it) } }
            val attachments = loaded.mapNotNull { result ->
                result.exceptionOrNull()?.message?.let { message ->
                    withContext(Dispatchers.Main.immediate) {
                        Toast.makeText(context, message, Toast.LENGTH_LONG).show()
                    }
                }
                result.getOrNull()
            }
            if (attachments.isNotEmpty()) {
                val currentBytes = pendingAttachments.sumOf { it.sizeBytes }
                val remainingBytes = 5L * 1024L * 1024L - currentBytes
                val accepted = mutableListOf<ChatAttachment>()
                var acceptedBytes = 0L
                attachments.forEach { attachment ->
                    if (acceptedBytes + attachment.sizeBytes <= remainingBytes) {
                        accepted += attachment
                        acceptedBytes += attachment.sizeBytes
                    }
                }
                if (accepted.size < attachments.size) {
                    Toast.makeText(context, "الحد الإجمالي للمرفقات في الرسالة هو 5 MB.", Toast.LENGTH_LONG).show()
                }
                if (accepted.isNotEmpty()) onAddAttachments(accepted)
            }
        }
    }

    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris -> loadUris(uris) }
    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris -> loadUris(uris) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .imePadding()
            .padding(start = 10.dp, end = 10.dp, top = 5.dp, bottom = 5.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Column(modifier = Modifier.widthIn(max = 820.dp).fillMaxWidth()) {
            if (!isConfigured || pendingAttachments.isNotEmpty()) {
                LazyRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(7.dp),
                    contentPadding = PaddingValues(horizontal = 3.dp, vertical = 2.dp)
                ) {
                    if (!isConfigured) {
                        item { InfoChip("الخدمة السحابية غير مضبوطة", MaterialTheme.colorScheme.error) }
                    }
                    items(pendingAttachments, key = { it.id }) { attachment ->
                        PendingAttachmentPreview(
                            attachment = attachment,
                            onRemove = { onRemoveAttachment(attachment.id) }
                        )
                    }
                }
                Spacer(Modifier.height(6.dp))
            }

            AnimatedVisibility(visible = isListening) {
                Surface(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 2.dp, vertical = 2.dp),
                    shape = RoundedCornerShape(16.dp),
                    color = AionPurple.copy(alpha = 0.10f),
                    border = BorderStroke(1.dp, AionPurple.copy(alpha = 0.30f))
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 11.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        val level = (rms / 12f).coerceIn(0f, 1f)
                        Box(
                            Modifier
                                .size((8f + level * 5f).dp)
                                .clip(CircleShape)
                                .background(AionPurpleSoft)
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(
                            text = liveTranscript.ifBlank { "أستمع إليك…" },
                            modifier = Modifier.weight(1f),
                            color = AionPurpleSoft,
                            fontSize = 11.sp,
                            maxLines = 2,
                            lineHeight = 16.sp
                        )
                        TextButton(onClick = { speechRecognizer?.stopListening() }) {
                            Text("إنهاء", fontSize = 10.sp)
                        }
                    }
                }
                Spacer(Modifier.height(5.dp))
            }

            Surface(
                modifier = Modifier.animateContentSize(),
                shape = RoundedCornerShape(27.dp),
                color = Color(0xFF16161B),
                border = BorderStroke(
                    1.dp,
                    when {
                        isListening -> AionPurple.copy(alpha = 0.85f)
                        inputFocused -> AionPurple.copy(alpha = 0.42f)
                        else -> Color(0xFF2B2931)
                    }
                )
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().defaultMinSize(minHeight = 58.dp).padding(horizontal = 5.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        onClick = { showAttachSheet = true },
                        enabled = !isSending,
                        shape = CircleShape,
                        color = Color.Transparent,
                        modifier = Modifier.size(42.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                Icons.Outlined.Add,
                                contentDescription = "إضافة مرفق",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(21.dp)
                            )
                        }
                    }

                    BasicTextField(
                        value = draft,
                        onValueChange = onDraftChange,
                        modifier = Modifier
                            .weight(1f)
                            .onFocusChanged { inputFocused = it.isFocused }
                            .padding(horizontal = 5.dp, vertical = 10.dp),
                        textStyle = MaterialTheme.typography.bodyLarge.copy(
                            color = MaterialTheme.colorScheme.onSurface,
                            textAlign = TextAlign.Start,
                            lineHeight = 22.sp
                        ),
                        minLines = 1,
                        maxLines = 7,
                        decorationBox = { inner ->
                            Box {
                                if (draft.isBlank()) {
                                    Text(
                                        "اكتب رسالة إلى AION…",
                                        color = if (isListening) AionPurpleSoft else MaterialTheme.colorScheme.onSurfaceVariant,
                                        fontSize = 14.sp
                                    )
                                }
                                inner()
                            }
                        }
                    )

                    when {
                        isSending -> {
                            val stopTransition = rememberInfiniteTransition(label = "aion-stop-life")
                            val stopPulse by stopTransition.animateFloat(
                                initialValue = 0.96f,
                                targetValue = 1.04f,
                                animationSpec = infiniteRepeatable(animation = tween(680), repeatMode = RepeatMode.Reverse),
                                label = "stop-pulse"
                            )
                            Surface(
                                onClick = onStop,
                                shape = CircleShape,
                                color = Color(0xFFF1EFF4),
                                modifier = Modifier.size(40.dp).scale(stopPulse)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(Icons.Outlined.Stop, contentDescription = "إيقاف", tint = Color(0xFF17151B), modifier = Modifier.size(17.dp))
                                }
                            }
                        }

                        draft.isNotBlank() || pendingAttachments.isNotEmpty() -> {
                            Surface(
                                onClick = {
                                    if (!isConfigured) {
                                        Toast.makeText(context, "اضبط اتصال AION Cloud من الإعدادات أولًا.", Toast.LENGTH_SHORT).show()
                                    } else {
                                        val outgoing = draft
                                        onSend(outgoing)
                                        onDraftChange("")
                                    }
                                },
                                shape = CircleShape,
                                color = if (isConfigured) AionPurpleStrong else Color(0xFF39343F),
                                modifier = Modifier.size(40.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(Icons.Outlined.ArrowUpward, contentDescription = "إرسال", tint = Color.White, modifier = Modifier.size(20.dp))
                                }
                            }
                        }

                        else -> {
                            val scale = if (isListening) (1f + (rms / 60f)).coerceAtMost(1.18f) else 1f
                            Surface(
                                onClick = { toggleListening() },
                                enabled = !isSending,
                                shape = CircleShape,
                                color = if (isListening) Color(0xFF2B1A42) else Color.Transparent,
                                modifier = Modifier.size(40.dp).scale(scale)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        Icons.Outlined.Mic,
                                        contentDescription = if (isListening) "إيقاف الاستماع" else "الصوت",
                                        tint = if (isListening) AionPurpleSoft else MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.size(21.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            Text(
                "قد يخطئ AION؛ تحقق من المعلومات المهمة.",
                modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp),
                textAlign = TextAlign.Center,
                fontSize = 9.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1
            )
        }
    }

    if (showAttachSheet) {
        ModalBottomSheet(
            onDismissRequest = { showAttachSheet = false },
            containerColor = Color(0xFF111218)
        ) {
            Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 8.dp)) {
                Text("أضف إلى المحادثة", fontSize = 19.sp, fontWeight = FontWeight.Bold)
                Text("يمكنك إرسال حتى 4 عناصر وبحجم إجمالي 5 MB حاليًا.", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(12.dp))
                AttachmentSheetRow(
                    icon = Icons.Outlined.Image,
                    title = "صورة",
                    subtitle = "PNG وJPEG وWEBP وGIF",
                    accent = AionPurple,
                    onClick = {
                        showAttachSheet = false
                        imagePicker.launch(arrayOf("image/*"))
                    }
                )
                AttachmentSheetRow(
                    icon = Icons.Outlined.Description,
                    title = "ملف",
                    subtitle = "PDF وWord وExcel ونصوص وكود",
                    accent = AionBlueSoft,
                    onClick = {
                        showAttachSheet = false
                        filePicker.launch(
                            arrayOf(
                                "application/pdf",
                                "text/*",
                                "application/json",
                                "application/xml",
                                "application/msword",
                                "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                                "application/vnd.ms-powerpoint",
                                "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                                "application/vnd.ms-excel",
                                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                            )
                        )
                    }
                )
                Spacer(Modifier.height(22.dp))
            }
        }
    }
}

@Composable
private fun InfoChip(text: String, accent: Color) {
    Surface(
        shape = RoundedCornerShape(13.dp),
        color = accent.copy(alpha = 0.10f),
        border = BorderStroke(1.dp, accent.copy(alpha = 0.28f))
    ) {
        Text(text, modifier = Modifier.padding(horizontal = 9.dp, vertical = 6.dp), color = accent, fontSize = 10.sp)
    }
}

@Composable
private fun AttachmentChip(attachment: ChatAttachment, onRemove: () -> Unit) {
    Surface(
        shape = RoundedCornerShape(13.dp),
        color = Color(0xFF18171E),
        border = BorderStroke(1.dp, Color(0xFF312B39))
    ) {
        Row(
            modifier = Modifier.padding(start = 8.dp, end = 3.dp, top = 4.dp, bottom = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                if (attachment.kind == AttachmentKind.IMAGE) Icons.Outlined.Image else Icons.Outlined.Description,
                contentDescription = null,
                modifier = Modifier.size(14.dp),
                tint = if (attachment.kind == AttachmentKind.IMAGE) AionPurpleSoft else AionBlueSoft
            )
            Spacer(Modifier.width(5.dp))
            Column {
                Text(attachment.name, fontSize = 9.sp, maxLines = 1)
                Text(formatSize(attachment.sizeBytes), fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            IconButton(onClick = onRemove, modifier = Modifier.size(28.dp)) {
                Icon(Icons.Outlined.Close, contentDescription = "إزالة", modifier = Modifier.size(13.dp))
            }
        }
    }
}

@Composable
private fun PendingAttachmentPreview(attachment: ChatAttachment, onRemove: () -> Unit) {
    if (attachment.kind == AttachmentKind.IMAGE) {
        val bitmap = rememberAttachmentPreview(attachment)
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = Color(0xFF18171E),
            border = BorderStroke(1.dp, Color(0xFF312B39))
        ) {
            Row(
                modifier = Modifier.padding(start = 5.dp, end = 2.dp, top = 5.dp, bottom = 5.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (bitmap != null) {
                    Image(
                        bitmap = bitmap.asImageBitmap(),
                        contentDescription = attachment.name,
                        modifier = Modifier.size(42.dp).clip(RoundedCornerShape(11.dp)),
                        contentScale = ContentScale.Crop
                    )
                } else {
                    Surface(shape = RoundedCornerShape(11.dp), color = AionPurple.copy(alpha = 0.12f), modifier = Modifier.size(42.dp)) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(Icons.Outlined.Image, contentDescription = null, tint = AionPurpleSoft, modifier = Modifier.size(18.dp))
                        }
                    }
                }
                Spacer(Modifier.width(7.dp))
                Column(modifier = Modifier.widthIn(max = 116.dp)) {
                    Text(attachment.name, fontSize = 10.sp, maxLines = 1)
                    Text(formatSize(attachment.sizeBytes), fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                IconButton(onClick = onRemove, modifier = Modifier.size(30.dp)) {
                    Icon(Icons.Outlined.Close, contentDescription = "إزالة المرفق", modifier = Modifier.size(14.dp))
                }
            }
        }
    } else {
        AttachmentChip(attachment = attachment, onRemove = onRemove)
    }
}

@Composable
private fun AttachmentSheetRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    accent: Color,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        shape = RoundedCornerShape(17.dp),
        color = Color(0xFF181920)
    ) {
        Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Surface(shape = CircleShape, color = accent.copy(alpha = 0.13f), modifier = Modifier.size(38.dp)) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(icon, contentDescription = null, tint = accent, modifier = Modifier.size(19.dp))
                }
            }
            Spacer(Modifier.width(11.dp))
            Column {
                Text(title, fontWeight = FontWeight.SemiBold)
                Text(subtitle, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 10.sp)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SourcesSheet(sources: List<ChatSource>, onOpen: (ChatSource) -> Unit, onDismiss: () -> Unit) {
    ModalBottomSheet(onDismissRequest = onDismiss, containerColor = Color(0xFF111218)) {
        Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 8.dp)) {
            Text("المصادر", fontSize = 19.sp, fontWeight = FontWeight.Bold)
            Text("المصادر التي استخدمها الرد عند البحث في الويب.", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 11.sp)
            Spacer(Modifier.height(12.dp))
            sources.forEachIndexed { index, source ->
                Surface(
                    onClick = { onOpen(source) },
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    shape = RoundedCornerShape(15.dp),
                    color = Color(0xFF181920)
                ) {
                    Row(modifier = Modifier.padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
                        Surface(shape = CircleShape, color = AionBlueSoft.copy(alpha = 0.12f), modifier = Modifier.size(28.dp)) {
                            Box(contentAlignment = Alignment.Center) {
                                Text("${index + 1}", color = AionBlueSoft, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                        Spacer(Modifier.width(9.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(source.title, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, maxLines = 2)
                            Text(source.url, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 9.sp, maxLines = 1)
                        }
                    }
                }
            }
            Spacer(Modifier.height(22.dp))
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ModelPickerSheet(
    options: List<AiModelOption>,
    selectedKey: String,
    onSelect: (String) -> Unit,
    onDismiss: () -> Unit
) {
    ModalBottomSheet(onDismissRequest = onDismiss, containerColor = Color(0xFF111218)) {
        Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 8.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("وضع AION لهذه المحادثة", fontSize = 19.sp, fontWeight = FontWeight.Bold)
                    Text(
                        "يُحفظ الاختيار لهذه المحادثة ويمكن تغييره في أي وقت.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 11.sp
                    )
                }
                IconButton(onClick = onDismiss) { Icon(Icons.Outlined.Close, contentDescription = "إغلاق") }
            }

            Spacer(Modifier.height(12.dp))
            options.forEach { option ->
                val selected = option.key == selectedKey
                Surface(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp).clickable(enabled = option.enabled) {
                        onSelect(option.key)
                    },
                    shape = RoundedCornerShape(17.dp),
                    color = if (selected) Color(0xFF26193A) else Color(0xFF181920),
                    border = BorderStroke(1.dp, if (selected) AionPurple else Color(0xFF2E2A36))
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(13.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        ModelGlyph(option)
                        Spacer(Modifier.width(11.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                option.label,
                                fontWeight = FontWeight.SemiBold,
                                color = if (option.enabled) MaterialTheme.colorScheme.onSurface else Color(0xFF77727D)
                            )
                            Text(option.provider, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 10.sp)
                        }
                        option.badge?.let {
                            Text(it, color = if (option.enabled) AionPurpleSoft else Color(0xFF77727D), fontSize = 9.sp)
                            Spacer(Modifier.width(7.dp))
                        }
                        if (selected) Icon(Icons.Outlined.Check, contentDescription = null, tint = AionPurple)
                    }
                }
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun ModelGlyph(option: AiModelOption) {
    val color = when {
        option.key == "auto" -> AionPurple
        option.provider == "OpenAI" -> Color(0xFFE8E8EC)
        option.key == "claude" -> Color(0xFFE07B49)
        option.key == "gemini" -> AionBlueSoft
        option.key == "grok" -> Color(0xFFD7D7DA)
        option.key == "deepseek" -> Color(0xFF658CFF)
        else -> AionPurpleSoft
    }
    Surface(shape = CircleShape, color = color.copy(alpha = 0.14f), modifier = Modifier.size(36.dp)) {
        Box(contentAlignment = Alignment.Center) {
            Text(
                when (option.key) {
                    "auto" -> "A"
                    "fast" -> "↗"
                    "deep" -> "◈"
                    "research" -> "⌕"
                    "claude" -> "C"
                    "gemini" -> "✦"
                    "grok" -> "X"
                    else -> "AI"
                },
                color = color,
                fontWeight = FontWeight.ExtraBold,
                fontSize = 12.sp
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ContextSheet(
    messageCount: Int,
    selectedModel: AiModelOption,
    isConfigured: Boolean,
    cloudHealthLabel: String,
    cloudHealthOk: Boolean?,
    pendingAttachments: Int,
    memoryEnabled: Boolean,
    projectName: String?,
    onDismiss: () -> Unit
) {
    ModalBottomSheet(onDismissRequest = onDismiss, containerColor = Color(0xFF111218)) {
        Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 8.dp)) {
            Text("سياق المحادثة", fontSize = 19.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(5.dp))
            Text(
                "هذه اللوحة تظهر عند الطلب فقط حتى تبقى الدردشة نظيفة.",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = 11.sp
            )
            Spacer(Modifier.height(15.dp))
            ContextRow("النموذج الحالي", selectedModel.label, AionPurple)
            ContextRow("الرسائل", messageCount.toString(), AionPurpleSoft)
            ContextRow("المشروع", projectName ?: "بدون مشروع", if (projectName != null) AionPurple else Color(0xFF8C8794))
            ContextRow("البحث في الويب", "تلقائي عند الحاجة", AionBlueSoft)
            ContextRow("المرفقات الجاهزة", pendingAttachments.toString(), AionPurpleSoft)
            ContextRow(
                "اتصال AION Cloud",
                when {
                    !isConfigured -> "غير مضبوط"
                    cloudHealthOk == true -> cloudHealthLabel
                    cloudHealthOk == false -> "تعذر التحقق"
                    else -> "العنوان مضبوط"
                },
                when {
                    cloudHealthOk == true -> AionPurple
                    cloudHealthOk == false -> MaterialTheme.colorScheme.error
                    else -> Color(0xFF8C8794)
                }
            )
            ContextRow("الذاكرة المحلية", if (memoryEnabled) "مفعلة" else "غير مضافة", if (memoryEnabled) AionPurple else Color(0xFF8C8794))
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun ContextRow(label: String, value: String, accent: Color) {
    Surface(
        modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp),
        shape = RoundedCornerShape(15.dp),
        color = Color(0xFF181920)
    ) {
        Row(modifier = Modifier.fillMaxWidth().padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(7.dp).clip(CircleShape).background(accent))
            Spacer(Modifier.width(9.dp))
            Text(label, modifier = Modifier.weight(1f), color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
            Text(value, fontWeight = FontWeight.SemiBold, fontSize = 11.sp)
        }
    }
}

@Composable
private fun AionMark(size: androidx.compose.ui.unit.Dp) {
    Surface(
        shape = RoundedCornerShape(size * 0.28f),
        color = Color(0xFF1B102A),
        modifier = Modifier.size(size),
        border = BorderStroke(1.dp, AionPurple.copy(alpha = 0.22f))
    ) {
        Box(contentAlignment = Alignment.Center) {
            Text(
                "A",
                color = AionPurpleSoft,
                fontSize = (size.value * 0.48f).sp,
                fontWeight = FontWeight.Black
            )
            Box(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = size * 0.18f)
                    .size(size * 0.13f)
                    .clip(CircleShape)
                    .background(AionPurple)
            )
        }
    }
}

@Composable
private fun SettingsDialog(
    initialEndpoint: String,
    initialInstructions: String,
    initialMemory: String,
    cloudHealthLabel: String,
    cloudHealthOk: Boolean?,
    isCheckingCloud: Boolean,
    onCheckCloud: (String) -> Unit,
    onSave: (String, String, String) -> Unit,
    onDismiss: () -> Unit
) {
    var endpoint by remember(initialEndpoint) { mutableStateOf(initialEndpoint) }
    var instructions by remember(initialInstructions) { mutableStateOf(initialInstructions) }
    var memory by remember(initialMemory) { mutableStateOf(initialMemory) }

    AlertDialog(
        onDismissRequest = onDismiss,
        icon = { Icon(Icons.Outlined.Settings, contentDescription = null, tint = AionPurple) },
        title = { Text("إعدادات AION") },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    "AION يتصل بخدمة AION Cloud من دون وضع مفاتيح مزودي الذكاء داخل التطبيق.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 11.sp
                )
                OutlinedTextField(
                    value = endpoint,
                    onValueChange = { endpoint = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("عنوان AION Cloud") },
                    supportingText = { Text("مثال: https://aion-core.اسمك.workers.dev") },
                    singleLine = true
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        cloudHealthLabel,
                        modifier = Modifier.weight(1f),
                        fontSize = 10.sp,
                        color = when (cloudHealthOk) {
                            true -> AionPurpleSoft
                            false -> MaterialTheme.colorScheme.error
                            null -> MaterialTheme.colorScheme.onSurfaceVariant
                        }
                    )
                    TextButton(
                        enabled = !isCheckingCloud && endpoint.trim().startsWith("https://"),
                        onClick = { onCheckCloud(endpoint) }
                    ) {
                        Text(if (isCheckingCloud) "جارٍ الفحص…" else "اختبار الاتصال")
                    }
                }
                OutlinedTextField(
                    value = instructions,
                    onValueChange = { instructions = it.take(8_000) },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("تعليمات AION") },
                    placeholder = { Text("مثال: أجب بالعربية، وكن دقيقًا ومباشرًا.") },
                    minLines = 3,
                    maxLines = 6
                )
                OutlinedTextField(
                    value = memory,
                    onValueChange = { memory = it.take(16_000) },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("ذاكرة محلية") },
                    placeholder = { Text("اكتب فقط المعلومات التي تريد من AION تذكرها.") },
                    minLines = 3,
                    maxLines = 7
                )
                Text(
                    "التعليمات والذاكرة محفوظتان على الجهاز وتُرسلان إلى AION Cloud مع الطلب فقط. لا تضع مفاتيح API أو كلمات مرور هنا.",
                    fontSize = 10.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        },
        confirmButton = {
            TextButton(
                enabled = endpoint.trim().startsWith("https://"),
                onClick = { onSave(endpoint, instructions, memory) }
            ) { Text("حفظ") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}

@Composable
private fun CapabilityDialog(capability: AionCapability, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        icon = { Icon(capability.icon(), contentDescription = null, tint = AionPurple) },
        title = { Text(capability.title) },
        text = {
            Column {
                Text(capability.description)
                Spacer(Modifier.height(12.dp))
                Text("الحالة: ${capability.state.label()}", color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (capability.state != CapabilityState.READY) {
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "البنية الأساسية موجودة وسيتم ربط التنفيذ الكامل ضمن خارطة AION Master.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("حسنًا") } }
    )
}

private fun CapabilityState.label(): String = when (this) {
    CapabilityState.READY -> "جاهز"
    CapabilityState.FOUNDATION -> "البنية جاهزة — الربط مستمر"
    CapabilityState.PLANNED -> "مخطط له"
}

private fun AionCapability.icon(): ImageVector = when (key) {
    "agent" -> Icons.Outlined.SmartToy
    "memory" -> Icons.Outlined.Memory
    "files" -> Icons.Outlined.Folder
    "voice" -> Icons.Outlined.Mic
    "search" -> Icons.Outlined.Search
    "tools" -> Icons.Outlined.Build
    else -> Icons.Outlined.Psychology
}

private fun formatSize(sizeBytes: Long): String = when {
    sizeBytes >= 1024L * 1024L -> String.format(Locale.US, "%.1f MB", sizeBytes / (1024f * 1024f))
    sizeBytes >= 1024L -> String.format(Locale.US, "%.0f KB", sizeBytes / 1024f)
    else -> "$sizeBytes B"
}
