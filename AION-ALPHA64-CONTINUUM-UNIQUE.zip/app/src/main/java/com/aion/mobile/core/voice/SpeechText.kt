package com.aion.mobile.core.voice

import android.speech.tts.TextToSpeech
import kotlin.math.min

/**
 * يجهز ردود AION للقراءة الصوتية بدل تمرير Markdown/روابط/كود إلى TTS حرفيًا.
 * الهدف ليس تغيير معنى الرد، بل إزالة الرموز التي تجعل النطق آليًا ومزعجًا.
 */
object SpeechText {
    private val fencedCode = Regex("```[\\s\\S]*?```")
    private val markdownLink = Regex("\\[([^]\\n]{1,160})]\\((https?://[^)\\s]+)\\)")
    private val bareUrl = Regex("https?://\\S+")
    private val citation = Regex("\\[(\\d{1,3}(?:\\s*[,،-]\\s*\\d{1,3})*)]")
    private val markdownHeading = Regex("(?m)^\\s{0,3}#{1,6}\\s+")
    private val markdownBullet = Regex("(?m)^\\s*[-*+]\\s+")
    private val markdownNumber = Regex("(?m)^\\s*\\d+[.)]\\s+")
    private val markdownQuote = Regex("(?m)^\\s*>\\s?")
    private val repeatedWhitespace = Regex("[ \\t]{2,}")
    private val repeatedBreaks = Regex("\\n{3,}")

    fun clean(text: String): String {
        if (text.isBlank()) return ""
        return text
            .replace(fencedCode, "\n")
            .replace(markdownLink) { it.groupValues[1] }
            .replace(bareUrl, " رابط ")
            .replace(citation, "")
            .replace(markdownHeading, "")
            .replace(markdownBullet, "")
            .replace(markdownNumber, "")
            .replace(markdownQuote, "")
            .replace("**", "")
            .replace("__", "")
            .replace("~~", "")
            .replace("`", "")
            .replace('|', ' ')
            .replace(repeatedWhitespace, " ")
            .replace(repeatedBreaks, "\n\n")
            .trim()
    }

    fun chunks(text: String): List<String> {
        val clean = clean(text)
        if (clean.isBlank()) return emptyList()
        // مقاطع أقصر تقلل زمن بدء TTS وتجعل المقاطعة أكثر استجابة، مع البقاء دون حد Android.
        val hardLimit = min((TextToSpeech.getMaxSpeechInputLength() - 128).coerceAtLeast(800), 1_200)
        if (clean.length <= hardLimit) return listOf(clean)

        val result = mutableListOf<String>()
        var remaining = clean
        while (remaining.isNotBlank()) {
            if (remaining.length <= hardLimit) {
                result += remaining.trim()
                break
            }
            val window = remaining.take(hardLimit)
            val preferred = listOf("\n\n", ". ", "؟ ", "! ", "؛ ", "، ", "\n", " ")
                .map { delimiter -> window.lastIndexOf(delimiter).let { if (it >= hardLimit / 2) it + delimiter.length else -1 } }
                .maxOrNull()
                ?.takeIf { it > 0 }
                ?: hardLimit
            result += remaining.take(preferred).trim()
            remaining = remaining.drop(preferred).trimStart()
        }
        return result.filter(String::isNotBlank)
    }
}
