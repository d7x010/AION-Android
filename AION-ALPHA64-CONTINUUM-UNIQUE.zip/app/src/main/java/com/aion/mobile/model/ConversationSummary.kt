package com.aion.mobile.model

/** بطاقة خفيفة للمحادثة؛ النصوص الكاملة تبقى في تخزين مستقل لكل محادثة. */
data class ConversationSummary(
    val id: String,
    val title: String,
    val updatedAt: Long
)
