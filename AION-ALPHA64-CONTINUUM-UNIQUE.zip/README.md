# AION Mobile V2 α7 — Conversation OS

AION هو تطبيق ذكاء شخصي لـAndroid بواجهة عربية أولًا وهوية مستقلة. α7 ينقل المشروع من جلسة محادثة واحدة وتجربة Cloud محدودة إلى نواة محادثة متعددة السجلات مع Streaming حقيقي، مرفقات مقروءة، بحث حي، أوضاع ذكاء فعلية، واستمرار المهمة في الخلفية.

## ما يعمل في α7
- محادثات متعددة محليًا مع بحث في السجل، مسودة مستقلة، تبديل وحذف وترحيل بيانات α6.
- Streaming حقيقي من Workers AI عبر SSE مع زر إيقاف وForeground Service.
- AION Auto / سريع / عميق / بحث:
  - Auto/Fast: GLM-4.7-Flash.
  - Deep: GPT-OSS-120B مع fallback.
  - Research: Gemma 4 + بحث حي ومصادر، مع fallback.
- مرفقات فعلية: نص وكود وPDF/Office وصور؛ التحويل على Cloudflare Workers AI.
- حالات تشغيل صادقة: يفهم طلبك / يقرأ المرفقات / يبحث في الويب / يصيغ الرد.
- عرض كتل الكود مع monospace وتمرير أفقي ونسخ.
- ذاكرة محلية صريحة وتعليمات شخصية قابلة للتحكم.
- AION Voice بنمط turn-by-turn محسّن: SpeechRecognizer + TTS + حركة تستجيب لشدة الصوت.

## ما لا ندعي أنه مكتمل
- الصوت Full-Duplex speech-to-speech الحقيقي ما زال غير مكتمل.
- Agents وProjects ما زالا Foundation.
- Claude/Gemini/Grok غير متصلين حاليًا وتظهر خياراتهم معطلة فقط.
- الذاكرة ليست استخراجًا تلقائيًا شاملًا من كل محادثة.

## البناء
المتطلبات الحالية للبناء الرسمي:
- Java 17
- Android SDK 36 / Build Tools 36.0.0
- Gradle 9.6.1

بوابة الفحص:
```bash
gradle :app:testDebugUnitTest :app:lintDebug :app:assembleDebug --stacktrace --no-daemon
```

اختبارات Worker المحلية:
```bash
cd cloudflare/aion-core
node --check src/index.js
node test-worker.mjs
```

## Cloudflare
`cloudflare/aion-core/wrangler.toml` يستخدم Workers AI binding باسم `AI`. البحث الحي يستخدم Firecrawl عند توفر `FIRECRAWL_API_KEY`، وإلا ينتقل إلى بحث Workers AI المدمج. الصور تُرسل مباشرة إلى Gemma 4 Vision بدل تحويلها إلى Markdown.

راجع `ALPHA7_TEST_PLAN_AR.md` و`AION_ALPHA7_HANDOFF_AR.md` قبل اعتماد APK.
