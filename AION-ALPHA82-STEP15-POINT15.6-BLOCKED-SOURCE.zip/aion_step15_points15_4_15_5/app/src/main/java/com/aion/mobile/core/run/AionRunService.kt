package com.aion.mobile.core.run

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.os.Process
import android.os.SystemClock
import androidx.core.app.NotificationCompat
import com.aion.mobile.MainActivity
import com.aion.mobile.R
import com.aion.mobile.core.ai.AionCloudException
import com.aion.mobile.core.ai.AionCloudGateway
import com.aion.mobile.core.ai.AionCloudSettings
import com.aion.mobile.core.ai.AionServerRunState
import com.aion.mobile.core.ai.GatewayActivity
import com.aion.mobile.core.ai.GatewayResult
import com.aion.mobile.core.files.AttachmentLoader
import com.aion.mobile.core.knowledge.AionKnowledgeSearchIndexer
import com.aion.mobile.core.local.AionLocalIntelligence
import com.aion.mobile.core.local.BackendCallPermit
import com.aion.mobile.core.local.BackendHealthStore
import com.aion.mobile.core.local.BackendHealthTracker
import com.aion.mobile.core.local.LocalIntelligenceDecision
import com.aion.mobile.core.local.LocalTelemetry
import com.aion.mobile.core.run.fault.RecoveryAction
import com.aion.mobile.core.run.fault.RunCancellationFence
import com.aion.mobile.core.sovereign.SovereignFailureClassifier
import com.aion.mobile.core.sovereign.SovereignTask
import com.aion.mobile.core.sovereign.SovereignTaskMachine
import com.aion.mobile.core.sovereign.SovereignTaskState
import com.aion.mobile.core.storage.ChatSessionStore
import com.aion.mobile.model.ChatMessage
import com.aion.mobile.model.MessageRole
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeout
import java.io.File
import java.io.IOException
import java.time.Instant
import java.util.UUID
import kotlin.coroutines.coroutineContext

class AionRunService : Service() {
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val gateway = AionCloudGateway()
    private var activeJob: Job? = null
    private var activeRunId: String? = null
    private var activeLeaseOwner: String? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannels()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP_ALL -> {
                activeJob?.cancel(CancellationException("durable_cancel_all"))
                return START_NOT_STICKY
            }
            ACTION_STOP -> {
                val runId = intent.getStringExtra(EXTRA_RUN_ID)
                if (!runId.isNullOrBlank()) {
                    RunCancellationFence.mark(noBackupFilesDir, runId)
                    markCancelled(runId)
                }
                if (runId == null || runId == activeRunId) activeJob?.cancel(CancellationException("durable_user_cancel"))
                return START_NOT_STICKY
            }
            ACTION_START -> {
                val runId = intent.getStringExtra(EXTRA_RUN_ID) ?: return START_NOT_STICKY
                val recoveryPlan = AionRecoveryEngine.localPlan(this, runId)
                when (recoveryPlan.action) {
                    RecoveryDispatch.CLEANUP -> {
                        DurableExecutionLeaseStore.clearTerminal(noBackupFilesDir, runId)
                        return START_NOT_STICKY
                    }
                    RecoveryDispatch.HOLD, RecoveryDispatch.FAIL_CLOSED -> return START_NOT_STICKY
                    RecoveryDispatch.WAIT_BACKOFF, RecoveryDispatch.WAIT_LEASE -> {
                        AionRecoveryScheduler.scheduleGeneral(this, recoveryPlan.delayMs.coerceAtLeast(1_000L))
                        return START_NOT_STICKY
                    }
                    RecoveryDispatch.WAIT_NETWORK -> {
                        AionRecoveryScheduler.scheduleNetwork(this)
                        return START_NOT_STICKY
                    }
                    RecoveryDispatch.START_NOW -> Unit
                }

                val request = AionRunRegistry.get(runId) ?: AionRunRequestStore.load(noBackupFilesDir, runId)
                    ?: return START_NOT_STICKY
                if (RunCancellationFence.isCancelled(noBackupFilesDir, runId)) {
                    markCancelled(runId)
                    return START_NOT_STICKY
                }
                val task = SovereignTaskStore.load(noBackupFilesDir, runId)
                    ?: SovereignTask(id = runId, goal = "chat:${request.conversationId}").also { SovereignTaskStore.save(noBackupFilesDir, it) }
                if (task.state in TERMINAL_STATES || task.state in setOf(SovereignTaskState.BLOCKED, SovereignTaskState.WAITING_USER)) {
                    return START_NOT_STICKY
                }

                if (activeJob?.isActive == true && activeRunId != runId) {
                    AionRecoveryScheduler.scheduleGeneral(this, 2_000L)
                    return START_NOT_STICKY
                }

                val leaseOwner = "android-${Process.myPid()}-${UUID.randomUUID()}"
                when (DurableExecutionLeaseStore.acquire(noBackupFilesDir, runId, leaseOwner, System.currentTimeMillis(), LEASE_TTL_MS)) {
                    LeaseClaimResult.HELD_BY_OTHER -> {
                        val lease = DurableExecutionLeaseStore.read(noBackupFilesDir, runId)
                        AionRecoveryScheduler.scheduleGeneral(this, ((lease?.untilMs ?: 0L) - System.currentTimeMillis()).coerceAtLeast(1_000L))
                        return START_NOT_STICKY
                    }
                    LeaseClaimResult.ACQUIRED, LeaseClaimResult.RENEWED -> Unit
                }

                AionRunRegistry.register(request)
                activeRunId = runId
                activeLeaseOwner = leaseOwner
                startForeground(NOTIFICATION_WORK_ID, buildWorkingNotification("يفهم طلبك…", runId))
                activeJob = serviceScope.launch { execute(request, leaseOwner) }
            }
        }
        return START_NOT_STICKY
    }

    private suspend fun execute(request: AionRunRequest, leaseOwner: String) {
        val currentText = StringBuilder()
        var currentActivity = GatewayActivity.THINKING
        var lastCheckpointChars = 0
        var lastCheckpointAt = 0L
        var lastUiPublishChars = 0
        var lastUiPublishAt = 0L
        val endpoint = AionCloudSettings.loadEndpoint(this)
        val executionJob = coroutineContext[Job]
        val leaseHeartbeat = serviceScope.launch {
            while (isActive) {
                delay(LEASE_HEARTBEAT_MS)
                val renewed = DurableExecutionLeaseStore.renew(
                    noBackupFilesDir, request.runId, leaseOwner, System.currentTimeMillis(), LEASE_TTL_MS
                )
                if (!renewed) {
                    val task = SovereignTaskStore.load(noBackupFilesDir, request.runId)
                    if (task == null || task.state !in TERMINAL_STATES) {
                        executionJob?.cancel(CancellationException("durable_lease_lost"))
                    }
                    break
                }
            }
        }

        fun renewLeaseOrThrow() {
            val renewed = DurableExecutionLeaseStore.renew(noBackupFilesDir, request.runId, leaseOwner, System.currentTimeMillis(), LEASE_TTL_MS)
            if (!renewed) throw CancellationException("durable_lease_lost")
        }

        fun persistRuntimeCheckpoint(step: String, extra: Map<String, String> = emptyMap()) {
            val task = SovereignTaskStore.load(noBackupFilesDir, request.runId) ?: return
            if (task.state in TERMINAL_STATES) return
            val payload = linkedMapOf(
                "cloudBoundary" to "true",
                "partialChars" to currentText.length.toString(),
                "activity" to currentActivity.name,
            ).apply { putAll(extra) }
            runCatching {
                SovereignTaskStore.save(noBackupFilesDir, SovereignTaskMachine.checkpoint(task.copy(currentStep = step), payload))
            }
        }

        fun checkpointStreamingReply(force: Boolean = false) {
            if (currentText.isEmpty()) return
            val now = SystemClock.elapsedRealtime()
            val enoughText = currentText.length - lastCheckpointChars >= 2_500
            val enoughTime = now - lastCheckpointAt >= 6_000L
            if (!force && !enoughText && !enoughTime) return
            val snapshot = currentText.toString()
            ChatSessionStore.checkpointMessages(
                this,
                request.conversationId,
                request.sessionMessages + ChatMessage(
                    id = request.placeholderId,
                    role = MessageRole.AION,
                    text = snapshot,
                    modelId = request.modelId,
                    modelLabel = request.modelLabel,
                    isStreaming = true
                )
            )
            persistRuntimeCheckpoint("streaming")
            lastCheckpointChars = currentText.length
            lastCheckpointAt = now
        }

        fun publishStreamingSnapshot(force: Boolean = false) {
            if (currentText.isEmpty() && !force) return
            val now = SystemClock.elapsedRealtime()
            if (!StreamingRenderPolicy.shouldPublish(now, lastUiPublishAt, currentText.length, lastUiPublishChars, force)) return
            AionRunUiRestorer.publishDurableTruth(this, request.runId, GatewayActivity.WRITING)
            lastUiPublishAt = now
            lastUiPublishChars = currentText.length
        }

        try {
            if (RunCancellationFence.isCancelled(noBackupFilesDir, request.runId)) throw CancellationException("durable_user_cancel")
            moveToRunning(request.runId)

            val taskForReconcile = SovereignTaskStore.load(noBackupFilesDir, request.runId)
                ?: throw IllegalStateException("missing_durable_task")
            val crossedCloudBoundary = taskForReconcile.checkpoint?.payload?.get("cloudBoundary") == "true"

            // A true offline capability runs before any server reconciliation only when this run
            // has never crossed the cloud boundary. This avoids network dependency for arithmetic
            // while preserving idempotent server recovery for runs that already touched Cloud.
            if (!crossedCloudBoundary) {
                when (val local = AionLocalIntelligence.route(request.messages, request.forceWebSearch)) {
                    is LocalIntelligenceDecision.Executed -> {
                        persistSuccessfulResult(request, local.result)
                        LocalTelemetry.recordBestEffort(
                            noBackupFilesDir,
                            "local_success",
                            mapOf("model" to local.result.execution.modelId, "runId" to request.runId),
                        )
                        showCompletedNotification()
                        return
                    }
                    is LocalIntelligenceDecision.CloudRequired -> {
                        LocalTelemetry.recordBestEffort(
                            noBackupFilesDir,
                            "cloud_required",
                            mapOf("reason" to local.reason, "runId" to request.runId),
                        )
                    }
                }
            }

            val serverAttempt = runCatching { gateway.getRunStatus(endpoint, request.runId) }
            if (serverAttempt.isFailure && crossedCloudBoundary) {
                val cause = serverAttempt.exceptionOrNull() ?: IOException("run_status_unavailable")
                markWaitingNetwork(request.runId, cause)
                AionRecoveryScheduler.scheduleNetwork(this, 2_000L)
                return
            }
            val server = serverAttempt.getOrNull()
            if (server != null) {
                DurableToolReceiptStore.mirrorServer(
                    root = noBackupFilesDir,
                    runId = request.runId,
                    status = server.toolReceiptStatus,
                    effect = server.toolEffect,
                    planDigest = server.toolPlanDigest,
                    resultDigest = server.toolResultDigest,
                    updatedAtMs = server.toolUpdatedAtMs,
                )
            }
            if (server?.state == AionServerRunState.FAILED) {
                throw AionCloudException(
                    server.statusCode.takeIf { it > 0 } ?: 502,
                    server.error.ifBlank { "فشل التنفيذ السابق على AION Cloud." }
                )
            }
            if (server != null) {
                val receipt = DurableToolReceiptStore.latest(noBackupFilesDir, request.runId)
                val decision = AionRecoveryEngine.reconcilePlan(
                    localState = taskForReconcile.state,
                    serverState = server.state,
                    serverRetryAfterMs = server.retryAfterMs,
                    hasDurableRequest = AionRunRequestStore.load(noBackupFilesDir, request.runId) != null,
                    crossedCloudBoundary = crossedCloudBoundary,
                    receiptStatus = receipt?.status ?: com.aion.mobile.core.run.fault.ToolReceiptStatus.NONE,
                    toolEffect = receipt?.effect ?: com.aion.mobile.core.run.fault.ToolEffect.NONE,
                    durableCancel = RunCancellationFence.isCancelled(noBackupFilesDir, request.runId) || taskForReconcile.cancelRequested,
                )
                when (decision.action) {
                    RecoveryAction.WAIT_SERVER -> {
                        pauseForRetry(request.runId, decision.delayMs.coerceAtLeast(1_000L), decision.reason)
                        return
                    }
                    RecoveryAction.APPLY_CANCEL -> throw CancellationException("durable_user_cancel")
                    RecoveryAction.CLEANUP_TERMINAL -> return
                    RecoveryAction.BLOCK_MISSING_REQUEST,
                    RecoveryAction.BLOCK_AMBIGUOUS_SIDE_EFFECT,
                    RecoveryAction.BLOCK_SERVER_CONFLICT,
                    RecoveryAction.HOLD_USER -> {
                        markBlocked(request.runId, decision.reason)
                        return
                    }
                    RecoveryAction.WAIT_BACKOFF -> {
                        pauseForRetry(request.runId, decision.delayMs.coerceAtLeast(1_000L), decision.reason)
                        return
                    }
                    RecoveryAction.WAIT_NETWORK, RecoveryAction.RECONCILE_SERVER -> {
                        markWaitingNetwork(request.runId, IOException(decision.reason))
                        AionRecoveryScheduler.scheduleNetwork(this, 2_000L)
                        return
                    }
                    RecoveryAction.WAIT_LEASE -> {
                        AionRecoveryScheduler.scheduleGeneral(this, 2_000L)
                        return
                    }
                    RecoveryAction.SCHEDULE_BACKGROUND_JOB -> {
                        AionRecoveryScheduler.scheduleGeneral(this, decision.delayMs)
                        return
                    }
                    RecoveryAction.RESTORE_FINAL,
                    RecoveryAction.CONTINUE_MODEL,
                    RecoveryAction.RESUME_RUN,
                    RecoveryAction.RESUME_TOOL -> Unit // Same idempotency key lets the Worker replay/continue safely.
                }
            }

            val taskBeforeCloud = SovereignTaskStore.load(noBackupFilesDir, request.runId)
            if (taskBeforeCloud != null && taskBeforeCloud.state !in TERMINAL_STATES) {
                SovereignTaskStore.save(
                    noBackupFilesDir,
                    SovereignTaskMachine.checkpoint(taskBeforeCloud.copy(currentStep = "cloud"), mapOf("cloudBoundary" to "true"))
                )
            }

            val cloudMessages = request.messages.map { message ->
                if (message.role != MessageRole.USER || message.attachments.isEmpty()) message else {
                    val restored = message.attachments.mapNotNull { AttachmentLoader.restoreData(it) }
                    if (restored.size != message.attachments.size) {
                        throw AionCloudException(400, "تعذر استعادة بعض المرفقات من الجهاز. أعد إرفاق الملفات ثم حاول مرة أخرى.")
                    }
                    message.copy(attachments = restored)
                }
            }

            val health = BackendHealthTracker(
                BackendHealthStore(File(noBackupFilesDir, "aion_local_intelligence/backend_health.bin"))
            )
            when (val permit = health.beforeCall(CLOUD_BACKEND_ID)) {
                is BackendCallPermit.CircuitOpen -> throw AionCloudException(
                    503,
                    "AION Cloud circuit is temporarily open after repeated failures.",
                    permit.retryAfterMs.coerceAtLeast(1_000L),
                )
                is BackendCallPermit.Allowed -> Unit
            }
            val cloudStartedAt = SystemClock.elapsedRealtime()
            val finalResult: GatewayResult = try {
                withTimeout(RUN_TIMEOUT_MS) {
                    gateway.streamComplete(
                        endpoint = endpoint,
                        mode = request.modelId,
                        messages = cloudMessages,
                        forceWebSearch = request.forceWebSearch,
                        sessionId = request.conversationId,
                        customInstructions = request.customInstructions,
                        memoryContext = request.memoryContext,
                        contextContext = request.contextContext,
                        idempotencyKey = request.runId,
                        onDelta = { delta ->
                            if (RunCancellationFence.isCancelled(noBackupFilesDir, request.runId)) throw CancellationException("durable_user_cancel")
                            renewLeaseOrThrow()
                            currentText.append(delta)
                            checkpointStreamingReply()
                            publishStreamingSnapshot()
                        },
                        onActivity = { activity ->
                            if (RunCancellationFence.isCancelled(noBackupFilesDir, request.runId)) throw CancellationException("durable_user_cancel")
                            renewLeaseOrThrow()
                            currentActivity = activity
                            persistRuntimeCheckpoint("activity", mapOf("activity" to activity.name))
                            AionRunUiRestorer.publishDurableTruth(this, request.runId, currentActivity)
                            getSystemService(NotificationManager::class.java).notify(NOTIFICATION_WORK_ID, buildWorkingNotification(activityLabel(activity), request.runId))
                        }
                    )
                }.also {
                    runCatching { health.recordSuccess(CLOUD_BACKEND_ID, SystemClock.elapsedRealtime() - cloudStartedAt) }
                }
            } catch (error: Throwable) {
                if (error !is CancellationException) {
                    runCatching { health.recordFailure(CLOUD_BACKEND_ID, SystemClock.elapsedRealtime() - cloudStartedAt) }
                }
                throw error
            }

            persistSuccessfulResult(request, finalResult)
            LocalTelemetry.recordBestEffort(
                noBackupFilesDir,
                "cloud_success",
                mapOf("provider" to finalResult.execution.providerKey, "model" to finalResult.execution.modelId, "runId" to request.runId),
            )
            showCompletedNotification()
        } catch (timeout: TimeoutCancellationException) {
            checkpointStreamingReply(force = true)
            pauseForRetry(request.runId, RETRY_AFTER_TIMEOUT_MS, "foreground_service_timeout")
        } catch (cancelled: CancellationException) {
            checkpointStreamingReply(force = true)
            if (RunCancellationFence.isCancelled(noBackupFilesDir, request.runId) || cancelled.message?.contains("durable_user_cancel") == true || cancelled.message?.contains("cancel_all") == true) {
                markCancelled(request.runId)
                persistStoppedPartial(request, currentText.toString(), currentActivity)
            } else if (cancelled.message?.contains("foreground_service_timeout") == true) {
                pauseForRetry(request.runId, RETRY_AFTER_TIMEOUT_MS, "foreground_service_timeout")
            } else {
                pauseForRetry(request.runId, 2_000L, cancelled.message ?: "execution_interrupted")
            }
        } catch (cloud: AionCloudException) {
            checkpointStreamingReply(force = true)
            if (cloud.statusCode == 425) {
                pauseForRetry(request.runId, cloud.retryAfterMs.coerceAtLeast(1_000L), "server_retry_after")
            } else if (cloud.statusCode == 408 || cloud.statusCode == 429 || cloud.statusCode in 500..599) {
                markWaitingNetwork(request.runId, cloud)
                AionRecoveryScheduler.scheduleNetwork(this, cloud.retryAfterMs.coerceAtLeast(2_000L))
            } else {
                failFinal(request, currentText.toString(), currentActivity, cloud)
            }
        } catch (io: IOException) {
            checkpointStreamingReply(force = true)
            markWaitingNetwork(request.runId, io)
            AionRecoveryScheduler.scheduleNetwork(this, 2_000L)
        } catch (throwable: Throwable) {
            checkpointStreamingReply(force = true)
            failFinal(request, currentText.toString(), currentActivity, throwable)
        } finally {
            leaseHeartbeat.cancel()
            AionRunRegistry.remove(request.runId)
            DurableExecutionLeaseStore.release(noBackupFilesDir, request.runId, leaseOwner)
            if (activeRunId == request.runId) {
                activeRunId = null
                activeLeaseOwner = null
                activeJob = null
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
        }
    }

    private fun persistSuccessfulResult(request: AionRunRequest, result: GatewayResult) {
        val assistant = ChatMessage(
            id = request.placeholderId, role = MessageRole.AION, text = result.text,
            modelId = request.modelId, modelLabel = request.modelLabel,
            executionProviderKey = result.execution.providerKey, executionProviderLabel = result.execution.providerLabel,
            executionModelId = result.execution.modelId, routingPolicy = result.execution.routingPolicy,
            fallbackUsed = result.execution.fallbackUsed, executionAttempts = result.execution.attempts,
            orchestratorContract = result.orchestration.contract, orchestratorTraceId = result.orchestration.traceId.takeIf { it.isNotBlank() },
            orchestratorSearchReason = result.orchestration.searchReason.takeIf { it.isNotBlank() }, orchestratorMemoryPolicy = result.orchestration.memoryPolicy.takeIf { it.isNotBlank() },
            orchestratorToolRoute = result.orchestration.toolRoute.takeIf { it.isNotBlank() }, orchestratorResponseProfile = result.orchestration.responseProfile.takeIf { it.isNotBlank() },
            sources = result.sources, isStreaming = false
        )
        ChatSessionStore.saveMessages(this, request.conversationId, request.sessionMessages + assistant)
        // Step 12.11: only a successfully persisted, source-backed result is eligible for automatic Knowledge indexing.
        runCatching { AionKnowledgeSearchIndexer.indexSuccessfulSources(this, request.conversationId, result.sources) }
        markCompleted(request.runId, result.text)
        DurableBackoffStore.clear(noBackupFilesDir, request.runId)
        AionRunBus.publish(
            AionRunSnapshot(
                runId = request.runId, conversationId = request.conversationId, placeholderId = request.placeholderId,
                modelId = request.modelId, modelLabel = request.modelLabel,
                executionProviderKey = result.execution.providerKey, executionProviderLabel = result.execution.providerLabel,
                executionModelId = result.execution.modelId, routingPolicy = result.execution.routingPolicy,
                fallbackUsed = result.execution.fallbackUsed, executionAttempts = result.execution.attempts,
                orchestratorContract = result.orchestration.contract, orchestratorTraceId = result.orchestration.traceId,
                orchestratorSearchReason = result.orchestration.searchReason, orchestratorMemoryPolicy = result.orchestration.memoryPolicy,
                orchestratorToolRoute = result.orchestration.toolRoute, orchestratorResponseProfile = result.orchestration.responseProfile,
                text = result.text, activity = GatewayActivity.WRITING, isRunning = false, sources = result.sources
            )
        )
    }

    private fun moveToRunning(runId: String) {
        var task = SovereignTaskStore.load(noBackupFilesDir, runId) ?: return
        if (task.state == SovereignTaskState.QUEUED) {
            task = SovereignTaskMachine.transition(task, SovereignTaskState.PLANNING)
            SovereignTaskStore.save(noBackupFilesDir, task)
        }
        if (task.state != SovereignTaskState.RUNNING && SovereignTaskMachine.canTransition(task.state, SovereignTaskState.RUNNING)) {
            task = SovereignTaskMachine.transition(task, SovereignTaskState.RUNNING)
            SovereignTaskStore.save(noBackupFilesDir, task)
        }
        AionRunUiRestorer.publishDurableTruth(this, runId)
    }

    private fun markCompleted(runId: String, finalText: String) {
        var task = SovereignTaskStore.load(noBackupFilesDir, runId) ?: return
        if (task.state in TERMINAL_STATES) return
        if (task.state != SovereignTaskState.VERIFYING && SovereignTaskMachine.canTransition(task.state, SovereignTaskState.VERIFYING)) {
            task = SovereignTaskMachine.transition(task, SovereignTaskState.VERIFYING)
            SovereignTaskStore.save(noBackupFilesDir, task)
            AionRunUiRestorer.publishDurableTruth(this, runId)
        }
        if (task.state == SovereignTaskState.VERIFYING) {
            task = SovereignTaskMachine.checkpoint(task, mapOf("finalCheckpoint" to "true", "finalDigest" to DurableRunFiles.sha256(finalText)))
            task = SovereignTaskMachine.transition(task, SovereignTaskState.COMPLETED)
        }
        SovereignTaskStore.save(noBackupFilesDir, task)
        if (task.state == SovereignTaskState.COMPLETED) DurableExecutionLeaseStore.clearTerminal(noBackupFilesDir, runId)
    }

    private fun markCancelled(runId: String) {
        val task = SovereignTaskStore.load(noBackupFilesDir, runId) ?: return
        if (task.state in TERMINAL_STATES) return
        val requested = SovereignTaskMachine.requestCancel(task)
        SovereignTaskStore.save(noBackupFilesDir, SovereignTaskMachine.applyCancellation(requested))
        DurableBackoffStore.clear(noBackupFilesDir, runId)
        DurableExecutionLeaseStore.clearTerminal(noBackupFilesDir, runId)
    }

    private fun pauseForRetry(runId: String, delayMs: Long, reason: String) {
        val now = System.currentTimeMillis()
        val task = SovereignTaskStore.load(noBackupFilesDir, runId) ?: return
        if (task.state in TERMINAL_STATES) return
        val paused = if (task.state == SovereignTaskState.PAUSED) task else if (SovereignTaskMachine.canTransition(task.state, SovereignTaskState.PAUSED)) {
            SovereignTaskMachine.transition(task, SovereignTaskState.PAUSED)
        } else task.copy(state = SovereignTaskState.PAUSED, updatedAt = Instant.now().toString(), revision = task.revision + 1)
        SovereignTaskStore.save(noBackupFilesDir, paused.copy(blockedReason = reason, nextRetryAt = Instant.ofEpochMilli(now + delayMs).toString()))
        AionRunUiRestorer.publishDurableTruth(this, runId)
        DurableBackoffStore.setNotBefore(noBackupFilesDir, runId, now + delayMs)
        AionRecoveryScheduler.scheduleGeneral(this, delayMs)
    }

    private fun markWaitingNetwork(runId: String, error: Throwable) {
        val task = SovereignTaskStore.load(noBackupFilesDir, runId) ?: return
        if (task.state in TERMINAL_STATES) return
        val failure = SovereignFailureClassifier.classify(
            status = (error as? AionCloudException)?.statusCode ?: 0,
            message = error.message.orEmpty()
        )
        val next = if (SovereignTaskMachine.canTransition(task.state, SovereignTaskState.WAITING_NETWORK)) {
            SovereignTaskMachine.transition(task, SovereignTaskState.WAITING_NETWORK)
        } else task.copy(state = SovereignTaskState.WAITING_NETWORK, revision = task.revision + 1, updatedAt = Instant.now().toString())
        SovereignTaskStore.save(noBackupFilesDir, next.copy(lastFailure = failure))
        AionRunUiRestorer.publishDurableTruth(this, runId)
    }

    private fun markBlocked(runId: String, reason: String) {
        val task = SovereignTaskStore.load(noBackupFilesDir, runId) ?: return
        if (task.state in TERMINAL_STATES) return
        val blocked = if (SovereignTaskMachine.canTransition(task.state, SovereignTaskState.BLOCKED)) {
            SovereignTaskMachine.transition(task, SovereignTaskState.BLOCKED)
        } else task.copy(state = SovereignTaskState.BLOCKED, revision = task.revision + 1, updatedAt = Instant.now().toString())
        SovereignTaskStore.save(noBackupFilesDir, blocked.copy(blockedReason = reason))
        AionRunUiRestorer.publishDurableTruth(this, runId)
        DurableBackoffStore.clear(noBackupFilesDir, runId)
    }

    private fun persistStoppedPartial(request: AionRunRequest, stoppedText: String, activity: GatewayActivity) {
        val assistant = if (stoppedText.isBlank()) null else ChatMessage(
            id = request.placeholderId, role = MessageRole.AION, text = stoppedText,
            modelId = request.modelId, modelLabel = request.modelLabel, isStreaming = false, wasStopped = true
        )
        ChatSessionStore.saveMessages(this, request.conversationId, request.sessionMessages + listOfNotNull(assistant))
        AionRunBus.publish(AionRunSnapshot(
            runId = request.runId, conversationId = request.conversationId, placeholderId = request.placeholderId,
            modelId = request.modelId, modelLabel = request.modelLabel, text = stoppedText,
            activity = activity, isRunning = false, wasStopped = true
        ))
    }

    private fun failFinal(request: AionRunRequest, partial: String, activity: GatewayActivity, throwable: Throwable) {
        val errorText = readableError(throwable)
        val task = SovereignTaskStore.load(noBackupFilesDir, request.runId)
        if (task != null && task.state !in TERMINAL_STATES) {
            val failure = SovereignFailureClassifier.classify(
                status = (throwable as? AionCloudException)?.statusCode ?: 0,
                message = throwable.message.orEmpty()
            )
            val finalTask = if (SovereignTaskMachine.canTransition(task.state, SovereignTaskState.FAILED_FINAL)) {
                SovereignTaskMachine.transition(task, SovereignTaskState.FAILED_FINAL)
            } else task.copy(state = SovereignTaskState.FAILED_FINAL, revision = task.revision + 1, updatedAt = Instant.now().toString())
            SovereignTaskStore.save(noBackupFilesDir, finalTask.copy(lastFailure = failure))
        }
        DurableBackoffStore.clear(noBackupFilesDir, request.runId)
        DurableExecutionLeaseStore.clearTerminal(noBackupFilesDir, request.runId)
        val assistant = ChatMessage(
            id = request.placeholderId, role = MessageRole.AION, text = errorText,
            modelId = request.modelId, modelLabel = request.modelLabel, isError = true, isStreaming = false
        )
        ChatSessionStore.saveMessages(this, request.conversationId, request.sessionMessages + assistant)
        AionRunBus.publish(AionRunSnapshot(
            runId = request.runId, conversationId = request.conversationId, placeholderId = request.placeholderId,
            modelId = request.modelId, modelLabel = request.modelLabel, text = if (partial.isBlank()) errorText else partial,
            activity = activity, isRunning = false, errorText = errorText
        ))
        showFailedNotification()
    }

    private fun activityLabel(activity: GatewayActivity): String = when (activity) {
        GatewayActivity.THINKING -> "يفهم طلبك…"
        GatewayActivity.READING_FILES -> "يقرأ المرفقات…"
        GatewayActivity.SEARCHING_WEB -> "يبحث في الويب…"
        GatewayActivity.COMPARING -> "يقارن النتائج…"
        GatewayActivity.WRITING -> "يصيغ الإجابة…"
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(NotificationChannel(CHANNEL_WORK, "مهام AION الجارية", NotificationManager.IMPORTANCE_LOW).apply {
            description = "حالة البحث والردود والمهام التي تعمل في الخلفية"; setShowBadge(false)
        })
        manager.createNotificationChannel(NotificationChannel(CHANNEL_DONE, "نتائج AION", NotificationManager.IMPORTANCE_DEFAULT).apply {
            description = "إشعار عند اكتمال رد أو مهمة أثناء وجودك خارج التطبيق"
        })
    }

    private fun openAppPendingIntent(): PendingIntent = PendingIntent.getActivity(
        this, 11, Intent(this, MainActivity::class.java).apply { flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP },
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    private fun buildWorkingNotification(status: String, runId: String): android.app.Notification {
        val stopIntent = PendingIntent.getService(
            this, 12, Intent(this, AionRunService::class.java).apply { action = ACTION_STOP; putExtra(EXTRA_RUN_ID, runId) },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_WORK)
            .setSmallIcon(R.drawable.ic_launcher_foreground).setContentTitle("AION يعمل على طلبك").setContentText(status)
            .setContentIntent(openAppPendingIntent()).setOngoing(true).setOnlyAlertOnce(true).setCategory(NotificationCompat.CATEGORY_PROGRESS)
            .addAction(0, "إلغاء", stopIntent).build()
    }

    private fun showCompletedNotification() {
        getSystemService(NotificationManager::class.java).notify(
            NOTIFICATION_DONE_ID,
            NotificationCompat.Builder(this, CHANNEL_DONE).setSmallIcon(R.drawable.ic_launcher_foreground)
                .setContentTitle("AION أكمل الرد").setContentText("النتيجة جاهزة. اضغط للعودة إلى المحادثة.")
                .setContentIntent(openAppPendingIntent()).setAutoCancel(true).setCategory(NotificationCompat.CATEGORY_MESSAGE).build()
        )
    }

    private fun showFailedNotification() {
        getSystemService(NotificationManager::class.java).notify(
            NOTIFICATION_DONE_ID,
            NotificationCompat.Builder(this, CHANNEL_DONE).setSmallIcon(R.drawable.ic_launcher_foreground)
                .setContentTitle("تعذر إكمال طلب AION").setContentText("افتح المحادثة لمعرفة التفاصيل والمحاولة من جديد.")
                .setContentIntent(openAppPendingIntent()).setAutoCancel(true).build()
        )
    }

    private fun readableError(error: Throwable): String = when (error) {
        is AionCloudException -> when (error.statusCode) {
            400 -> error.message ?: "الطلب غير صالح. راجع إعدادات AION Cloud أو محتوى الرسالة."
            401, 403 -> "رفض AION Cloud الطلب بسبب إعداد صلاحيات الخادم. تحقق من إعداد Cloudflare ثم أعد المحاولة."
            408, 425, 502, 503, 504 -> "خدمة الذكاء مشغولة أو انقطع المسار مؤقتًا. أعد المحاولة بعد لحظات."
            413 -> error.message ?: "الرسالة أو أحد المرفقات أكبر من الحد الآمن للإرسال."
            429 -> "تم بلوغ حد استخدام مؤقت لدى الخادم أو نموذج الذكاء. انتظر قليلًا ثم أعد المحاولة."
            else -> "تعذر الحصول على رد من AION Cloud (${error.statusCode}): ${error.message}"
        }
        else -> "تعذر الاتصال بالإنترنت أو بـ AION Cloud: ${error.message.orEmpty().ifBlank { "خطأ غير معروف" }}"
    }

    override fun onTimeout(startId: Int, fgsType: Int) {
        activeRunId?.let { runId ->
            pauseForRetry(runId, RETRY_AFTER_TIMEOUT_MS, "foreground_service_timeout")
        }
        activeJob?.cancel(CancellationException("foreground_service_timeout"))
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf(startId)
        super.onTimeout(startId, fgsType)
    }

    override fun onDestroy() {
        serviceScope.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_START = "com.aion.mobile.action.START_RUN"
        const val ACTION_STOP = "com.aion.mobile.action.STOP_RUN"
        const val ACTION_STOP_ALL = "com.aion.mobile.action.STOP_ALL_RUNS"
        const val EXTRA_RUN_ID = "run_id"

        private val TERMINAL_STATES = setOf(SovereignTaskState.COMPLETED, SovereignTaskState.FAILED_FINAL, SovereignTaskState.CANCELLED)
        private const val LEASE_TTL_MS = 90_000L
        private const val LEASE_HEARTBEAT_MS = 25_000L
        private const val RUN_TIMEOUT_MS = 14 * 60_000L
        private const val RETRY_AFTER_TIMEOUT_MS = 5_000L
        private const val CLOUD_BACKEND_ID = "aion-cloud"
        private const val CHANNEL_WORK = "aion_work"
        private const val CHANNEL_DONE = "aion_done"
        private const val NOTIFICATION_WORK_ID = 4101
        private const val NOTIFICATION_DONE_ID = 4102
    }
}
