const DEFAULT_MODEL = "@cf/meta/llama-3.1-8b-instruct";
const MAX_MESSAGES = 24;
const MAX_MESSAGE_CHARS = 12_000;
const MAX_REQUESTS_PER_WINDOW = 20;
const WINDOW_MS = 10 * 60 * 1000;
const buckets = new Map();

function json(value, status = 200) {
  return new Response(JSON.stringify(value), {
    status,
    headers: {
      "content-type": "application/json; charset=utf-8",
      "cache-control": "no-store",
      "access-control-allow-origin": "*",
      "access-control-allow-methods": "POST, OPTIONS",
      "access-control-allow-headers": "content-type",
    },
  });
}

function allowRequest(request) {
  const ip = request.headers.get("CF-Connecting-IP") || "unknown";
  const now = Date.now();
  const bucket = buckets.get(ip);
  if (!bucket || now - bucket.startedAt >= WINDOW_MS) {
    buckets.set(ip, { startedAt: now, count: 1 });
    return true;
  }
  if (bucket.count >= MAX_REQUESTS_PER_WINDOW) return false;
  bucket.count += 1;
  return true;
}

function cleanMessages(input) {
  if (!Array.isArray(input) || input.length === 0) throw new Error("messages مطلوبة.");
  if (input.length > MAX_MESSAGES) throw new Error("عدد الرسائل أكبر من الحد المسموح.");
  return input.map((message) => {
    const role = message?.role === "assistant" ? "assistant" : message?.role === "system" ? "system" : "user";
    const content = typeof message?.content === "string" ? message.content.trim() : "";
    if (!content) throw new Error("كل رسالة تحتاج نصًا.");
    if (content.length > MAX_MESSAGE_CHARS) throw new Error("إحدى الرسائل طويلة جدًا.");
    return { role, content };
  });
}

export default {
  async fetch(request, env) {
    if (request.method === "OPTIONS") return json({ ok: true });
    const url = new URL(request.url);
    if (request.method === "GET" && url.pathname === "/health") {
      return json({ ok: true, service: "AION α6 Free Cloud Core", model: DEFAULT_MODEL });
    }
    if (request.method !== "POST" || url.pathname !== "/v1/chat") {
      return json({ error: "المسار غير موجود." }, 404);
    }
    if (!allowRequest(request)) return json({ error: "تم بلوغ حد التجربة المؤقت. حاول بعد بضع دقائق." }, 429);
    try {
      const payload = await request.json();
      const messages = cleanMessages(payload.messages);
      const result = await env.AI.run(DEFAULT_MODEL, { messages, max_tokens: 900, temperature: 0.7 });
      const response = typeof result?.response === "string" ? result.response.trim() : "";
      if (!response) return json({ error: "النموذج لم يُرجع نصًا." }, 502);
      return json({ response, model: DEFAULT_MODEL });
    } catch (error) {
      console.error("aion-core", error);
      return json({ error: "تعذر تنفيذ طلب الذكاء الاصطناعي." }, 500);
    }
  },
};
