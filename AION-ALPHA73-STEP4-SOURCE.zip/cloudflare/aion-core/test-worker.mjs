import assert from "node:assert/strict";
import worker from "./src/index.js";

function sseStream(parts) {
  const encoder = new TextEncoder();
  return new ReadableStream({
    start(controller) {
      for (const part of parts) controller.enqueue(encoder.encode(part));
      controller.close();
    },
  });
}

async function testTrueStreaming() {
  const calls = [];
  const env = {
    AI: {
      run: async (model, payload) => {
        calls.push({ model, payload });
        assert.equal(payload.stream, true);
        return sseStream([
          'data: {"response":"مرح"}\n\n',
          'data: {"response":"مرحبا"}\n\n',
          'data: [DONE]\n\n',
        ]);
      },
      toMarkdown: async () => { throw new Error("not expected"); },
    },
  };
  const request = new Request("https://aion.test/v1/chat/stream", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ mode: "auto", messages: [{ role: "user", content: "هلا" }] }),
  });
  const response = await worker.fetch(request, env);
  const text = await response.text();
  assert.equal(response.status, 200);
  assert.match(text, /event: delta/);
  assert.match(text, /"text":"مرح"/);
  assert.match(text, /"text":"با"/);
  assert.match(text, /"trueStreaming":true/);
  assert.equal(calls.length, 1);
}

async function testTextAttachmentContext() {
  let capturedMessages;
  const env = {
    AI: {
      run: async (_model, payload) => {
        capturedMessages = payload.messages;
        return { response: "قرأت الملف" };
      },
      toMarkdown: async () => { throw new Error("text files should decode locally"); },
    },
  };
  const data = Buffer.from("alpha beta gamma", "utf8").toString("base64");
  const request = new Request("https://aion.test/v1/chat", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({
      mode: "deep",
      messages: [{
        role: "user",
        content: "حلل الملف",
        attachments: [{ name: "notes.txt", mimeType: "text/plain", kind: "FILE", sizeBytes: 16, data }],
      }],
    }),
  });
  const response = await worker.fetch(request, env);
  const body = await response.json();
  assert.equal(response.status, 200);
  assert.equal(body.response, "قرأت الملف");
  assert.ok(capturedMessages.some((m) => m.content.includes("alpha beta gamma")));
}

async function testBinaryAttachmentConversion() {
  let converted = false;
  let capturedMessages;
  const env = {
    AI: {
      run: async (_model, payload) => {
        capturedMessages = payload.messages;
        return { response: "تم" };
      },
      toMarkdown: async (input) => {
        converted = true;
        assert.equal(input.name, "sample.pdf");
        assert.equal(input.blob.type, "application/pdf");
        return { name: "sample.pdf", format: "markdown", data: "# عنوان\nمحتوى PDF" };
      },
    },
  };
  const data = Buffer.from("fake-pdf", "utf8").toString("base64");
  const request = new Request("https://aion.test/v1/chat", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({
      messages: [{ role: "user", content: "", attachments: [{ name: "sample.pdf", mimeType: "application/pdf", kind: "FILE", sizeBytes: 8, data }] }],
    }),
  });
  const response = await worker.fetch(request, env);
  const body = await response.json();
  assert.equal(body.response, "تم");
  assert.equal(converted, true);
  assert.ok(capturedMessages.some((m) => m.content.includes("محتوى PDF")));
}

async function testStreamingFallbackBeforeFirstToken() {
  let call = 0;
  const env = {
    AI: {
      run: async () => {
        call += 1;
        if (call === 1) throw new Error("primary unavailable");
        return sseStream(['data: {"response":"بديل"}\n\ndata: [DONE]\n\n']);
      },
      toMarkdown: async () => ({ data: "" }),
    },
  };
  const response = await worker.fetch(new Request("https://aion.test/v1/chat/stream", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ messages: [{ role: "user", content: "اختبار" }] }),
  }), env);
  const text = await response.text();
  assert.equal(call, 2);
  assert.match(text, /بديل/);
}


async function testModelRouting() {
  const models = [];
  const env = {
    AI: {
      run: async (model, payload) => {
        models.push({ model, payload });
        return { response: "ok" };
      },
      toMarkdown: async () => ({ data: "" }),
    },
  };

  const deep = await worker.fetch(new Request("https://aion.test/v1/chat", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ mode: "deep", messages: [{ role: "user", content: "حلل بعمق" }] }),
  }), env);
  assert.equal(deep.status, 200);
  assert.equal(models.at(-1).model, "@cf/openai/gpt-oss-120b");
  assert.equal(models.at(-1).payload.max_tokens, 8000);

  const auto = await worker.fetch(new Request("https://aion.test/v1/chat", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ mode: "auto", messages: [{ role: "user", content: "اشرح لي هذه الفكرة" }] }),
  }), env);
  assert.equal(auto.status, 200);
  assert.equal(models.at(-1).model, "@cf/qwen/qwen3.8-27b");
  assert.equal(models.at(-1).payload.reasoning_effort, "medium");

  const greeting = await worker.fetch(new Request("https://aion.test/v1/chat", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ mode: "auto", messages: [{ role: "user", content: "هلا" }] }),
  }), env);
  assert.equal(greeting.status, 200);
  assert.equal(models.at(-1).model, "@cf/zai-org/glm-4.7-flash");

  const research = await worker.fetch(new Request("https://aion.test/v1/chat", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ mode: "research", messages: [{ role: "user", content: "بحث" }] }),
  }), { ...env, FIRECRAWL_API_KEY: undefined });
  assert.equal(research.status, 200);
  assert.equal(models.at(-1).model, "@cf/qwen/qwen3.8-27b");
  assert.deepEqual(models.at(-1).payload.web_search_options, {});
}




async function testNativeVisionRouting() {
  let capturedModel = null;
  let capturedMessages = null;
  const env = {
    AI: {
      run: async (model, payload) => {
        capturedModel = model;
        capturedMessages = payload.messages;
        return { response: "قطة" };
      },
      toMarkdown: async () => { throw new Error("image should not use markdown conversion"); },
    },
  };
  const imageData = Buffer.from("fake-image", "utf8").toString("base64");
  const response = await worker.fetch(new Request("https://aion.test/v1/chat", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({
      mode: "auto",
      messages: [{
        role: "user",
        content: "ما هذه الصورة؟",
        attachments: [{ name: "cat.jpg", mimeType: "image/jpeg", kind: "IMAGE", sizeBytes: 10, data: imageData }],
      }],
    }),
  }), env);
  assert.equal(response.status, 200);
  assert.equal(capturedModel, "@cf/qwen/qwen3.8-27b");
  const last = capturedMessages.at(-1);
  assert.ok(Array.isArray(last.content));
  assert.equal(last.content[0].type, "text");
  assert.equal(last.content[1].type, "image_url");
  assert.match(last.content[1].image_url.url, /^data:image\/jpeg;base64,/);
}

async function testNoFallbackAfterPartialToken() {
  let calls = 0;
  const encoder = new TextEncoder();
  const env = {
    AI: {
      run: async () => {
        calls += 1;
        return new ReadableStream({
          start(controller) {
            controller.enqueue(encoder.encode('data: {"response":"جزء"}\n\n'));
            controller.enqueue(encoder.encode('data: {bad-json}\n\n'));
            controller.close();
          },
        });
      },
      toMarkdown: async () => ({ data: "" }),
    },
  };
  const response = await worker.fetch(new Request("https://aion.test/v1/chat/stream", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ mode: "fast", messages: [{ role: "user", content: "اختبار" }] }),
  }), env);
  const body = await response.text();
  assert.equal(calls, 1);
  assert.match(body, /جزء/);
  assert.match(body, /event: error/);
}

async function testPersonalizationAndLongContext() {
  let capturedMessages;
  const env = {
    AI: {
      run: async (_model, payload) => {
        capturedMessages = payload.messages;
        return { response: "ok" };
      },
      toMarkdown: async () => ({ data: "" }),
    },
  };
  const messages = Array.from({ length: 140 }, (_, i) => ({
    role: i % 2 === 0 ? "user" : "assistant",
    content: `message-${i}`,
  }));
  const response = await worker.fetch(new Request("https://aion.test/v1/chat", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({
      mode: "fast",
      customInstructions: "تكلم بالعربية فقط",
      memoryContext: "اسم المشروع AION",
      messages,
    }),
  }), env);
  assert.equal(response.status, 200);
  assert.ok(capturedMessages[0].content.includes("تكلم بالعربية فقط"));
  assert.ok(capturedMessages[0].content.includes("اسم المشروع AION"));
  assert.ok(capturedMessages.length <= 121); // system + up to 96 conversation messages
  assert.ok(capturedMessages.at(-1).content.includes("message-139"));
}



async function testLargeSingleMessageLimit() {
  let receivedLength = 0;
  const env = {
    AI: {
      run: async (_model, payload) => {
        receivedLength = payload.messages.at(-1).content.length;
        return { response: "ok" };
      },
      toMarkdown: async () => ({ data: "" }),
    },
  };
  const large = "س".repeat(30_000);
  const accepted = await worker.fetch(new Request("https://aion.test/v1/chat", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ mode: "fast", messages: [{ role: "user", content: large }] }),
  }), env);
  assert.equal(accepted.status, 200);
  assert.equal(receivedLength, 30_000);

  const rejected = await worker.fetch(new Request("https://aion.test/v1/chat", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ mode: "fast", messages: [{ role: "user", content: "س".repeat(48_001) }] }),
  }), env);
  assert.equal(rejected.status, 413);
}

async function testSessionAffinity() {
  let capturedOptions = null;
  const env = {
    AI: {
      run: async (_model, _payload, options) => {
        capturedOptions = options;
        return { response: "ok" };
      },
      toMarkdown: async () => ({ data: "" }),
    },
  };
  const response = await worker.fetch(new Request("https://aion.test/v1/chat", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({
      sessionId: "conversation-123",
      messages: [{ role: "user", content: "اختبار الكاش" }],
    }),
  }), env);
  const body = await response.json();
  assert.equal(response.status, 200);
  assert.equal(body.sessionAffinity, true);
  assert.equal(capturedOptions.extraHeaders["x-session-affinity"], "conversation-123");
}

async function testNativeSearchCitations() {
  const env = {
    AI: {
      run: async () => ({
        choices: [{
          message: {
            content: "خبر حديث",
            annotations: [{
              type: "url_citation",
              url_citation: { url: "https://example.com/news", title: "Example News" },
            }],
          },
        }],
      }),
      toMarkdown: async () => ({ data: "" }),
    },
  };
  const response = await worker.fetch(new Request("https://aion.test/v1/chat", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ mode: "research", messages: [{ role: "user", content: "ابحث عن خبر" }] }),
  }), env);
  const body = await response.json();
  assert.equal(response.status, 200);
  assert.equal(body.sources[0].url, "https://example.com/news");
  assert.equal(body.sources[0].title, "Example News");
}

async function testVoiceStatusAndUnavailableFallback() {
  const baseEnv = {
    AI: {
      run: async () => ({ response: "ok" }),
      toMarkdown: async () => ({ data: "" }),
    },
  };

  const statusResponse = await worker.fetch(new Request("https://aion.test/v1/status"), baseEnv);
  const statusBody = await statusResponse.json();
  assert.equal(statusResponse.status, 200);
  assert.equal(statusBody.voice.neural, false);
  assert.equal(statusBody.voice.localFallback, true);
  assert.equal(statusBody.voice.sampleRate, 24000);

  const ttsResponse = await worker.fetch(new Request("https://aion.test/v1/voice/tts", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ text: "مرحبا" }),
  }), baseEnv);
  const ttsBody = await ttsResponse.json();
  assert.equal(ttsResponse.status, 503);
  assert.equal(ttsBody.code, "neural_voice_unavailable");
  assert.equal(ttsBody.fallback, "android-tts");
}

async function testNeuralVoiceProxy() {
  const originalFetch = globalThis.fetch;
  let capturedUrl = "";
  let capturedHeaders = null;
  let capturedBody = null;
  try {
    globalThis.fetch = async (url, options) => {
      capturedUrl = String(url);
      capturedHeaders = options.headers;
      capturedBody = JSON.parse(options.body);
      return new Response(new Uint8Array([1, 2, 3, 4]), {
        status: 200,
        headers: { "content-type": "audio/pcm" },
      });
    };

    const env = {
      ELEVENLABS_API_KEY: "server-secret",
      AION_VOICE_ID: "voice-123",
      ELEVENLABS_MODEL_ID: "eleven_flash_v2_5",
      AI: {
        run: async () => ({ response: "ok" }),
        toMarkdown: async () => ({ data: "" }),
      },
    };

    const statusResponse = await worker.fetch(new Request("https://aion.test/v1/status"), env);
    const status = await statusResponse.json();
    assert.equal(status.voice.neural, true);
    assert.equal(status.voice.provider, "elevenlabs");

    const response = await worker.fetch(new Request("https://aion.test/v1/voice/tts", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ text: "أهلا بك في AION", profile: "calm" }),
    }), env);
    assert.equal(response.status, 200);
    assert.equal(response.headers.get("x-aion-audio-format"), "pcm_s16le");
    assert.equal(response.headers.get("x-aion-sample-rate"), "24000");
    assert.equal(response.headers.get("x-aion-voice-provider"), "elevenlabs");
    assert.match(capturedUrl, /\/v1\/text-to-speech\/voice-123\/stream\?output_format=pcm_24000$/);
    assert.equal(capturedHeaders["xi-api-key"], "server-secret");
    assert.equal(capturedBody.text, "أهلا بك في AION");
    assert.equal(capturedBody.model_id, "eleven_flash_v2_5");
    assert.equal(capturedBody.voice_settings.speed, 0.94);
    assert.deepEqual([...new Uint8Array(await response.arrayBuffer())], [1, 2, 3, 4]);
  } finally {
    globalThis.fetch = originalFetch;
  }
}

await testTrueStreaming();
await testTextAttachmentContext();
await testBinaryAttachmentConversion();
await testStreamingFallbackBeforeFirstToken();
await testModelRouting();
await testPersonalizationAndLongContext();
await testNativeVisionRouting();
await testNoFallbackAfterPartialToken();
await testLargeSingleMessageLimit();
await testSessionAffinity();
await testNativeSearchCitations();
await testVoiceStatusAndUnavailableFallback();
await testNeuralVoiceProxy();
console.log("AION worker tests: PASS");
