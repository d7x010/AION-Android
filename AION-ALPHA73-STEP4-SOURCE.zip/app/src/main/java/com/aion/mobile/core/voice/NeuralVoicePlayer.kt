package com.aion.mobile.core.voice

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicReference
import kotlin.math.max

enum class NeuralVoicePlaybackResult {
    PLAYED,
    UNAVAILABLE,
    INTERRUPTED,
    FAILED
}

/**
 * Streams server-side neural PCM directly into AudioTrack.
 *
 * Provider keys never enter the APK. AION Cloud either exposes /v1/voice/tts or returns 503,
 * in which case the caller should fall back to Android TextToSpeech.
 */
class NeuralVoicePlayer {
    private val connectionRef = AtomicReference<HttpURLConnection?>(null)
    private val trackRef = AtomicReference<AudioTrack?>(null)
    private val stopRequested = AtomicBoolean(false)

    fun stop() {
        stopRequested.set(true)
        connectionRef.getAndSet(null)?.disconnect()
        trackRef.getAndSet(null)?.let(::releaseTrack)
    }

    suspend fun speak(
        endpoint: String,
        text: String,
        profile: String = "balanced",
        onStarted: () -> Unit = {},
        onLevel: (Float) -> Unit = {},
    ): NeuralVoicePlaybackResult = withContext(Dispatchers.IO) {
        val cleanEndpoint = endpoint.trim().trimEnd('/')
        val cleanText = text.trim()
        if (!cleanEndpoint.startsWith("https://") || cleanText.isBlank()) {
            return@withContext NeuralVoicePlaybackResult.UNAVAILABLE
        }

        stopRequested.set(false)
        var connection: HttpURLConnection? = null
        var track: AudioTrack? = null
        val cancellationHandle = currentCoroutineContext()[Job]?.invokeOnCompletion { cause ->
            if (cause is CancellationException) {
                stopRequested.set(true)
                connectionRef.getAndSet(null)?.disconnect()
                trackRef.getAndSet(null)?.let(::releaseTrack)
            }
        }

        try {
            connection = (URL("$cleanEndpoint/v1/voice/tts").openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                doOutput = true
                useCaches = false
                connectTimeout = 12_000
                readTimeout = 45_000
                setRequestProperty("Accept", "audio/pcm")
                setRequestProperty("Content-Type", "application/json; charset=utf-8")
                setRequestProperty("X-Aion-Client", "AION-Android/alpha7.3")
            }
            connectionRef.set(connection)

            val payload = JSONObject()
                .put("text", cleanText)
                .put("profile", profile)
                .toString()
                .toByteArray(Charsets.UTF_8)
            connection.setFixedLengthStreamingMode(payload.size)
            connection.outputStream.use { it.write(payload) }

            val code = connection.responseCode
            if (code == 404 || code == 503) {
                return@withContext NeuralVoicePlaybackResult.UNAVAILABLE
            }
            if (code !in 200..299) {
                // Consume a small server error so the TCP connection can close cleanly.
                connection.errorStream?.let { stream ->
                    runCatching {
                        BufferedReader(InputStreamReader(stream, Charsets.UTF_8)).use { it.readLine() }
                    }
                }
                return@withContext NeuralVoicePlaybackResult.FAILED
            }

            val sampleRate = connection.getHeaderField("x-aion-sample-rate")
                ?.toIntOrNull()
                ?.coerceIn(8_000, 48_000)
                ?: 24_000
            val minBuffer = AudioTrack.getMinBufferSize(
                sampleRate,
                AudioFormat.CHANNEL_OUT_MONO,
                AudioFormat.ENCODING_PCM_16BIT
            )
            if (minBuffer <= 0) return@withContext NeuralVoicePlaybackResult.FAILED

            val audioTrack = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ASSISTANT)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(sampleRate)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(max(minBuffer * 2, 16_384))
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()
            track = audioTrack
            trackRef.set(audioTrack)
            audioTrack.play()
            onStarted()

            val buffer = ByteArray(8_192)
            connection.inputStream.use { input ->
                while (true) {
                    currentCoroutineContext().ensureActive()
                    if (stopRequested.get()) return@withContext NeuralVoicePlaybackResult.INTERRUPTED
                    val read = input.read(buffer)
                    if (read < 0) break
                    if (read == 0) continue
                    val chunk = if (read == buffer.size) buffer else buffer.copyOf(read)
                    onLevel(VoiceAmplitude.pcm16LittleEndian(chunk))

                    var written = 0
                    while (written < read) {
                        currentCoroutineContext().ensureActive()
                        if (stopRequested.get()) return@withContext NeuralVoicePlaybackResult.INTERRUPTED
                        val count = audioTrack.write(buffer, written, read - written, AudioTrack.WRITE_BLOCKING)
                        if (count <= 0) return@withContext NeuralVoicePlaybackResult.FAILED
                        written += count
                    }
                }
            }
            onLevel(0f)
            if (stopRequested.get()) NeuralVoicePlaybackResult.INTERRUPTED else NeuralVoicePlaybackResult.PLAYED
        } catch (error: CancellationException) {
            throw error
        } catch (_: Throwable) {
            if (stopRequested.get()) NeuralVoicePlaybackResult.INTERRUPTED else NeuralVoicePlaybackResult.FAILED
        } finally {
            cancellationHandle?.dispose()
            connectionRef.compareAndSet(connection, null)
            trackRef.compareAndSet(track, null)
            connection?.disconnect()
            track?.let(::releaseTrack)
            onLevel(0f)
        }
    }

    private fun releaseTrack(track: AudioTrack) {
        runCatching { if (track.playState == AudioTrack.PLAYSTATE_PLAYING) track.pause() }
        runCatching { track.flush() }
        runCatching { track.stop() }
        runCatching { track.release() }
    }
}
