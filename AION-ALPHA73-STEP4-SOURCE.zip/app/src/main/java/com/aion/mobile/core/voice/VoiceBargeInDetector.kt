package com.aion.mobile.core.voice

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioDeviceInfo
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.MediaRecorder
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.NoiseSuppressor
import androidx.core.content.ContextCompat
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.concurrent.thread
import kotlin.math.sqrt

/**
 * Best-effort voice barge-in detector used only while AION is speaking.
 *
 * On built-in speaker it is enabled only when Android exposes AcousticEchoCanceler;
 * on wired/USB/Bluetooth headsets it can work without AEC because playback leakage is much lower.
 * The detector never records or stores audio: it computes a short PCM energy window and discards it.
 */
class VoiceBargeInDetector {
    private val running = AtomicBoolean(false)
    @Volatile private var record: AudioRecord? = null
    @Volatile private var worker: Thread? = null

    data class Support(
        val supported: Boolean,
        val usingEchoCancellation: Boolean,
        val headsetRoute: Boolean
    )

    fun support(context: Context): Support {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            return Support(false, false, false)
        }
        val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
        val headset = audioManager?.getDevices(AudioManager.GET_DEVICES_OUTPUTS)
            ?.any(::isHeadsetLike)
            ?: false
        val aec = AcousticEchoCanceler.isAvailable()
        return Support(supported = headset || aec, usingEchoCancellation = aec, headsetRoute = headset)
    }

    fun start(
        context: Context,
        threshold: Float = VoiceBargeInPolicy.DEFAULT_THRESHOLD,
        onVoiceDetected: () -> Unit
    ): Boolean {
        stop()
        val support = support(context)
        if (!support.supported) return false

        val sampleRate = 16_000
        val minBuffer = AudioRecord.getMinBufferSize(
            sampleRate,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        )
        if (minBuffer <= 0) return false

        val bufferBytes = maxOf(minBuffer * 2, 8_192)
        val audioRecord = runCatching {
            AudioRecord.Builder()
                .setAudioSource(MediaRecorder.AudioSource.VOICE_COMMUNICATION)
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(sampleRate)
                        .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
                        .build()
                )
                .setBufferSizeInBytes(bufferBytes)
                .build()
        }.getOrNull() ?: return false

        if (audioRecord.state != AudioRecord.STATE_INITIALIZED) {
            runCatching { audioRecord.release() }
            return false
        }

        val aec = if (AcousticEchoCanceler.isAvailable()) {
            runCatching { AcousticEchoCanceler.create(audioRecord.audioSessionId) }.getOrNull()
        } else null
        // Do not listen over the phone speaker unless a real echo canceller instance exists.
        if (!support.headsetRoute && aec == null) {
            runCatching { audioRecord.release() }
            return false
        }
        runCatching { aec?.enabled = true }

        val ns = if (NoiseSuppressor.isAvailable()) {
            runCatching { NoiseSuppressor.create(audioRecord.audioSessionId) }.getOrNull()
        } else null
        runCatching { ns?.enabled = true }

        running.set(true)
        record = audioRecord
        val localWorker = thread(name = "AION-voice-barge-in", isDaemon = true) {
            val samples = ShortArray(640) // ~40 ms at 16 kHz.
            var warmupFrames = 0
            var strongFrames = 0
            try {
                audioRecord.startRecording()
                while (running.get()) {
                    val read = audioRecord.read(samples, 0, samples.size, AudioRecord.READ_BLOCKING)
                    if (read <= 0) continue
                    if (warmupFrames < VoiceBargeInPolicy.WARMUP_FRAMES) { // Ignore the first ~320 ms after playback starts.
                        warmupFrames += 1
                        continue
                    }
                    val level = normalizedRms(samples, read)
                    strongFrames = VoiceBargeInPolicy.nextStrongFrames(strongFrames, level, threshold)
                    // Require sustained near-field speech instead of one transient/noise spike.
                    if (VoiceBargeInPolicy.shouldInterrupt(strongFrames) && running.compareAndSet(true, false)) {
                        onVoiceDetected()
                        break
                    }
                }
            } catch (_: Throwable) {
                // Best-effort feature. Manual tap interruption remains available.
            } finally {
                runCatching { if (audioRecord.recordingState == AudioRecord.RECORDSTATE_RECORDING) audioRecord.stop() }
                runCatching { aec?.release() }
                runCatching { ns?.release() }
                runCatching { audioRecord.release() }
                if (record === audioRecord) record = null
            }
        }
        worker = localWorker
        return true
    }

    fun stop() {
        running.set(false)
        val current = record
        runCatching { current?.stop() }
        worker?.interrupt()
        worker = null
        record = null
    }

    private fun normalizedRms(samples: ShortArray, count: Int): Float {
        if (count <= 0) return 0f
        var sumSquares = 0.0
        for (index in 0 until count) {
            val normalized = samples[index] / 32768.0
            sumSquares += normalized * normalized
        }
        return sqrt(sumSquares / count).toFloat().coerceIn(0f, 1f)
    }

    private fun isHeadsetLike(device: AudioDeviceInfo): Boolean = when (device.type) {
        AudioDeviceInfo.TYPE_WIRED_HEADSET,
        AudioDeviceInfo.TYPE_WIRED_HEADPHONES,
        AudioDeviceInfo.TYPE_BLUETOOTH_SCO,
        AudioDeviceInfo.TYPE_USB_HEADSET -> true
        else -> false
    }
}
