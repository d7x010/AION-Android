package com.aion.mobile.core.voice

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.NoiseSuppressor
import androidx.core.content.ContextCompat
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.max
import kotlin.math.sqrt

/**
 * Very small microphone monitor used only while AION is speaking.
 *
 * It deliberately requires platform AEC support. Without echo cancellation the assistant could
 * hear its own speaker output and interrupt itself, so unsupported devices keep tap-to-interrupt
 * as the safe fallback.
 */
class VoiceBargeInDetector(private val context: Context) {
    private val running = AtomicBoolean(false)
    @Volatile private var worker: Thread? = null
    @Volatile private var recorder: AudioRecord? = null

    fun isSupported(): Boolean =
        AcousticEchoCanceler.isAvailable() &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    fun start(onSpeechDetected: () -> Unit): Boolean {
        if (!isSupported() || !running.compareAndSet(false, true)) return false

        val sampleRate = 16_000
        val minBuffer = AudioRecord.getMinBufferSize(
            sampleRate,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        )
        if (minBuffer <= 0) {
            running.set(false)
            return false
        }

        val localRecorder = runCatching {
            AudioRecord.Builder()
                .setAudioSource(MediaRecorder.AudioSource.VOICE_COMMUNICATION)
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(sampleRate)
                        .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
                        .build()
                )
                .setBufferSizeInBytes(max(minBuffer * 2, 4_096))
                .build()
        }.getOrNull()

        if (localRecorder == null || localRecorder.state != AudioRecord.STATE_INITIALIZED) {
            runCatching { localRecorder?.release() }
            running.set(false)
            return false
        }

        recorder = localRecorder
        val echoCanceler = runCatching { AcousticEchoCanceler.create(localRecorder.audioSessionId) }.getOrNull()
        val noiseSuppressor = runCatching {
            if (NoiseSuppressor.isAvailable()) NoiseSuppressor.create(localRecorder.audioSessionId) else null
        }.getOrNull()
        runCatching { echoCanceler?.enabled = true }
        runCatching { noiseSuppressor?.enabled = true }

        worker = Thread({
            val buffer = ShortArray(640) // ~40 ms at 16 kHz.
            var noiseFloor = 0.018f
            var speechFrames = 0
            var warmupFrames = 0
            try {
                localRecorder.startRecording()
                while (running.get() && localRecorder.recordingState == AudioRecord.RECORDSTATE_RECORDING) {
                    val read = localRecorder.read(buffer, 0, buffer.size, AudioRecord.READ_BLOCKING)
                    if (read <= 0) continue
                    val level = normalizedRms(buffer, read)

                    // Ignore the first ~320 ms while the output route/AEC settles.
                    if (warmupFrames < 8) {
                        noiseFloor = (noiseFloor * 0.72f) + (level * 0.28f)
                        warmupFrames += 1
                        continue
                    }

                    val threshold = VoiceBargeInPolicy.triggerThreshold(noiseFloor)
                    if (level >= threshold) {
                        speechFrames += 1
                    } else {
                        speechFrames = (speechFrames - 1).coerceAtLeast(0)
                        // Learn only quiet frames; assistant echo should not inflate the floor rapidly.
                        noiseFloor = (noiseFloor * 0.94f) + (level.coerceAtMost(threshold) * 0.06f)
                    }

                    if (VoiceBargeInPolicy.shouldTrigger(level, noiseFloor, speechFrames)) {
                        running.set(false)
                        onSpeechDetected()
                        break
                    }
                }
            } catch (_: Throwable) {
                // Barge-in is optional; tap-to-interrupt remains available on any OEM failure.
            } finally {
                runCatching { if (localRecorder.recordingState == AudioRecord.RECORDSTATE_RECORDING) localRecorder.stop() }
                runCatching { echoCanceler?.release() }
                runCatching { noiseSuppressor?.release() }
                runCatching { localRecorder.release() }
                recorder = null
                running.set(false)
            }
        }, "AION-Live-BargeIn").apply {
            isDaemon = true
            start()
        }
        return true
    }

    fun stop() {
        running.set(false)
        runCatching { recorder?.stop() }
        worker?.interrupt()
        worker = null
        recorder = null
    }

    private fun normalizedRms(samples: ShortArray, count: Int): Float {
        if (count <= 0) return 0f
        var sum = 0.0
        for (index in 0 until count) {
            val normalized = samples[index] / 32768.0
            sum += normalized * normalized
        }
        return sqrt(sum / count).toFloat().coerceIn(0f, 1f)
    }
}
