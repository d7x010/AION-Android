package com.aion.mobile.core.voice

import android.speech.tts.TextToSpeech
import kotlin.math.min

/**
 * AION Speech Director (local fallback path).
 *
 * It prepares written answers for speech instead of feeding Markdown/code/URLs to TTS verbatim,
 * then breaks long prose at natural Arabic/Latin punctuation so playback starts quickly and
 * interruption does not have to wait for a huge utterance to finish.
 */
object SpeechText {
    private val fencedCode = Regex("```[\\s\\S]*?```")
    private val markdownLink = Regex("\\[([^]\\n]{1,160})]\\((https?://[^)\\s]+)\\)")
    private val bareUrl = Regex("https?://\\S+")
    private val citation = Regex("\\[(\\d{1,3}(?:\\s*[,،-]\\s*\\d{1,3})*)]")
    private val markdownHeading = Regex("(?m)^\\s{0,3}#{1,6}\\s+")
    private val markdownBullet = Regex("(?m)^\\s*[-*+]\\s+")
    private val markdownNumber = Regex("(?m)^\\s*\\d+[.)]\\s+")
    private val markdownQuote = Regex("(?m)^\\s*>\\s?")
    private val repeatedWhitespace = Regex("[ \\t]{2,}")
    private val repeatedBreaks = Regex("\\n{3,}")
    private val repeatedPunctuation = Regex("([.!؟!،؛])\\1{2,}")

    fun clean(text: String): String {
        if (text.isBlank()) return ""
        return text
            .replace(fencedCode, "\n")
            .replace(markdownLink) { it.groupValues[1] }
            .replace(bareUrl, " رابط ")
            .replace(citation, "")
            .replace(markdownHeading, "")
            .replace(markdownBullet, "")
            .replace(markdownNumber, "")
            .replace(markdownQuote, "")
            .replace("**", "")
            .replace("__", "")
            .replace("~~", "")
            .replace("`", "")
            .replace('|', ' ')
            .replace(repeatedPunctuation) { it.groupValues[1] }
            .replace(repeatedWhitespace, " ")
            .replace(repeatedBreaks, "\n\n")
            .trim()
    }

    /** Pure splitter used by tests and future neural TTS providers as well. */
    fun splitNatural(cleanText: String, hardLimit: Int): List<String> {
        val clean = cleanText.trim()
        if (clean.isBlank()) return emptyList()
        val safeHardLimit = hardLimit.coerceAtLeast(220)
        val target = min(430, safeHardLimit)
        val result = mutableListOf<String>()
        var remaining = clean

        while (remaining.isNotBlank()) {
            if (remaining.length <= safeHardLimit) {
                result += remaining.trim()
                break
            }

            val windowLimit = min(safeHardLimit, target + 170)
            val window = remaining.take(windowLimit)
            val minimumBreak = (target * 0.45f).toInt()
            val preferred = listOf("\n\n", ". ", "؟ ", "! ", "؛ ", ": ", "، ", "\n", " ")
                .map { delimiter ->
                    window.lastIndexOf(delimiter).let { index ->
                        if (index >= minimumBreak) index + delimiter.length else -1
                    }
                }
                .maxOrNull()
                ?.takeIf { it > 0 }
                ?: windowLimit

            result += remaining.take(preferred).trim()
            remaining = remaining.drop(preferred).trimStart()
        }

        return result.filter(String::isNotBlank)
    }

    fun chunks(text: String): List<String> {
        val clean = clean(text)
        if (clean.isBlank()) return emptyList()
        // Keep utterances deliberately shorter than Android's technical maximum. This gives
        // faster first audio, quicker interruption, and more natural phrase boundaries.
        val hardLimit = min((TextToSpeech.getMaxSpeechInputLength() - 128).coerceAtLeast(420), 700)
        return splitNatural(clean, hardLimit)
    }
}
