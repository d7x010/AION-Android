# AION α7.3 — Step 4: AION Live

الحالة: مكتملة محليًا قبل بوابة Android Gradle الرسمية.

## ما تم إغلاقه

### 1) جلسة Live واحدة داخل نفس المحادثة
- `AionLiveSessionState` هو مصدر الحقيقة للـpresentation والمرحلة والكتم وConversation ID.
- Fullscreen وMini Orb هما شكلان لنفس الجلسة؛ التصغير لا ينهي الصوت ولا يغير Conversation ID.
- الانتقال إلى محادثة/Project آخر ينهي Live الحالي بدل السماح بإرسال الصوت إلى سياق خاطئ.

### 2) Fullscreen → Mini Orb
- السحب للأسفل أو زر التصغير يحول Live إلى Mini Orb.
- Back من شاشة Live يصغّر ولا ينهي؛ الإنهاء محصور بالزر الأحمر الصريح.
- Mini Orb تأخذ `imePadding` و`navigationBarsPadding` حتى تبقى فوق Composer والكيبورد.
- Label الحالة يظهر مؤقتًا، ثم تبقى الـOrb فقط لتقليل الضوضاء.
- عند الكتم يظهر badge واضح فوق Mini Orb.

### 3) حالة حيّة مفهومة
- الحالات: Initializing / Listening / Thinking / Reading files / Searching / Comparing / Writing / Speaking / Reconnecting / Error.
- `AionLiveUiPolicy` يفصل نصوص الحالة عن واجهة Compose ويعرض العمل الخارجي فقط، بلا كشف reasoning داخلي.
- Purple للعمل الداخلي، Blue للبحث الخارجي، Red للخطأ.
- Listening وSpeaking يتحركان من RMS/PCM الحقيقي، والحالات الأخرى لها Motion دلالي مستقل.

### 4) المقاطعة
- الضغط على الـOrb أثناء كلام AION يوقف TTS/Neural playback ويعيد الاستماع فورًا.
- Typed interruption: بدء طلب نصي جديد أثناء كلام AION يوقف الصوت القديم ويكمل نفس Live session مع الدور الجديد.
- Voice barge-in تلقائي best-effort عبر `AudioRecord` فقط عند وجود AEC حقيقي على speaker أو headset route منخفض التسرب.
- detector لا يخزن الصوت ولا يرسله؛ يحسب PCM RMS قصيرًا محليًا ثم يتخلص من العينات.
- warm-up + sustained-frame gate لتقليل المقاطعات الكاذبة من صوت AION نفسه.

### 5) Android audio lifecycle
- Audio focus يُطلب فقط عند كلام AION ويُحرر عند الانتهاء/المقاطعة/الإغلاق.
- `VoiceCommunicationSession` يدخل MODE_IN_COMMUNICATION مؤقتًا لتحسين AEC على OEMs، ويحفظ/يعيد mode والمسار السابق عند نهاية Live.
- إذا لا توجد سماعة/بلوتوث، يحاول إبقاء الكلام على speaker بدل انتقال بعض الأجهزة إلى earpiece؛ وإذا توجد سماعة متصلة لا يفرض speaker عليها.
- تنظيف SpeechRecognizer وTTS وNeural player وbarge-in callbacks عند dispose.
- إصلاح stale mute capture داخل Recognition/TTS callbacks عبر `rememberUpdatedState`.

### 6) واجهة أقل ازدحامًا
- لا يوجد زر إنهاء مكرر في أعلى الشاشة؛ الزر الأحمر السفلي هو الإنهاء الصريح الوحيد.
- زر Stop/Interrupt يظهر فقط أثناء Speaking أو وجود رد جارٍ.
- Keyboard = تصغير للعودة للكتابة مع بقاء الجلسة.
- Transcript مختصر يعرض كلام المستخدم الجزئي أو آخر كلام AION، ولا يحول شاشة Live إلى سجل دردشة ثانٍ.
- semantics/stateDescription للـOrb وMini Orb لدعم TalkBack بشكل أفضل.

## حدود Step 4 المقصودة
- Full-duplex speech-to-speech الحقيقي ليس ضمن هذه الخطوة.
- استمرار الميكروفون بعد خروج التطبيق بالكامل يحتاج Foreground microphone service وهو مؤجل لمرحلة Android integration.
- Neural Voice البشرية وضبط الأصوات/My Voice هي Step 5.

## الفحوص المحلية
- AION Live core Kotlin smoke: PASS.
- Kotlin parser smoke لملفات UI المعدلة: PASS من ناحية syntax؛ Android/Compose classpath غير متوفر محليًا.
- XML parse: PASS.
- Worker syntax/regression: PASS.
- Structural delimiter scan: PASS.
- Full Android Unit + Lint + assembleDebug يبقى لبوابة GitHub بعد اكتمال المراحل المتماسكة.

## الإصدار
- versionCode: 19
- versionName: 2.0.0-alpha7.3-dev5

## إغلاق بوابة GitHub — إصلاحات تحقق dev5
- صُحح مسار `graphicsLayer` في Compose إلى `androidx.compose.ui.graphics.graphicsLayer`.
- أضيف `@OptIn(ExperimentalMaterial3Api::class)` لموضع `ModalBottomSheet` فقط.
- صُححت أولوية `SpeechText.splitNatural`: علامات نهاية الجملة تسبق المسافة العادية عند اختيار نقطة التقسيم، مع بقاء `hardLimit` كما هو.
- السبب: GitHub Actions وصل إلى 50 اختبارًا؛ 49 نجحت وفشل فقط `naturalSplitPrefersSentenceBoundaries` قبل هذا الإصلاح.

