# AION Android — 2.0.0-alpha7.3-dev21

## مسار التطوير الحالي: α7.3
- Step 1: Chat Shell / Composer / Activity System.
- Step 2: Drawer / Search / Projects.
- Step 3: Attachments / Images / PDF / Markdown / Code / Tables / Sources.
- Step 4: AION Live / Mini Orb / interruption / safe voice barge-in / Android audio session.
- Step 5: Neural Voice + Voice Selection/Tuning + My Voice + Playback Arbitration — مغلق رسميًا عند dev9.
- Step 6.1: Multi‑Provider Core — مغلق رسميًا.
- Step 6.2: Claude Execution — مغلق رسميًا عند dev11.
- Step 6.3: Gemini Execution — مغلق رسميًا.
- Step 6.4: Grok/xAI Execution — مغلق رسميًا.
- Step 6.5: Provider Routing & Failover Policy — مغلق رسميًا عند dev14.
- Step 6.6: Cross‑Model Context Compatibility — مغلق رسميًا عند dev15.
- Step 6 Final Closure: تكامل 6.1–6.6 — مغلق رسميًا عند dev16/code30.
- Step 7.1: AION Core + Orchestrator Contract — dev17/code31، GitHub Gate PASS.
- Step 7.2: Memory Engine v1 — مغلق رسميًا عند dev18/code32، Step 7 Gate Run 34439898717 أخضر.
- Step 7.3 + 7.4: Context Engine v1 + Memory Retrieval Intelligence v1 — مغلقان رسميًا عند dev19/code33، Step 7 Gate Run 34441915894 أخضر.
- Step 7.5 + 7.6: Memory Controls & Privacy + Universal Tool Router v1 — dev21/code35، Local PASS وGitHub Gate pending.
- الإصدار الداخلي الحالي: `versionCode = 35` / `versionName = 2.0.0-alpha7.3-dev21`.
- Claude وGemini وGrok يعملون فعليًا عند تهيئة مزوديهم على AION Cloud؛ الاختيارات الخارجية pinned بلا fallback صامت.
# خط الأساس المستقر: AION Mobile V2 α7.2.1 — Runtime Hotfix

AION هو تطبيق ذكاء شخصي لـAndroid بواجهة عربية أولًا وهوية مستقلة. إصدار α7.2.1 يبني على α7.2، مع Hotfix خاص بالإقلاع بعد التحديث. α7.2 يركز على استقرار المحادثات الطويلة، Projects وذاكرتها المستقلة، تحسين الأداء، صقل واجهة الاستخدام، وتحسين المكالمة الصوتية turn-by-turn.

## ما يعمل في α7.2.1
- محادثات متعددة محليًا مع بحث داخل محتوى الرسائل، مسودة مستقلة، Pin، Archive/Restore، Share، ونقل المحادثة إلى Project.
- Projects محلية فعلية: تعليمات مشروع، ذاكرة مشروع مستقلة، وخيار عزل الذاكرة العامة.
- Streaming حقيقي عبر AION Cloud/Workers AI مع Stop، Retry، حفظ checkpoint خفيف، واستمرار المهمة في Foreground Service.
- نافذة سياق للمحادثات الطويلة تحفظ بداية المهمة مع أحدث الرسائل بدل إسقاط البداية بالكامل.
- أوضاع AION:
  - Auto / General: Qwen 3.8 27B.
  - Fast: GLM-4.7-Flash.
  - Deep: GPT-OSS-120B.
  - Vision / Research: Qwen 3.8 27B مع Gemma 4 كاحتياط عند الحاجة.
- بحث ويب حي مع Workers AI Web Search، واستخدام Firecrawl اختياريًا عند وجود `FIRECRAWL_API_KEY`.
- مرفقات فعلية: صور، نص، كود، PDF وOffice؛ الصور تمر إلى Vision مباشرة، والمستندات تُحوّل على Cloud عند الحاجة.
- عرض Markdown موسع يشمل العناوين والقوائم والاقتباسات والكود والجداول القابلة للتمرير.
- ذاكرة محلية صريحة + ذاكرة مستقلة لكل Project.
- AION Voice بنمط turn-by-turn قابل للمقاطعة مع SpeechRecognizer + TTS، وحركة تعتمد على RMS/PCM الحقيقي بدل Animation ثابت.
- تحسينات أداء في Streaming، فهرس المحادثات، البحث المحلي، المسودات، الصور، وعمليات التخزين.
- اتصالات HTTPS فقط مع تعطيل Android Backup لمحادثات ومرفقات AION في نسخة التطوير الحالية.

## ما لا ندعي أنه مكتمل
- Full-Duplex speech-to-speech الحقيقي ما زال مرحلة لاحقة.
- Agent runtime متعدد الأدوات ما زال Foundation وليس وكيل تنفيذ كاملًا.
- Claude وGemini وGrok متصلون فعليًا عند تهيئة مزوديهم على AION Cloud؛ كل خيار خارجي يبقى معطلًا إذا لم يعلن الخادم جاهزيته.
- الذاكرة لا تستخرج تلقائيًا كل حقيقة من جميع المحادثات؛ الحفظ الصريح هو المسار الموثوق حاليًا.
- المزامنة السحابية متعددة الأجهزة ليست جزءًا من α7.2.

## إصدار Android
- `versionCode = 35`
- `versionName = 2.0.0-alpha7.3-dev21`
- `minSdk = 26`
- `targetSdk = 36`
- `compileSdk = 36`

## البناء الرسمي
المتطلبات الحالية:
- Java 17
- Android SDK 36 / Build Tools 36.0.0
- Gradle 9.6.1 في GitHub Actions

بوابة Android:
```bash
gradle :app:testDebugUnitTest :app:lintDebug :app:assembleDebug --stacktrace --no-daemon
```

اختبارات Worker المحلية:
```bash
node --check cloudflare/aion-core/src/index.js
node cloudflare/aion-core/test-worker.mjs
```

المتوقع: `AION worker tests: PASS`.

## Cloudflare
`cloudflare/aion-core/wrangler.toml` يستخدم Workers AI binding باسم `AI`. البحث الحي يعمل عبر Workers AI Web Search حتى دون Firecrawl. الصور تُرسل كرؤية أصلية إلى Qwen 3.8، مع Gemma 4 كمسار احتياطي للرؤية/البحث عند الحاجة.

## بوابة اعتماد α7.2.1
لا يعتبر APK معتمدًا إلا بعد نجاح GitHub Actions في:
1. Unit Tests.
2. Android Lint.
3. `assembleDebug`.
4. رفع Artifact.
5. نشر `aion-core` بنجاح.

ثم تُنفذ اختبارات الهاتف الواردة في `ALPHA7_TEST_PLAN_AR.md`، خصوصًا Streaming، Projects، الصور، البحث، المكالمة الصوتية، وإدارة المرفقات.


## Step 6.4 — Grok Execution
- Grok/xAI أصبح مسار تنفيذ فعليًا عبر xAI Responses API من AION Cloud.
- يدعم Sync وSSE Streaming وفهم JPEG/PNG.
- `XAI_API_KEY` يبقى خادميًا فقط و`AION_GROK_MODEL` متغير خادمي؛ لا model id داخل APK.
- يرسل Worker `store=false` إلى Responses API لعدم حفظ سجل الطلب/الرد لدى xAI ضمن هذا المسار.
- بحث الويب مع Grok يستخدم Firecrawl في هذه النقطة؛ لا fallback صامت إلى Workers AI أو xAI Web Search.


## Step 6.5 — Provider Routing & Failover
- selection الذي اختاره المستخدم منفصل عن execution model الفعلي.
- لا cross-provider fallback صامت لـClaude/Gemini/Grok.
- AION built-ins تسمح فقط بـWorkers AI internal fallback قبل أول token.
- التطبيق يحفظ ويعرض provenance الفعلي للمزود/model عند توفره.


## Step 6.6 — Cross‑Model Context Compatibility
- AION Cloud يطبع history إلى provider-neutral transcript واحد قبل Claude/Gemini/Grok.
- same-role turns تُدمج، وGemini يستلم user/model متناوبًا.
- system instructions تبقى system-level لكل مزود ولا تدخل كرسالة مستخدم.
- leading orphan assistant history لا تُرفع إلى system؛ وآخر turn يجب أن يكون user.
- current-turn images تبقى native vision حسب كل مزود.
- status يعلن `models.context.contract=1`.


## Step 7.1 — AION Core + Orchestrator Contract
- AION Cloud ينشئ خطة تشغيل versioned قبل كل inference بدل توزيع قرارات mode/search/memory بين مسارات منفصلة.
- الخطة تغطي model / memory / search / tool / clarification / response مع trace metadata بلا نص المستخدم أو محتوى الذاكرة.
- البحث الحالي أصبح typed decision داخل Orchestrator؛ Generic Tool Router الكامل لم يبدأ بعد.
- Android يتحقق من contract=1 ويخزن metadata الآمنة مع الرد النهائي للتقييم والتشخيص لاحقًا.
- Memory في 7.1 ما زالت `provided-context-only`; Memory Engine v1 هي النقطة التالية بعد الإغلاق الأخضر.
