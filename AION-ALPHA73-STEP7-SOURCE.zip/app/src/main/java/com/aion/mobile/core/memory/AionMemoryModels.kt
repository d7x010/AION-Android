package com.aion.mobile.core.memory

enum class MemoryScope { USER, PROJECT, CONVERSATION }
enum class MemoryKind { FACT, PREFERENCE, DECISION, INSTRUCTION, NOTE }
enum class MemorySource { USER_SETTINGS, PROJECT_NOTES, EXPLICIT, AUTOMATIC }

data class AionMemoryEntry(
    val id: String,
    val scope: MemoryScope,
    val ownerId: String = "",
    val kind: MemoryKind = MemoryKind.NOTE,
    val text: String,
    val slot: String = "",
    val source: MemorySource,
    val confidence: Float = 1f,
    val createdAt: Long,
    val updatedAt: Long,
    val expiresAt: Long = 0L,
    val active: Boolean = true
)

data class AionMemoryContext(
    val contract: Int = MemoryEnginePolicy.CONTRACT,
    val text: String = "",
    val entryCount: Int = 0,
    val scopes: Set<MemoryScope> = emptySet(),
    val truncated: Boolean = false
)
