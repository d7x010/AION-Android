package com.aion.mobile.core.memory

data class MemoryPrivacySettings(
    val memoryEnabled: Boolean = true,
    val allowUserScope: Boolean = true,
    val allowProjectScope: Boolean = true,
    val allowConversationScope: Boolean = true,
    val automaticMemoryEnabled: Boolean = false
)

enum class ConversationMemoryMode { NORMAL, TEMPORARY }

data class MemoryPrivacyDecision(
    val contract: Int = MemoryPrivacyPolicy.CONTRACT,
    val memoryEnabled: Boolean,
    val temporary: Boolean,
    val allowedScopes: Set<MemoryScope>,
    val allowAutomaticWrite: Boolean,
    val allowExplicitWrite: Boolean
)

/** Pure privacy policy. No memory is retrieved or written when the user disables it or marks a chat temporary. */
object MemoryPrivacyPolicy {
    const val CONTRACT = 1
    const val POLICY = "user-controlled-memory-privacy-v1"

    fun evaluate(
        settings: MemoryPrivacySettings,
        mode: ConversationMemoryMode,
        hasProject: Boolean
    ): MemoryPrivacyDecision {
        val temporary = mode == ConversationMemoryMode.TEMPORARY
        if (!settings.memoryEnabled || temporary) {
            return MemoryPrivacyDecision(
                memoryEnabled = false,
                temporary = temporary,
                allowedScopes = emptySet(),
                allowAutomaticWrite = false,
                allowExplicitWrite = false
            )
        }

        val scopes = buildSet {
            if (settings.allowUserScope) add(MemoryScope.USER)
            if (hasProject && settings.allowProjectScope) add(MemoryScope.PROJECT)
            if (settings.allowConversationScope) add(MemoryScope.CONVERSATION)
        }
        return MemoryPrivacyDecision(
            memoryEnabled = scopes.isNotEmpty(),
            temporary = false,
            allowedScopes = scopes,
            allowAutomaticWrite = settings.automaticMemoryEnabled && scopes.isNotEmpty(),
            allowExplicitWrite = scopes.isNotEmpty()
        )
    }
}
