package com.aion.mobile.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.ParcelFileDescriptor
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.widget.Toast
import android.util.Base64
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.rememberTransformableState
import androidx.compose.foundation.gestures.transformable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.ArrowUpward
import androidx.compose.material.icons.outlined.Build
import androidx.compose.material.icons.outlined.Call
import androidx.compose.material.icons.outlined.Check
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.ContentCopy
import androidx.compose.material.icons.outlined.Code
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.Folder
import androidx.compose.material.icons.outlined.Image
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.KeyboardArrowDown
import androidx.compose.material.icons.outlined.Memory
import androidx.compose.material.icons.outlined.Menu
import androidx.compose.material.icons.outlined.Mic
import androidx.compose.material.icons.outlined.MoreHoriz
import androidx.compose.material.icons.outlined.OpenInNew
import androidx.compose.material.icons.outlined.Psychology
import androidx.compose.material.icons.outlined.PictureAsPdf
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.SmartToy
import androidx.compose.material.icons.outlined.Stop
import androidx.compose.material.icons.outlined.TableChart
import androidx.compose.material.icons.outlined.VolumeUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.produceState
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import com.aion.mobile.core.AionCapability
import com.aion.mobile.core.CapabilityState
import com.aion.mobile.core.FeatureRegistry
import com.aion.mobile.core.ai.AionCloudVoiceOption
import com.aion.mobile.core.ai.GatewayActivity
import com.aion.mobile.core.files.AttachmentLoader
import com.aion.mobile.core.files.AttachmentPresentationPolicy
import com.aion.mobile.core.project.AionProject
import com.aion.mobile.core.memory.MemoryPrivacySettings
import com.aion.mobile.core.render.MarkdownBlockKind
import com.aion.mobile.core.render.MarkdownRenderPolicy
import com.aion.mobile.core.ai.ProviderRoutingPolicy
import com.aion.mobile.core.search.ConversationSearchHit
import com.aion.mobile.core.search.ConversationSearchPolicy
import com.aion.mobile.core.storage.ConversationSummary
import com.aion.mobile.core.state.ComposerPolicy
import com.aion.mobile.core.state.ComposerPrimaryAction
import com.aion.mobile.core.state.toAionActivityState
import com.aion.mobile.core.voice.AionLiveEvent
import com.aion.mobile.core.voice.AionLiveNavigationPolicy
import com.aion.mobile.core.voice.AionLivePresentation
import com.aion.mobile.core.voice.AionLiveReducer
import com.aion.mobile.core.voice.AionLiveSessionState
import com.aion.mobile.core.voice.AionVoiceProfile
import com.aion.mobile.core.voice.AionVoiceSettings
import com.aion.mobile.core.voice.AionVoicePlaybackArbiter
import com.aion.mobile.core.voice.AionVoicePlaybackOwner
import com.aion.mobile.core.voice.MyVoiceCredential
import com.aion.mobile.core.voice.MyVoicePolicy
import com.aion.mobile.core.voice.MyVoiceSampleRecorder
import com.aion.mobile.core.voice.NeuralVoiceContract
import com.aion.mobile.core.voice.NeuralVoicePlaybackResult
import com.aion.mobile.core.voice.NeuralVoicePlayer
import com.aion.mobile.core.voice.SpeechText
import com.aion.mobile.core.voice.VoiceSelectionPolicy
import com.aion.mobile.core.voice.VoiceAudioFocus
import com.aion.mobile.core.voice.VoicePlaybackPolicy
import com.aion.mobile.feature.chat.AiModelOption
import com.aion.mobile.feature.chat.ChatViewModel
import com.aion.mobile.ui.design.AionHaptics
import com.aion.mobile.ui.design.AionLayout
import com.aion.mobile.model.AttachmentKind
import com.aion.mobile.model.ChatAttachment
import com.aion.mobile.model.ChatMessage
import com.aion.mobile.model.ChatSource
import com.aion.mobile.model.MessageRole
import com.aion.mobile.ui.components.AionActivityIndicator
import com.aion.mobile.ui.design.AionColors
import com.aion.mobile.ui.design.AionRadii
import com.aion.mobile.ui.design.AionSizes
import com.aion.mobile.ui.design.AionSpacing
import com.aion.mobile.ui.theme.AionBlueSoft
import com.aion.mobile.ui.theme.AionPurple
import com.aion.mobile.ui.theme.AionPurpleSoft
import com.aion.mobile.ui.theme.AionPurpleStrong
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.temporal.ChronoUnit
import java.util.Locale

@Composable
fun AionApp(chatViewModel: ChatViewModel = viewModel(), safeMode: Boolean = false) {
    val context = LocalContext.current
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
        val scope = rememberCoroutineScope()
        var selectedCapability by remember { mutableStateOf<AionCapability?>(null) }
        var showSettings by remember { mutableStateOf(false) }
        var showModelPicker by remember { mutableStateOf(false) }
        var showContext by remember { mutableStateOf(false) }
        var liveSession by remember { mutableStateOf(AionLiveSessionState()) }
        val voicePlaybackArbiter = remember { AionVoicePlaybackArbiter() }

        DisposableEffect(Unit) {
            onDispose { voicePlaybackArbiter.interruptAll() }
        }

        fun showLiveConversationLock() {
            Toast.makeText(
                context,
                "AION Live مرتبط بهذه المحادثة. أنهِ الجلسة قبل الانتقال إلى محادثة أخرى.",
                Toast.LENGTH_SHORT
            ).show()
        }

        ModalNavigationDrawer(
            drawerState = drawerState,
            drawerContent = {
                AionDrawer(
                    conversations = chatViewModel.conversations,
                    archivedConversations = chatViewModel.archivedConversations,
                    projects = chatViewModel.projects,
                    activeConversationId = chatViewModel.activeConversationId,
                    activeProjectId = chatViewModel.activeProject?.id,
                    isSending = chatViewModel.isSending,
                    searchQuery = chatViewModel.drawerSearchQuery,
                    searchResults = chatViewModel.drawerSearchResults,
                    isSearchLoading = chatViewModel.isDrawerSearching,
                    onSearchQueryChange = chatViewModel::updateDrawerSearchQuery,
                    onSearchHitClick = { hit ->
                        if (AionLiveNavigationPolicy.canOpenConversation(liveSession, hit.conversationId)) {
                            chatViewModel.openSearchHit(hit)
                        } else {
                            showLiveConversationLock()
                        }
                        scope.launch { drawerState.close() }
                    },
                    onConversationClick = { conversationId ->
                        chatViewModel.clearDrawerSearch()
                        if (AionLiveNavigationPolicy.canOpenConversation(liveSession, conversationId)) {
                            chatViewModel.switchConversation(conversationId)
                        } else {
                            showLiveConversationLock()
                        }
                        scope.launch { drawerState.close() }
                    },
                    onConversationRename = chatViewModel::renameConversation,
                    onConversationShare = chatViewModel::shareConversation,
                    onConversationDelete = { conversationId ->
                        if (AionLiveNavigationPolicy.canRemoveConversation(liveSession, conversationId)) {
                            chatViewModel.deleteConversation(conversationId)
                        } else {
                            showLiveConversationLock()
                        }
                    },
                    onConversationPin = chatViewModel::togglePinned,
                    onConversationArchive = { conversationId ->
                        if (AionLiveNavigationPolicy.canRemoveConversation(liveSession, conversationId)) {
                            chatViewModel.archiveConversation(conversationId)
                        } else {
                            showLiveConversationLock()
                        }
                    },
                    onConversationRestore = chatViewModel::restoreConversation,
                    onConversationMove = { conversationId, projectId ->
                        if (AionLiveNavigationPolicy.canMoveConversation(liveSession, conversationId)) {
                            chatViewModel.moveConversationToProject(conversationId, projectId)
                        } else {
                            showLiveConversationLock()
                        }
                    },
                    onProjectClick = { projectId ->
                        chatViewModel.clearDrawerSearch()
                        if (AionLiveNavigationPolicy.canCreateOrOpenDifferentContext(liveSession)) {
                            chatViewModel.openProject(projectId)
                        } else {
                            showLiveConversationLock()
                        }
                        scope.launch { drawerState.close() }
                    },
                    onProjectCreate = { name, instructions ->
                        if (AionLiveNavigationPolicy.canMutateProjectContext(liveSession)) {
                            chatViewModel.createProject(name, instructions)
                        } else {
                            showLiveConversationLock()
                        }
                    },
                    onProjectUpdate = { project ->
                        if (AionLiveNavigationPolicy.canMutateProjectContext(liveSession)) {
                            chatViewModel.updateProject(project)
                        } else {
                            showLiveConversationLock()
                        }
                    },
                    onProjectDelete = { projectId ->
                        if (AionLiveNavigationPolicy.canMutateProjectContext(liveSession)) {
                            chatViewModel.deleteProject(projectId)
                        } else {
                            showLiveConversationLock()
                        }
                    },
                    onCapabilityClick = { capability ->
                        if (capability.key == "memory") showSettings = true
                        else selectedCapability = capability
                        scope.launch { drawerState.close() }
                    },
                    onNewChat = { projectId ->
                        chatViewModel.clearDrawerSearch()
                        if (AionLiveNavigationPolicy.canCreateOrOpenDifferentContext(liveSession)) {
                            chatViewModel.newConversation(projectId)
                        } else {
                            showLiveConversationLock()
                        }
                        scope.launch { drawerState.close() }
                    },
                    onContext = {
                        showContext = true
                        scope.launch { drawerState.close() }
                    },
                    onSettings = {
                        showSettings = true
                        scope.launch { drawerState.close() }
                    }
                )
            }
        ) {
            AionChatScreen(
                messages = chatViewModel.messages,
                pendingAttachments = chatViewModel.pendingAttachments,
                onSend = chatViewModel::send,
                onStop = chatViewModel::stopGeneration,
                onRetry = chatViewModel::retryResponse,
                onEditMessage = chatViewModel::editAndResend,
                onRememberMessage = chatViewModel::rememberText,
                onAddAttachments = chatViewModel::addAttachments,
                onRemoveAttachment = chatViewModel::removeAttachment,
                onMenu = { scope.launch { drawerState.open() } },
                onNewChat = {
                    if (AionLiveNavigationPolicy.canCreateOrOpenDifferentContext(liveSession)) {
                        chatViewModel.newConversation()
                    } else {
                        showLiveConversationLock()
                    }
                },
                onModelPicker = { showModelPicker = true },
                onModeShortcut = chatViewModel::selectModel,
                onStartVoiceCall = {
                    voicePlaybackArbiter.interruptAll()
                    liveSession = AionLiveReducer.reduce(
                        liveSession,
                        AionLiveEvent.Start(chatViewModel.activeConversationId)
                    )
                },
                selectedModel = chatViewModel.selectedModel,
                activeProjectName = chatViewModel.activeProject?.name,
                cloudEndpoint = chatViewModel.cloudEndpoint,
                neuralVoiceAvailable = chatViewModel.neuralVoiceAvailable,
                voiceSettings = chatViewModel.resolvedVoiceSettings,
                myVoiceToken = chatViewModel.myVoiceToken,
                voicePlaybackArbiter = voicePlaybackArbiter,
                isConfigured = chatViewModel.isConfigured,
                isSending = chatViewModel.isSending,
                activity = chatViewModel.activity,
                safeMode = safeMode,
                draft = chatViewModel.draft,
                onDraftChange = chatViewModel::updateDraft,
                scrollToMessageId = chatViewModel.scrollTargetMessageId,
                onScrollTargetConsumed = chatViewModel::consumeScrollTargetMessage
            )
        }

        selectedCapability?.let { capability ->
            CapabilityDialog(capability = capability, onDismiss = { selectedCapability = null })
        }

        if (showSettings) {
            SettingsDialog(
                initialEndpoint = chatViewModel.cloudEndpoint,
                initialInstructions = chatViewModel.customInstructions,
                initialMemory = chatViewModel.memoryNotes,
                initialMemoryPrivacy = chatViewModel.memoryPrivacySettings,
                cloudHealthLabel = chatViewModel.cloudHealthLabel,
                cloudHealthOk = chatViewModel.cloudHealthOk,
                cloudHealthEndpoint = chatViewModel.cloudHealthEndpoint,
                neuralVoiceAvailable = chatViewModel.neuralVoiceAvailable,
                neuralVoiceProvider = chatViewModel.neuralVoiceProvider,
                voiceOptions = chatViewModel.neuralVoiceOptions,
                defaultVoiceKey = chatViewModel.neuralVoiceDefaultKey,
                initialVoiceSettings = chatViewModel.voiceSettings,
                myVoiceCloudAvailable = chatViewModel.myVoiceCloudAvailable,
                myVoiceProvider = chatViewModel.myVoiceProvider,
                myVoiceMaxSampleBytes = chatViewModel.myVoiceMaxSampleBytes,
                myVoiceCredential = chatViewModel.myVoiceCredential,
                isMyVoiceBusy = chatViewModel.isMyVoiceBusy,
                myVoiceStatusLabel = chatViewModel.myVoiceStatusLabel,
                voicePlaybackArbiter = voicePlaybackArbiter,
                onCreateMyVoice = chatViewModel::createMyVoice,
                onDeleteMyVoice = chatViewModel::deleteMyVoice,
                isCheckingCloud = chatViewModel.isCheckingCloud,
                onCheckCloud = chatViewModel::checkCloudConnection,
                onSave = { endpoint, instructions, memory, memoryPrivacy, voiceSettings ->
                    chatViewModel.saveSettings(endpoint)
                    chatViewModel.savePersonalization(instructions, memory)
                    chatViewModel.saveMemoryPrivacy(memoryPrivacy)
                    chatViewModel.saveVoiceSettings(voiceSettings)
                    showSettings = false
                },
                onDismiss = { showSettings = false }
            )
        }

        if (showModelPicker) {
            ModelPickerSheet(
                options = chatViewModel.modelOptions,
                selectedKey = chatViewModel.selectedModelKey,
                onSelect = {
                    chatViewModel.selectModel(it)
                    showModelPicker = false
                },
                onDismiss = { showModelPicker = false }
            )
        }

        if (showContext) {
            ContextSheet(
                messageCount = chatViewModel.messages.size,
                selectedModel = chatViewModel.selectedModel,
                isConfigured = chatViewModel.isConfigured,
                cloudHealthLabel = chatViewModel.cloudHealthLabel,
                cloudHealthOk = chatViewModel.cloudHealthOk,
                pendingAttachments = chatViewModel.pendingAttachments.size,
                memoryEnabled = chatViewModel.memoryPrivacySettings.run {
                    memoryEnabled && (allowUserScope || allowProjectScope || allowConversationScope)
                },
                temporaryMemory = chatViewModel.isTemporaryConversation,
                projectName = chatViewModel.activeProject?.name,
                onTemporaryMemoryChange = chatViewModel::setTemporaryConversation,
                onDismiss = { showContext = false }
            )
        }

        if (liveSession.isActive) {
            VoiceCallOverlay(
                presentation = liveSession.presentation,
                cloudEndpoint = chatViewModel.cloudEndpoint,
                neuralVoiceAvailable = chatViewModel.neuralVoiceAvailable,
                voiceSettings = chatViewModel.resolvedVoiceSettings,
                myVoiceToken = chatViewModel.myVoiceToken,
                voicePlaybackArbiter = voicePlaybackArbiter,
                messages = chatViewModel.messages,
                isSending = chatViewModel.isSending,
                activity = chatViewModel.activity,
                onSend = chatViewModel::send,
                onStop = chatViewModel::stopGeneration,
                onPhaseChanged = { phase ->
                    liveSession = AionLiveReducer.reduce(liveSession, AionLiveEvent.PhaseChanged(phase))
                },
                onMutedChanged = { muted ->
                    liveSession = AionLiveReducer.reduce(liveSession, AionLiveEvent.SetMuted(muted))
                },
                onMinimize = { liveSession = AionLiveReducer.reduce(liveSession, AionLiveEvent.Minimize) },
                onRestore = { liveSession = AionLiveReducer.reduce(liveSession, AionLiveEvent.Restore) },
                onDismiss = { liveSession = AionLiveReducer.reduce(liveSession, AionLiveEvent.End) }
            )
        }
    }
}

private fun normalizeLocalSearch(value: String): String = ConversationSearchPolicy.normalize(value)

private data class DrawerConversationSection(
    val label: String,
    val items: List<ConversationSummary>
)

private fun groupDrawerConversations(items: List<ConversationSummary>): List<DrawerConversationSection> {
    if (items.isEmpty()) return emptyList()
    val pinned = items.filter { it.pinned }
    val regular = items.filterNot { it.pinned }
    val zone = ZoneId.systemDefault()
    val today = LocalDate.now(zone)

    fun labelFor(updatedAt: Long): String {
        val date = Instant.ofEpochMilli(updatedAt.coerceAtLeast(0L)).atZone(zone).toLocalDate()
        val days = ChronoUnit.DAYS.between(date, today)
        return when {
            days <= 0L -> "اليوم"
            days == 1L -> "أمس"
            days <= 6L -> "آخر 7 أيام"
            else -> "أقدم"
        }
    }

    val sections = mutableListOf<DrawerConversationSection>()
    if (pinned.isNotEmpty()) sections += DrawerConversationSection("مثبتة", pinned)
    regular.groupBy { labelFor(it.updatedAt) }.forEach { (label, sectionItems) ->
        sections += DrawerConversationSection(label, sectionItems)
    }
    val order = mapOf("مثبتة" to 0, "اليوم" to 1, "أمس" to 2, "آخر 7 أيام" to 3, "أقدم" to 4)
    return sections.sortedBy { order[it.label] ?: 99 }
}

@Composable
private fun DrawerSectionLabel(label: String) {
    Text(
        label,
        modifier = Modifier.fillMaxWidth().padding(start = 10.dp, end = 10.dp, top = 11.dp, bottom = 4.dp),
        style = MaterialTheme.typography.labelMedium,
        fontWeight = FontWeight.SemiBold,
        color = MaterialTheme.colorScheme.onSurfaceVariant
    )
}

@Composable
private fun HighlightedDrawerText(
    text: String,
    query: String,
    selected: Boolean,
    title: Boolean
) {
    val cleanQuery = query.trim()
    val start = if (cleanQuery.isBlank()) -1 else text.indexOf(cleanQuery, ignoreCase = true)
    val annotated = if (start < 0) {
        AnnotatedString(text)
    } else {
        buildAnnotatedString {
            append(text.substring(0, start))
            withStyle(
                SpanStyle(
                    color = AionColors.ExternalSoft,
                    background = AionColors.External.copy(alpha = 0.12f),
                    fontWeight = FontWeight.SemiBold
                )
            ) {
                append(text.substring(start, start + cleanQuery.length))
            }
            append(text.substring(start + cleanQuery.length))
        }
    }
    Text(
        text = annotated,
        maxLines = 1,
        style = if (title) MaterialTheme.typography.labelLarge else MaterialTheme.typography.bodySmall,
        fontWeight = if (title && selected) FontWeight.SemiBold else FontWeight.Normal,
        color = if (title && selected) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant
    )
}

@Composable
private fun ConversationSearchResultEntry(
    hit: ConversationSearchHit,
    projectName: String?,
    query: String,
    enabled: Boolean,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 4.dp, vertical = 1.dp)
            .clickable(enabled = enabled, onClick = onClick),
        shape = RoundedCornerShape(AionRadii.Card),
        color = AionColors.SurfaceMuted,
        border = BorderStroke(1.dp, AionColors.Border)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 9.dp),
            verticalAlignment = Alignment.Top
        ) {
            Icon(
                if (hit.role == MessageRole.USER) Icons.Outlined.Edit else Icons.Outlined.Psychology,
                contentDescription = null,
                modifier = Modifier.size(17.dp),
                tint = if (hit.role == MessageRole.USER) AionColors.TextSecondary else AionColors.IntelligenceSoft
            )
            Spacer(Modifier.width(8.dp))
            Column(modifier = Modifier.weight(1f)) {
                HighlightedDrawerText(
                    text = hit.conversationTitle,
                    query = query,
                    selected = false,
                    title = true
                )
                val meta = buildString {
                    append(if (hit.role == MessageRole.USER) "أنت" else "AION")
                    if (!projectName.isNullOrBlank()) append(" • ").append(projectName)
                }
                Text(
                    meta,
                    style = MaterialTheme.typography.labelMedium,
                    color = if (projectName != null) AionColors.IntelligenceSoft else AionColors.TextTertiary,
                    maxLines = 1
                )
                if (hit.snippet.isNotBlank()) {
                    Spacer(Modifier.height(2.dp))
                    Text(
                        hit.snippet,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
            Text(
                "انتقال",
                style = MaterialTheme.typography.labelMedium,
                color = AionColors.ExternalSoft,
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AionDrawer(
    conversations: List<ConversationSummary>,
    archivedConversations: List<ConversationSummary>,
    projects: List<AionProject>,
    activeConversationId: String,
    activeProjectId: String?,
    isSending: Boolean,
    searchQuery: String,
    searchResults: List<ConversationSearchHit>,
    isSearchLoading: Boolean,
    onSearchQueryChange: (String) -> Unit,
    onSearchHitClick: (ConversationSearchHit) -> Unit,
    onConversationClick: (String) -> Unit,
    onConversationRename: (String, String) -> Unit,
    onConversationShare: (String) -> Unit,
    onConversationDelete: (String) -> Unit,
    onConversationPin: (String) -> Unit,
    onConversationArchive: (String) -> Unit,
    onConversationRestore: (String) -> Unit,
    onConversationMove: (String, String?) -> Unit,
    onProjectClick: (String) -> Unit,
    onProjectCreate: (String, String) -> Unit,
    onProjectUpdate: (AionProject) -> Unit,
    onProjectDelete: (String) -> Unit,
    onCapabilityClick: (AionCapability) -> Unit,
    onNewChat: (String?) -> Unit,
    onContext: () -> Unit,
    onSettings: () -> Unit
) {
    var showCreateProject by remember { mutableStateOf(false) }
    var workspaceProjectId by remember { mutableStateOf<String?>(null) }
    var showAllProjects by remember { mutableStateOf(false) }
    var showArchived by remember { mutableStateOf(false) }
    var newProjectName by remember { mutableStateOf("") }
    var newProjectInstructions by remember { mutableStateOf("") }

    val query = searchQuery
    val normalizedQuery = normalizeLocalSearch(query)
    val projectSnapshot = projects.toList()
    val conversationSnapshot = conversations.toList()
    val projectNames = remember(projectSnapshot) { projectSnapshot.associate { it.id to it.name } }
    val normalizedProjectNames = remember(projectSnapshot) {
        projectSnapshot.associate { it.id to normalizeLocalSearch(it.name) }
    }
    // التطبيع العربي لنصوص آلاف الأحرف مكلف إذا تكرر مع كل ضغطة مفتاح.
    // نحسب مفتاح البحث مرة عند تغير قائمة المحادثات ثم نبحث داخله فقط أثناء الكتابة.
    val conversationSearchKeys = remember(conversationSnapshot) {
        conversationSnapshot.associate { conversation ->
            conversation.id to normalizeLocalSearch(
                buildString {
                    append(conversation.title).append('\n')
                    append(conversation.preview).append('\n')
                    append(conversation.searchText)
                }
            )
        }
    }
    val filtered = remember(conversationSnapshot, normalizedProjectNames, conversationSearchKeys, normalizedQuery) {
        if (normalizedQuery.isBlank()) conversationSnapshot
        else conversationSnapshot.filter { conversation ->
            conversationSearchKeys[conversation.id].orEmpty().contains(normalizedQuery) ||
                conversation.projectId?.let { normalizedProjectNames[it] }?.contains(normalizedQuery) == true
        }
    }
    val projectConversationCounts = remember(conversationSnapshot) {
        conversationSnapshot
            .mapNotNull { it.projectId }
            .groupingBy { it }
            .eachCount()
    }
    val projectLastConversationActivity = remember(conversationSnapshot) {
        conversationSnapshot
            .filter { it.projectId != null }
            .groupBy { it.projectId!! }
            .mapValues { (_, items) -> items.maxOfOrNull { it.updatedAt } ?: 0L }
    }
    val orderedProjects = remember(projectSnapshot, activeProjectId, projectLastConversationActivity) {
        projectSnapshot.sortedWith(
            compareByDescending<AionProject> { it.id == activeProjectId }
                .thenByDescending { project -> maxOf(project.updatedAt, projectLastConversationActivity[project.id] ?: 0L) }
        )
    }
    val filteredProjects = remember(projectSnapshot, normalizedProjectNames, normalizedQuery) {
        if (normalizedQuery.isBlank()) emptyList()
        else projectSnapshot.filter { project ->
            normalizedProjectNames[project.id].orEmpty().contains(normalizedQuery) ||
                normalizeLocalSearch(project.instructions).contains(normalizedQuery) ||
                normalizeLocalSearch(project.memoryNotes).contains(normalizedQuery)
        }
    }

    ModalDrawerSheet(
        modifier = Modifier.fillMaxHeight().fillMaxWidth(0.86f).widthIn(max = AionSizes.DrawerMaxWidth),
        drawerContainerColor = AionColors.Background
    ) {
        Spacer(Modifier.height(10.dp))
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            AionMark(size = 32.dp)
            Spacer(Modifier.width(10.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text("AION", fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
                Text(
                    activeProjectId?.let { projectNames[it] } ?: "المساعد الذكي",
                    color = if (activeProjectId != null) AionColors.IntelligenceSoft else MaterialTheme.colorScheme.onSurfaceVariant,
                    style = MaterialTheme.typography.labelMedium,
                    maxLines = 1
                )
            }
            Surface(
                onClick = { onNewChat(activeProjectId) },
                enabled = !isSending,
                shape = CircleShape,
                color = AionColors.SurfaceInteractive,
                modifier = Modifier.size(AionSizes.TouchTarget)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(Icons.Outlined.Add, contentDescription = "محادثة جديدة", modifier = Modifier.size(20.dp))
                }
            }
        }

        Surface(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp),
            shape = RoundedCornerShape(AionRadii.Card),
            color = AionColors.SurfaceRaised,
            border = BorderStroke(1.dp, AionColors.Border)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth().defaultMinSize(minHeight = 44.dp).padding(start = 11.dp, end = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    Icons.Outlined.Search,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp),
                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.width(8.dp))
                BasicTextField(
                    value = query,
                    onValueChange = onSearchQueryChange,
                    modifier = Modifier.weight(1f),
                    singleLine = true,
                    textStyle = MaterialTheme.typography.bodyMedium.copy(color = MaterialTheme.colorScheme.onSurface),
                    decorationBox = { inner ->
                        Box {
                            if (query.isBlank()) {
                                Text("ابحث في المحادثات", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            inner()
                        }
                    }
                )
                if (query.isNotBlank()) {
                    IconButton(onClick = { onSearchQueryChange("") }, modifier = Modifier.size(AionSizes.TouchTarget)) {
                        Icon(Icons.Outlined.Close, contentDescription = "مسح البحث", modifier = Modifier.size(15.dp))
                    }
                }
            }
        }

        if (normalizedQuery.isBlank()) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(start = 18.dp, end = 10.dp, top = 8.dp, bottom = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "المشاريع",
                    modifier = Modifier.weight(1f),
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                IconButton(
                    onClick = { showCreateProject = true },
                    enabled = !isSending,
                    modifier = Modifier.size(AionSizes.TouchTarget)
                ) {
                    Icon(Icons.Outlined.Add, contentDescription = "مشروع جديد", modifier = Modifier.size(AionSizes.SmallIcon))
                }
            }

            if (projects.isEmpty()) {
                Surface(
                    onClick = { showCreateProject = true },
                    shape = RoundedCornerShape(14.dp),
                    color = AionColors.SurfaceMuted,
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 2.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Outlined.Folder, contentDescription = null, modifier = Modifier.size(18.dp), tint = AionPurpleSoft)
                        Spacer(Modifier.width(8.dp))
                        Column {
                            Text("أنشئ مشروعًا", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold)
                            Text("محادثات + تعليمات + ذاكرة مستقلة", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            } else {
                val visibleProjects = if (showAllProjects) orderedProjects else orderedProjects.take(4)
                visibleProjects.forEach { project ->
                    ProjectDrawerEntry(
                        project = project,
                        conversationCount = projectConversationCounts[project.id] ?: 0,
                        selected = project.id == activeProjectId,
                        enabled = !isSending,
                        onOpen = { workspaceProjectId = project.id },
                        onNewChat = { onNewChat(project.id) },
                        onUpdate = onProjectUpdate,
                        onDelete = { onProjectDelete(project.id) }
                    )
                }
                if (orderedProjects.size > 4) {
                    TextButton(
                        onClick = { showAllProjects = !showAllProjects },
                        modifier = Modifier.padding(horizontal = 10.dp)
                    ) {
                        Text(if (showAllProjects) "عرض أقل" else "عرض كل المشاريع (${orderedProjects.size})")
                    }
                }
            }
        }

        if (normalizedQuery.isNotBlank() && filteredProjects.isNotEmpty()) {
            DrawerSectionLabel("المشاريع")
            filteredProjects.take(5).forEach { project ->
                ProjectDrawerEntry(
                    project = project,
                    conversationCount = projectConversationCounts[project.id] ?: 0,
                    selected = project.id == activeProjectId,
                    enabled = !isSending,
                    onOpen = { workspaceProjectId = project.id },
                    onNewChat = { onNewChat(project.id) },
                    onUpdate = onProjectUpdate,
                    onDelete = { onProjectDelete(project.id) }
                )
            }
        }

        if (normalizedQuery.isBlank() || filtered.isNotEmpty()) {
            Text(
                if (normalizedQuery.isBlank()) "المحادثات" else "المحادثات المطابقة",
                modifier = Modifier.padding(horizontal = 18.dp, vertical = 7.dp),
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        if (filtered.isEmpty() && filteredProjects.isEmpty() && searchResults.isEmpty() && !isSearchLoading) {
            Column(
                modifier = Modifier.weight(1f).fillMaxWidth().padding(horizontal = 22.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Icon(Icons.Outlined.Search, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(8.dp))
                Text(
                    if (conversations.isEmpty()) "ابدأ محادثة وسيظهر سجلها هنا" else "لا توجد نتائج مطابقة",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    style = MaterialTheme.typography.bodySmall,
                    textAlign = TextAlign.Center
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f).fillMaxWidth(),
                contentPadding = PaddingValues(horizontal = AionSpacing.Sm, vertical = AionSpacing.Xs),
                verticalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                val grouped = if (normalizedQuery.isBlank()) groupDrawerConversations(filtered) else emptyList()
                if (normalizedQuery.isNotBlank()) {
                    item(key = "message-search-heading") {
                        DrawerSectionLabel(if (isSearchLoading) "أبحث داخل الرسائل…" else "داخل الرسائل")
                    }
                    if (!isSearchLoading) {
                        items(
                            items = searchResults,
                            key = { hit -> "search-${hit.conversationId}-${hit.messageId}" }
                        ) { hit ->
                            ConversationSearchResultEntry(
                                hit = hit,
                                projectName = hit.projectId?.let { projectNames[it] },
                                query = query,
                                enabled = !isSending,
                                onClick = { onSearchHitClick(hit) }
                            )
                        }
                        if (searchResults.isEmpty()) {
                            item(key = "message-search-empty") {
                                Text(
                                    "لا توجد رسالة مطابقة في الفهرس المحلي",
                                    modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = AionColors.TextTertiary
                                )
                            }
                        }
                    }
                }
                if (normalizedQuery.isBlank()) {
                    grouped.forEach { section ->
                        item(key = "section-${section.label}") {
                            DrawerSectionLabel(section.label)
                        }
                        items(section.items, key = { it.id }) { conversation ->
                            ConversationDrawerEntry(
                                conversation = conversation,
                                projectName = conversation.projectId?.let { projectNames[it] },
                                projects = projects,
                                selected = conversation.id == activeConversationId,
                                running = isSending && conversation.id == activeConversationId,
                                query = "",
                                enabled = !isSending,
                                onClick = { onConversationClick(conversation.id) },
                                onRename = { title -> onConversationRename(conversation.id, title) },
                                onShare = { onConversationShare(conversation.id) },
                                onPin = { onConversationPin(conversation.id) },
                                onArchive = { onConversationArchive(conversation.id) },
                                onMove = { projectId -> onConversationMove(conversation.id, projectId) },
                                onDelete = { onConversationDelete(conversation.id) }
                            )
                        }
                    }
                } else {
                    items(filtered, key = { it.id }) { conversation ->
                        ConversationDrawerEntry(
                            conversation = conversation,
                            projectName = conversation.projectId?.let { projectNames[it] },
                            projects = projects,
                            selected = conversation.id == activeConversationId,
                            running = isSending && conversation.id == activeConversationId,
                            query = query,
                            enabled = !isSending,
                            onClick = { onConversationClick(conversation.id) },
                            onRename = { title -> onConversationRename(conversation.id, title) },
                            onShare = { onConversationShare(conversation.id) },
                            onPin = { onConversationPin(conversation.id) },
                            onArchive = { onConversationArchive(conversation.id) },
                            onMove = { projectId -> onConversationMove(conversation.id, projectId) },
                            onDelete = { onConversationDelete(conversation.id) }
                        )
                    }
                }
            }
        }

        HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.35f))
        DrawerEntry(
            Icons.Outlined.Description,
            "الأرشيف",
            if (archivedConversations.isEmpty()) "لا توجد محادثات مؤرشفة" else "${archivedConversations.size} محادثة",
            onClick = { showArchived = true }
        )
        DrawerEntry(Icons.Outlined.Memory, "الذاكرة", "تفضيلات وقرارات وسياق", onClick = {
            FeatureRegistry.capabilities.firstOrNull { it.key == "memory" }?.let(onCapabilityClick)
        })
        DrawerEntry(Icons.Outlined.Info, "سياق المحادثة", "ما الذي يستخدمه AION الآن", onContext)
        HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.25f))
        DrawerEntry(Icons.Outlined.Settings, "الإعدادات", null, onSettings)
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 9.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("AION Mobile", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.labelMedium)
            Text("α7.3 dev", color = AionColors.IntelligenceSoft, style = MaterialTheme.typography.labelMedium)
        }
    }

    workspaceProjectId?.let { projectId ->
        projects.firstOrNull { it.id == projectId }?.let { project ->
            ProjectWorkspaceSheet(
                project = project,
                conversations = conversations.filter { it.projectId == project.id && !it.archived },
                enabled = !isSending,
                onDismiss = { workspaceProjectId = null },
                onOpenProject = {
                    workspaceProjectId = null
                    onProjectClick(project.id)
                },
                onNewChat = {
                    workspaceProjectId = null
                    onNewChat(project.id)
                },
                onConversationClick = { conversationId ->
                    workspaceProjectId = null
                    onConversationClick(conversationId)
                }
            )
        }
    }

    if (showArchived) {
        AlertDialog(
            onDismissRequest = { showArchived = false },
            title = { Text("الأرشيف") },
            text = {
                if (archivedConversations.isEmpty()) {
                    Text("لا توجد محادثات مؤرشفة حاليًا.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                } else {
                    LazyColumn(
                        modifier = Modifier.fillMaxWidth().height(360.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        items(archivedConversations, key = { it.id }) { conversation ->
                            Surface(
                                shape = RoundedCornerShape(14.dp),
                                color = AionColors.SurfaceMuted,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(conversation.title, style = MaterialTheme.typography.labelLarge, maxLines = 1, fontWeight = FontWeight.SemiBold)
                                        if (conversation.preview.isNotBlank()) {
                                            Text(
                                                conversation.preview,
                                                style = MaterialTheme.typography.bodySmall,
                                                maxLines = 1,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }
                                    TextButton(
                                        enabled = !isSending,
                                        onClick = { onConversationRestore(conversation.id) }
                                    ) { Text("استعادة") }
                                    IconButton(
                                        enabled = !isSending,
                                        onClick = { onConversationDelete(conversation.id) },
                                        modifier = Modifier.size(34.dp)
                                    ) {
                                        Icon(Icons.Outlined.DeleteOutline, contentDescription = "حذف", modifier = Modifier.size(18.dp))
                                    }
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showArchived = false }) { Text("إغلاق") } }
        )
    }

    if (showCreateProject) {
        AlertDialog(
            onDismissRequest = { showCreateProject = false },
            title = { Text("مشروع جديد") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = newProjectName,
                        onValueChange = { newProjectName = it.take(60) },
                        label = { Text("اسم المشروع") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = newProjectInstructions,
                        onValueChange = { newProjectInstructions = it.take(6_000) },
                        label = { Text("تعليمات المشروع") },
                        minLines = 3,
                        maxLines = 6,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        if (newProjectName.isNotBlank()) {
                            onProjectCreate(newProjectName, newProjectInstructions)
                            newProjectName = ""
                            newProjectInstructions = ""
                            showCreateProject = false
                        }
                    }
                ) { Text("إنشاء") }
            },
            dismissButton = { TextButton(onClick = { showCreateProject = false }) { Text("إلغاء") } }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ProjectWorkspaceSheet(
    project: AionProject,
    conversations: List<ConversationSummary>,
    enabled: Boolean,
    onDismiss: () -> Unit,
    onOpenProject: () -> Unit,
    onNewChat: () -> Unit,
    onConversationClick: (String) -> Unit
) {
    val orderedConversations = remember(conversations) { conversations.sortedByDescending { it.updatedAt } }
    val memoryCount = project.memoryNotes.lineSequence().count { it.isNotBlank() }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = AionColors.Surface
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 6.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = AionColors.Intelligence.copy(alpha = 0.12f),
                    modifier = Modifier.size(46.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(Icons.Outlined.Folder, contentDescription = null, tint = AionColors.IntelligenceSoft)
                    }
                }
                Spacer(Modifier.width(11.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(project.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, maxLines = 1)
                    Text(
                        buildString {
                            append(orderedConversations.size).append(" محادثة")
                            append(" • ")
                            append(if (project.projectOnlyMemory) "ذاكرة معزولة" else "ذاكرة مشتركة")
                            if (memoryCount > 0) append(" • ").append(memoryCount).append(" محفوظات")
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(Modifier.height(14.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = onNewChat,
                    enabled = enabled,
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Outlined.Add, contentDescription = null, modifier = Modifier.size(17.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("محادثة جديدة")
                }
                OutlinedButton(
                    onClick = onOpenProject,
                    enabled = enabled,
                    modifier = Modifier.weight(1f)
                ) {
                    Text(if (orderedConversations.isEmpty()) "فتح المشروع" else "آخر محادثة")
                }
            }

            if (project.instructions.isNotBlank()) {
                Spacer(Modifier.height(14.dp))
                Text("تعليمات المشروع", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(5.dp))
                Surface(
                    shape = RoundedCornerShape(AionRadii.Card),
                    color = AionColors.SurfaceMuted,
                    border = BorderStroke(1.dp, AionColors.Border)
                ) {
                    Text(
                        project.instructions.trim(),
                        modifier = Modifier.fillMaxWidth().padding(12.dp),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 4,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            Spacer(Modifier.height(14.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("آخر المحادثات", modifier = Modifier.weight(1f), style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold)
                Text(
                    if (orderedConversations.isEmpty()) "لا توجد بعد" else orderedConversations.size.toString(),
                    style = MaterialTheme.typography.labelMedium,
                    color = AionColors.TextTertiary
                )
            }
            Spacer(Modifier.height(6.dp))

            if (orderedConversations.isEmpty()) {
                Surface(
                    shape = RoundedCornerShape(AionRadii.Card),
                    color = AionColors.SurfaceMuted,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        "ابدأ أول محادثة داخل هذا المشروع. ستستخدم تعليماته وذاكرته تلقائيًا.",
                        modifier = Modifier.padding(13.dp),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                orderedConversations.take(7).forEach { conversation ->
                    Surface(
                        onClick = { onConversationClick(conversation.id) },
                        enabled = enabled,
                        shape = RoundedCornerShape(13.dp),
                        color = Color.Transparent,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(horizontal = 9.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Outlined.ChatBubbleOutline, contentDescription = null, modifier = Modifier.size(17.dp), tint = AionColors.TextSecondary)
                            Spacer(Modifier.width(8.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(conversation.title, style = MaterialTheme.typography.labelLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                if (conversation.preview.isNotBlank()) {
                                    Text(
                                        conversation.preview,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        }
                    }
                }
            }
            Spacer(Modifier.height(AionSpacing.Xxl))
        }
    }
}

@Composable
private fun ProjectDrawerEntry(
    project: AionProject,
    conversationCount: Int,
    selected: Boolean,
    enabled: Boolean,
    onOpen: () -> Unit,
    onNewChat: () -> Unit,
    onUpdate: (AionProject) -> Unit,
    onDelete: () -> Unit
) {
    var menuExpanded by remember(project.id) { mutableStateOf(false) }
    var showEdit by remember(project.id) { mutableStateOf(false) }
    var showDeleteConfirm by remember(project.id) { mutableStateOf(false) }
    var name by remember(project.id, project.name) { mutableStateOf(project.name) }
    var instructions by remember(project.id, project.instructions) { mutableStateOf(project.instructions) }
    var projectMemory by remember(project.id, project.memoryNotes) { mutableStateOf(project.memoryNotes) }
    var projectOnlyMemory by remember(project.id, project.projectOnlyMemory) { mutableStateOf(project.projectOnlyMemory) }

    Surface(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 1.dp).clickable(enabled = enabled, onClick = onOpen),
        shape = RoundedCornerShape(AionRadii.Card),
        color = if (selected) AionColors.SurfaceSelected else Color.Transparent,
        border = if (selected) BorderStroke(1.dp, AionColors.Intelligence.copy(alpha = 0.22f)) else null
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(start = 10.dp, end = 2.dp, top = 7.dp, bottom = 7.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Outlined.Folder, contentDescription = null, modifier = Modifier.size(18.dp), tint = if (selected) AionPurpleSoft else MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.width(8.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(project.name, style = MaterialTheme.typography.labelLarge, maxLines = 1, fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal)
                val memoryCount = project.memoryNotes.lineSequence().count { it.isNotBlank() }
                val scopeLabel = if (project.projectOnlyMemory) "ذاكرة معزولة" else "ذاكرة مشتركة"
                Text(
                    buildString {
                        if (conversationCount > 0) append(conversationCount).append(" محادثة • ")
                        append(scopeLabel)
                        if (memoryCount > 0) append(" • ").append(memoryCount).append(" محفوظات")
                        else if (project.instructions.isNotBlank()) append(" • تعليمات مفعّلة")
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            IconButton(onClick = onNewChat, enabled = enabled, modifier = Modifier.size(AionSizes.TouchTarget)) {
                Icon(Icons.Outlined.Add, contentDescription = "محادثة جديدة داخل المشروع", modifier = Modifier.size(16.dp))
            }
            Box {
                IconButton(onClick = { menuExpanded = true }, enabled = enabled, modifier = Modifier.size(AionSizes.TouchTarget)) {
                    Icon(Icons.Outlined.MoreHoriz, contentDescription = "خيارات المشروع", modifier = Modifier.size(16.dp))
                }
                DropdownMenu(expanded = menuExpanded, onDismissRequest = { menuExpanded = false }) {
                    DropdownMenuItem(
                        text = { Text("إعدادات المشروع") },
                        leadingIcon = { Icon(Icons.Outlined.Settings, contentDescription = null) },
                        onClick = {
                            menuExpanded = false
                            name = project.name
                            instructions = project.instructions
                            projectMemory = project.memoryNotes
                            projectOnlyMemory = project.projectOnlyMemory
                            showEdit = true
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("حذف المشروع") },
                        leadingIcon = { Icon(Icons.Outlined.DeleteOutline, contentDescription = null) },
                        onClick = {
                            menuExpanded = false
                            showDeleteConfirm = true
                        }
                    )
                }
            }
        }
    }

    if (showEdit) {
        AlertDialog(
            onDismissRequest = { showEdit = false },
            title = { Text("إعدادات المشروع") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it.take(60) },
                        label = { Text("الاسم") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = instructions,
                        onValueChange = { instructions = it.take(6_000) },
                        label = { Text("تعليمات المشروع") },
                        minLines = 3,
                        maxLines = 7,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = projectMemory,
                        onValueChange = { projectMemory = it.take(16_000) },
                        label = { Text("ذاكرة المشروع") },
                        supportingText = {
                            Text("زر «تذكّر» داخل أي محادثة في هذا المشروع يضيف هنا، حتى لو كانت الذاكرة العامة مسموحة أيضًا.")
                        },
                        minLines = 3,
                        maxLines = 7,
                        modifier = Modifier.fillMaxWidth()
                    )
                    if (projectMemory.isNotBlank()) {
                        TextButton(onClick = { projectMemory = "" }) {
                            Text("مسح ذاكرة المشروع", color = MaterialTheme.colorScheme.error)
                        }
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("ذاكرة خاصة بالمشروع", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold)
                            Text(
                                "عند تفعيلها لا تستخدم الذاكرة العامة داخل هذا المشروع.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(
                            checked = projectOnlyMemory,
                            onCheckedChange = { projectOnlyMemory = it }
                        )
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (name.isNotBlank()) onUpdate(
                        project.copy(
                            name = name,
                            instructions = instructions,
                            memoryNotes = projectMemory,
                            projectOnlyMemory = projectOnlyMemory
                        )
                    )
                    showEdit = false
                }) { Text("حفظ") }
            },
            dismissButton = { TextButton(onClick = { showEdit = false }) { Text("إلغاء") } }
        )
    }

    if (showDeleteConfirm) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirm = false },
            title = { Text("حذف المشروع؟") },
            text = { Text("لن تُحذف المحادثات؛ ستعود إلى قائمة المحادثات العامة.") },
            confirmButton = {
                TextButton(onClick = {
                    showDeleteConfirm = false
                    onDelete()
                }) { Text("حذف", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = { TextButton(onClick = { showDeleteConfirm = false }) { Text("إلغاء") } }
        )
    }
}

@Composable
private fun ConversationDrawerEntry(
    conversation: ConversationSummary,
    projectName: String?,
    projects: List<AionProject>,
    selected: Boolean,
    running: Boolean = false,
    query: String = "",
    enabled: Boolean,
    onClick: () -> Unit,
    onRename: (String) -> Unit,
    onShare: () -> Unit,
    onPin: () -> Unit,
    onArchive: () -> Unit,
    onMove: (String?) -> Unit,
    onDelete: () -> Unit
) {
    var menuExpanded by remember(conversation.id) { mutableStateOf(false) }
    var showRename by remember(conversation.id) { mutableStateOf(false) }
    var showDeleteConfirm by remember(conversation.id) { mutableStateOf(false) }
    var showMove by remember(conversation.id) { mutableStateOf(false) }
    var renameValue by remember(conversation.id, conversation.title) { mutableStateOf(conversation.title) }

    Surface(
        modifier = Modifier.fillMaxWidth().clickable(enabled = enabled, onClick = onClick),
        shape = RoundedCornerShape(AionRadii.Card),
        color = if (selected) AionColors.Intelligence.copy(alpha = 0.09f) else Color.Transparent,
        border = if (selected) BorderStroke(1.dp, AionColors.Intelligence.copy(alpha = 0.18f)) else null
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(start = 11.dp, end = 3.dp, top = 8.dp, bottom = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(
                    if (projectName != null) Icons.Outlined.Folder else Icons.Outlined.ChatBubbleOutline,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp),
                    tint = if (selected) AionPurpleSoft else MaterialTheme.colorScheme.onSurfaceVariant
                )
                if (conversation.pinned) {
                    Box(
                        Modifier
                            .align(Alignment.TopStart)
                            .size(6.dp)
                            .clip(CircleShape)
                            .background(AionPurple)
                    )
                }
            }
            Spacer(Modifier.width(8.dp))
            Column(modifier = Modifier.weight(1f)) {
                HighlightedDrawerText(
                    text = conversation.title,
                    query = query,
                    selected = selected,
                    title = true
                )
                val subtitle = when {
                    projectName != null && conversation.preview.isNotBlank() -> "$projectName • ${conversation.preview}"
                    projectName != null -> projectName
                    else -> conversation.preview
                }
                if (subtitle.isNotBlank()) {
                    HighlightedDrawerText(
                        text = subtitle,
                        query = query,
                        selected = false,
                        title = false
                    )
                }
            }
            if (running) {
                Box(
                    Modifier
                        .padding(horizontal = 5.dp)
                        .size(7.dp)
                        .clip(CircleShape)
                        .background(AionColors.Intelligence)
                )
            }
            Box {
                IconButton(onClick = { menuExpanded = true }, enabled = enabled, modifier = Modifier.size(AionSizes.TouchTarget)) {
                    Icon(
                        Icons.Outlined.MoreHoriz,
                        contentDescription = "خيارات المحادثة",
                        modifier = Modifier.size(17.dp),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                DropdownMenu(expanded = menuExpanded, onDismissRequest = { menuExpanded = false }) {
                    DropdownMenuItem(
                        text = { Text(if (conversation.pinned) "إلغاء التثبيت" else "تثبيت") },
                        leadingIcon = { Icon(Icons.Outlined.Check, contentDescription = null) },
                        onClick = {
                            menuExpanded = false
                            onPin()
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("نقل إلى مشروع") },
                        leadingIcon = { Icon(Icons.Outlined.Folder, contentDescription = null) },
                        onClick = {
                            menuExpanded = false
                            showMove = true
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("إعادة التسمية") },
                        leadingIcon = { Icon(Icons.Outlined.Edit, contentDescription = null) },
                        onClick = {
                            menuExpanded = false
                            renameValue = conversation.title
                            showRename = true
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("مشاركة") },
                        leadingIcon = { Icon(Icons.Outlined.Description, contentDescription = null) },
                        onClick = {
                            menuExpanded = false
                            onShare()
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("أرشفة") },
                        leadingIcon = { Icon(Icons.Outlined.Close, contentDescription = null) },
                        onClick = {
                            menuExpanded = false
                            onArchive()
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("حذف") },
                        leadingIcon = { Icon(Icons.Outlined.DeleteOutline, contentDescription = null) },
                        onClick = {
                            menuExpanded = false
                            showDeleteConfirm = true
                        }
                    )
                }
            }
        }
    }

    if (showRename) {
        AlertDialog(
            onDismissRequest = { showRename = false },
            title = { Text("إعادة تسمية المحادثة") },
            text = {
                OutlinedTextField(
                    value = renameValue,
                    onValueChange = { renameValue = it.take(60) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        if (renameValue.isNotBlank()) onRename(renameValue)
                        showRename = false
                    }
                ) { Text("حفظ") }
            },
            dismissButton = { TextButton(onClick = { showRename = false }) { Text("إلغاء") } }
        )
    }

    if (showMove) {
        AlertDialog(
            onDismissRequest = { showMove = false },
            title = { Text("نقل إلى مشروع") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Surface(
                        onClick = {
                            onMove(null)
                            showMove = false
                        },
                        shape = RoundedCornerShape(12.dp),
                        color = if (conversation.projectId == null) AionColors.SurfaceSelected else AionColors.SurfaceMuted
                    ) {
                        Text("بدون مشروع", modifier = Modifier.fillMaxWidth().padding(12.dp), style = MaterialTheme.typography.bodyMedium)
                    }
                    projects.forEach { project ->
                        Surface(
                            onClick = {
                                onMove(project.id)
                                showMove = false
                            },
                            shape = RoundedCornerShape(12.dp),
                            color = if (conversation.projectId == project.id) AionColors.SurfaceSelected else AionColors.SurfaceMuted
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Outlined.Folder, contentDescription = null, modifier = Modifier.size(16.dp), tint = AionPurpleSoft)
                                Spacer(Modifier.width(8.dp))
                                Text(project.name, style = MaterialTheme.typography.bodyMedium)
                            }
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { showMove = false }) { Text("إلغاء") } }
        )
    }

    if (showDeleteConfirm) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirm = false },
            title = { Text("حذف المحادثة؟") },
            text = { Text("سيُحذف سجل هذه المحادثة من الجهاز.") },
            confirmButton = {
                TextButton(
                    onClick = {
                        showDeleteConfirm = false
                        onDelete()
                    }
                ) { Text("حذف", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = { TextButton(onClick = { showDeleteConfirm = false }) { Text("إلغاء") } }
        )
    }
}

@Composable
private fun DrawerEntry(icon: ImageVector, title: String, subtitle: String?, onClick: () -> Unit) {
    NavigationDrawerItem(
        label = {
            Column {
                Text(title, fontSize = 14.sp)
                if (!subtitle.isNullOrBlank()) {
                    Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        },
        selected = false,
        onClick = onClick,
        icon = { Icon(icon, contentDescription = null, modifier = Modifier.size(21.dp)) },
        modifier = Modifier.padding(horizontal = 8.dp, vertical = 1.dp)
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AionChatScreen(
    messages: List<ChatMessage>,
    pendingAttachments: List<ChatAttachment>,
    onSend: (String) -> Unit,
    onStop: () -> Unit,
    onRetry: (Long) -> Unit,
    onEditMessage: (Long, String) -> Unit,
    onRememberMessage: (String) -> Unit,
    onAddAttachments: (List<ChatAttachment>) -> Unit,
    onRemoveAttachment: (Long) -> Unit,
    onMenu: () -> Unit,
    onNewChat: () -> Unit,
    onModelPicker: () -> Unit,
    onModeShortcut: (String) -> Unit,
    onStartVoiceCall: () -> Unit,
    selectedModel: AiModelOption,
    activeProjectName: String?,
    cloudEndpoint: String,
    neuralVoiceAvailable: Boolean,
    voiceSettings: AionVoiceSettings,
    myVoiceToken: String,
    voicePlaybackArbiter: AionVoicePlaybackArbiter,
    isConfigured: Boolean,
    isSending: Boolean,
    activity: GatewayActivity?,
    safeMode: Boolean,
    draft: String,
    onDraftChange: (String) -> Unit,
    scrollToMessageId: Long?,
    onScrollTargetConsumed: (Long) -> Unit
) {
    val context = LocalContext.current
    val readAloudScope = rememberCoroutineScope()
    val neuralReadPlayer = remember { NeuralVoicePlayer() }
    val readAloudFocus = remember { VoiceAudioFocus(context.applicationContext) }
    var readAloudJob by remember { mutableStateOf<Job?>(null) }
    var readAloudLease by remember { mutableStateOf<Long?>(null) }
    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }

    LaunchedEffect(isSending) {
        if (
            isSending &&
            Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    var ttsEngine by remember { mutableStateOf<TextToSpeech?>(null) }

    fun releaseReadAloudLease(token: Long) {
        voicePlaybackArbiter.release(AionVoicePlaybackOwner.READ_ALOUD, token)
        if (readAloudLease == token) readAloudLease = null
    }

    fun stopReadAloudHardware() {
        readAloudJob?.cancel()
        neuralReadPlayer.stop()
        runCatching { ttsEngine?.stop() }
        readAloudFocus.abandon()
    }

    DisposableEffect(context, safeMode) {
        if (safeMode) {
            voicePlaybackArbiter.interrupt(AionVoicePlaybackOwner.READ_ALOUD)
            stopReadAloudHardware()
            readAloudJob = null
            readAloudLease = null
            ttsEngine = null
            onDispose {
                voicePlaybackArbiter.interrupt(AionVoicePlaybackOwner.READ_ALOUD)
                stopReadAloudHardware()
                readAloudJob = null
                readAloudLease = null
            }
        } else {
            var engine: TextToSpeech? = null
            engine = runCatching {
                TextToSpeech(context.applicationContext) { status ->
                    val ready = engine ?: return@TextToSpeech
                    if (status == TextToSpeech.SUCCESS) {
                        // بعض محركات TTS المخصصة من الشركات ترمي RuntimeException عند
                        // الاستعلام عن الأصوات أو AudioAttributes. لا نسمح للصوت بإسقاط الدردشة.
                        runCatching { configureNaturalTts(ready, Locale.getDefault()) }
                        ready.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                            override fun onStart(utteranceId: String?) = Unit

                            private fun tokenOf(utteranceId: String?): Long? = utteranceId
                                ?.takeIf { it.startsWith("aion-read-") }
                                ?.removePrefix("aion-read-")
                                ?.substringBefore('-')
                                ?.toLongOrNull()

                            private fun finishIfCurrent(utteranceId: String?) {
                                val token = tokenOf(utteranceId) ?: return
                                readAloudScope.launch {
                                    if (voicePlaybackArbiter.isCurrent(AionVoicePlaybackOwner.READ_ALOUD, token)) {
                                        readAloudFocus.abandon()
                                        releaseReadAloudLease(token)
                                    }
                                }
                            }

                            override fun onDone(utteranceId: String?) {
                                if (utteranceId?.endsWith(":last") == true) finishIfCurrent(utteranceId)
                            }

                            override fun onStop(utteranceId: String?, interrupted: Boolean) {
                                finishIfCurrent(utteranceId)
                            }

                            @Deprecated("Deprecated in Java")
                            override fun onError(utteranceId: String?) {
                                finishIfCurrent(utteranceId)
                            }
                        })
                        ttsEngine = ready
                    }
                }
            }.getOrNull()
            onDispose {
                voicePlaybackArbiter.interrupt(AionVoicePlaybackOwner.READ_ALOUD)
                stopReadAloudHardware()
                readAloudJob = null
                readAloudLease = null
                engine?.let { current ->
                    runCatching { current.stop() }
                    runCatching { current.shutdown() }
                }
                ttsEngine = null
            }
        }
    }

    fun speakLocally(text: String, lease: Long): Boolean {
        if (!voicePlaybackArbiter.isCurrent(AionVoicePlaybackOwner.READ_ALOUD, lease)) return false
        val engine = ttsEngine
        if (engine == null) {
            readAloudFocus.abandon()
            releaseReadAloudLease(lease)
            Toast.makeText(context, "خدمة قراءة النص ما زالت تتهيأ أو غير متاحة على الجهاز.", Toast.LENGTH_SHORT).show()
            return false
        }
        val chunks = SpeechText.chunks(text)
        if (chunks.isEmpty()) {
            readAloudFocus.abandon()
            releaseReadAloudLease(lease)
            return false
        }
        readAloudFocus.request()
        runCatching { engine.setSpeechRate(voiceSettings.speed.coerceIn(0.72f, 1.20f)) }
        var queued = true
        chunks.forEachIndexed { index, chunk ->
            if (!queued || !voicePlaybackArbiter.isCurrent(AionVoicePlaybackOwner.READ_ALOUD, lease)) {
                queued = false
                return@forEachIndexed
            }
            val isLast = index == chunks.lastIndex
            val result = engine.speak(
                chunk,
                if (index == 0) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD,
                null,
                "aion-read-$lease-$index${if (isLast) ":last" else ""}"
            )
            if (result == TextToSpeech.ERROR) queued = false
        }
        if (!queued) {
            runCatching { engine.stop() }
            if (voicePlaybackArbiter.isCurrent(AionVoicePlaybackOwner.READ_ALOUD, lease)) {
                readAloudFocus.abandon()
                releaseReadAloudLease(lease)
            }
            return false
        }
        return true
    }

    val speak: (String) -> Unit = { text ->
        if (safeMode) {
            Toast.makeText(context, "قراءة الصوت متوقفة مؤقتًا في الوضع الآمن.", Toast.LENGTH_SHORT).show()
        } else if (text.isNotBlank()) {
            val lease = voicePlaybackArbiter.claim(AionVoicePlaybackOwner.READ_ALOUD) {
                stopReadAloudHardware()
            }
            readAloudLease = lease

            val canUseNeural = neuralVoiceAvailable ||
                (voiceSettings.voiceKey == MyVoicePolicy.MY_VOICE_KEY && myVoiceToken.isNotBlank())
            if (!canUseNeural) {
                speakLocally(text, lease)
            } else {
                val job = readAloudScope.launch {
                    val clean = SpeechText.clean(text)
                    val chunks = SpeechText.splitNatural(clean, 2_800)
                    if (chunks.isEmpty()) {
                        releaseReadAloudLease(lease)
                        return@launch
                    }
                    var handedOffToLocal = false
                    readAloudFocus.request()
                    try {
                        for ((index, chunk) in chunks.withIndex()) {
                            if (!voicePlaybackArbiter.isCurrent(AionVoicePlaybackOwner.READ_ALOUD, lease)) return@launch
                            var chunkStarted = false
                            val result = neuralReadPlayer.speak(
                                endpoint = cloudEndpoint,
                                text = chunk,
                                profile = voiceSettings.profile.key,
                                voiceKey = voiceSettings.voiceKey,
                                speed = voiceSettings.speed,
                                expression = voiceSettings.expression,
                                clarity = voiceSettings.clarity,
                                myVoiceToken = if (voiceSettings.voiceKey == MyVoicePolicy.MY_VOICE_KEY) myVoiceToken else "",
                                onStarted = { chunkStarted = true }
                            )
                            when (result) {
                                NeuralVoicePlaybackResult.PLAYED -> Unit
                                NeuralVoicePlaybackResult.INTERRUPTED -> return@launch
                                NeuralVoicePlaybackResult.UNAVAILABLE,
                                NeuralVoicePlaybackResult.FAILED -> {
                                    val remainder = VoicePlaybackPolicy.localFallbackText(
                                        chunks = chunks,
                                        failedIndex = index,
                                        failedChunkStarted = chunkStarted
                                    )
                                    if (
                                        remainder.isNotBlank() &&
                                        voicePlaybackArbiter.isCurrent(AionVoicePlaybackOwner.READ_ALOUD, lease)
                                    ) {
                                        handedOffToLocal = withContext(Dispatchers.Main.immediate) {
                                            speakLocally(remainder, lease)
                                        }
                                    }
                                    return@launch
                                }
                            }
                        }
                    } finally {
                        if (readAloudLease == lease) readAloudJob = null
                        if (!handedOffToLocal) {
                            if (voicePlaybackArbiter.isCurrent(AionVoicePlaybackOwner.READ_ALOUD, lease)) {
                                readAloudFocus.abandon()
                                releaseReadAloudLease(lease)
                            }
                        }
                    }
                }
                readAloudJob = job
            }
        }
    }


    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            CenterAlignedTopAppBar(
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                ),
                navigationIcon = {
                    IconButton(onClick = onMenu) {
                        Icon(Icons.Outlined.Menu, contentDescription = "القائمة")
                    }
                },
                title = {
                    Surface(
                        onClick = onModelPicker,
                        shape = RoundedCornerShape(AionRadii.Chip),
                        color = Color.Transparent
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = AionSpacing.Sm, vertical = AionSpacing.Xs),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    "AION",
                                    fontWeight = FontWeight.ExtraBold,
                                    style = MaterialTheme.typography.titleMedium
                                )
                                val modeLabel = selectedModel.label.removePrefix("AION ").ifBlank { "Auto" }
                                Text(
                                    if (activeProjectName.isNullOrBlank()) modeLabel else "$modeLabel · $activeProjectName",
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    style = MaterialTheme.typography.labelMedium,
                                    maxLines = 1
                                )
                            }
                            Spacer(Modifier.width(AionSpacing.Xs))
                            Icon(
                                Icons.Outlined.KeyboardArrowDown,
                                contentDescription = "اختيار وضع AION",
                                modifier = Modifier.size(AionSizes.SmallIcon),
                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                },
                actions = {
                    IconButton(onClick = onNewChat, enabled = !isSending, modifier = Modifier.size(AionSizes.TouchTarget)) {
                        Icon(Icons.Outlined.Edit, contentDescription = "محادثة جديدة", modifier = Modifier.size(AionSizes.Icon))
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
                if (messages.isEmpty()) {
                    WelcomeContent(onSuggestion = onSend)
                } else {
                    MessagesList(
                        messages = messages,
                        activity = activity,
                        onSpeak = speak,
                        onRetry = onRetry,
                        onEditMessage = onEditMessage,
                        onRememberMessage = onRememberMessage,
                        scrollToMessageId = scrollToMessageId,
                        onScrollTargetConsumed = onScrollTargetConsumed
                    )
                }
            }
            ChatComposer(
                onSend = onSend,
                onModeShortcut = onModeShortcut,
                onStartVoiceCall = onStartVoiceCall,
                onStop = onStop,
                onAddAttachments = onAddAttachments,
                onRemoveAttachment = onRemoveAttachment,
                pendingAttachments = pendingAttachments,
                selectedModel = selectedModel,
                activeProjectName = activeProjectName,
                isConfigured = isConfigured,
                isSending = isSending,
                safeMode = safeMode,
                draft = draft,
                onDraftChange = onDraftChange
            )
        }
    }
}

@Composable
private fun WelcomeContent(onSuggestion: (String) -> Unit) {
    val suggestions = listOf(
        Triple(Icons.Outlined.Search, "ابحث في الويب", "اعثر على معلومات حديثة مع المصادر"),
        Triple(Icons.Outlined.Psychology, "حلّل بعمق", "فكّر في فكرة أو قرار خطوة بخطوة"),
        Triple(Icons.Outlined.Edit, "اكتب وصُغ", "رسائل، نصوص، أفكار ومحتوى"),
        Triple(Icons.Outlined.Build, "أنجز مهمة", "خطط، راجع، وبرمج بطريقة منظمة")
    )
    val prompts = listOf(
        "ابحث في الويب عن أهم الأخبار التقنية اليوم",
        "حلّل هذه الفكرة معي بعمق",
        "ساعدني في كتابة نص احترافي",
        "راجع مشروعي خطوة بخطوة"
    )

    Column(
        modifier = Modifier.fillMaxSize().padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        AionMark(size = 52.dp)
        Spacer(Modifier.height(16.dp))
        Text(
            "ما الذي نعمل عليه؟",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.ExtraBold,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(6.dp))
        Text(
            "فكّر، ابحث، أنشئ، أو اعمل على مشروعك مع AION.",
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
            style = MaterialTheme.typography.bodyMedium
        )
        Spacer(Modifier.height(24.dp))

        Column(
            modifier = Modifier.widthIn(max = 640.dp).fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(AionSpacing.Sm)
        ) {
            suggestions.chunked(2).forEachIndexed { rowIndex, rowItems ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(AionSpacing.Sm)
                ) {
                    rowItems.forEachIndexed { columnIndex, suggestion ->
                        val promptIndex = rowIndex * 2 + columnIndex
                        WelcomeSuggestionCard(
                            icon = suggestion.first,
                            title = suggestion.second,
                            subtitle = suggestion.third,
                            modifier = Modifier.weight(1f),
                            onClick = { onSuggestion(prompts[promptIndex]) }
                        )
                    }
                    if (rowItems.size == 1) Spacer(Modifier.weight(1f))
                }
            }
        }
    }
}

@Composable
private fun WelcomeSuggestionCard(
    icon: ImageVector,
    title: String,
    subtitle: String,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        modifier = modifier.defaultMinSize(minHeight = 112.dp),
        shape = RoundedCornerShape(AionRadii.Card),
        color = AionColors.Surface,
        border = BorderStroke(1.dp, AionColors.Border)
    ) {
        Column(
            modifier = Modifier.padding(horizontal = AionSpacing.Md, vertical = AionSpacing.Md),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Surface(
                shape = CircleShape,
                color = AionColors.Intelligence.copy(alpha = 0.12f),
                modifier = Modifier.size(34.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(icon, contentDescription = null, tint = AionColors.IntelligenceSoft, modifier = Modifier.size(AionSizes.SmallIcon))
                }
            }
            Spacer(Modifier.height(10.dp))
            Text(title, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(2.dp))
            Text(
                subtitle,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                style = MaterialTheme.typography.bodySmall,
                maxLines = 2
            )
        }
    }
}

private fun unreadMessagesLabel(count: Int): String = when (count) {
    1 -> "رسالة جديدة"
    2 -> "رسالتان جديدتان"
    in 3..10 -> "$count رسائل جديدة"
    else -> "$count رسالة جديدة"
}

@Composable
private fun MessagesList(
    messages: List<ChatMessage>,
    activity: GatewayActivity?,
    onSpeak: (String) -> Unit,
    onRetry: (Long) -> Unit,
    onEditMessage: (Long, String) -> Unit,
    onRememberMessage: (String) -> Unit,
    scrollToMessageId: Long?,
    onScrollTargetConsumed: (Long) -> Unit
) {
    val state = rememberLazyListState()
    val scope = rememberCoroutineScope()
    val lastText = messages.lastOrNull()?.text.orEmpty()
    val lastIsStreaming = messages.lastOrNull()?.isStreaming == true
    var autoFollow by remember { mutableStateOf(true) }
    var programmaticScroll by remember { mutableStateOf(false) }
    var previousCount by remember { mutableStateOf(messages.size) }
    var previousPosition by remember { mutableStateOf(0L) }
    var unreadWhilePaused by remember { mutableStateOf(0) }
    var highlightedMessageId by remember { mutableStateOf<Long?>(null) }

    val isNearBottom by remember {
        derivedStateOf {
            if (messages.isEmpty()) true
            else {
                val lastVisible = state.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: -1
                lastVisible >= messages.size // the dedicated bottom anchor is visible
            }
        }
    }

    suspend fun goToBottom(animated: Boolean) {
        if (messages.isEmpty()) return
        programmaticScroll = true
        try {
            val anchorIndex = messages.size
            if (animated) state.animateScrollToItem(anchorIndex)
            else state.scrollToItem(anchorIndex)
        } finally {
            programmaticScroll = false
        }
    }

    LaunchedEffect(messages.size) {
        val growth = (messages.size - previousCount).coerceAtLeast(0)
        val last = messages.lastOrNull()
        when {
            growth > 0 && last?.role == MessageRole.USER -> {
                autoFollow = true
                unreadWhilePaused = 0
                goToBottom(animated = true)
            }
            growth > 0 && autoFollow && last?.isStreaming == true -> goToBottom(animated = true)
            growth > 0 && !autoFollow -> unreadWhilePaused += growth
        }
        previousCount = messages.size
    }

    LaunchedEffect(lastText.length, autoFollow) {
        if (autoFollow && messages.isNotEmpty()) {
            unreadWhilePaused = 0
            goToBottom(animated = false)
        }
    }

    LaunchedEffect(state, messages.size) {
        snapshotFlow {
            val index = state.firstVisibleItemIndex
            val offset = state.firstVisibleItemScrollOffset
            val packed = index.toLong() * 1_000_000L + offset.toLong()
            Triple(state.isScrollInProgress, packed, isNearBottom)
        }.collect { (scrolling, position, nearBottom) ->
            if (!programmaticScroll) {
                if (nearBottom) {
                    autoFollow = true
                    unreadWhilePaused = 0
                } else if (scrolling && position < previousPosition) {
                    autoFollow = false
                }
            }
            previousPosition = position
        }
    }

    LaunchedEffect(scrollToMessageId, messages.size) {
        val targetId = scrollToMessageId ?: return@LaunchedEffect
        val targetIndex = messages.indexOfFirst { it.id == targetId }
        if (targetIndex >= 0) {
            autoFollow = false
            unreadWhilePaused = 0
            state.animateScrollToItem(targetIndex)
            highlightedMessageId = targetId
            onScrollTargetConsumed(targetId)
            delay(1_800L)
            if (highlightedMessageId == targetId) highlightedMessageId = null
        } else {
            onScrollTargetConsumed(targetId)
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        LazyColumn(
            state = state,
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(horizontal = AionLayout.ChatHorizontalPadding, vertical = AionLayout.ChatVerticalPadding),
            verticalArrangement = Arrangement.spacedBy(AionLayout.MessageSpacing)
        ) {
            itemsIndexed(messages, key = { _, message -> message.id }) { _, message ->
                Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.TopCenter) {
                    Surface(
                        modifier = Modifier.widthIn(max = AionSizes.ContentMaxWidth).fillMaxWidth(),
                        shape = RoundedCornerShape(AionRadii.Card),
                        color = if (highlightedMessageId == message.id) AionColors.External.copy(alpha = 0.08f) else Color.Transparent,
                        border = if (highlightedMessageId == message.id) BorderStroke(1.dp, AionColors.External.copy(alpha = 0.30f)) else null
                    ) {
                        MessageBubble(
                            message = message,
                            activity = activity,
                            onSpeak = onSpeak,
                            onRetry = onRetry,
                            onEditMessage = onEditMessage,
                            onRememberMessage = onRememberMessage
                        )
                    }
                }
            }
            // Dedicated anchor lets streaming follow the true bottom of a long answer instead
            // of repeatedly placing the beginning of the last message at the top of the viewport.
            item(key = "aion-chat-bottom-anchor") {
                Spacer(Modifier.height(1.dp))
            }
        }

        AnimatedVisibility(
            visible = !autoFollow && messages.isNotEmpty(),
            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = AionLayout.ScrollReturnBottomGap)
        ) {
            Surface(
                onClick = {
                    autoFollow = true
                    unreadWhilePaused = 0
                    scope.launch { goToBottom(animated = true) }
                },
                shape = CircleShape,
                color = AionColors.SurfaceSelected,
                border = BorderStroke(1.dp, AionColors.Intelligence.copy(alpha = 0.22f))
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Outlined.KeyboardArrowDown, contentDescription = null, modifier = Modifier.size(16.dp), tint = AionPurpleSoft)
                    Spacer(Modifier.width(5.dp))
                    Text(
                        when {
                            unreadWhilePaused > 0 -> unreadMessagesLabel(unreadWhilePaused)
                            lastIsStreaming -> "AION ما زال يكتب"
                            else -> "العودة لآخر رد"
                        },
                        style = MaterialTheme.typography.labelMedium,
                        color = AionColors.IntelligenceSoft,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun MessageBubble(
    message: ChatMessage,
    activity: GatewayActivity?,
    onSpeak: (String) -> Unit,
    onRetry: (Long) -> Unit,
    onEditMessage: (Long, String) -> Unit,
    onRememberMessage: (String) -> Unit
) {
    val isUser = message.role == MessageRole.USER
    val clipboard = LocalClipboardManager.current
    val context = LocalContext.current
    var actionsVisible by remember(message.id, message.isStreaming) { mutableStateOf(!isUser && !message.isStreaming) }
    var showSources by remember(message.id) { mutableStateOf(false) }
    var showEdit by remember(message.id) { mutableStateOf(false) }
    var editText by remember(message.id, message.text) { mutableStateOf(message.text) }
    var userExpanded by remember(message.id) { mutableStateOf(false) }
    val executionLabel = remember(
        message.executionProviderLabel,
        message.executionModelId,
        message.fallbackUsed
    ) {
        ProviderRoutingPolicy.displayLabel(
            providerLabel = message.executionProviderLabel,
            executionModelId = message.executionModelId,
            fallbackUsed = message.fallbackUsed
        )
    }
    val canCollapseUserText = isUser && message.text.length > 1_100
    val visibleUserText = if (canCollapseUserText && !userExpanded) {
        message.text.take(920).trimEnd() + "…"
    } else message.text

    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = if (isUser) Arrangement.Start else Arrangement.End,
            verticalAlignment = Alignment.Top
        ) {
            Column(modifier = Modifier.fillMaxWidth(if (isUser) AionLayout.UserBubbleMaxFraction else 1f)) {
                if (message.attachments.isNotEmpty()) {
                    MessageAttachmentRow(message.attachments, isUser)
                    if (message.text.isNotBlank()) Spacer(Modifier.height(6.dp))
                }

                val showLiveIndicator = !isUser && message.isStreaming && message.text.isBlank()
                if (showLiveIndicator) {
                    LiveThinkingIndicator(
                        modelLabel = message.modelLabel ?: "AION",
                        activity = activity ?: GatewayActivity.THINKING
                    )
                } else Surface(
                    modifier = if (isUser && !message.isStreaming) {
                        Modifier.clickable { actionsVisible = !actionsVisible }.animateContentSize()
                    } else Modifier.animateContentSize(),
                    shape = RoundedCornerShape(if (isUser) AionRadii.UserBubble else AionRadii.Card),
                    color = when {
                        isUser -> AionColors.SurfaceRaised
                        message.isError -> AionColors.Error.copy(alpha = 0.10f)
                        else -> Color.Transparent
                    }
                ) {
                    Column {
                        if (message.text.isNotBlank()) {
                            if (isUser) {
                                Column {
                                    RichMessageText(
                                        text = visibleUserText,
                                        modifier = Modifier.padding(
                                            start = AionLayout.UserBubbleHorizontalPadding,
                                            end = AionLayout.UserBubbleHorizontalPadding,
                                            top = AionLayout.UserBubbleVerticalPadding,
                                            bottom = if (canCollapseUserText) AionSpacing.Xs else AionLayout.UserBubbleVerticalPadding
                                        ),
                                        color = if (message.isError) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface
                                    )
                                    if (canCollapseUserText) {
                                        TextButton(
                                            onClick = { userExpanded = !userExpanded },
                                            modifier = Modifier.padding(horizontal = 6.dp)
                                        ) {
                                            Text(
                                                if (userExpanded) "عرض أقل" else "عرض المزيد",
                                                style = MaterialTheme.typography.labelMedium,
                                                color = AionColors.IntelligenceSoft
                                            )
                                        }
                                    }
                                }
                            } else {
                                SelectionContainer {
                                    RichMessageText(
                                        text = message.text,
                                        modifier = Modifier.padding(
                                            horizontal = if (message.isError) AionLayout.UserBubbleHorizontalPadding else AionLayout.AssistantTextEdgePadding,
                                            vertical = if (message.isError) AionLayout.UserBubbleVerticalPadding else AionLayout.AssistantTextEdgePadding
                                        ),
                                        color = if (message.isError) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface,
                                        sources = message.sources
                                    )
                                }
                            }
                        }
                    }
                }

                if (!isUser && message.sources.isNotEmpty() && !message.isStreaming) {
                    Spacer(Modifier.height(AionSpacing.Sm))
                    SourceSummaryChips(
                        sources = message.sources,
                        onClick = { showSources = true }
                    )
                }

                if (!isUser && !message.isStreaming && !message.isError && executionLabel.isNotBlank()) {
                    Spacer(Modifier.height(6.dp))
                    Surface(
                        shape = CircleShape,
                        color = AionColors.SurfaceMuted,
                        border = BorderStroke(1.dp, AionColors.Border)
                    ) {
                        Text(
                            executionLabel,
                            modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                if (!isUser && message.wasStopped) {
                    Surface(
                        modifier = Modifier.padding(top = 7.dp),
                        shape = CircleShape,
                        color = AionColors.SurfaceMuted,
                        border = BorderStroke(1.dp, AionColors.Border)
                    ) {
                        Text(
                            "تم إيقاف الرد",
                            modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp),
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                AnimatedVisibility(visible = !message.isStreaming && actionsVisible) {
                    if (isUser) {
                        Row(
                            modifier = Modifier.padding(top = 5.dp),
                            horizontalArrangement = Arrangement.spacedBy(2.dp)
                        ) {
                            SmallAction(
                                icon = Icons.Outlined.ContentCopy,
                                description = "نسخ",
                                onClick = { clipboard.setText(AnnotatedString(message.text)) }
                            )
                            SmallAction(
                                icon = Icons.Outlined.Edit,
                                description = "تعديل",
                                onClick = {
                                    editText = message.text
                                    showEdit = true
                                }
                            )
                            if (message.text.isNotBlank()) {
                                SmallAction(
                                    icon = Icons.Outlined.Memory,
                                    description = "حفظ في الذاكرة",
                                    onClick = {
                                        onRememberMessage(message.text)
                                        Toast.makeText(context, "تمت إضافتها إلى ذاكرة AION المحلية.", Toast.LENGTH_SHORT).show()
                                    }
                                )
                            }
                        }
                    } else {
                        ResponseActions(
                            isError = message.isError,
                            onCopy = { clipboard.setText(AnnotatedString(message.text)) },
                            onSpeak = { onSpeak(message.text) },
                            onRetry = { onRetry(message.id) },
                            onShare = {
                                val shareText = buildString {
                                    append(message.text)
                                    if (message.sources.isNotEmpty()) {
                                        append("\n\nالمصادر:\n")
                                        message.sources.forEachIndexed { index, source ->
                                            append(index + 1).append(". ").append(source.title).append("\n")
                                            append(source.url).append("\n")
                                        }
                                    }
                                }.trim()
                                runCatching {
                                    context.startActivity(
                                        Intent.createChooser(
                                            Intent(Intent.ACTION_SEND).apply {
                                                type = "text/plain"
                                                putExtra(Intent.EXTRA_TEXT, shareText)
                                            },
                                            "مشاركة رد AION"
                                        )
                                    )
                                }
                            }
                        )
                    }
                }
            }
        }
    }

    if (showEdit) {
        AlertDialog(
            onDismissRequest = { showEdit = false },
            title = { Text("تعديل الرسالة") },
            text = {
                OutlinedTextField(
                    value = editText,
                    onValueChange = { editText = it },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 3,
                    maxLines = 10
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        val clean = editText.trim()
                        if (clean.isNotBlank() || message.attachments.isNotEmpty()) {
                            showEdit = false
                            onEditMessage(message.id, clean)
                        }
                    }
                ) { Text("حفظ وإعادة الإرسال") }
            },
            dismissButton = {
                TextButton(onClick = { showEdit = false }) { Text("إلغاء") }
            }
        )
    }

    if (showSources) {
        SourcesSheet(
            sources = message.sources,
            onOpen = { source ->
                val uri = runCatching { Uri.parse(source.url) }.getOrNull()
                if (uri?.scheme.equals("https", ignoreCase = true) || uri?.scheme.equals("http", ignoreCase = true)) {
                    runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, uri)) }
                }
            },
            onDismiss = { showSources = false }
        )
    }
}

private fun inlineMarkdown(text: String, color: Color): AnnotatedString = buildAnnotatedString {
    var index = 0
    while (index < text.length) {
        when {
            text.startsWith("**", index) || text.startsWith("__", index) -> {
                val marker = text.substring(index, index + 2)
                val end = text.indexOf(marker, index + 2)
                if (end > index + 2) {
                    withStyle(SpanStyle(fontWeight = FontWeight.Bold, color = color)) {
                        append(text.substring(index + 2, end))
                    }
                    index = end + 2
                } else {
                    append(text[index])
                    index++
                }
            }
            text.startsWith("~~", index) -> {
                val end = text.indexOf("~~", index + 2)
                if (end > index + 2) {
                    withStyle(
                        SpanStyle(
                            color = AionColors.TextTertiary,
                            textDecoration = TextDecoration.LineThrough
                        )
                    ) {
                        append(text.substring(index + 2, end))
                    }
                    index = end + 2
                } else {
                    append(text[index])
                    index++
                }
            }
            text[index] == '`' -> {
                val end = text.indexOf('`', index + 1)
                if (end > index + 1) {
                    withStyle(
                        SpanStyle(
                            fontFamily = FontFamily.Monospace,
                            color = AionColors.IntelligenceSoft,
                            background = AionColors.SurfaceSelected
                        )
                    ) {
                        append(text.substring(index + 1, end))
                    }
                    index = end + 1
                } else {
                    append(text[index])
                    index++
                }
            }
            text[index] == '*' || text[index] == '_' -> {
                val marker = text[index]
                val end = text.indexOf(marker, index + 1)
                if (end > index + 1 && !text.substring(index + 1, end).contains('\n')) {
                    withStyle(SpanStyle(fontStyle = FontStyle.Italic, color = color)) {
                        append(text.substring(index + 1, end))
                    }
                    index = end + 1
                } else {
                    append(text[index])
                    index++
                }
            }
            text[index] == '[' -> {
                val citationEnd = text.indexOf(']', index + 1)
                val citationNumber = if (citationEnd > index + 1) {
                    text.substring(index + 1, citationEnd).toIntOrNull()
                } else null
                if (citationNumber != null && citationNumber in 1..99) {
                    val start = length
                    withStyle(
                        SpanStyle(
                            color = AionColors.ExternalSoft,
                            fontWeight = FontWeight.SemiBold
                        )
                    ) {
                        append(text.substring(index, citationEnd + 1))
                    }
                    addStringAnnotation(
                        tag = "AION_SOURCE",
                        annotation = citationNumber.toString(),
                        start = start,
                        end = length
                    )
                    index = citationEnd + 1
                } else {
                    val closeLabel = citationEnd
                    val openUrl = if (closeLabel > index) text.getOrNull(closeLabel + 1) else null
                    val closeUrl = if (openUrl == '(') text.indexOf(')', closeLabel + 2) else -1
                    if (closeLabel > index + 1 && openUrl == '(' && closeUrl > closeLabel + 2) {
                        val start = length
                        withStyle(
                            SpanStyle(
                                color = AionColors.ExternalSoft,
                                textDecoration = TextDecoration.Underline,
                                fontWeight = FontWeight.Medium
                            )
                        ) {
                            append(text.substring(index + 1, closeLabel))
                        }
                        val url = text.substring(closeLabel + 2, closeUrl)
                        addStringAnnotation(
                            tag = "AION_URL",
                            annotation = url,
                            start = start,
                            end = length
                        )
                        index = closeUrl + 1
                    } else {
                        append(text[index])
                        index++
                    }
                }
            }
            else -> {
                append(text[index])
                index++
            }
        }
    }
}

@Composable
private fun InlineMarkdownText(
    text: String,
    color: Color,
    style: androidx.compose.ui.text.TextStyle,
    modifier: Modifier = Modifier,
    fontWeight: FontWeight? = null,
    sources: List<ChatSource> = emptyList()
) {
    val context = LocalContext.current
    val annotated = remember(text, color) { inlineMarkdown(text, color) }
    val resolvedStyle = style.copy(color = color, fontWeight = fontWeight ?: style.fontWeight)
    val directLinks = remember(annotated) {
        annotated.getStringAnnotations("AION_URL", 0, annotated.length)
    }
    val sourceLinks = remember(annotated, sources.size) {
        annotated.getStringAnnotations("AION_SOURCE", 0, annotated.length)
            .filter { item -> item.item.toIntOrNull()?.let { it in 1..sources.size } == true }
    }

    if (directLinks.isEmpty() && sourceLinks.isEmpty()) {
        Text(text = annotated, modifier = modifier, style = resolvedStyle)
    } else {
        androidx.compose.foundation.text.ClickableText(
            text = annotated,
            modifier = modifier,
            style = resolvedStyle,
            onClick = { offset ->
                val citation = annotated
                    .getStringAnnotations("AION_SOURCE", offset, offset)
                    .firstOrNull()
                    ?.item
                    ?.toIntOrNull()
                val citationUrl = citation
                    ?.takeIf { it in 1..sources.size }
                    ?.let { sources[it - 1].url }
                val directUrl = annotated
                    .getStringAnnotations("AION_URL", offset, offset)
                    .firstOrNull()
                    ?.item
                val target = citationUrl ?: directUrl
                if (!target.isNullOrBlank()) {
                    val uri = runCatching { Uri.parse(target) }.getOrNull()
                    if (uri?.scheme.equals("https", ignoreCase = true) || uri?.scheme.equals("http", ignoreCase = true)) {
                        runCatching {
                            context.startActivity(Intent(Intent.ACTION_VIEW, uri))
                        }
                    }
                }
            }
        )
    }
}

@Composable
private fun MarkdownTextBlocks(text: String, color: Color, sources: List<ChatSource> = emptyList()) {
    val blocks = remember(text) { MarkdownRenderPolicy.parseBlocks(text) }
    Column(verticalArrangement = Arrangement.spacedBy(AionSpacing.Sm)) {
        blocks.forEach { block ->
            when (block.kind) {
                MarkdownBlockKind.PARAGRAPH -> InlineMarkdownText(
                    text = block.text,
                    color = color,
                    style = MaterialTheme.typography.bodyLarge,
                    sources = sources
                )

                MarkdownBlockKind.HEADING -> InlineMarkdownText(
                    text = block.text,
                    color = color,
                    style = when (block.level) {
                        1 -> MaterialTheme.typography.titleLarge
                        2 -> MaterialTheme.typography.titleMedium
                        else -> MaterialTheme.typography.titleSmall
                    },
                    fontWeight = FontWeight.Bold,
                    sources = sources
                )

                MarkdownBlockKind.BULLET -> Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.Top
                ) {
                    Text(
                        "•",
                        modifier = Modifier.width(20.dp),
                        style = MaterialTheme.typography.bodyLarge,
                        color = AionColors.IntelligenceSoft
                    )
                    InlineMarkdownText(
                        text = block.text,
                        color = color,
                        style = MaterialTheme.typography.bodyLarge,
                        modifier = Modifier.weight(1f),
                        sources = sources
                    )
                }

                MarkdownBlockKind.NUMBERED -> Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.Top
                ) {
                    Text(
                        "${block.level}.",
                        modifier = Modifier.width(32.dp),
                        style = MaterialTheme.typography.bodyMedium,
                        color = AionColors.IntelligenceSoft,
                        fontWeight = FontWeight.SemiBold
                    )
                    InlineMarkdownText(
                        text = block.text,
                        color = color,
                        style = MaterialTheme.typography.bodyLarge,
                        modifier = Modifier.weight(1f),
                        sources = sources
                    )
                }

                MarkdownBlockKind.QUOTE -> Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(IntrinsicSize.Min)
                        .clip(RoundedCornerShape(AionRadii.Card))
                        .background(AionColors.Surface)
                ) {
                    Box(
                        Modifier
                            .width(3.dp)
                            .fillMaxHeight()
                            .background(AionColors.Intelligence.copy(alpha = 0.72f))
                    )
                    InlineMarkdownText(
                        text = block.text,
                        color = AionColors.TextSecondary,
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier
                            .weight(1f)
                            .padding(horizontal = AionSpacing.Md, vertical = AionSpacing.Sm),
                        sources = sources
                    )
                }

                MarkdownBlockKind.TABLE -> {
                    val tableScroll = rememberScrollState()
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(AionRadii.Card),
                        color = AionColors.Surface,
                        border = BorderStroke(1.dp, AionColors.Border)
                    ) {
                        Row(modifier = Modifier.horizontalScroll(tableScroll)) {
                            val columnCount = block.rows.maxOfOrNull { it.size } ?: 0
                            repeat(columnCount) { columnIndex ->
                                val width = MarkdownRenderPolicy.tableColumnWidthDp(block.rows, columnIndex).dp
                                Column(modifier = Modifier.width(width)) {
                                    block.rows.forEachIndexed { rowIndex, row ->
                                        val cell = row.getOrNull(columnIndex).orEmpty()
                                        Surface(
                                            color = if (rowIndex == 0) {
                                                AionColors.SurfaceRaised
                                            } else if (rowIndex % 2 == 0) {
                                                AionColors.SurfaceMuted.copy(alpha = 0.42f)
                                            } else {
                                                Color.Transparent
                                            },
                                            border = BorderStroke(0.5.dp, AionColors.Border)
                                        ) {
                                            InlineMarkdownText(
                                                text = cell,
                                                color = if (rowIndex == 0) AionColors.TextPrimary else AionColors.TextSecondary,
                                                style = MaterialTheme.typography.bodySmall.copy(
                                                    fontSize = 13.sp,
                                                    lineHeight = 20.sp
                                                ),
                                                fontWeight = if (rowIndex == 0) FontWeight.SemiBold else null,
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .padding(horizontal = AionSpacing.Sm, vertical = AionSpacing.Sm),
                                                sources = sources
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                MarkdownBlockKind.DIVIDER -> HorizontalDivider(
                    modifier = Modifier.padding(vertical = AionSpacing.Xs),
                    color = AionColors.Border
                )
            }
        }
    }
}

@Composable
private fun RichMessageText(text: String, modifier: Modifier = Modifier, color: Color, sources: List<ChatSource> = emptyList()) {
    val clipboard = LocalClipboardManager.current
    val scope = rememberCoroutineScope()
    val segments = remember(text) { MarkdownRenderPolicy.splitSegments(text) }
    var copiedCodeIndex by remember(text) { mutableStateOf<Int?>(null) }
    val expandedCode = remember(text) { mutableStateOf(setOf<Int>()) }

    Column(modifier = modifier, verticalArrangement = Arrangement.spacedBy(AionSpacing.Sm)) {
        segments.forEachIndexed { segmentIndex, segment ->
            if (!segment.code) {
                if (segment.text.isNotBlank()) MarkdownTextBlocks(segment.text, color, sources)
            } else {
                val canCollapse = remember(segment.text) { MarkdownRenderPolicy.shouldCollapseCode(segment.text) }
                val isExpanded = segmentIndex in expandedCode.value
                val visibleCode = if (canCollapse && !isExpanded) {
                    MarkdownRenderPolicy.collapsedCode(segment.text)
                } else {
                    segment.text
                }
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(AionRadii.Card),
                    color = AionColors.Surface,
                    border = BorderStroke(1.dp, AionColors.Border)
                ) {
                    Column {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(start = AionSpacing.Md, end = AionSpacing.Xs, top = AionSpacing.Xs),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    Icons.Outlined.Code,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp),
                                    tint = AionColors.IntelligenceSoft
                                )
                                Spacer(Modifier.width(AionSpacing.Xs))
                                Text(
                                    MarkdownRenderPolicy.normalizeLanguageLabel(segment.language),
                                    style = MaterialTheme.typography.labelMedium,
                                    color = AionColors.TextSecondary,
                                    fontWeight = FontWeight.SemiBold
                                )
                                val lineCount = segment.text.lineSequence().count()
                                if (lineCount > 1) {
                                    Text(
                                        " · $lineCount سطر",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = AionColors.TextTertiary
                                    )
                                }
                                if (!segment.fenceClosed) {
                                    Text(
                                        " · جارٍ الإكمال",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = AionColors.IntelligenceSoft
                                    )
                                }
                            }
                            IconButton(
                                onClick = {
                                    clipboard.setText(AnnotatedString(segment.text))
                                    copiedCodeIndex = segmentIndex
                                    scope.launch {
                                        delay(1_200)
                                        if (copiedCodeIndex == segmentIndex) copiedCodeIndex = null
                                    }
                                },
                                modifier = Modifier.size(AionSizes.TouchTarget)
                            ) {
                                Icon(
                                    if (copiedCodeIndex == segmentIndex) Icons.Outlined.Check else Icons.Outlined.ContentCopy,
                                    contentDescription = if (copiedCodeIndex == segmentIndex) "تم نسخ الكود" else "نسخ الكود",
                                    modifier = Modifier.size(AionSizes.SmallIcon),
                                    tint = if (copiedCodeIndex == segmentIndex) AionColors.Success else AionColors.TextTertiary
                                )
                            }
                        }

                        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                            Text(
                                visibleCode,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .horizontalScroll(rememberScrollState())
                                    .padding(
                                        start = AionSpacing.Md,
                                        end = AionSpacing.Md,
                                        bottom = if (canCollapse) AionSpacing.Xs else AionSpacing.Md
                                    ),
                                fontFamily = FontFamily.Monospace,
                                fontSize = 13.sp,
                                lineHeight = 20.sp,
                                color = AionColors.TextPrimary,
                                textAlign = TextAlign.Start
                            )
                        }

                        if (canCollapse) {
                            TextButton(
                                onClick = {
                                    expandedCode.value = if (isExpanded) {
                                        expandedCode.value - segmentIndex
                                    } else {
                                        expandedCode.value + segmentIndex
                                    }
                                },
                                modifier = Modifier.padding(horizontal = AionSpacing.Xs)
                            ) {
                                Text(
                                    if (isExpanded) "طي الكود" else "عرض الكود كاملًا",
                                    color = AionColors.IntelligenceSoft,
                                    style = MaterialTheme.typography.labelMedium
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun rememberAttachmentPreview(attachment: ChatAttachment): Bitmap? {
    val bitmap by produceState<Bitmap?>(
        initialValue = null,
        key1 = attachment.localPath,
        key2 = attachment.base64Data
    ) {
        value = withContext(Dispatchers.IO) { decodeAttachmentPreview(attachment, 720, 540) }
    }
    return bitmap
}

@Composable
private fun rememberPdfPageCount(attachment: ChatAttachment): Int? {
    val pages by produceState<Int?>(
        initialValue = null,
        key1 = attachment.localPath,
        key2 = attachment.name,
        key3 = attachment.mimeType
    ) {
        if (!AttachmentPresentationPolicy.isPdf(attachment.name, attachment.mimeType)) {
            value = null
            return@produceState
        }
        value = withContext(Dispatchers.IO) {
            runCatching {
                val path = attachment.localPath.takeIf { it.isNotBlank() } ?: return@runCatching null
                val file = File(path)
                if (!file.isFile) return@runCatching null
                ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY).use { descriptor ->
                    PdfRenderer(descriptor).use { renderer -> renderer.pageCount }
                }
            }.getOrNull()
        }
    }
    return pages
}

private fun decodeAttachmentPreview(
    attachment: ChatAttachment,
    requestedWidth: Int,
    requestedHeight: Int
): Bitmap? = runCatching {
    val path = attachment.localPath.takeIf { it.isNotBlank() && File(it).isFile }
    if (path != null) {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(path, bounds)
        val options = BitmapFactory.Options().apply {
            inSampleSize = calculateImageSample(
                bounds.outWidth,
                bounds.outHeight,
                requestedWidth,
                requestedHeight
            )
        }
        val decoded = BitmapFactory.decodeFile(path, options)
        return@runCatching decoded?.let { applyExifOrientation(path, it) }
    }

    if (attachment.base64Data.isBlank()) return@runCatching null
    val bytes = Base64.decode(attachment.base64Data, Base64.DEFAULT)
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
    val options = BitmapFactory.Options().apply {
        inSampleSize = calculateImageSample(
            bounds.outWidth,
            bounds.outHeight,
            requestedWidth,
            requestedHeight
        )
    }
    BitmapFactory.decodeByteArray(bytes, 0, bytes.size, options)
}.getOrNull()

@Suppress("DEPRECATION")
private fun applyExifOrientation(path: String, bitmap: Bitmap): Bitmap {
    val orientation = runCatching {
        android.media.ExifInterface(path).getAttributeInt(
            android.media.ExifInterface.TAG_ORIENTATION,
            android.media.ExifInterface.ORIENTATION_NORMAL
        )
    }.getOrDefault(android.media.ExifInterface.ORIENTATION_NORMAL)

    val matrix = Matrix()
    when (orientation) {
        android.media.ExifInterface.ORIENTATION_ROTATE_90 -> matrix.postRotate(90f)
        android.media.ExifInterface.ORIENTATION_ROTATE_180 -> matrix.postRotate(180f)
        android.media.ExifInterface.ORIENTATION_ROTATE_270 -> matrix.postRotate(270f)
        android.media.ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> matrix.preScale(-1f, 1f)
        android.media.ExifInterface.ORIENTATION_FLIP_VERTICAL -> matrix.preScale(1f, -1f)
        android.media.ExifInterface.ORIENTATION_TRANSPOSE -> {
            matrix.preScale(-1f, 1f)
            matrix.postRotate(270f)
        }
        android.media.ExifInterface.ORIENTATION_TRANSVERSE -> {
            matrix.preScale(-1f, 1f)
            matrix.postRotate(90f)
        }
        else -> return bitmap
    }

    return runCatching {
        Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
            .also { rotated -> if (rotated !== bitmap) bitmap.recycle() }
    }.getOrDefault(bitmap)
}

private fun calculateImageSample(
    width: Int,
    height: Int,
    requestedWidth: Int,
    requestedHeight: Int
): Int {
    if (width <= 0 || height <= 0) return 1
    var sample = 1
    while (width / (sample * 2) >= requestedWidth && height / (sample * 2) >= requestedHeight) {
        sample *= 2
    }
    return sample.coerceAtLeast(1)
}

private fun openAttachmentExternally(context: android.content.Context, attachment: ChatAttachment): Boolean {
    val path = attachment.localPath.takeIf { it.isNotBlank() } ?: return false
    val file = File(path)
    if (!file.isFile) return false
    return runCatching {
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.files", file)
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, attachment.mimeType.ifBlank { "application/octet-stream" })
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(intent)
        true
    }.getOrDefault(false)
}

private fun attachmentIcon(attachment: ChatAttachment): ImageVector {
    val type = AttachmentPresentationPolicy.typeLabel(attachment.name, attachment.mimeType)
    return when {
        attachment.kind == AttachmentKind.IMAGE -> Icons.Outlined.Image
        AttachmentPresentationPolicy.isPdf(attachment.name, attachment.mimeType) -> Icons.Outlined.PictureAsPdf
        type == "كود" -> Icons.Outlined.Code
        type == "جدول" -> Icons.Outlined.TableChart
        else -> Icons.Outlined.Description
    }
}

@Composable
private fun MessageAttachmentRow(attachments: List<ChatAttachment>, isUser: Boolean) {
    var previewAttachment by remember { mutableStateOf<ChatAttachment?>(null) }

    if (attachments.size == 1) {
        MessageAttachmentItem(
            attachment = attachments.first(),
            isUser = isUser,
            onPreview = { previewAttachment = it }
        )
    } else {
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(AionSpacing.Sm),
            contentPadding = PaddingValues(end = AionSpacing.Xs)
        ) {
            items(attachments, key = { it.id }) { attachment ->
                MessageAttachmentItem(
                    attachment = attachment,
                    isUser = isUser,
                    onPreview = { previewAttachment = it }
                )
            }
        }
    }

    previewAttachment?.let { attachment ->
        val bitmap = rememberAttachmentPreview(attachment)
        if (bitmap != null) {
            var zoom by remember(attachment.id) { mutableFloatStateOf(1f) }
            var panX by remember(attachment.id) { mutableFloatStateOf(0f) }
            var panY by remember(attachment.id) { mutableFloatStateOf(0f) }
            val transformState = rememberTransformableState { zoomChange, panChange, _ ->
                val nextZoom = (zoom * zoomChange).coerceIn(1f, 5f)
                zoom = nextZoom
                if (nextZoom <= 1.01f) {
                    panX = 0f
                    panY = 0f
                } else {
                    panX += panChange.x
                    panY += panChange.y
                }
            }

            Dialog(
                onDismissRequest = { previewAttachment = null },
                properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false)
            ) {
                Surface(modifier = Modifier.fillMaxSize(), color = Color.Black) {
                    Box(modifier = Modifier.fillMaxSize()) {
                        Image(
                            bitmap = bitmap.asImageBitmap(),
                            contentDescription = attachment.name,
                            modifier = Modifier
                                .fillMaxSize()
                                .pointerInput(attachment.id) {
                                    detectTapGestures(
                                        onDoubleTap = {
                                            if (zoom > 1.01f) {
                                                zoom = 1f
                                                panX = 0f
                                                panY = 0f
                                            } else {
                                                zoom = 2.5f
                                            }
                                        }
                                    )
                                }
                                .graphicsLayer {
                                    scaleX = zoom
                                    scaleY = zoom
                                    translationX = panX
                                    translationY = panY
                                }
                                .transformable(transformState)
                                .padding(horizontal = AionSpacing.Sm, vertical = 64.dp),
                            contentScale = ContentScale.Fit
                        )

                        Surface(
                            onClick = { previewAttachment = null },
                            shape = CircleShape,
                            color = AionColors.SurfaceRaised.copy(alpha = 0.92f),
                            border = BorderStroke(1.dp, AionColors.Border),
                            modifier = Modifier
                                .align(Alignment.TopEnd)
                                .padding(AionSpacing.Lg)
                                .size(AionSizes.TouchTarget)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    Icons.Outlined.Close,
                                    contentDescription = "إغلاق الصورة",
                                    modifier = Modifier.size(AionSizes.SmallIcon)
                                )
                            }
                        }

                        Surface(
                            shape = RoundedCornerShape(AionRadii.Chip),
                            color = AionColors.SurfaceRaised.copy(alpha = 0.92f),
                            modifier = Modifier
                                .align(Alignment.BottomCenter)
                                .padding(bottom = AionSpacing.Xxl)
                        ) {
                            Column(
                                modifier = Modifier.padding(
                                    horizontal = AionSpacing.Md,
                                    vertical = AionSpacing.Sm
                                ),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    attachment.name,
                                    style = MaterialTheme.typography.labelMedium,
                                    color = AionColors.TextPrimary,
                                    maxLines = 1
                                )
                                Text(
                                    "${AttachmentPresentationPolicy.formatSize(attachment.sizeBytes)} · انقر مرتين للتكبير",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = AionColors.TextTertiary,
                                    maxLines = 1
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun MessageAttachmentItem(
    attachment: ChatAttachment,
    isUser: Boolean,
    onPreview: (ChatAttachment) -> Unit
) {
    if (attachment.kind == AttachmentKind.IMAGE) {
        val bitmap = rememberAttachmentPreview(attachment)
        if (bitmap != null) {
            Surface(
                onClick = { onPreview(attachment) },
                modifier = Modifier
                    .widthIn(min = AionSizes.AttachmentCardMinWidth, max = AionSizes.AttachmentCardMaxWidth)
                    .height(AionSizes.AttachmentImageHeight),
                shape = RoundedCornerShape(AionRadii.Attachment),
                color = if (isUser) {
                    AionColors.Intelligence.copy(alpha = 0.11f)
                } else {
                    AionColors.SurfaceRaised
                },
                border = BorderStroke(1.dp, AionColors.Border)
            ) {
                Box {
                    Image(
                        bitmap = bitmap.asImageBitmap(),
                        contentDescription = attachment.name,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                    Surface(
                        shape = RoundedCornerShape(AionRadii.Chip),
                        color = Color.Black.copy(alpha = 0.58f),
                        modifier = Modifier
                            .align(Alignment.BottomStart)
                            .padding(AionSpacing.Sm)
                    ) {
                        Text(
                            AttachmentPresentationPolicy.formatSize(attachment.sizeBytes),
                            modifier = Modifier.padding(horizontal = 7.dp, vertical = 4.dp),
                            color = Color.White,
                            style = MaterialTheme.typography.labelSmall
                        )
                    }
                }
            }
        } else {
            CompactAttachmentCard(attachment, isUser)
        }
    } else {
        CompactAttachmentCard(attachment, isUser)
    }
}

@Composable
private fun CompactAttachmentCard(attachment: ChatAttachment, isUser: Boolean) {
    val context = LocalContext.current
    val pdfPages = rememberPdfPageCount(attachment)
    val accent = AionColors.ExternalSoft
    Surface(
        onClick = {
            if (!openAttachmentExternally(context, attachment)) {
                Toast.makeText(context, "لا يوجد تطبيق متوافق لفتح هذا الملف.", Toast.LENGTH_SHORT).show()
            }
        },
        shape = RoundedCornerShape(AionRadii.Card),
        color = if (isUser) {
            AionColors.Intelligence.copy(alpha = 0.08f)
        } else {
            AionColors.SurfaceRaised
        },
        border = BorderStroke(1.dp, AionColors.Border),
        modifier = Modifier.widthIn(min = AionSizes.AttachmentCardMinWidth, max = AionSizes.AttachmentCardMaxWidth)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = AionSpacing.Md, vertical = AionSpacing.Sm),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = accent.copy(alpha = 0.12f),
                modifier = Modifier.size(AionSizes.AttachmentIconBox)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        attachmentIcon(attachment),
                        contentDescription = null,
                        tint = accent,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
            Spacer(Modifier.width(AionSpacing.Sm))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    attachment.name,
                    style = MaterialTheme.typography.labelLarge,
                    color = AionColors.TextPrimary,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(Modifier.height(2.dp))
                Text(
                    AttachmentPresentationPolicy.secondaryLabel(
                        name = attachment.name,
                        mimeType = attachment.mimeType,
                        sizeBytes = attachment.sizeBytes,
                        pdfPages = pdfPages
                    ),
                    style = MaterialTheme.typography.bodySmall,
                    color = AionColors.TextTertiary,
                    maxLines = 1
                )
            }
        }
    }
}

private fun sourceHost(url: String): String = runCatching {
    Uri.parse(url).host?.removePrefix("www.").orEmpty()
}.getOrDefault("")

@Composable
private fun SourceSummaryChips(
    sources: List<ChatSource>,
    onClick: () -> Unit
) {
    val hosts = remember(sources) {
        sources.map { sourceHost(it.url) }.filter { it.isNotBlank() }.distinct()
    }
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState()),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(AionSpacing.Xs)
    ) {
        Text(
            "المصادر",
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        val visible = hosts.take(3)
        visible.forEach { host ->
            Surface(
                onClick = onClick,
                shape = RoundedCornerShape(AionRadii.Chip),
                color = AionColors.External.copy(alpha = 0.09f),
                border = BorderStroke(1.dp, AionColors.External.copy(alpha = 0.18f))
            ) {
                Text(
                    host,
                    modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp),
                    style = MaterialTheme.typography.labelMedium,
                    color = AionColors.ExternalSoft,
                    maxLines = 1
                )
            }
        }
        val hiddenCount = (hosts.size - visible.size).coerceAtLeast(0)
        if (hiddenCount > 0 || (hosts.isEmpty() && sources.size > 0)) {
            Surface(
                onClick = onClick,
                shape = RoundedCornerShape(AionRadii.Chip),
                color = AionColors.Surface,
                border = BorderStroke(1.dp, AionColors.Border)
            ) {
                Text(
                    if (hiddenCount > 0) "+$hiddenCount" else "${sources.size}",
                    modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp),
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun ResponseActions(
    isError: Boolean,
    onCopy: () -> Unit,
    onSpeak: () -> Unit,
    onRetry: () -> Unit,
    onShare: () -> Unit
) {
    var moreExpanded by remember { mutableStateOf(false) }
    var copied by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    Row(
        modifier = Modifier.padding(top = AionSpacing.Xs),
        horizontalArrangement = Arrangement.spacedBy(0.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        SmallAction(
            icon = if (copied) Icons.Outlined.Check else Icons.Outlined.ContentCopy,
            description = if (copied) "تم النسخ" else "نسخ",
            tint = if (copied) AionColors.Success else null,
            onClick = {
                onCopy()
                copied = true
                scope.launch {
                    delay(1_200)
                    copied = false
                }
            }
        )
        if (!isError) SmallAction(icon = Icons.Outlined.VolumeUp, description = "استماع", onClick = onSpeak)
        if (isError) SmallAction(icon = Icons.Outlined.Refresh, description = "إعادة المحاولة", onClick = onRetry)
        Box {
            SmallAction(Icons.Outlined.MoreHoriz, "المزيد") { moreExpanded = true }
            DropdownMenu(expanded = moreExpanded, onDismissRequest = { moreExpanded = false }) {
                if (!isError) {
                    DropdownMenuItem(
                        text = { Text("إعادة التوليد") },
                        leadingIcon = { Icon(Icons.Outlined.Refresh, contentDescription = null) },
                        onClick = { moreExpanded = false; onRetry() }
                    )
                    DropdownMenuItem(
                        text = { Text("مشاركة") },
                        leadingIcon = { Icon(Icons.Outlined.Share, contentDescription = null) },
                        onClick = { moreExpanded = false; onShare() }
                    )
                }
            }
        }
    }
}

@Composable
private fun SmallAction(
    icon: ImageVector,
    description: String,
    tint: Color? = null,
    onClick: () -> Unit
) {
    IconButton(onClick = onClick, modifier = Modifier.size(AionSizes.TouchTarget)) {
        Icon(
            icon,
            contentDescription = description,
            modifier = Modifier.size(AionSizes.SmallIcon),
            tint = tint ?: AionColors.TextTertiary
        )
    }
}

@Composable
private fun LiveThinkingIndicator(modelLabel: String, activity: GatewayActivity) {
    // modelLabel remains in the signature for compatibility with the message renderer,
    // but α7.3 deliberately prioritizes the observable action over model branding.
    @Suppress("UNUSED_VARIABLE") val ignoredModelLabel = modelLabel
    AionActivityIndicator(
        state = activity.toAionActivityState(),
        modifier = Modifier.padding(horizontal = 2.dp, vertical = AionSpacing.Sm)
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ChatComposer(
    onSend: (String) -> Unit,
    onModeShortcut: (String) -> Unit,
    onStartVoiceCall: () -> Unit,
    onStop: () -> Unit,
    onAddAttachments: (List<ChatAttachment>) -> Unit,
    onRemoveAttachment: (Long) -> Unit,
    pendingAttachments: List<ChatAttachment>,
    selectedModel: AiModelOption,
    activeProjectName: String?,
    isConfigured: Boolean,
    isSending: Boolean,
    safeMode: Boolean,
    draft: String,
    onDraftChange: (String) -> Unit
) {
    val context = LocalContext.current
    val hapticView = LocalView.current
    val scope = rememberCoroutineScope()
    var showAttachSheet by remember { mutableStateOf(false) }
    var isListening by remember { mutableStateOf(false) }
    var inputFocused by remember { mutableStateOf(false) }
    var rms by remember { mutableFloatStateOf(0f) }
    var voiceBase by remember { mutableStateOf("") }
    var liveTranscript by remember { mutableStateOf("") }

    val speechRecognizer = remember(context, safeMode) {
        if (!safeMode && SpeechRecognizer.isRecognitionAvailable(context)) SpeechRecognizer.createSpeechRecognizer(context) else null
    }

    fun mergeVoiceText(base: String, spoken: String): String {
        return listOf(base.trim(), spoken.trim()).filter { it.isNotBlank() }.joinToString(" ")
    }

    DisposableEffect(speechRecognizer) {
        speechRecognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { isListening = true }
            override fun onBeginningOfSpeech() { isListening = true }
            override fun onRmsChanged(rmsdB: Float) { rms = rmsdB.coerceIn(0f, 12f) }
            override fun onBufferReceived(buffer: ByteArray?) = Unit
            override fun onEndOfSpeech() = Unit

            override fun onError(error: Int) {
                isListening = false
                rms = 0f
                liveTranscript = ""
                if (error != SpeechRecognizer.ERROR_NO_MATCH && error != SpeechRecognizer.ERROR_SPEECH_TIMEOUT) {
                    Toast.makeText(context, "تعذر التقاط الصوت. حاول مرة أخرى.", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onResults(results: Bundle?) {
                val spoken = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                val turnText = mergeVoiceText(voiceBase, spoken)
                isListening = false
                rms = 0f
                liveTranscript = ""
                if (turnText.isNotBlank()) {
                    // Dictation is deliberately different from AION Live: it only fills the composer
                    // so the user can review/edit the text before sending.
                    onDraftChange(turnText)
                }
            }

            override fun onPartialResults(partialResults: Bundle?) {
                liveTranscript = partialResults
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull()
                    .orEmpty()
            }

            override fun onEvent(eventType: Int, params: Bundle?) = Unit
        })
        onDispose {
            speechRecognizer?.cancel()
            speechRecognizer?.destroy()
        }
    }

    fun startListeningNow() {
        val recognizer = speechRecognizer
        if (recognizer == null) {
            Toast.makeText(context, "خدمة التعرف على الصوت غير متاحة على هذا الجهاز.", Toast.LENGTH_SHORT).show()
            return
        }
        voiceBase = draft
        liveTranscript = ""
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag())
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 900L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 520L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 350L)
        }
        runCatching { recognizer.startListening(intent) }
            .onFailure { Toast.makeText(context, "تعذر تشغيل الميكروفون.", Toast.LENGTH_SHORT).show() }
    }

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) startListeningNow()
        else Toast.makeText(context, "يحتاج AION إذن الميكروفون لتحويل كلامك إلى نص.", Toast.LENGTH_SHORT).show()
    }

    fun toggleListening() {
        if (safeMode) {
            Toast.makeText(context, "الصوت معطل مؤقتًا لأن AION يعمل في الوضع الآمن.", Toast.LENGTH_SHORT).show()
            return
        }
        if (isListening) {
            speechRecognizer?.stopListening()
            return
        }
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            startListeningNow()
        } else {
            permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    fun loadUris(uris: List<Uri>) {
        if (uris.isEmpty()) return
        if (pendingAttachments.size + uris.size > 4) {
            Toast.makeText(context, "يمكن إرفاق حتى 4 عناصر في الرسالة الواحدة حاليًا.", Toast.LENGTH_SHORT).show()
            return
        }
        scope.launch {
            val loaded = withContext(Dispatchers.IO) { uris.map { AttachmentLoader.load(context, it) } }
            val errors = loaded.mapNotNull { it.exceptionOrNull()?.message?.takeIf(String::isNotBlank) }
            val attachments = loaded.mapNotNull { it.getOrNull() }
            if (errors.isNotEmpty()) {
                val message = if (errors.size == 1) {
                    errors.first()
                } else {
                    "تعذر تحميل ${errors.size} مرفقات. ${errors.first()}"
                }
                Toast.makeText(context, message, Toast.LENGTH_LONG).show()
            }
            if (attachments.isNotEmpty()) {
                val currentBytes = pendingAttachments.sumOf { it.sizeBytes }
                val remainingBytes = 5L * 1024L * 1024L - currentBytes
                val accepted = mutableListOf<ChatAttachment>()
                var acceptedBytes = 0L
                attachments.forEach { attachment ->
                    if (acceptedBytes + attachment.sizeBytes <= remainingBytes) {
                        accepted += attachment
                        acceptedBytes += attachment.sizeBytes
                    }
                }
                val rejected = attachments.filterNot { candidate -> accepted.any { it.id == candidate.id } }
                rejected.forEach { AttachmentLoader.deleteLocalCopy(context, it) }
                if (rejected.isNotEmpty()) {
                    Toast.makeText(context, "الحد الإجمالي للمرفقات في الرسالة هو 5 MB.", Toast.LENGTH_LONG).show()
                }
                if (accepted.isNotEmpty()) onAddAttachments(accepted)
            }
        }
    }

    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris -> loadUris(uris) }
    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris -> loadUris(uris) }
    val primaryAction = ComposerPolicy.primaryAction(
        isSending = isSending,
        draftHasText = draft.isNotBlank(),
        hasAttachments = pendingAttachments.isNotEmpty()
    )

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .imePadding()
            .padding(
                start = AionLayout.ComposerOuterHorizontal,
                end = AionLayout.ComposerOuterHorizontal,
                top = AionLayout.ComposerOuterTop,
                bottom = AionLayout.ComposerOuterBottom
            ),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Column(modifier = Modifier.widthIn(max = AionSizes.ContentMaxWidth).fillMaxWidth()) {
            if (safeMode || !isConfigured || selectedModel.key != "auto" || !activeProjectName.isNullOrBlank() || pendingAttachments.isNotEmpty()) {
                LazyRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(7.dp),
                    contentPadding = PaddingValues(horizontal = 3.dp, vertical = 2.dp)
                ) {
                    if (safeMode) {
                        item { InfoChip("الوضع الآمن — الصوت والتجارب الثقيلة متوقفة", AionColors.Warning) }
                    }
                    if (!isConfigured) {
                        item { InfoChip("الخدمة السحابية غير مضبوطة", MaterialTheme.colorScheme.error) }
                    }
                    if (selectedModel.key != "auto") {
                        item {
                            InfoChip(
                                selectedModel.label.removePrefix("AION "),
                                if (selectedModel.key == "research") AionColors.External else AionColors.Intelligence
                            )
                        }
                    }
                    if (!activeProjectName.isNullOrBlank()) {
                        item { InfoChip("المشروع · $activeProjectName", AionColors.IntelligenceSoft) }
                    }
                    items(pendingAttachments, key = { it.id }) { attachment ->
                        PendingAttachmentPreview(
                            attachment = attachment,
                            onRemove = { onRemoveAttachment(attachment.id) }
                        )
                    }
                }
                Spacer(Modifier.height(6.dp))
            }

            AnimatedVisibility(visible = isListening) {
                Surface(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 2.dp, vertical = 2.dp),
                    shape = RoundedCornerShape(16.dp),
                    color = AionPurple.copy(alpha = 0.10f),
                    border = BorderStroke(1.dp, AionPurple.copy(alpha = 0.30f))
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 11.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        val level = (rms / 12f).coerceIn(0f, 1f)
                        Box(
                            Modifier
                                .size((8f + level * 5f).dp)
                                .clip(CircleShape)
                                .background(AionPurpleSoft)
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(
                            text = liveTranscript.ifBlank { "أستمع إليك…" },
                            modifier = Modifier.weight(1f),
                            color = AionPurpleSoft,
                            style = MaterialTheme.typography.bodyMedium,
                            maxLines = 2
                        )
                        TextButton(onClick = { speechRecognizer?.stopListening() }) {
                            Text("إنهاء", style = MaterialTheme.typography.labelMedium)
                        }
                    }
                }
                Spacer(Modifier.height(5.dp))
            }

            Surface(
                modifier = Modifier.animateContentSize(),
                shape = RoundedCornerShape(AionRadii.Composer),
                color = AionColors.SurfaceRaised,
                border = BorderStroke(
                    1.dp,
                    when {
                        isListening -> AionPurple.copy(alpha = 0.85f)
                        inputFocused -> AionColors.BorderFocused
                        else -> AionColors.Border
                    }
                )
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().defaultMinSize(minHeight = AionSizes.ComposerMinHeight).padding(horizontal = 5.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        onClick = {
                            AionHaptics.tap(hapticView)
                            showAttachSheet = true
                        },
                        enabled = !isSending,
                        shape = CircleShape,
                        color = Color.Transparent,
                        modifier = Modifier.size(AionSizes.TouchTarget)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                Icons.Outlined.Add,
                                contentDescription = "إضافة مرفق",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(AionSizes.Icon)
                            )
                        }
                    }

                    BasicTextField(
                        value = draft,
                        onValueChange = onDraftChange,
                        modifier = Modifier
                            .weight(1f)
                            .onFocusChanged { inputFocused = it.isFocused }
                            .padding(horizontal = 5.dp, vertical = 10.dp),
                        textStyle = MaterialTheme.typography.bodyLarge.copy(
                            color = MaterialTheme.colorScheme.onSurface,
                            textAlign = TextAlign.Start
                        ),
                        cursorBrush = SolidColor(AionColors.Intelligence),
                        minLines = 1,
                        maxLines = 7,
                        decorationBox = { inner ->
                            Box {
                                if (draft.isBlank()) {
                                    Text(
                                        "اكتب رسالة إلى AION…",
                                        color = if (isListening) AionPurpleSoft else MaterialTheme.colorScheme.onSurfaceVariant,
                                        style = MaterialTheme.typography.bodyMedium
                                    )
                                }
                                inner()
                            }
                        }
                    )

                    when (primaryAction) {
                        ComposerPrimaryAction.STOP -> {
                            Surface(
                                onClick = {
                                    AionHaptics.tap(hapticView)
                                    onStop()
                                },
                                shape = CircleShape,
                                color = AionColors.TextPrimary,
                                modifier = Modifier.size(AionSizes.TouchTarget)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        Icons.Outlined.Stop,
                                        contentDescription = "إيقاف",
                                        tint = AionColors.Background,
                                        modifier = Modifier.size(AionSizes.SmallIcon)
                                    )
                                }
                            }
                        }

                        ComposerPrimaryAction.SEND -> {
                            Surface(
                                onClick = {
                                    if (!isConfigured) {
                                        Toast.makeText(context, "اضبط اتصال AION Cloud من الإعدادات أولًا.", Toast.LENGTH_SHORT).show()
                                    } else {
                                        AionHaptics.confirm(hapticView)
                                        val outgoing = draft
                                        onSend(outgoing)
                                        onDraftChange("")
                                    }
                                },
                                shape = CircleShape,
                                color = if (isConfigured) AionColors.TextPrimary else AionColors.BorderStrong,
                                modifier = Modifier.size(AionSizes.TouchTarget)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(Icons.Outlined.ArrowUpward, contentDescription = "إرسال", tint = if (isConfigured) AionColors.Background else AionColors.TextSecondary, modifier = Modifier.size(AionSizes.Icon))
                                }
                            }
                        }

                        ComposerPrimaryAction.LIVE_AND_DICTATION -> {
                            val scale = if (isListening) (1f + (rms / 60f)).coerceAtMost(1.18f) else 1f
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Surface(
                                    onClick = {
                                        AionHaptics.tap(hapticView)
                                        toggleListening()
                                    },
                                    enabled = !isSending,
                                    shape = CircleShape,
                                    color = if (isListening) AionColors.Intelligence.copy(alpha = 0.18f) else Color.Transparent,
                                    modifier = Modifier.size(AionSizes.TouchTarget).scale(scale)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(
                                            Icons.Outlined.Mic,
                                            contentDescription = if (isListening) "إيقاف الإملاء الصوتي" else "إملاء صوتي",
                                            tint = if (isListening) AionColors.IntelligenceSoft else MaterialTheme.colorScheme.onSurfaceVariant,
                                            modifier = Modifier.size(AionSizes.Icon)
                                        )
                                    }
                                }
                                if (!isListening) {
                                    AionLiveEntryButton(
                                        onClick = {
                                            AionHaptics.confirm(hapticView)
                                            if (safeMode) {
                                                Toast.makeText(context, "AION Live معطل مؤقتًا في الوضع الآمن.", Toast.LENGTH_SHORT).show()
                                            } else if (!isConfigured) {
                                                Toast.makeText(context, "اضبط اتصال AION Cloud من الإعدادات أولًا.", Toast.LENGTH_SHORT).show()
                                            } else {
                                                onStartVoiceCall()
                                            }
                                        }
                                    )
                                }
                            }
                        }
                    }
                }
            }

            AnimatedVisibility(visible = !inputFocused) {
                Text(
                    "قد يخطئ AION؛ تحقق من المعلومات المهمة.",
                    modifier = Modifier.fillMaxWidth().padding(horizontal = AionSpacing.Sm, vertical = AionSpacing.Xs),
                    textAlign = TextAlign.Center,
                    style = MaterialTheme.typography.labelMedium,
                    color = AionColors.TextTertiary
                )
            }
        }
    }

    if (showAttachSheet) {
        ModalBottomSheet(
            onDismissRequest = { showAttachSheet = false },
            containerColor = AionColors.Surface
        ) {
            Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 8.dp)) {
                Text("أضف إلى المحادثة", fontSize = 19.sp, fontWeight = FontWeight.Bold)
                Text("يمكنك إرسال حتى 4 عناصر وبحجم إجمالي 5 MB حاليًا.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(12.dp))
                AttachmentSheetRow(
                    icon = Icons.Outlined.Image,
                    title = "صورة",
                    subtitle = "PNG وJPEG وWEBP وGIF",
                    accent = AionColors.External,
                    onClick = {
                        showAttachSheet = false
                        imagePicker.launch(arrayOf("image/*"))
                    }
                )
                AttachmentSheetRow(
                    icon = Icons.Outlined.Description,
                    title = "ملف",
                    subtitle = "PDF وWord وExcel ونصوص وكود",
                    accent = AionBlueSoft,
                    onClick = {
                        showAttachSheet = false
                        filePicker.launch(
                            arrayOf(
                                "application/pdf",
                                "text/*",
                                "application/json",
                                "application/xml",
                                "application/msword",
                                "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                                "application/vnd.ms-powerpoint",
                                "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                                "application/vnd.ms-excel",
                                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                            )
                        )
                    }
                )
                Spacer(Modifier.height(AionSpacing.Md))
                Text(
                    "أدوات AION",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = AionSpacing.Xs, vertical = AionSpacing.Xs)
                )
                AttachmentSheetRow(
                    icon = Icons.Outlined.Search,
                    title = "بحث في الويب",
                    subtitle = "فعّل وضع البحث الحي مع المصادر لهذه المحادثة",
                    accent = AionColors.External,
                    onClick = {
                        showAttachSheet = false
                        onModeShortcut("research")
                    }
                )
                AttachmentSheetRow(
                    icon = Icons.Outlined.Psychology,
                    title = "تحليل عميق",
                    subtitle = "استخدم وضع الاستدلال الأعمق لهذه المحادثة",
                    accent = AionColors.Intelligence,
                    onClick = {
                        showAttachSheet = false
                        onModeShortcut("deep")
                    }
                )
                Spacer(Modifier.height(AionSpacing.Xxl))
            }
        }
    }
}

@Composable
private fun AionLiveEntryButton(onClick: () -> Unit) {
    Surface(
        onClick = onClick,
        shape = CircleShape,
        color = AionColors.TextPrimary,
        modifier = Modifier
            .size(AionSizes.TouchTarget)
            .semantics { contentDescription = "AION Live" }
    ) {
        Box(contentAlignment = Alignment.Center) {
            Row(
                horizontalArrangement = Arrangement.spacedBy(2.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                val bars = listOf(10.dp, 17.dp, 13.dp, 19.dp, 11.dp)
                bars.forEachIndexed { index, height ->
                    Box(
                        Modifier
                            .width(2.dp)
                            .height(height)
                            .clip(CircleShape)
                            .background(if (index == 2) AionColors.IntelligenceStrong else AionColors.Background)
                    )
                }
            }
        }
    }
}

@Composable
private fun InfoChip(text: String, accent: Color) {
    val contentColor = when (accent) {
        AionColors.Intelligence, AionColors.IntelligenceStrong -> AionColors.IntelligenceSoft
        AionColors.External -> AionColors.ExternalSoft
        else -> accent
    }
    Surface(
        shape = RoundedCornerShape(AionRadii.Chip),
        color = accent.copy(alpha = 0.10f),
        border = BorderStroke(1.dp, accent.copy(alpha = 0.28f))
    ) {
        Text(
            text = text,
            modifier = Modifier.padding(horizontal = 9.dp, vertical = 6.dp),
            color = contentColor,
            style = MaterialTheme.typography.labelMedium
        )
    }
}

@Composable
private fun PendingAttachmentCard(attachment: ChatAttachment, onRemove: () -> Unit) {
    val context = LocalContext.current
    val bitmap = if (attachment.kind == AttachmentKind.IMAGE) rememberAttachmentPreview(attachment) else null
    val pdfPages = rememberPdfPageCount(attachment)
    val accent = AionColors.ExternalSoft

    Surface(
        onClick = {
            if (!openAttachmentExternally(context, attachment)) {
                Toast.makeText(context, "لا يوجد تطبيق متوافق لفتح هذا المرفق.", Toast.LENGTH_SHORT).show()
            }
        },
        shape = RoundedCornerShape(AionRadii.Attachment),
        color = AionColors.SurfaceRaised,
        border = BorderStroke(1.dp, AionColors.Border)
    ) {
        Row(
            modifier = Modifier.padding(start = AionSpacing.Xs, end = 2.dp, top = AionSpacing.Xs, bottom = AionSpacing.Xs),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (bitmap != null) {
                Image(
                    bitmap = bitmap.asImageBitmap(),
                    contentDescription = attachment.name,
                    modifier = Modifier
                        .size(AionSizes.AttachmentThumb)
                        .clip(RoundedCornerShape(12.dp)),
                    contentScale = ContentScale.Crop
                )
            } else {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = accent.copy(alpha = 0.12f),
                    modifier = Modifier.size(AionSizes.AttachmentThumb)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            attachmentIcon(attachment),
                            contentDescription = null,
                            tint = accent,
                            modifier = Modifier.size(21.dp)
                        )
                    }
                }
            }

            Spacer(Modifier.width(AionSpacing.Sm))
            Column(modifier = Modifier.widthIn(min = 94.dp, max = 150.dp)) {
                Text(
                    attachment.name,
                    style = MaterialTheme.typography.labelMedium,
                    color = AionColors.TextPrimary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    AttachmentPresentationPolicy.secondaryLabel(
                        name = attachment.name,
                        mimeType = attachment.mimeType,
                        sizeBytes = attachment.sizeBytes,
                        pdfPages = pdfPages
                    ),
                    style = MaterialTheme.typography.labelSmall,
                    color = AionColors.TextTertiary,
                    maxLines = 1
                )
            }

            IconButton(onClick = onRemove, modifier = Modifier.size(AionSizes.TouchTarget)) {
                Icon(
                    Icons.Outlined.Close,
                    contentDescription = "إزالة المرفق",
                    modifier = Modifier.size(AionSizes.SmallIcon),
                    tint = AionColors.TextTertiary
                )
            }
        }
    }
}

@Composable
private fun PendingAttachmentPreview(attachment: ChatAttachment, onRemove: () -> Unit) {
    PendingAttachmentCard(attachment = attachment, onRemove = onRemove)
}

@Composable
private fun AttachmentSheetRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    accent: Color,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        shape = RoundedCornerShape(17.dp),
        color = AionColors.SurfaceRaised
    ) {
        Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Surface(shape = CircleShape, color = accent.copy(alpha = 0.13f), modifier = Modifier.size(38.dp)) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(icon, contentDescription = null, tint = accent, modifier = Modifier.size(19.dp))
                }
            }
            Spacer(Modifier.width(11.dp))
            Column {
                Text(title, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold)
                Text(subtitle, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SourcesSheet(sources: List<ChatSource>, onOpen: (ChatSource) -> Unit, onDismiss: () -> Unit) {
    ModalBottomSheet(onDismissRequest = onDismiss, containerColor = AionColors.Surface) {
        Column(modifier = Modifier.fillMaxWidth().padding(horizontal = AionSpacing.Lg, vertical = AionSpacing.Sm)) {
            Text("المصادر", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text(
                "${sources.size} ${if (sources.size == 1) "مصدر" else "مصادر"} مرتبطة بهذا الرد.",
                color = AionColors.TextTertiary,
                style = MaterialTheme.typography.bodySmall
            )
            Spacer(Modifier.height(AionSpacing.Md))
            sources.forEachIndexed { index, source ->
                val host = remember(source.url) { sourceHost(source.url) }
                Surface(
                    onClick = { onOpen(source) },
                    modifier = Modifier.fillMaxWidth().padding(vertical = AionSpacing.Xs),
                    shape = RoundedCornerShape(AionRadii.Card),
                    color = AionColors.SurfaceRaised,
                    border = BorderStroke(1.dp, AionColors.External.copy(alpha = 0.12f))
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = AionSpacing.Md, vertical = AionSpacing.Md),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = AionColors.External.copy(alpha = 0.11f),
                            modifier = Modifier.size(32.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text(
                                    "${index + 1}",
                                    color = AionColors.ExternalSoft,
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                        Spacer(Modifier.width(AionSpacing.Sm))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                source.title.ifBlank { host.ifBlank { "مصدر" } },
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.SemiBold,
                                maxLines = 2
                            )
                            if (host.isNotBlank()) {
                                Spacer(Modifier.height(2.dp))
                                Text(
                                    host,
                                    color = AionColors.ExternalSoft,
                                    style = MaterialTheme.typography.bodySmall,
                                    maxLines = 1
                                )
                            }
                            if (source.snippet.isNotBlank()) {
                                Spacer(Modifier.height(AionSpacing.Xs))
                                Text(
                                    source.snippet,
                                    color = AionColors.TextSecondary,
                                    style = MaterialTheme.typography.bodySmall,
                                    maxLines = 3,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                        Icon(
                            Icons.Outlined.OpenInNew,
                            contentDescription = "فتح المصدر",
                            modifier = Modifier.size(AionSizes.SmallIcon),
                            tint = AionColors.TextTertiary
                        )
                    }
                }
            }
            Spacer(Modifier.height(AionSpacing.Xxl))
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ModelPickerSheet(
    options: List<AiModelOption>,
    selectedKey: String,
    onSelect: (String) -> Unit,
    onDismiss: () -> Unit
) {
    ModalBottomSheet(onDismissRequest = onDismiss, containerColor = AionColors.Surface) {
        Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 8.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("وضع AION لهذه المحادثة", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text(
                        "يُحفظ الاختيار لهذه المحادثة ويمكن تغييره في أي وقت.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
                IconButton(onClick = onDismiss) { Icon(Icons.Outlined.Close, contentDescription = "إغلاق") }
            }

            Spacer(Modifier.height(12.dp))
            options.forEach { option ->
                val selected = option.key == selectedKey
                Surface(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp).clickable(enabled = option.enabled) {
                        onSelect(option.key)
                    },
                    shape = RoundedCornerShape(17.dp),
                    color = if (selected) AionColors.Intelligence.copy(alpha = 0.12f) else AionColors.SurfaceRaised,
                    border = BorderStroke(1.dp, if (selected) AionColors.Intelligence.copy(alpha = 0.55f) else AionColors.Border)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(13.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        ModelGlyph(option)
                        Spacer(Modifier.width(11.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                option.label,
                                fontWeight = FontWeight.SemiBold,
                                color = if (option.enabled) MaterialTheme.colorScheme.onSurface else AionColors.TextDisabled
                            )
                            Text(option.provider, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                        }
                        option.badge?.let {
                            Text(it, color = if (option.enabled) AionColors.IntelligenceSoft else AionColors.TextTertiary, style = MaterialTheme.typography.labelMedium)
                            Spacer(Modifier.width(7.dp))
                        }
                        if (selected) Icon(Icons.Outlined.Check, contentDescription = null, tint = AionPurple)
                    }
                }
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun ModelGlyph(option: AiModelOption) {
    val color = when {
        option.key == "auto" -> AionPurple
        option.provider == "OpenAI" -> Color(0xFFE8E8EC)
        option.key == "claude" -> Color(0xFFE07B49)
        option.key == "gemini" -> AionBlueSoft
        option.key == "grok" -> Color(0xFFD7D7DA)
        option.key == "deepseek" -> Color(0xFF658CFF)
        else -> AionPurpleSoft
    }
    Surface(shape = CircleShape, color = color.copy(alpha = 0.14f), modifier = Modifier.size(36.dp)) {
        Box(contentAlignment = Alignment.Center) {
            Text(
                when (option.key) {
                    "auto" -> "A"
                    "fast" -> "↗"
                    "deep" -> "◈"
                    "research" -> "⌕"
                    "claude" -> "C"
                    "gemini" -> "✦"
                    "grok" -> "X"
                    else -> "AI"
                },
                color = color,
                fontWeight = FontWeight.ExtraBold,
                fontSize = 12.sp
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ContextSheet(
    messageCount: Int,
    selectedModel: AiModelOption,
    isConfigured: Boolean,
    cloudHealthLabel: String,
    cloudHealthOk: Boolean?,
    pendingAttachments: Int,
    memoryEnabled: Boolean,
    temporaryMemory: Boolean,
    projectName: String?,
    onTemporaryMemoryChange: (Boolean) -> Unit,
    onDismiss: () -> Unit
) {
    ModalBottomSheet(onDismissRequest = onDismiss, containerColor = AionColors.Surface) {
        Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 8.dp)) {
            Text("سياق المحادثة", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(5.dp))
            Text(
                "هذه اللوحة تظهر عند الطلب فقط حتى تبقى الدردشة نظيفة.",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                style = MaterialTheme.typography.bodySmall
            )
            Spacer(Modifier.height(15.dp))
            ContextRow("النموذج الحالي", selectedModel.label, AionPurple)
            ContextRow("الرسائل", messageCount.toString(), AionPurpleSoft)
            ContextRow("المشروع", projectName ?: "بدون مشروع", if (projectName != null) AionPurple else AionColors.TextTertiary)
            ContextRow("البحث في الويب", "تلقائي عند الحاجة", AionBlueSoft)
            ContextRow("المرفقات الجاهزة", pendingAttachments.toString(), AionPurpleSoft)
            ContextRow(
                "اتصال AION Cloud",
                when {
                    !isConfigured -> "غير مضبوط"
                    cloudHealthOk == true -> cloudHealthLabel
                    cloudHealthOk == false -> "تعذر التحقق"
                    else -> "العنوان مضبوط"
                },
                when {
                    cloudHealthOk == true -> AionPurple
                    cloudHealthOk == false -> MaterialTheme.colorScheme.error
                    else -> AionColors.TextTertiary
                }
            )
            ContextRow(
                "الذاكرة المحلية",
                when {
                    temporaryMemory -> "موقوفة لهذه المحادثة"
                    memoryEnabled -> "مفعلة"
                    else -> "معطلة من الإعدادات"
                },
                if (memoryEnabled && !temporaryMemory) AionPurple else AionColors.TextTertiary
            )
            Surface(
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                shape = RoundedCornerShape(15.dp),
                color = AionColors.SurfaceRaised
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 13.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text("محادثة مؤقتة", fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.labelLarge)
                        Text(
                            "عند تفعيلها لا تُقرأ الذاكرة ولا يُسمح بالحفظ منها لهذه المحادثة.",
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                    Switch(checked = temporaryMemory, onCheckedChange = onTemporaryMemoryChange)
                }
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun ContextRow(label: String, value: String, accent: Color) {
    Surface(
        modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp),
        shape = RoundedCornerShape(15.dp),
        color = AionColors.SurfaceRaised
    ) {
        Row(modifier = Modifier.fillMaxWidth().padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(7.dp).clip(CircleShape).background(accent))
            Spacer(Modifier.width(9.dp))
            Text(label, modifier = Modifier.weight(1f), color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
            Text(value, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.labelMedium)
        }
    }
}

@Composable
private fun AionMark(size: androidx.compose.ui.unit.Dp) {
    Surface(
        shape = RoundedCornerShape(size * 0.30f),
        color = AionColors.SurfaceSelected,
        modifier = Modifier.size(size),
        border = BorderStroke(1.dp, AionColors.BorderStrong.copy(alpha = 0.72f))
    ) {
        Canvas(Modifier.fillMaxSize().padding(size * 0.18f)) {
            val stroke = (this.size.minDimension * 0.10f).coerceAtLeast(1.4f)
            val inset = stroke * 0.70f
            val arcSize = Size(this.size.width - inset * 2f, this.size.height - inset * 2f)
            drawArc(
                color = AionColors.IntelligenceSoft,
                startAngle = 205f,
                sweepAngle = 258f,
                useCenter = false,
                topLeft = Offset(inset, inset),
                size = arcSize,
                style = Stroke(width = stroke, cap = StrokeCap.Round)
            )
            // Blue node represents AION reaching outward to tools/web; purple remains the core.
            drawCircle(
                color = AionColors.External,
                radius = stroke * 0.78f,
                center = Offset(this.size.width * 0.80f, this.size.height * 0.34f)
            )
            drawCircle(
                color = AionColors.IntelligenceStrong,
                radius = stroke * 0.62f,
                center = Offset(this.size.width * 0.52f, this.size.height * 0.55f)
            )
            drawCircle(
                color = AionColors.TextPrimary.copy(alpha = 0.88f),
                radius = stroke * 0.38f,
                center = Offset(this.size.width * 0.31f, this.size.height * 0.70f)
            )
        }
    }
}

@Composable
private fun SettingsDialog(
    initialEndpoint: String,
    initialInstructions: String,
    initialMemory: String,
    initialMemoryPrivacy: MemoryPrivacySettings,
    cloudHealthLabel: String,
    cloudHealthOk: Boolean?,
    cloudHealthEndpoint: String,
    neuralVoiceAvailable: Boolean,
    neuralVoiceProvider: String,
    voiceOptions: List<AionCloudVoiceOption>,
    defaultVoiceKey: String,
    initialVoiceSettings: AionVoiceSettings,
    myVoiceCloudAvailable: Boolean,
    myVoiceProvider: String,
    myVoiceMaxSampleBytes: Long,
    myVoiceCredential: MyVoiceCredential,
    isMyVoiceBusy: Boolean,
    myVoiceStatusLabel: String,
    voicePlaybackArbiter: AionVoicePlaybackArbiter,
    onCreateMyVoice: (String, File, String, String, Boolean) -> Unit,
    onDeleteMyVoice: () -> Unit,
    isCheckingCloud: Boolean,
    onCheckCloud: (String) -> Unit,
    onSave: (String, String, String, MemoryPrivacySettings, AionVoiceSettings) -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    var endpoint by remember(initialEndpoint) { mutableStateOf(initialEndpoint) }
    var instructions by remember(initialInstructions) { mutableStateOf(initialInstructions) }
    var memory by remember(initialMemory) { mutableStateOf(initialMemory) }
    var memoryPrivacy by remember(initialMemoryPrivacy) { mutableStateOf(initialMemoryPrivacy.copy(automaticMemoryEnabled = false)) }
    var voiceSettings by remember(initialVoiceSettings) { mutableStateOf(initialVoiceSettings.normalized()) }
    val previewScope = rememberCoroutineScope()
    val previewPlayer = remember { NeuralVoicePlayer() }
    val previewFocus = remember { VoiceAudioFocus(context.applicationContext) }
    var previewJob by remember { mutableStateOf<Job?>(null) }
    var previewLease by remember { mutableStateOf<Long?>(null) }
    var previewing by remember { mutableStateOf(false) }
    var previewStatus by remember { mutableStateOf("") }

    LaunchedEffect(voiceOptions, defaultVoiceKey, myVoiceCredential.token, myVoiceCloudAvailable, endpoint, cloudHealthEndpoint) {
        val availableKeys = buildList {
            addAll(voiceOptions.map { it.key })
            if (
                myVoiceCloudAvailable &&
                cloudHealthEndpoint == endpoint.trim().trimEnd('/') &&
                myVoiceCredential.usable &&
                myVoiceCredential.cloudEndpoint.trim().trimEnd('/') == endpoint.trim().trimEnd('/')
            ) add(MyVoicePolicy.MY_VOICE_KEY)
        }
        if (availableKeys.isNotEmpty()) {
            val resolved = VoiceSelectionPolicy.resolve(
                savedKey = voiceSettings.voiceKey,
                defaultKey = defaultVoiceKey,
                availableKeys = availableKeys
            )
            if (resolved != voiceSettings.voiceKey) {
                voiceSettings = voiceSettings.copy(voiceKey = resolved)
            }
        }
    }

    fun stopPreviewHardware() {
        previewJob?.cancel()
        previewPlayer.stop()
        previewFocus.abandon()
        previewing = false
    }

    fun stopPreview() {
        if (!voicePlaybackArbiter.interrupt(AionVoicePlaybackOwner.PREVIEW)) {
            stopPreviewHardware()
        }
        previewJob = null
        previewLease = null
    }

    DisposableEffect(Unit) {
        onDispose { stopPreview() }
    }

    fun previewVoice() {
        if (previewing) {
            stopPreview()
            previewStatus = "تم إيقاف المعاينة"
            return
        }
        val clean = voiceSettings.normalized()
        val availableKeys = buildList {
            addAll(voiceOptions.map { it.key })
            if (
                myVoiceCloudAvailable &&
                cloudHealthEndpoint == endpoint.trim().trimEnd('/') &&
                myVoiceCredential.usable &&
                myVoiceCredential.cloudEndpoint.trim().trimEnd('/') == endpoint.trim().trimEnd('/')
            ) add(MyVoicePolicy.MY_VOICE_KEY)
        }
        val resolvedKey = VoiceSelectionPolicy.resolve(
            savedKey = clean.voiceKey,
            defaultKey = defaultVoiceKey,
            availableKeys = availableKeys
        )
        val myVoiceSelected = resolvedKey == MyVoicePolicy.MY_VOICE_KEY && myVoiceCredential.usable
        if ((!neuralVoiceAvailable && !myVoiceSelected) || resolvedKey.isBlank() || !endpoint.trim().startsWith("https://")) return

        val lease = voicePlaybackArbiter.claim(AionVoicePlaybackOwner.PREVIEW) {
            stopPreviewHardware()
        }
        previewLease = lease
        previewing = true
        previewStatus = "جارٍ تحضير المعاينة…"
        val job = previewScope.launch {
            previewFocus.request()
            val result = try {
                previewPlayer.speak(
                    endpoint = endpoint,
                    text = "مرحبًا، أنا AION. هذه معاينة للصوت الذي اخترته.",
                    profile = clean.profile.key,
                    voiceKey = resolvedKey,
                    speed = clean.speed,
                    expression = clean.expression,
                    clarity = clean.clarity,
                    myVoiceToken = if (resolvedKey == MyVoicePolicy.MY_VOICE_KEY) myVoiceCredential.token else "",
                    onStarted = {
                        previewScope.launch {
                            if (
                                previewLease == lease &&
                                voicePlaybackArbiter.isCurrent(AionVoicePlaybackOwner.PREVIEW, lease)
                            ) {
                                previewStatus = "تشغيل المعاينة…"
                            }
                        }
                    }
                )
            } finally {
                if (voicePlaybackArbiter.isCurrent(AionVoicePlaybackOwner.PREVIEW, lease)) {
                    previewFocus.abandon()
                }
                voicePlaybackArbiter.release(AionVoicePlaybackOwner.PREVIEW, lease)
            }
            if (previewLease == lease) {
                previewing = false
                previewJob = null
                previewLease = null
                previewStatus = when (result) {
                    NeuralVoicePlaybackResult.PLAYED -> "تمت المعاينة"
                    NeuralVoicePlaybackResult.INTERRUPTED -> "تم إيقاف المعاينة"
                    NeuralVoicePlaybackResult.UNAVAILABLE -> "الصوت العصبي غير متاح مؤقتًا"
                    NeuralVoicePlaybackResult.FAILED -> "تعذرت المعاينة؛ تحقق من AION Cloud"
                }
            }
        }
        previewJob = job
    }


    AlertDialog(
        onDismissRequest = {
            stopPreview()
            onDismiss()
        },
        icon = { Icon(Icons.Outlined.Settings, contentDescription = null, tint = AionPurple) },
        title = { Text("إعدادات AION") },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    "AION يتصل بخدمة AION Cloud من دون وضع مفاتيح مزودي الذكاء داخل التطبيق.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    style = MaterialTheme.typography.bodySmall
                )
                OutlinedTextField(
                    value = endpoint,
                    onValueChange = { endpoint = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("عنوان AION Cloud") },
                    supportingText = { Text("مثال: https://aion-core.اسمك.workers.dev") },
                    singleLine = true
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        cloudHealthLabel,
                        modifier = Modifier.weight(1f),
                        style = MaterialTheme.typography.bodySmall,
                        color = when (cloudHealthOk) {
                            true -> AionPurpleSoft
                            false -> MaterialTheme.colorScheme.error
                            null -> MaterialTheme.colorScheme.onSurfaceVariant
                        }
                    )
                    TextButton(
                        enabled = !isCheckingCloud && endpoint.trim().startsWith("https://"),
                        onClick = { onCheckCloud(endpoint) }
                    ) {
                        Text(if (isCheckingCloud) "جارٍ الفحص…" else "اختبار الاتصال")
                    }
                }

                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(AionRadii.Card),
                    color = AionColors.SurfaceRaised,
                    border = BorderStroke(1.dp, AionColors.Border)
                ) {
                    Column(
                        modifier = Modifier.padding(AionSpacing.Md),
                        verticalArrangement = Arrangement.spacedBy(AionSpacing.Md)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                Icons.Outlined.VolumeUp,
                                contentDescription = null,
                                tint = if (neuralVoiceAvailable) AionColors.IntelligenceSoft else AionColors.TextTertiary,
                                modifier = Modifier.size(AionSizes.SmallIcon)
                            )
                            Spacer(Modifier.width(AionSpacing.Sm))
                            Column(modifier = Modifier.weight(1f)) {
                                Text("صوت AION", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold)
                                Text(
                                    if (neuralVoiceAvailable) {
                                        "Neural Voice مفعّل${if (neuralVoiceProvider.isNotBlank()) " • $neuralVoiceProvider" else ""}"
                                    } else {
                                        "يستخدم صوت Android المحلي كمسار احتياطي"
                                    },
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        Text("الصوت", style = MaterialTheme.typography.labelMedium, color = AionColors.TextSecondary)
                        if (neuralVoiceAvailable && voiceOptions.isNotEmpty()) {
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(AionSpacing.Sm)) {
                                items(voiceOptions, key = { it.key }) { option ->
                                    val normalizedKey = NeuralVoiceContract.normalizedVoiceKey(option.key)
                                    val isDefault = normalizedKey == NeuralVoiceContract.normalizedVoiceKey(defaultVoiceKey)
                                    FilterChip(
                                        selected = NeuralVoiceContract.normalizedVoiceKey(voiceSettings.voiceKey) == normalizedKey,
                                        onClick = {
                                            stopPreview()
                                            previewStatus = ""
                                            voiceSettings = voiceSettings.copy(voiceKey = normalizedKey)
                                        },
                                        label = {
                                            Text(
                                                buildString {
                                                    append(option.label)
                                                    append(" • ")
                                                    append(VoiceSelectionPolicy.genderLabel(option.gender))
                                                    if (isDefault) append(" • افتراضي")
                                                }
                                            )
                                        }
                                    )
                                }
                            }
                        } else {
                            Text(
                                if (neuralVoiceAvailable) "الخادم لم يرسل قائمة أصوات صالحة بعد."
                                else "تظهر أصوات الذكر/الأنثى هنا فقط عندما يعلن عنها AION Cloud فعليًا؛ لا يتم عرض خيارات وهمية.",
                                style = MaterialTheme.typography.bodySmall,
                                color = AionColors.TextTertiary
                            )
                        }

                        MyVoiceSettingsCard(
                            cloudAvailable = myVoiceCloudAvailable && cloudHealthEndpoint == endpoint.trim().trimEnd('/'),
                            provider = myVoiceProvider,
                            maxSampleBytes = myVoiceMaxSampleBytes,
                            credential = myVoiceCredential,
                            busy = isMyVoiceBusy,
                            statusLabel = myVoiceStatusLabel,
                            selected = voiceSettings.voiceKey == MyVoicePolicy.MY_VOICE_KEY,
                            onBeforeRecordOrImport = {
                                stopPreview()
                                previewStatus = ""
                            },
                            onSelect = {
                                stopPreview()
                                previewStatus = ""
                                voiceSettings = voiceSettings.copy(voiceKey = MyVoicePolicy.MY_VOICE_KEY)
                            },
                            onCreate = { file, name, secret, consent ->
                                onCreateMyVoice(endpoint, file, name, secret, consent)
                            },
                            onDeleteRemote = onDeleteMyVoice
                        )

                        Text("أسلوب الإلقاء", style = MaterialTheme.typography.labelMedium, color = AionColors.TextSecondary)
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(AionSpacing.Sm)) {
                            items(AionVoiceProfile.entries, key = { it.key }) { profile ->
                                FilterChip(
                                    selected = voiceSettings.profile == profile,
                                    onClick = {
                                        stopPreview()
                                        previewStatus = ""
                                        voiceSettings = voiceSettings.applyProfilePreset(profile)
                                    },
                                    label = { Text(profile.label) }
                                )
                            }
                        }
                        Text(
                            voiceSettings.profile.description,
                            style = MaterialTheme.typography.bodySmall,
                            color = AionColors.TextTertiary
                        )

                        VoiceTuningSlider(
                            label = "السرعة",
                            value = voiceSettings.speed,
                            valueText = String.format(Locale.US, "%.2f×", voiceSettings.speed),
                            valueRange = 0.72f..1.20f,
                            steps = 11,
                            onValueChange = {
                                stopPreview()
                                previewStatus = ""
                                voiceSettings = voiceSettings.copy(speed = it)
                            }
                        )
                        VoiceTuningSlider(
                            label = "التعبير",
                            value = voiceSettings.expression,
                            valueText = "${(voiceSettings.expression * 100).toInt()}%",
                            valueRange = 0f..1f,
                            steps = 9,
                            onValueChange = {
                                stopPreview()
                                previewStatus = ""
                                voiceSettings = voiceSettings.copy(expression = it)
                            }
                        )
                        VoiceTuningSlider(
                            label = "الوضوح",
                            value = voiceSettings.clarity,
                            valueText = "${(voiceSettings.clarity * 100).toInt()}%",
                            valueRange = 0f..1f,
                            steps = 9,
                            onValueChange = {
                                stopPreview()
                                previewStatus = ""
                                voiceSettings = voiceSettings.copy(clarity = it)
                            }
                        )

                        OutlinedButton(
                            onClick = { previewVoice() },
                            enabled = previewing || (
                                endpoint.trim().startsWith("https://") &&
                                    (
                                        (neuralVoiceAvailable && voiceOptions.isNotEmpty()) ||
                                            (myVoiceCloudAvailable && myVoiceCredential.usable)
                                    )
                            ),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Outlined.VolumeUp, contentDescription = null)
                            Spacer(Modifier.width(AionSpacing.Sm))
                            Text(if (previewing) "إيقاف المعاينة" else "معاينة الصوت")
                        }
                        if (previewStatus.isNotBlank()) {
                            Text(
                                previewStatus,
                                style = MaterialTheme.typography.bodySmall,
                                color = if (previewStatus.startsWith("تعذرت")) MaterialTheme.colorScheme.error else AionColors.TextSecondary
                            )
                        }
                    }
                }

                OutlinedTextField(
                    value = instructions,
                    onValueChange = { instructions = it.take(8_000) },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("تعليمات AION") },
                    placeholder = { Text("مثال: أجب بالعربية، وكن دقيقًا ومباشرًا.") },
                    minLines = 3,
                    maxLines = 6
                )
                OutlinedTextField(
                    value = memory,
                    onValueChange = { memory = it.take(16_000) },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("ذاكرة محلية") },
                    placeholder = { Text("اكتب فقط المعلومات التي تريد من AION تذكرها.") },
                    minLines = 3,
                    maxLines = 7
                )
                MemoryPrivacySwitch(
                    title = "استخدام الذاكرة",
                    description = "إيقافه يمنع قراءة الذاكرة وحفظ ذكريات جديدة.",
                    checked = memoryPrivacy.memoryEnabled,
                    onCheckedChange = { memoryPrivacy = memoryPrivacy.copy(memoryEnabled = it) }
                )
                if (memoryPrivacy.memoryEnabled) {
                    MemoryPrivacySwitch("ذاكرة المستخدم", "تفضيلات وحقائق عامة عبر المحادثات.", memoryPrivacy.allowUserScope) {
                        memoryPrivacy = memoryPrivacy.copy(allowUserScope = it)
                    }
                    MemoryPrivacySwitch("ذاكرة المشروع", "قرارات وملاحظات المشروع النشط فقط.", memoryPrivacy.allowProjectScope) {
                        memoryPrivacy = memoryPrivacy.copy(allowProjectScope = it)
                    }
                    MemoryPrivacySwitch("ذاكرة المحادثة", "ذكريات مرتبطة بهذه المحادثة فقط.", memoryPrivacy.allowConversationScope) {
                        memoryPrivacy = memoryPrivacy.copy(allowConversationScope = it)
                    }
                }
                Text(
                    "التعليمات والذاكرة محفوظتان على الجهاز وتُرسلان إلى AION Cloud مع الطلب فقط. الحفظ التلقائي للذاكرة غير مفعّل في هذه المرحلة. لا تضع مفاتيح API أو كلمات مرور هنا.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        },
        confirmButton = {
            TextButton(
                enabled = endpoint.trim().startsWith("https://"),
                onClick = {
                    stopPreview()
                    onSave(endpoint, instructions, memory, memoryPrivacy.copy(automaticMemoryEnabled = false), voiceSettings.normalized())
                }
            ) { Text("حفظ") }
        },
        dismissButton = {
            TextButton(
                onClick = {
                    stopPreview()
                    onDismiss()
                }
            ) { Text("إلغاء") }
        }
    )
}

@Composable
private fun MemoryPrivacySwitch(
    title: String,
    description: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold)
            Text(description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}

@Composable
private fun MyVoiceSettingsCard(
    cloudAvailable: Boolean,
    provider: String,
    maxSampleBytes: Long,
    credential: MyVoiceCredential,
    busy: Boolean,
    statusLabel: String,
    selected: Boolean,
    onBeforeRecordOrImport: () -> Unit,
    onSelect: () -> Unit,
    onCreate: (File, String, String, Boolean) -> Unit,
    onDeleteRemote: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val recorder = remember { MyVoiceSampleRecorder() }
    var sampleFile by remember { mutableStateOf(recorder.sampleFile(context).takeIf { it.isFile }) }
    var recording by remember { mutableStateOf(false) }
    var elapsedMs by remember { mutableStateOf(MyVoicePolicy.durationMsFromWav(sampleFile)) }
    var consent by remember { mutableStateOf(false) }
    var displayName by remember { mutableStateOf("صوتي") }
    var enrollmentSecret by remember { mutableStateOf("") }
    var localStatus by remember { mutableStateOf("") }
    var showDeleteConfirm by remember { mutableStateOf(false) }

    fun refreshSampleStatus(messageWhenReady: String = "العينة جاهزة للإنشاء") {
        sampleFile = recorder.sampleFile(context).takeIf { it.isFile }
        elapsedMs = MyVoicePolicy.durationMsFromWav(sampleFile)
        localStatus = if (MyVoicePolicy.sampleReady(sampleFile)) {
            messageWhenReady
        } else {
            "العينة غير متوافقة: استخدم WAV • 16 kHz • Mono • PCM 16-bit • مدة 15–90 ثانية"
        }
    }

    fun beginRecording() {
        onBeforeRecordOrImport()
        val result = recorder.start(context) { completed ->
            scope.launch {
                recording = false
                sampleFile = completed?.takeIf { it.isFile }
                elapsedMs = MyVoicePolicy.durationMsFromWav(sampleFile)
                localStatus = if (MyVoicePolicy.sampleReady(sampleFile)) {
                    "العينة المسجلة جاهزة للإنشاء"
                } else {
                    "العينة أقصر من 15 ثانية؛ سجّل عينة أطول"
                }
            }
        }
        when (result) {
            MyVoiceSampleRecorder.StartResult.STARTED -> {
                recording = true
                sampleFile = null
                elapsedMs = 0L
                localStatus = "تحدث بصوت طبيعي وفي مكان هادئ"
            }
            MyVoiceSampleRecorder.StartResult.PERMISSION_REQUIRED -> localStatus = "يحتاج My Voice إذن الميكروفون"
            MyVoiceSampleRecorder.StartResult.AUDIO_UNAVAILABLE -> localStatus = "تعذر فتح الميكروفون للتسجيل"
            MyVoiceSampleRecorder.StartResult.ALREADY_RECORDING -> Unit
        }
    }

    val micPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) beginRecording() else localStatus = "تم رفض إذن الميكروفون"
    }

    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        onBeforeRecordOrImport()
        scope.launch {
            localStatus = "جارٍ فحص العينة المستوردة…"
            val result = withContext(Dispatchers.IO) { recorder.importWav(context, uri) }
            when (result) {
                MyVoiceSampleRecorder.ImportResult.IMPORTED -> refreshSampleStatus("تم استيراد العينة وهي جاهزة للإنشاء")
                MyVoiceSampleRecorder.ImportResult.TOO_LARGE -> {
                    sampleFile = recorder.sampleFile(context).takeIf { it.isFile }
                    elapsedMs = MyVoicePolicy.durationMsFromWav(sampleFile)
                    localStatus = "الملف أكبر من الحد المسموح لعينة My Voice"
                }
                MyVoiceSampleRecorder.ImportResult.INVALID_WAV -> {
                    sampleFile = recorder.sampleFile(context).takeIf { it.isFile }
                    elapsedMs = MyVoicePolicy.durationMsFromWav(sampleFile)
                    localStatus = "الملف غير متوافق؛ المطلوب WAV 16 kHz Mono PCM 16-bit لمدة 15–90 ثانية"
                }
                MyVoiceSampleRecorder.ImportResult.READ_FAILED -> {
                    sampleFile = recorder.sampleFile(context).takeIf { it.isFile }
                    elapsedMs = MyVoicePolicy.durationMsFromWav(sampleFile)
                    localStatus = "تعذر قراءة ملف العينة"
                }
            }
        }
    }

    fun requestRecording() {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            beginRecording()
        } else {
            micPermission.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    LaunchedEffect(recording) {
        while (recording) {
            elapsedMs = recorder.durationMs
            delay(250L)
        }
    }

    LaunchedEffect(credential.token) {
        if (credential.exists) {
            enrollmentSecret = ""
            consent = false
            sampleFile = recorder.sampleFile(context).takeIf { it.isFile }
            elapsedMs = MyVoicePolicy.durationMsFromWav(sampleFile)
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            if (recorder.isRecording) recorder.stop(context)
        }
    }

    val sampleReady = MyVoicePolicy.sampleReady(sampleFile) &&
        (sampleFile?.length() ?: Long.MAX_VALUE) <= maxSampleBytes.coerceAtMost(MyVoicePolicy.MAX_SAMPLE_BYTES)
    val canCreate = MyVoicePolicy.canEnroll(
        cloudAvailable = cloudAvailable,
        sampleReady = sampleReady,
        consent = consent,
        enrollmentSecret = enrollmentSecret
    ) && !busy

    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(AionRadii.Card),
        color = AionColors.SurfaceMuted,
        border = BorderStroke(1.dp, AionColors.Border)
    ) {
        Column(
            modifier = Modifier.padding(AionSpacing.Md),
            verticalArrangement = Arrangement.spacedBy(AionSpacing.Sm)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Outlined.Mic, contentDescription = null, tint = AionColors.IntelligenceSoft)
                Spacer(Modifier.width(AionSpacing.Sm))
                Column(modifier = Modifier.weight(1f)) {
                    Text("My Voice", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold)
                    Text(
                        when {
                            credential.usable && cloudAvailable ->
                                "صوتك الشخصي جاهز للاستخدام${if (provider.isNotBlank()) " • $provider" else ""}"
                            credential.exists ->
                                "يوجد اعتماد صوت محفوظ لكنه غير قابل للاستخدام حاليًا"
                            cloudAvailable ->
                                "أنشئ صوتًا شخصيًا من تسجيلك أنت فقط"
                            else ->
                                "التسجيل والاستيراد محليان؛ الإنشاء السحابي معطل حتى تُفعّل My Voice في AION Cloud"
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = AionColors.TextSecondary
                    )
                }
            }

            if (credential.usable && cloudAvailable) {
                FilterChip(
                    selected = selected,
                    onClick = onSelect,
                    label = { Text(if (selected) "صوتي • مستخدم الآن" else "استخدم صوتي") }
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(AionSpacing.Sm),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedButton(
                    onClick = {
                        if (recording) {
                            scope.launch {
                                val completed = withContext(Dispatchers.IO) { recorder.stop(context) }
                                recording = false
                                sampleFile = completed?.takeIf { it.isFile }
                                elapsedMs = MyVoicePolicy.durationMsFromWav(sampleFile)
                                localStatus = if (MyVoicePolicy.sampleReady(sampleFile)) {
                                    "العينة المسجلة جاهزة للإنشاء"
                                } else {
                                    "سجل 15 ثانية على الأقل"
                                }
                            }
                        } else {
                            requestRecording()
                        }
                    },
                    enabled = !busy,
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(if (recording) Icons.Outlined.Stop else Icons.Outlined.Mic, contentDescription = null)
                    Spacer(Modifier.width(AionSpacing.Xs))
                    Text(if (recording) "إيقاف ${MyVoicePolicy.formatDuration(elapsedMs)}" else "تسجيل")
                }

                OutlinedButton(
                    onClick = { importLauncher.launch(arrayOf("audio/wav", "audio/x-wav", "audio/wave", "audio/*")) },
                    enabled = !busy && !recording,
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Outlined.Description, contentDescription = null)
                    Spacer(Modifier.width(AionSpacing.Xs))
                    Text("استيراد WAV")
                }
            }

            if (sampleFile?.isFile == true && !recording) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        "العينة: ${MyVoicePolicy.formatDuration(elapsedMs)} • ${(sampleFile?.length() ?: 0L) / 1024L} KB",
                        modifier = Modifier.weight(1f),
                        style = MaterialTheme.typography.bodySmall,
                        color = if (sampleReady) AionPurpleSoft else MaterialTheme.colorScheme.error
                    )
                    TextButton(
                        enabled = !busy,
                        onClick = {
                            recorder.deleteSample(context)
                            sampleFile = null
                            elapsedMs = 0L
                            localStatus = "تم حذف العينة المحلية"
                        }
                    ) { Text("حذف العينة") }
                }
            }

            if (localStatus.isNotBlank()) {
                Text(localStatus, style = MaterialTheme.typography.bodySmall, color = AionColors.TextTertiary)
            }

            if (!credential.exists) {
                OutlinedTextField(
                    value = displayName,
                    onValueChange = { displayName = it.take(48) },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("اسم الصوت") },
                    singleLine = true
                )
                if (cloudAvailable) {
                    OutlinedTextField(
                        value = enrollmentSecret,
                        onValueChange = { enrollmentSecret = it.take(128) },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("رمز إعداد My Voice") },
                        supportingText = { Text("رمز المالك لنسخة Alpha؛ يُستخدم مرة واحدة ولا يتم حفظه على الجهاز.") },
                        visualTransformation = PasswordVisualTransformation(),
                        singleLine = true
                    )
                }
                Row(verticalAlignment = Alignment.Top) {
                    Checkbox(checked = consent, onCheckedChange = { consent = it })
                    Text(
                        "أؤكد أن هذه العينة لصوتي أنا شخصيًا، وأوافق على إرسالها إلى AION Cloud ومزود الصوت لإنشاء صوت شخصي. لا أستخدم تسجيل شخص آخر. بعد نجاح الإنشاء يحذف AION ملف العينة المحلي تلقائيًا.",
                        modifier = Modifier.weight(1f),
                        style = MaterialTheme.typography.bodySmall,
                        color = AionColors.TextSecondary
                    )
                }
                Button(
                    onClick = {
                        sampleFile?.takeIf { it.isFile }?.let {
                            onCreate(it, displayName, enrollmentSecret, consent)
                        }
                    },
                    enabled = canCreate,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(if (busy) "جارٍ إنشاء My Voice…" else "إنشاء My Voice")
                }
            } else {
                OutlinedButton(
                    onClick = { showDeleteConfirm = true },
                    enabled = !busy,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Outlined.DeleteOutline, contentDescription = null)
                    Spacer(Modifier.width(AionSpacing.Sm))
                    Text(if (busy) "جارٍ الحذف…" else "حذف My Voice نهائيًا")
                }
            }

            Text(
                statusLabel,
                style = MaterialTheme.typography.bodySmall,
                color = if (
                    statusLabel.startsWith("تعذر") ||
                    statusLabel.startsWith("يجب") ||
                    statusLabel.contains("غير قابل")
                ) MaterialTheme.colorScheme.error else AionColors.TextTertiary
            )
            Text(
                "العينة المقبولة: WAV • 16 kHz • Mono • PCM 16-bit • 15–90 ثانية. لا يدخل مفتاح مزود الصوت إلى APK، واعتماد My Voice محفوظ مشفرًا عبر Android Keystore.",
                style = MaterialTheme.typography.bodySmall,
                color = AionColors.TextTertiary
            )
        }
    }

    if (showDeleteConfirm) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirm = false },
            title = { Text("حذف My Voice؟") },
            text = {
                Text("سيطلب AION حذف النسخة الصوتية من مزود الصوت ثم يمسح الاعتماد من هذا الجهاز. لا يمكن التراجع عن الحذف.")
            },
            confirmButton = {
                TextButton(onClick = {
                    showDeleteConfirm = false
                    onDeleteRemote()
                }) { Text("حذف نهائي") }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirm = false }) { Text("إلغاء") }
            }
        )
    }
}

@Composable
private fun VoiceTuningSlider(
    label: String,
    value: Float,
    valueText: String,
    valueRange: ClosedFloatingPointRange<Float>,
    steps: Int,
    onValueChange: (Float) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(label, style = MaterialTheme.typography.labelMedium, modifier = Modifier.weight(1f))
            Text(valueText, style = MaterialTheme.typography.bodySmall, color = AionColors.TextSecondary)
        }
        Slider(
            value = value.coerceIn(valueRange.start, valueRange.endInclusive),
            onValueChange = onValueChange,
            valueRange = valueRange,
            steps = steps
        )
    }
}

@Composable
private fun CapabilityDialog(capability: AionCapability, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        icon = { Icon(capability.icon(), contentDescription = null, tint = AionPurple) },
        title = { Text(capability.title) },
        text = {
            Column {
                Text(capability.description)
                Spacer(Modifier.height(12.dp))
                Text("الحالة: ${capability.state.label()}", color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (capability.state != CapabilityState.READY) {
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "البنية الأساسية موجودة وسيتم ربط التنفيذ الكامل ضمن خارطة AION Master.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("حسنًا") } }
    )
}

private fun CapabilityState.label(): String = when (this) {
    CapabilityState.READY -> "جاهز"
    CapabilityState.FOUNDATION -> "البنية جاهزة — الربط مستمر"
    CapabilityState.PLANNED -> "مخطط له"
}

private fun AionCapability.icon(): ImageVector = when (key) {
    "agent" -> Icons.Outlined.SmartToy
    "memory" -> Icons.Outlined.Memory
    "files" -> Icons.Outlined.Folder
    "voice" -> Icons.Outlined.Mic
    "search" -> Icons.Outlined.Search
    "tools" -> Icons.Outlined.Build
    else -> Icons.Outlined.Psychology
}

