package com.aion.mobile.core.orchestration

/**
 * عقد AION Intelligence Core v1.
 *
 * هذه الطبقة لا تنفذ الأدوات بعد. Memory Engine v1 يجهز سياقًا محليًا scoped قبل الإرسال،
 * بينما يوحّد هذا العقد قرار التشغيل القادم
 * من AION Cloud وحصر metadata الآمنة التي يمكن للتطبيق حفظها أو استخدامها في التقييم.
 * لا يجب أن يحتوي trace على نص المستخدم أو محتوى الذاكرة أو مفاتيح المزودات.
 */
object AionOrchestratorContract {
    const val VERSION = 1

    private val traceIdPattern = Regex("^[0-9a-fA-F-]{16,64}$")
    private val searchReasons = setOf(
        "research-mode",
        "forced",
        "explicit-request",
        "freshness-signal",
        "not-required"
    )
    private val memoryPolicies = setOf("memory-v1-local-scoped", "provided-context-only", "none")
    private val toolRoutes = setOf("legacy-web-search", "none")
    private val responseProfiles = setOf("concise", "balanced", "deep", "research")

    fun isCompatible(contract: Int): Boolean = contract == VERSION

    fun normalizeTraceId(value: String?): String =
        value.orEmpty().trim().takeIf { traceIdPattern.matches(it) }.orEmpty()

    fun normalizeSearchReason(value: String?): String =
        value.orEmpty().trim().lowercase().takeIf { it in searchReasons }.orEmpty()

    fun normalizeMemoryPolicy(value: String?): String =
        value.orEmpty().trim().lowercase().takeIf { it in memoryPolicies }.orEmpty()

    fun normalizeToolRoute(value: String?): String =
        value.orEmpty().trim().lowercase().takeIf { it in toolRoutes }.orEmpty()

    fun normalizeResponseProfile(value: String?): String =
        value.orEmpty().trim().lowercase().takeIf { it in responseProfiles }.orEmpty()
}
