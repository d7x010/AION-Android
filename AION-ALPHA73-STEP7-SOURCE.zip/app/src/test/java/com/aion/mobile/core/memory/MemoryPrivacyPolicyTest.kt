package com.aion.mobile.core.memory

import org.junit.Assert.*
import org.junit.Test

class MemoryPrivacyPolicyTest {
    @Test fun temporaryChatDisablesReadAndWrite() {
        val result = MemoryPrivacyPolicy.evaluate(MemoryPrivacySettings(), ConversationMemoryMode.TEMPORARY, hasProject = true)
        assertFalse(result.memoryEnabled)
        assertTrue(result.temporary)
        assertTrue(result.allowedScopes.isEmpty())
        assertFalse(result.allowAutomaticWrite)
        assertFalse(result.allowExplicitWrite)
    }

    @Test fun userCanDisableIndividualScopes() {
        val result = MemoryPrivacyPolicy.evaluate(
            MemoryPrivacySettings(allowUserScope = false, allowProjectScope = true, allowConversationScope = false),
            ConversationMemoryMode.NORMAL,
            hasProject = true
        )
        assertEquals(setOf(MemoryScope.PROJECT), result.allowedScopes)
    }

    @Test fun automaticMemoryStaysOptIn() {
        val default = MemoryPrivacyPolicy.evaluate(MemoryPrivacySettings(), ConversationMemoryMode.NORMAL, false)
        assertFalse(default.allowAutomaticWrite)
    }
}
