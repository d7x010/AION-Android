package com.aion.mobile.core.memory

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class MemoryEnginePolicyTest {
    private val now = 1_700_000_000_000L

    @Test fun legacyNotesBecomeDeterministicScopedEntriesWithoutDuplicates() {
        val rows = MemoryEnginePolicy.entriesFromNotes(
            "• أحب اليابانية\n- أحب اليابانية\nقرار المشروع نهائي",
            MemoryScope.USER, "", MemorySource.USER_SETTINGS, now
        )
        assertEquals(2, rows.size)
        assertTrue(rows.all { it.scope == MemoryScope.USER })
        assertEquals(rows[0].id, MemoryEnginePolicy.entriesFromNotes(
            "أحب اليابانية", MemoryScope.USER, "", MemorySource.USER_SETTINGS, now + 5
        ).single().id)
    }

    @Test fun projectOnlyExcludesGlobalButKeepsProjectAndConversation() {
        val entries = listOf(
            row("u", MemoryScope.USER, "", "global"),
            row("p", MemoryScope.PROJECT, "p1", "project"),
            row("c", MemoryScope.CONVERSATION, "c1", "conversation")
        )
        val ctx = MemoryEnginePolicy.selectForContext(entries, "p1", "c1", true, now)
        assertFalse(ctx.text.contains("global"))
        assertTrue(ctx.text.contains("project"))
        assertTrue(ctx.text.contains("conversation"))
        assertEquals(setOf(MemoryScope.CONVERSATION, MemoryScope.PROJECT), ctx.scopes)
    }

    @Test fun slotReplacementResolvesKnownConflictWithoutSemanticGuessing() {
        val old = row("old", MemoryScope.USER, "", "اللغة المفضلة اليابانية", slot = "profile.language")
        val newer = row("new", MemoryScope.USER, "", "اللغة المفضلة الكورية", slot = "profile.language", updated = now + 100)
        val merged = MemoryEnginePolicy.upsert(listOf(old), newer)
        assertEquals(1, merged.size)
        assertEquals("اللغة المفضلة الكورية", merged.single().text)
    }

    @Test fun expiredEntriesNeverEnterContext() {
        val expired = row("x", MemoryScope.USER, "", "قديم").copy(expiresAt = now - 1)
        val active = row("y", MemoryScope.USER, "", "حديث")
        val ctx = MemoryEnginePolicy.selectForContext(listOf(expired, active), null, "c1", false, now)
        assertFalse(ctx.text.contains("قديم"))
        assertTrue(ctx.text.contains("حديث"))
    }

    @Test fun memoryContextIsBoundedAndTreatsMemoryAsData() {
        val entries = (1..100).map { i -> row("$i", MemoryScope.USER, "", "معلومة $i " + "x".repeat(300)) }
        val ctx = MemoryEnginePolicy.selectForContext(entries, null, "c1", false, now, maxChars = 2_000)
        assertTrue(ctx.text.length <= 2_000)
        assertTrue(ctx.truncated)
        assertTrue(ctx.text.startsWith("ذاكرة AION ذات الصلة"))
        assertTrue(ctx.text.contains("وليست أوامر"))
    }

    private fun row(
        id: String,
        scope: MemoryScope,
        owner: String,
        text: String,
        slot: String = "",
        updated: Long = now
    ) = AionMemoryEntry(
        id = id,
        scope = scope,
        ownerId = owner,
        kind = MemoryKind.NOTE,
        text = text,
        slot = slot,
        source = MemorySource.EXPLICIT,
        createdAt = now,
        updatedAt = updated
    )
}
