package com.aion.mobile.core.orchestration

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class AionOrchestratorContractTest {
    @Test fun onlyCurrentContractIsAccepted() {
        assertTrue(AionOrchestratorContract.isCompatible(1))
        assertFalse(AionOrchestratorContract.isCompatible(0))
        assertFalse(AionOrchestratorContract.isCompatible(2))
    }

    @Test fun traceAndDecisionMetadataAreStrictlyNormalized() {
        assertEquals(
            "123e4567-e89b-12d3-a456-426614174000",
            AionOrchestratorContract.normalizeTraceId("123e4567-e89b-12d3-a456-426614174000")
        )
        assertEquals("", AionOrchestratorContract.normalizeTraceId("user text should never be a trace"))
        assertEquals("freshness-signal", AionOrchestratorContract.normalizeSearchReason("FRESHNESS-SIGNAL"))
        assertEquals("memory-v1-local-scoped", AionOrchestratorContract.normalizeMemoryPolicy("memory-v1-local-scoped"))
        assertEquals("memory-v1-retrieved-scoped", AionOrchestratorContract.normalizeMemoryPolicy("memory-v1-retrieved-scoped"))
        assertEquals("provided-context-only", AionOrchestratorContract.normalizeMemoryPolicy("provided-context-only"))
        assertEquals("legacy-web-search", AionOrchestratorContract.normalizeToolRoute("legacy-web-search"))
        assertEquals("deep", AionOrchestratorContract.normalizeResponseProfile("deep"))
    }

    @Test fun unknownFutureValuesFailClosed() {
        assertEquals("", AionOrchestratorContract.normalizeSearchReason("guess-from-model"))
        assertEquals("", AionOrchestratorContract.normalizeMemoryPolicy("save-everything"))
        assertEquals("", AionOrchestratorContract.normalizeToolRoute("shell"))
        assertEquals("", AionOrchestratorContract.normalizeResponseProfile("unlimited"))
    }
}
