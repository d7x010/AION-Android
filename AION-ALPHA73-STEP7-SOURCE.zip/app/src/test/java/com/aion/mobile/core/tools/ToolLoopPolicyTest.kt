package com.aion.mobile.core.tools

import org.junit.Assert.assertEquals
import org.junit.Test

class ToolLoopPolicyTest {
    @Test fun keepsExplicitOrderAndDeduplicates() {
        val plan = ToolLoopPolicy.plan(listOf("web.search", "calculator", "web.search"))
        assertEquals(listOf("web.search", "calculator"), plan.steps.map { it.toolId })
        assertEquals(ToolLoopPolicy.MAX_STEPS, plan.maxSteps)
    }

    @Test fun ignoresUnknownTools() {
        val plan = ToolLoopPolicy.plan(listOf("shell", "calculator"))
        assertEquals(listOf("calculator"), plan.steps.map { it.toolId })
    }
}
