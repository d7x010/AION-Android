# AION α7 — ملف انتقال مختصر

المرجع الحاكم لهذه الجولة هو مشروع Android في هذا الأرشيف مع Worker داخل `cloudflare/aion-core`.

## ما تغير جوهريًا
- Streaming حقيقي على Workers AI.
- مرفقات حقيقية وقراءة مستندات/صور.
- Multi-conversation + بحث محلي في السجل + مسودات مستقلة.
- ربط مهام الخلفية بمعرّف المحادثة.
- اختيار الوضع في Top Bar.
- Code blocks + copy.
- Voice RMS/TTS محسّن.
- ذاكرة محلية وتعليمات شخصية صريحة.
- Routing: Auto/Fast=GLM 4.7 Flash، Deep=GPT-OSS-120B، Research=Gemma 4، مع fallback.

## لا تعتبر مكتملًا
- Full-duplex voice الحقيقي.
- Agents/Projects كاملة.
- أدوات/Agent runtime كامل متعدد الأدوات.
- ذاكرة تلقائية شاملة.

## بوابة البناء
Gradle tasks المطلوبة: `:app:testDebugUnitTest :app:lintDebug :app:assembleDebug`. لا تعتمد APK قبل نجاحها.


## خط أساس Step 6 النهائي
- الإصدار: AION 2.0.0-alpha7.3-dev16 / versionCode 30.
- Step 6.1–6.6 مكتملة تكامليًا عند نجاح Gate النهائية.
- Claude/Gemini/Grok مزودات تنفيذ فعلية عند تهيئة مفاتيحها/model IDs على AION Cloud.
- external providers pinned بلا cross-provider fallback صامت.
- Workers AI fallback داخلي فقط وقبل أول token.
- provider-neutral context يحكم التبديل بين النماذج داخل نفس المحادثة.
- Voice/My Voice/AION Live تبقى على عقود Step 4/5 دون تغيير.

## CURRENT — Step 7.5 + 7.6 / dev20
- Step 6 مغلق رسميًا عند dev16/code30.
- Step 7.1 Orchestrator Contract مغلق رسميًا عند dev17/code31.
- Step 7.2 Memory Engine v1 مغلق رسميًا عند dev18/code32، Run 34439898717 أخضر.
- 7.3 + 7.4 أغلقتا رسميًا على dev19/code33 (Gate Run 34441915894).
- الدفعة الحالية تجمع 7.5 Memory Controls & Privacy + 7.6 Universal Tool Router في dev20/code34.
- Context Engine يستخدم budget بالحجم/estimated tokens، recent verbatim + opening anchor + extractive digest حرفي للمحذوف، بلا generated summary.
- project conversation context صار منفصلًا عن long-term memory.
- Memory retrieval يطبق hard scope isolation ثم ranking محلي query-aware؛ لا embeddings ولا auto-save عام بعد.
- Orchestrator memory policy أصبحت `memory-v1-retrieved-scoped` عند إرفاق ذاكرة مسترجعة.
- لا تعلن 7.5/7.6 CLOSED قبل GitHub Gate لـdev20/code34.


## Step 7 current
- 7.1 Orchestrator Contract: CLOSED/GREEN on dev17/code31.
- 7.2 Memory Engine v1: CLOSED/GREEN on dev18/code32.
- 7.3 + 7.4 Context Engine + Memory Retrieval: CLOSED/GREEN on dev19/code33.
- 7.5 + 7.6 Memory Privacy + Tool Router: local PASS on dev20/code34; GitHub Gate pending.
- New cadence after 7.2: two related roadmap points per development batch/Gate.
