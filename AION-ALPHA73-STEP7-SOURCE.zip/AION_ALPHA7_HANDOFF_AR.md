# AION α7 — ملف انتقال مختصر

المرجع الحاكم لهذه الجولة هو مشروع Android في هذا الأرشيف مع Worker داخل `cloudflare/aion-core`.

## ما تغير جوهريًا
- Streaming حقيقي على Workers AI.
- مرفقات حقيقية وقراءة مستندات/صور.
- Multi-conversation + بحث محلي في السجل + مسودات مستقلة.
- ربط مهام الخلفية بمعرّف المحادثة.
- اختيار الوضع في Top Bar.
- Code blocks + copy.
- Voice RMS/TTS محسّن.
- ذاكرة محلية وتعليمات شخصية صريحة.
- Routing: Auto/Fast=GLM 4.7 Flash، Deep=GPT-OSS-120B، Research=Gemma 4، مع fallback.

## لا تعتبر مكتملًا
- Full-duplex voice الحقيقي.
- Agents/Projects كاملة.
- أدوات/Agent runtime كامل متعدد الأدوات.
- ذاكرة تلقائية شاملة.

## بوابة البناء
Gradle tasks المطلوبة: `:app:testDebugUnitTest :app:lintDebug :app:assembleDebug`. لا تعتمد APK قبل نجاحها.


## خط أساس Step 6 النهائي
- الإصدار: AION 2.0.0-alpha7.3-dev16 / versionCode 30.
- Step 6.1–6.6 مكتملة تكامليًا عند نجاح Gate النهائية.
- Claude/Gemini/Grok مزودات تنفيذ فعلية عند تهيئة مفاتيحها/model IDs على AION Cloud.
- external providers pinned بلا cross-provider fallback صامت.
- Workers AI fallback داخلي فقط وقبل أول token.
- provider-neutral context يحكم التبديل بين النماذج داخل نفس المحادثة.
- Voice/My Voice/AION Live تبقى على عقود Step 4/5 دون تغيير.

## CURRENT — Step 7.2 Memory Engine v1 / dev18
- Step 6 مغلق رسميًا عند dev16/code30، Final Closure Run 34432888644 أخضر.
- Step 7.1 Orchestrator Contract مغلق رسميًا عند dev17/code31، Step 7 Gate Run 34438323198 أخضر.
- Step 7.2 يبني Memory Engine v1 محليًا فوق Orchestrator: structured entries + scopes user/project/conversation + kinds + sources + confidence/expiry/slots.
- الذاكرة العامة الحالية وذاكرة المشاريع تُزامنان إلى الفهرس الجديد بدون فقد البيانات، مع بقاء واجهة المستخدم الحالية متوافقة.
- projectOnlyMemory يمنع global USER memory داخل المشروع ويُبقي project/conversation scoped memory.
- Memory v1 لا تحفظ كل رسالة تلقائيًا، ولا تستخدم semantic/vector retrieval بعد، ولا تضيف شاشة إدارة جديدة.
- Orchestrator يعلن `memory-v1-local-scoped` عند إرفاق سياق الذاكرة و`none` عند غيابه.
- لا تعلن 7.2 CLOSED قبل GitHub Gate لـdev18/code32.


## Step 7 current
- 7.1 Orchestrator Contract: CLOSED/GREEN on dev17/code31.
- 7.2 Memory Engine v1: local PASS on dev18/code32; GitHub Gate pending.
- Do not claim 7.2 closed until the Step 7 Gate is green.
