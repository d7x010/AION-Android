import assert from "node:assert/strict";
import worker from "./src/index.js";

function makePcm16MonoWav(seconds = 15) {
  const sampleRate = 16_000;
  const dataBytes = sampleRate * 2 * seconds;
  const bytes = new Uint8Array(44 + dataBytes);
  const view = new DataView(bytes.buffer);
  const ascii = (offset, text) => {
    for (let i = 0; i < text.length; i += 1) bytes[offset + i] = text.charCodeAt(i);
  };
  ascii(0, "RIFF");
  view.setUint32(4, 36 + dataBytes, true);
  ascii(8, "WAVE");
  ascii(12, "fmt ");
  view.setUint32(16, 16, true);
  view.setUint16(20, 1, true);
  view.setUint16(22, 1, true);
  view.setUint32(24, sampleRate, true);
  view.setUint32(28, sampleRate * 2, true);
  view.setUint16(32, 2, true);
  view.setUint16(34, 16, true);
  ascii(36, "data");
  view.setUint32(40, dataBytes, true);
  return bytes;
}

function sseStream(parts) {
  const encoder = new TextEncoder();
  return new ReadableStream({
    start(controller) {
      for (const part of parts) controller.enqueue(encoder.encode(part));
      controller.close();
    },
  });
}

async function testTrueStreaming() {
  const calls = [];
  const env = {
    AI: {
      run: async (model, payload) => {
        calls.push({ model, payload });
        assert.equal(payload.stream, true);
        return sseStream([
          'data: {"response":"مرح"}\n\n',
          'data: {"response":"مرحبا"}\n\n',
          'data: [DONE]\n\n',
        ]);
      },
      toMarkdown: async () => { throw new Error("not expected"); },
    },
  };
  const request = new Request("https://aion.test/v1/chat/stream", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ mode: "auto", messages: [{ role: "user", content: "هلا" }] }),
  });
  const response = await worker.fetch(request, env);
  const text = await response.text();
  assert.equal(response.status, 200);
  assert.match(text, /event: delta/);
  assert.match(text, /"text":"مرح"/);
  assert.match(text, /"text":"با"/);
  assert.match(text, /"trueStreaming":true/);
  assert.equal(calls.length, 1);
}

async function testTextAttachmentContext() {
  let capturedMessages;
  const env = {
    AI: {
      run: async (_model, payload) => {
        capturedMessages = payload.messages;
        return { response: "قرأت الملف" };
      },
      toMarkdown: async () => { throw new Error("text files should decode locally"); },
    },
  };
  const data = Buffer.from("alpha beta gamma", "utf8").toString("base64");
  const request = new Request("https://aion.test/v1/chat", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({
      mode: "deep",
      messages: [{
        role: "user",
        content: "حلل الملف",
        attachments: [{ name: "notes.txt", mimeType: "text/plain", kind: "FILE", sizeBytes: 16, data }],
      }],
    }),
  });
  const response = await worker.fetch(request, env);
  const body = await response.json();
  assert.equal(response.status, 200);
  assert.equal(body.response, "قرأت الملف");
  assert.ok(capturedMessages.some((m) => m.content.includes("alpha beta gamma")));
}

async function testBinaryAttachmentConversion() {
  let converted = false;
  let capturedMessages;
  const env = {
    AI: {
      run: async (_model, payload) => {
        capturedMessages = payload.messages;
        return { response: "تم" };
      },
      toMarkdown: async (input) => {
        converted = true;
        assert.equal(input.name, "sample.pdf");
        assert.equal(input.blob.type, "application/pdf");
        return { name: "sample.pdf", format: "markdown", data: "# عنوان\nمحتوى PDF" };
      },
    },
  };
  const data = Buffer.from("fake-pdf", "utf8").toString("base64");
  const request = new Request("https://aion.test/v1/chat", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({
      messages: [{ role: "user", content: "", attachments: [{ name: "sample.pdf", mimeType: "application/pdf", kind: "FILE", sizeBytes: 8, data }] }],
    }),
  });
  const response = await worker.fetch(request, env);
  const body = await response.json();
  assert.equal(body.response, "تم");
  assert.equal(converted, true);
  assert.ok(capturedMessages.some((m) => m.content.includes("محتوى PDF")));
}

async function testStreamingFallbackBeforeFirstToken() {
  let call = 0;
  const env = {
    AI: {
      run: async () => {
        call += 1;
        if (call === 1) throw new Error("primary unavailable");
        return sseStream(['data: {"response":"بديل"}\n\ndata: [DONE]\n\n']);
      },
      toMarkdown: async () => ({ data: "" }),
    },
  };
  const response = await worker.fetch(new Request("https://aion.test/v1/chat/stream", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ messages: [{ role: "user", content: "اختبار" }] }),
  }), env);
  const text = await response.text();
  assert.equal(call, 2);
  assert.match(text, /بديل/);
  assert.match(text, /"providerKey":"workers-ai"/);
  assert.match(text, /"policy":"aion-workers-internal-fallback"/);
  assert.match(text, /"fallbackUsed":true/);
  assert.match(text, /"attempts":2/);
}


async function testModelRouting() {
  const models = [];
  const env = {
    AI: {
      run: async (model, payload) => {
        models.push({ model, payload });
        return { response: "ok" };
      },
      toMarkdown: async () => ({ data: "" }),
    },
  };

  const deep = await worker.fetch(new Request("https://aion.test/v1/chat", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ mode: "deep", messages: [{ role: "user", content: "حلل بعمق" }] }),
  }), env);
  assert.equal(deep.status, 200);
  assert.equal(models.at(-1).model, "@cf/openai/gpt-oss-120b");
  assert.equal(models.at(-1).payload.max_tokens, 8000);

  const auto = await worker.fetch(new Request("https://aion.test/v1/chat", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ mode: "auto", messages: [{ role: "user", content: "اشرح لي هذه الفكرة" }] }),
  }), env);
  assert.equal(auto.status, 200);
  assert.equal(models.at(-1).model, "@cf/qwen/qwen3.8-27b");
  assert.equal(models.at(-1).payload.reasoning_effort, "medium");

  const greeting = await worker.fetch(new Request("https://aion.test/v1/chat", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ mode: "auto", messages: [{ role: "user", content: "هلا" }] }),
  }), env);
  assert.equal(greeting.status, 200);
  assert.equal(models.at(-1).model, "@cf/zai-org/glm-4.7-flash");

  const research = await worker.fetch(new Request("https://aion.test/v1/chat", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ mode: "research", messages: [{ role: "user", content: "بحث" }] }),
  }), { ...env, FIRECRAWL_API_KEY: undefined });
  assert.equal(research.status, 200);
  assert.equal(models.at(-1).model, "@cf/qwen/qwen3.8-27b");
  assert.deepEqual(models.at(-1).payload.web_search_options, {});
}




async function testNativeVisionRouting() {
  let capturedModel = null;
  let capturedMessages = null;
  const env = {
    AI: {
      run: async (model, payload) => {
        capturedModel = model;
        capturedMessages = payload.messages;
        return { response: "قطة" };
      },
      toMarkdown: async () => { throw new Error("image should not use markdown conversion"); },
    },
  };
  const imageData = Buffer.from("fake-image", "utf8").toString("base64");
  const response = await worker.fetch(new Request("https://aion.test/v1/chat", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({
      mode: "auto",
      messages: [{
        role: "user",
        content: "ما هذه الصورة؟",
        attachments: [{ name: "cat.jpg", mimeType: "image/jpeg", kind: "IMAGE", sizeBytes: 10, data: imageData }],
      }],
    }),
  }), env);
  assert.equal(response.status, 200);
  assert.equal(capturedModel, "@cf/qwen/qwen3.8-27b");
  const last = capturedMessages.at(-1);
  assert.ok(Array.isArray(last.content));
  assert.equal(last.content[0].type, "text");
  assert.equal(last.content[1].type, "image_url");
  assert.match(last.content[1].image_url.url, /^data:image\/jpeg;base64,/);
}

async function testNoFallbackAfterPartialToken() {
  let calls = 0;
  const encoder = new TextEncoder();
  const env = {
    AI: {
      run: async () => {
        calls += 1;
        return new ReadableStream({
          start(controller) {
            controller.enqueue(encoder.encode('data: {"response":"جزء"}\n\n'));
            controller.enqueue(encoder.encode('data: {bad-json}\n\n'));
            controller.close();
          },
        });
      },
      toMarkdown: async () => ({ data: "" }),
    },
  };
  const response = await worker.fetch(new Request("https://aion.test/v1/chat/stream", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ mode: "fast", messages: [{ role: "user", content: "اختبار" }] }),
  }), env);
  const body = await response.text();
  assert.equal(calls, 1);
  assert.match(body, /جزء/);
  assert.match(body, /event: error/);
}

async function testPersonalizationAndLongContext() {
  let capturedMessages;
  const env = {
    AI: {
      run: async (_model, payload) => {
        capturedMessages = payload.messages;
        return { response: "ok" };
      },
      toMarkdown: async () => ({ data: "" }),
    },
  };
  const messages = Array.from({ length: 140 }, (_, i) => ({
    role: i % 2 === 0 ? "user" : "assistant",
    content: `message-${i}`,
  }));
  const response = await worker.fetch(new Request("https://aion.test/v1/chat", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({
      mode: "fast",
      customInstructions: "تكلم بالعربية فقط",
      memoryContext: "اسم المشروع AION",
      messages,
    }),
  }), env);
  assert.equal(response.status, 200);
  assert.ok(capturedMessages[0].content.includes("تكلم بالعربية فقط"));
  assert.ok(capturedMessages[0].content.includes("اسم المشروع AION"));
  assert.ok(capturedMessages.length <= 121); // system + up to 96 conversation messages
  assert.ok(capturedMessages.at(-1).content.includes("message-139"));
}



async function testLargeSingleMessageLimit() {
  let receivedLength = 0;
  const env = {
    AI: {
      run: async (_model, payload) => {
        receivedLength = payload.messages.at(-1).content.length;
        return { response: "ok" };
      },
      toMarkdown: async () => ({ data: "" }),
    },
  };
  const large = "س".repeat(30_000);
  const accepted = await worker.fetch(new Request("https://aion.test/v1/chat", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ mode: "fast", messages: [{ role: "user", content: large }] }),
  }), env);
  assert.equal(accepted.status, 200);
  assert.equal(receivedLength, 30_000);

  const rejected = await worker.fetch(new Request("https://aion.test/v1/chat", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ mode: "fast", messages: [{ role: "user", content: "س".repeat(48_001) }] }),
  }), env);
  assert.equal(rejected.status, 413);
}

async function testSessionAffinity() {
  let capturedOptions = null;
  const env = {
    AI: {
      run: async (_model, _payload, options) => {
        capturedOptions = options;
        return { response: "ok" };
      },
      toMarkdown: async () => ({ data: "" }),
    },
  };
  const response = await worker.fetch(new Request("https://aion.test/v1/chat", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({
      sessionId: "conversation-123",
      messages: [{ role: "user", content: "اختبار الكاش" }],
    }),
  }), env);
  const body = await response.json();
  assert.equal(response.status, 200);
  assert.equal(body.sessionAffinity, true);
  assert.equal(capturedOptions.extraHeaders["x-session-affinity"], "conversation-123");
}

async function testNativeSearchCitations() {
  const env = {
    AI: {
      run: async () => ({
        choices: [{
          message: {
            content: "خبر حديث",
            annotations: [{
              type: "url_citation",
              url_citation: { url: "https://example.com/news", title: "Example News" },
            }],
          },
        }],
      }),
      toMarkdown: async () => ({ data: "" }),
    },
  };
  const response = await worker.fetch(new Request("https://aion.test/v1/chat", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ mode: "research", messages: [{ role: "user", content: "ابحث عن خبر" }] }),
  }), env);
  const body = await response.json();
  assert.equal(response.status, 200);
  assert.equal(body.sources[0].url, "https://example.com/news");
  assert.equal(body.sources[0].title, "Example News");
}

async function testVoiceStatusAndUnavailableFallback() {
  const baseEnv = {
    AI: {
      run: async () => ({ response: "ok" }),
      toMarkdown: async () => ({ data: "" }),
    },
  };

  const statusResponse = await worker.fetch(new Request("https://aion.test/v1/status"), baseEnv);
  const statusBody = await statusResponse.json();
  assert.equal(statusResponse.status, 200);
  assert.equal(statusBody.voice.neural, false);
  assert.equal(statusBody.voice.localFallback, true);
  assert.equal(statusBody.voice.sampleRate, 24000);

  const ttsResponse = await worker.fetch(new Request("https://aion.test/v1/voice/tts", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ text: "مرحبا" }),
  }), baseEnv);
  const ttsBody = await ttsResponse.json();
  assert.equal(ttsResponse.status, 503);
  assert.equal(ttsBody.code, "neural_voice_unavailable");
  assert.equal(ttsBody.fallback, "android-tts");
}

async function testNeuralVoiceProxy() {
  const originalFetch = globalThis.fetch;
  let capturedUrl = "";
  let capturedHeaders = null;
  let capturedBody = null;
  try {
    globalThis.fetch = async (url, options) => {
      capturedUrl = String(url);
      capturedHeaders = options.headers;
      capturedBody = JSON.parse(options.body);
      return new Response(new Uint8Array([1, 2, 3, 4]), {
        status: 200,
        headers: { "content-type": "audio/pcm" },
      });
    };

    const env = {
      ELEVENLABS_API_KEY: "server-secret",
      AION_VOICE_ID: "voice-123",
      ELEVENLABS_MODEL_ID: "eleven_flash_v2_5",
      AI: {
        run: async () => ({ response: "ok" }),
        toMarkdown: async () => ({ data: "" }),
      },
    };

    const statusResponse = await worker.fetch(new Request("https://aion.test/v1/status"), env);
    const status = await statusResponse.json();
    assert.equal(status.voice.neural, true);
    assert.equal(status.voice.provider, "elevenlabs");

    const response = await worker.fetch(new Request("https://aion.test/v1/voice/tts", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ text: "أهلا بك في AION", profile: "calm" }),
    }), env);
    assert.equal(response.status, 200);
    assert.equal(response.headers.get("x-aion-audio-format"), "pcm_s16le");
    assert.equal(response.headers.get("x-aion-sample-rate"), "24000");
    assert.equal(response.headers.get("x-aion-voice-provider"), "elevenlabs");
    assert.match(capturedUrl, /\/v1\/text-to-speech\/voice-123\/stream\?output_format=pcm_24000$/);
    assert.equal(capturedHeaders["xi-api-key"], "server-secret");
    assert.equal(capturedBody.text, "أهلا بك في AION");
    assert.equal(capturedBody.model_id, "eleven_flash_v2_5");
    assert.equal(capturedBody.voice_settings.speed, 0.94);
    assert.deepEqual([...new Uint8Array(await response.arrayBuffer())], [1, 2, 3, 4]);
  } finally {
    globalThis.fetch = originalFetch;
  }
}

async function testNeuralVoiceCatalogAndTuning() {
  const originalFetch = globalThis.fetch;
  let capturedUrl = "";
  let capturedBody = null;
  try {
    globalThis.fetch = async (url, options) => {
      capturedUrl = String(url);
      capturedBody = JSON.parse(options.body);
      return new Response(new Uint8Array([10, 20, 30, 40]), {
        status: 200,
        headers: { "content-type": "audio/pcm" },
      });
    };

    const env = {
      ELEVENLABS_API_KEY: "server-secret",
      AION_VOICES_JSON: JSON.stringify([
        { key: "male_1", label: "AION Male", gender: "male", voiceId: "voice-male-secret" },
        { key: "female_1", label: "AION Female", gender: "female", voiceId: "voice-female-secret" },
      ]),
      AION_DEFAULT_VOICE_KEY: "female_1",
      AI: {
        run: async () => ({ response: "ok" }),
        toMarkdown: async () => ({ data: "" }),
      },
    };

    const statusResponse = await worker.fetch(new Request("https://aion.test/v1/status"), env);
    const status = await statusResponse.json();
    assert.equal(status.voice.neural, true);
    assert.equal(status.voice.defaultVoice, "female_1");
    assert.equal(status.voice.voices.length, 2);
    assert.equal(status.voice.voices[1].gender, "female");
    assert.equal(JSON.stringify(status.voice).includes("voice-female-secret"), false);

    const response = await worker.fetch(new Request("https://aion.test/v1/voice/tts", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        text: "مرحبا",
        voice: "female_1",
        profile: "expressive",
        settings: { speed: 9, expression: 1, clarity: -2 },
      }),
    }), env);

    assert.equal(response.status, 200);
    assert.equal(response.headers.get("x-aion-voice-key"), "female_1");
    assert.match(capturedUrl, /voice-female-secret/);
    assert.equal(capturedBody.voice_settings.speed, 1.2);
    assert.equal(capturedBody.voice_settings.style, 0.35);
    assert.equal(capturedBody.voice_settings.similarity_boost, 0);
  } finally {
    globalThis.fetch = originalFetch;
  }
}


async function testMyVoiceEnrollmentAndUse() {
  const originalFetch = globalThis.fetch;
  try {
    globalThis.fetch = async (url, options = {}) => {
      if (String(url).endsWith("/v1/voices/add") && options.method === "POST") {
        return new Response(JSON.stringify({ voice_id: "private-clone-123", requires_verification: false }), {
          status: 200,
          headers: { "content-type": "application/json" },
        });
      }
      if (String(url).includes("/v1/text-to-speech/private-clone-123/stream")) {
        return new Response(new Uint8Array([7, 8, 9, 10]), {
          status: 200,
          headers: { "content-type": "audio/pcm" },
        });
      }
      if (String(url).endsWith("/v1/voices/private-clone-123") && options.method === "DELETE") {
        return new Response(JSON.stringify({ status: "ok" }), {
          status: 200,
          headers: { "content-type": "application/json" },
        });
      }
      throw new Error(`unexpected upstream ${url}`);
    };

    const env = {
      ELEVENLABS_API_KEY: "server-secret",
      AION_MY_VOICE_ENROLLMENT_SECRET: "owner-enrollment-secret-123",
      AION_MY_VOICE_TOKEN_SECRET: "owner-token-secret-at-least-32-characters-123456",
      AI: {
        run: async () => ({ response: "ok" }),
        toMarkdown: async () => ({ data: "" }),
      },
    };

    const statusResponse = await worker.fetch(new Request("https://aion.test/v1/status"), env);
    const status = await statusResponse.json();
    assert.equal(status.voice.myVoice.available, true);
    assert.equal(status.voice.myVoice.requiresConsent, true);
    assert.equal(status.voice.myVoice.maxSampleBytes, 3600000);
    assert.equal(JSON.stringify(status).includes(env.AION_MY_VOICE_ENROLLMENT_SECRET), false);
    assert.equal(JSON.stringify(status).includes(env.AION_MY_VOICE_TOKEN_SECRET), false);

    const deniedForm = new FormData();
    deniedForm.append("name", "صوتي");
    deniedForm.append("consent", "self");
    deniedForm.append("sample", new Blob([makePcm16MonoWav(15)], { type: "audio/wav" }), "sample.wav");
    const denied = await worker.fetch(new Request("https://aion.test/v1/voice/my-voice", {
      method: "POST",
      headers: { "X-Aion-Voice-Enrollment": "wrong-secret" },
      body: deniedForm,
    }), env);
    assert.equal(denied.status, 403);

    const invalidForm = new FormData();
    invalidForm.append("name", "صوتي");
    invalidForm.append("consent", "self");
    invalidForm.append("sample", new Blob([new Uint8Array(1024)], { type: "audio/wav" }), "bad.wav");
    const invalid = await worker.fetch(new Request("https://aion.test/v1/voice/my-voice", {
      method: "POST",
      headers: { "X-Aion-Voice-Enrollment": env.AION_MY_VOICE_ENROLLMENT_SECRET },
      body: invalidForm,
    }), env);
    assert.equal(invalid.status, 415);

    const form = new FormData();
    form.append("name", "صوتي");
    form.append("consent", "self");
    form.append("sample", new Blob([makePcm16MonoWav(15)], { type: "audio/wav" }), "sample.wav");
    const createdResponse = await worker.fetch(new Request("https://aion.test/v1/voice/my-voice", {
      method: "POST",
      headers: { "X-Aion-Voice-Enrollment": env.AION_MY_VOICE_ENROLLMENT_SECRET },
      body: form,
    }), env);
    const created = await createdResponse.json();
    assert.equal(createdResponse.status, 200);
    assert.equal(created.key, "my_voice");
    assert.equal(created.requiresVerification, false);
    assert.match(String(created.token), /^v1\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+$/);
    assert.equal(String(created.token).includes("private-clone-123"), false);
    assert.equal(JSON.stringify(created).includes("private-clone-123"), false);

    const tts = await worker.fetch(new Request("https://aion.test/v1/voice/tts", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ text: "مرحبا", voice: "my_voice", myVoiceToken: created.token }),
    }), env);
    assert.equal(tts.status, 200);
    assert.equal(tts.headers.get("x-aion-voice-key"), "my_voice");
    assert.deepEqual([...new Uint8Array(await tts.arrayBuffer())], [7, 8, 9, 10]);

    const invalidTts = await worker.fetch(new Request("https://aion.test/v1/voice/tts", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ text: "مرحبا", voice: "my_voice", myVoiceToken: "v1.bad.bad" }),
    }), env);
    assert.equal(invalidTts.status, 403);

    const deleted = await worker.fetch(new Request("https://aion.test/v1/voice/my-voice", {
      method: "DELETE",
      headers: { "X-Aion-My-Voice": created.token },
    }), env);
    assert.equal(deleted.status, 200);
    assert.equal((await deleted.json()).deleted, true);
  } finally {
    globalThis.fetch = originalFetch;
  }
}

async function testMultiProviderFoundationCatalog() {
  const env = {
    ANTHROPIC_API_KEY: ["anthropic", "test", "key"].join("-"),
    AION_CLAUDE_MODEL: "claude-sonnet-5",
    GEMINI_API_KEY: ["gemini", "test", "key"].join("-"),
    AION_GEMINI_MODEL: "gemini-3.7-flash",
    XAI_API_KEY: ["xai", "test", "key"].join("-"),
    AION_GROK_MODEL: "grok-test-1",
    AI: {
      run: async () => ({ response: "ok" }),
      toMarkdown: async () => ({ data: "" }),
    },
  };

  const statusResponse = await worker.fetch(new Request("https://aion.test/v1/status"), env);
  const status = await statusResponse.json();
  assert.equal(statusResponse.status, 200);
  assert.equal(status.version, "7.3.0-dev21");
  assert.equal(status.models.contract, 2);
  assert.equal(status.models.routing.contract, 1);
  assert.equal(status.models.routing.explicitExternal, "pinned");
  assert.equal(status.models.routing.builtInFallback, "workers-ai-only");
  assert.equal(status.models.routing.crossProviderFailover, false);
  assert.equal(status.models.routing.continuity, "same-conversation-per-turn");
  assert.equal(status.models.context.contract, 1);
  assert.equal(status.models.context.canonicalHistory, "provider-neutral");
  assert.equal(status.models.context.mergeConsecutiveRoles, true);
  assert.equal(status.models.context.requireUserLast, true);
  assert.equal(status.models.context.crossModelSwitching, true);
  assert.equal(status.models.orchestrator.contract, 1);
  assert.equal(status.intelligence.orchestrator.contract, 1);
  assert.deepEqual(
    status.intelligence.orchestrator.decisions,
    ["model", "memory", "context", "search", "tool", "clarification", "response"]
  );
  assert.equal(status.intelligence.orchestrator.traceContainsUserText, false);
  assert.equal(status.intelligence.orchestrator.context.contract, 1);
  assert.equal(status.intelligence.orchestrator.context.policy, "budgeted-extractive-v1");
  assert.equal(status.intelligence.orchestrator.context.generatedSummary, false);
  assert.equal(status.intelligence.orchestrator.memoryRetrieval.contract, 1);
  assert.equal(status.intelligence.orchestrator.memoryRetrieval.policy, "hybrid-lexical-scoped-v1");
  assert.equal(status.intelligence.orchestrator.memoryRetrieval.hardScopeIsolation, true);

  const claude = status.models.external.find((item) => item.key === "claude");
  const gemini = status.models.external.find((item) => item.key === "gemini");
  const grok = status.models.external.find((item) => item.key === "grok");
  assert.equal(claude.configured, true);
  assert.equal(claude.chatReady, true);
  assert.equal(claude.enabled, true);
  assert.equal(claude.modelId, "claude-sonnet-5");
  assert.equal(gemini.configured, true);
  assert.equal(gemini.chatReady, true);
  assert.equal(gemini.enabled, true);
  assert.equal(gemini.modelId, "gemini-3.7-flash");
  assert.equal(grok.configured, true);
  assert.equal(grok.chatReady, true);
  assert.equal(grok.enabled, true);
  assert.equal(grok.modelId, "grok-test-1");

  const serialized = JSON.stringify(status);
  assert.equal(serialized.includes(env.ANTHROPIC_API_KEY), false);
  assert.equal(serialized.includes(env.GEMINI_API_KEY), false);
  assert.equal(serialized.includes(env.XAI_API_KEY), false);

}

async function testRoutingMetadataForWorkersFallback() {
  let calls = 0;
  const env = {
    AI: {
      run: async (model) => {
        calls += 1;
        if (calls === 1) throw new Error("first worker model unavailable");
        return { response: "fallback ok" };
      },
      toMarkdown: async () => ({ data: "" }),
    },
  };
  const response = await worker.fetch(new Request("https://aion.test/v1/chat", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ mode: "fast", messages: [{ role: "user", content: "اختبار fallback" }] }),
  }), env);
  const body = await response.json();
  assert.equal(response.status, 200);
  assert.equal(calls, 2);
  assert.equal(body.routing.providerKey, "workers-ai");
  assert.equal(body.routing.providerLabel, "Cloudflare Workers AI");
  assert.equal(body.routing.policy, "aion-workers-internal-fallback");
  assert.equal(body.routing.fallbackUsed, true);
  assert.equal(body.routing.attempts, 2);
  assert.equal(body.routing.crossProviderFailover, false);
  assert.equal(body.routing.modelId, "@cf/qwen/qwen3.8-27b");
}

async function testPinnedExternalNeverCrossProviderFallback() {
  const originalFetch = globalThis.fetch;
  let upstreamCalls = 0;
  let workersCalls = 0;
  try {
    globalThis.fetch = async (url) => {
      upstreamCalls += 1;
      assert.equal(String(url), "https://api.anthropic.com/v1/messages");
      return new Response(JSON.stringify({ error: { message: "anthropic unavailable" } }), {
        status: 503,
        headers: { "content-type": "application/json" },
      });
    };
    const env = {
      ANTHROPIC_API_KEY: "anthropic-secret-server-only",
      AION_CLAUDE_MODEL: "claude-test-1",
      GEMINI_API_KEY: "gemini-secret-server-only",
      AION_GEMINI_MODEL: "gemini-test-1",
      XAI_API_KEY: "xai-secret-server-only",
      AION_GROK_MODEL: "grok-test-1",
      AI: {
        run: async () => { workersCalls += 1; return { response: "must not run" }; },
        toMarkdown: async () => ({ data: "" }),
      },
    };
    const response = await worker.fetch(new Request("https://aion.test/v1/chat", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ mode: "claude", messages: [{ role: "user", content: "ابق على Claude" }] }),
    }), env);
    assert.equal(response.status, 503);
    assert.equal(upstreamCalls, 1);
    assert.equal(workersCalls, 0);
  } finally {
    globalThis.fetch = originalFetch;
  }
}

async function testCrossProviderConversationContinuity() {
  const originalFetch = globalThis.fetch;
  let capturedBody = null;
  try {
    globalThis.fetch = async (url, options = {}) => {
      assert.match(String(url), /generativelanguage\.googleapis\.com/);
      capturedBody = JSON.parse(options.body);
      return new Response(JSON.stringify({
        candidates: [{ content: { role: "model", parts: [{ text: "Gemini تابع نفس السياق" }] }, finishReason: "STOP" }],
      }), { status: 200, headers: { "content-type": "application/json" } });
    };
    const env = {
      GEMINI_API_KEY: "gemini-secret-server-only",
      AION_GEMINI_MODEL: "gemini-test-1",
      AI: { run: async () => ({ response: "wrong" }), toMarkdown: async () => ({ data: "" }) },
    };
    const response = await worker.fetch(new Request("https://aion.test/v1/chat", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        mode: "gemini",
        messages: [
          { role: "user", content: "اسمي علي" },
          { role: "assistant", content: "حفظت الاسم في سياق هذه المحادثة" },
          { role: "user", content: "ما الاسم الذي ذكرته؟" },
        ],
      }),
    }), env);
    const body = await response.json();
    assert.equal(response.status, 200);
    assert.equal(body.routing.providerKey, "gemini");
    assert.equal(body.routing.policy, "pinned-external");
    assert.equal(body.routing.fallbackUsed, false);
    assert.equal(body.routing.attempts, 1);
    assert.equal(body.routing.crossProviderFailover, false);
    assert.equal(body.routing.modelId, "gemini-test-1");
    assert.deepEqual(capturedBody.contents.map((item) => item.role), ["user", "model", "user"]);
    assert.equal(capturedBody.contents[1].parts[0].text, "حفظت الاسم في سياق هذه المحادثة");
  } finally {
    globalThis.fetch = originalFetch;
  }
}

async function testCrossModelContextTranslationContract() {
  const originalFetch = globalThis.fetch;
  const captured = { claude: null, gemini: null, grok: null };
  try {
    globalThis.fetch = async (url, options = {}) => {
      const target = String(url);
      const body = JSON.parse(options.body || "{}");
      if (target === "https://api.anthropic.com/v1/messages") {
        captured.claude = body;
        return new Response(JSON.stringify({
          content: [{ type: "text", text: "Claude ok" }],
        }), { status: 200, headers: { "content-type": "application/json" } });
      }
      if (target.includes("generativelanguage.googleapis.com")) {
        captured.gemini = body;
        return new Response(JSON.stringify({
          candidates: [{ content: { role: "model", parts: [{ text: "Gemini ok" }] }, finishReason: "STOP" }],
        }), { status: 200, headers: { "content-type": "application/json" } });
      }
      if (target === "https://api.x.ai/v1/responses") {
        captured.grok = body;
        return new Response(JSON.stringify({
          output: [{ type: "message", content: [{ type: "output_text", text: "Grok ok" }] }],
        }), { status: 200, headers: { "content-type": "application/json" } });
      }
      throw new Error(`unexpected fetch ${target}`);
    };

    const env = {
      ANTHROPIC_API_KEY: "anthropic-secret-server-only",
      AION_CLAUDE_MODEL: "claude-test-1",
      GEMINI_API_KEY: "gemini-secret-server-only",
      AION_GEMINI_MODEL: "gemini-test-1",
      XAI_API_KEY: "xai-secret-server-only",
      AION_GROK_MODEL: "grok-test-1",
      AI: { run: async () => ({ response: "wrong" }), toMarkdown: async () => ({ data: "" }) },
    };

    const history = [
      { role: "assistant", content: "رد يتيم من نافذة سياق مقطوعة" },
      { role: "user", content: "اسمي علي" },
      { role: "assistant", content: "سأحتفظ بالاسم داخل سياق هذه المحادثة" },
      { role: "user", content: "وأحب اليابان" },
      { role: "user", content: "ما الذي تذكره عني؟" },
    ];

    for (const mode of ["claude", "gemini", "grok"]) {
      const response = await worker.fetch(new Request("https://aion.test/v1/chat", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ mode, customInstructions: "لا تخترع معلومات", messages: history }),
      }), env);
      assert.equal(response.status, 200);
    }

    assert.deepEqual(captured.claude.messages.map((item) => item.role), ["user", "assistant", "user"]);
    assert.equal(captured.claude.messages[0].content[0].text, "اسمي علي");
    assert.match(captured.claude.messages[2].content.map((part) => part.text || "").join(""), /أحب اليابان/);
    assert.match(captured.claude.messages[2].content.map((part) => part.text || "").join(""), /ما الذي تذكره/);

    assert.deepEqual(captured.gemini.contents.map((item) => item.role), ["user", "model", "user"]);
    assert.equal(captured.gemini.contents[0].parts[0].text, "اسمي علي");
    assert.match(captured.gemini.contents[2].parts.map((part) => part.text || "").join(""), /أحب اليابان/);
    assert.match(captured.gemini.contents[2].parts.map((part) => part.text || "").join(""), /ما الذي تذكره/);

    assert.deepEqual(captured.grok.input.map((item) => item.role), ["user", "assistant", "user"]);
    assert.equal(captured.grok.input[0].content, "اسمي علي");
    assert.match(captured.grok.input[2].content, /أحب اليابان/);
    assert.match(captured.grok.input[2].content, /ما الذي تذكره/);

    assert.ok(captured.claude.system.includes("لا تخترع معلومات"));
    assert.ok(captured.gemini.systemInstruction.parts[0].text.includes("لا تخترع معلومات"));
    assert.ok(captured.grok.instructions.includes("لا تخترع معلومات"));
    assert.equal(JSON.stringify(captured).includes("رد يتيم من نافذة سياق مقطوعة"), false);
  } finally {
    globalThis.fetch = originalFetch;
  }
}


async function testStep6IntegratedClosureMatrix() {
  const originalFetch = globalThis.fetch;
  const captured = { claude: null, gemini: null, grok: null };
  let workersCalls = 0;
  const upstreamTargets = [];
  try {
    globalThis.fetch = async (url, options = {}) => {
      const target = String(url);
      upstreamTargets.push(target);
      const body = JSON.parse(options.body || "{}");
      if (target === "https://api.anthropic.com/v1/messages") {
        captured.claude = body;
        return new Response(JSON.stringify({ content: [{ type: "text", text: "Claude closure ok" }] }), {
          status: 200,
          headers: { "content-type": "application/json" },
        });
      }
      if (target.includes("generativelanguage.googleapis.com")) {
        captured.gemini = body;
        return new Response(JSON.stringify({
          candidates: [{ content: { role: "model", parts: [{ text: "Gemini closure ok" }] }, finishReason: "STOP" }],
        }), { status: 200, headers: { "content-type": "application/json" } });
      }
      if (target === "https://api.x.ai/v1/responses") {
        captured.grok = body;
        return new Response(JSON.stringify({
          output: [{ type: "message", content: [{ type: "output_text", text: "Grok closure ok" }] }],
        }), { status: 200, headers: { "content-type": "application/json" } });
      }
      throw new Error(`unexpected closure upstream ${target}`);
    };

    const env = {
      ANTHROPIC_API_KEY: "anthropic-closure-secret",
      AION_CLAUDE_MODEL: "claude-closure-model",
      GEMINI_API_KEY: "gemini-closure-secret",
      AION_GEMINI_MODEL: "gemini-closure-model",
      XAI_API_KEY: "xai-closure-secret",
      AION_GROK_MODEL: "grok-closure-model",
      AI: {
        run: async () => {
          workersCalls += 1;
          if (workersCalls === 1) throw new Error("closure primary workers model unavailable");
          return { response: "Workers fallback closure ok" };
        },
        toMarkdown: async () => ({ data: "" }),
      },
    };

    const statusResponse = await worker.fetch(new Request("https://aion.test/v1/status"), env);
    const status = await statusResponse.json();
    assert.equal(statusResponse.status, 200);
    assert.equal(status.version, "7.3.0-dev21");
    assert.equal(status.models.contract, 2);
    assert.equal(status.models.routing.contract, 1);
    assert.equal(status.models.routing.crossProviderFailover, false);
    assert.equal(status.models.context.contract, 1);
    assert.equal(status.models.context.crossModelSwitching, true);
    assert.equal(status.models.orchestrator.contract, 1);
    assert.equal(status.intelligence.orchestrator.contract, 1);
    assert.deepEqual(
      status.models.external.map((item) => [item.key, item.chatReady, item.enabled]),
      [["claude", true, true], ["gemini", true, true], ["grok", true, true]],
    );

    const history = [
      { role: "user", content: "نختبر إغلاق Step 6" },
      { role: "assistant", content: "السياق مستمر" },
      { role: "user", content: "أكمل بنفس السياق" },
    ];

    const expected = {
      claude: ["anthropic", "claude-closure-model"],
      gemini: ["gemini", "gemini-closure-model"],
      grok: ["xai", "grok-closure-model"],
    };

    for (const mode of ["claude", "gemini", "grok"]) {
      const response = await worker.fetch(new Request("https://aion.test/v1/chat", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ mode, customInstructions: "لا تغير المعنى", messages: history }),
      }), env);
      const body = await response.json();
      assert.equal(response.status, 200);
      assert.equal(body.routing.providerKey, expected[mode][0]);
      assert.equal(body.routing.modelId, expected[mode][1]);
      assert.equal(body.routing.policy, "pinned-external");
      assert.equal(body.routing.fallbackUsed, false);
      assert.equal(body.routing.attempts, 1);
      assert.equal(body.routing.crossProviderFailover, false);
    }

    assert.equal(upstreamTargets.length, 3);
    assert.equal(upstreamTargets.filter((u) => u === "https://api.anthropic.com/v1/messages").length, 1);
    assert.equal(upstreamTargets.filter((u) => u.includes("generativelanguage.googleapis.com")).length, 1);
    assert.equal(upstreamTargets.filter((u) => u === "https://api.x.ai/v1/responses").length, 1);
    assert.deepEqual(captured.claude.messages.map((item) => item.role), ["user", "assistant", "user"]);
    assert.deepEqual(captured.gemini.contents.map((item) => item.role), ["user", "model", "user"]);
    assert.deepEqual(captured.grok.input.map((item) => item.role), ["user", "assistant", "user"]);

    const workersResponse = await worker.fetch(new Request("https://aion.test/v1/chat", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ mode: "fast", messages: history }),
    }), env);
    const workersBody = await workersResponse.json();
    assert.equal(workersResponse.status, 200);
    assert.equal(workersCalls, 2);
    assert.equal(workersBody.routing.providerKey, "workers-ai");
    assert.equal(workersBody.routing.policy, "aion-workers-internal-fallback");
    assert.equal(workersBody.routing.fallbackUsed, true);
    assert.equal(workersBody.routing.attempts, 2);
    assert.equal(workersBody.routing.crossProviderFailover, false);

    const serializedStatus = JSON.stringify(status);
    assert.equal(serializedStatus.includes(env.ANTHROPIC_API_KEY), false);
    assert.equal(serializedStatus.includes(env.GEMINI_API_KEY), false);
    assert.equal(serializedStatus.includes(env.XAI_API_KEY), false);
  } finally {
    globalThis.fetch = originalFetch;
  }
}

async function testStep7OrchestratorContract() {
  const originalFetch = globalThis.fetch;
  try {
    globalThis.fetch = async (url) => {
      const target = String(url);
      if (target === "https://api.firecrawl.dev/v2/search") {
        return new Response(JSON.stringify({
          data: { web: [{ title: "مصدر حي", url: "https://example.com/live", description: "معلومة حديثة" }] },
        }), { status: 200, headers: { "content-type": "application/json" } });
      }
      throw new Error(`unexpected orchestrator upstream ${target}`);
    };

    const env = {
      FIRECRAWL_API_KEY: "firecrawl-step7-key",
      AI: {
        run: async () => ({ response: "orchestrated ok" }),
        toMarkdown: async () => ({ data: "" }),
      },
    };

    const statusResponse = await worker.fetch(new Request("https://aion.test/v1/status"), env);
    const status = await statusResponse.json();
    assert.equal(statusResponse.status, 200);
    assert.equal(status.version, "7.3.0-dev21");
    assert.equal(status.intelligence.orchestrator.contract, 1);
    assert.equal(status.intelligence.orchestrator.memory, "memory-v1-retrieved-scoped");
    assert.equal(status.intelligence.orchestrator.tools.contract, 1);
    assert.equal(status.intelligence.orchestrator.tools.policy, "universal-tool-router-v1");
    assert.deepEqual(status.intelligence.orchestrator.tools.registry, ["web.search"]);
    assert.equal(status.intelligence.orchestrator.tools.typedFailures, true);
    assert.equal(status.intelligence.orchestrator.traceContainsUserText, false);
    assert.equal(status.intelligence.orchestrator.context.policy, "budgeted-extractive-v1");
    assert.equal(status.intelligence.orchestrator.memoryRetrieval.policy, "hybrid-lexical-scoped-v1");

    const plainResponse = await worker.fetch(new Request("https://aion.test/v1/chat", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        mode: "auto",
        memoryContext: "اسم المشروع AION",
        messages: [{ role: "user", content: "اشرح الفكرة" }],
      }),
    }), env);
    const plain = await plainResponse.json();
    assert.equal(plainResponse.status, 200);
    assert.equal(plain.orchestration.contract, 1);
    assert.match(plain.orchestration.traceId, /^[0-9a-f-]{36}$/i);
    assert.equal(plain.orchestration.requestedSelection, "auto");
    assert.equal(plain.orchestration.search.required, false);
    assert.equal(plain.orchestration.search.reason, "not-required");
    assert.equal(plain.orchestration.memory.policy, "memory-v1-retrieved-scoped");
    assert.equal(plain.orchestration.memory.attached, true);
    assert.equal(plain.orchestration.memory.retrievalPolicy, "hybrid-lexical-scoped-v1");
    assert.equal(plain.orchestration.context.policy, "budgeted-extractive-v1");
    assert.equal(plain.orchestration.context.supplementalAttached, false);
    assert.equal(plain.orchestration.context.generatedSummary, false);
    assert.equal(plain.orchestration.tool.contract, 1);
    assert.equal(plain.orchestration.tool.policy, "universal-tool-router-v1");
    assert.equal(plain.orchestration.tool.route, "none");
    assert.deepEqual(plain.orchestration.tool.permissions, []);
    assert.equal(plain.orchestration.clarification.evaluated, false);
    assert.equal(plain.orchestration.response.profile, "balanced");
    assert.equal(JSON.stringify(plain.orchestration).includes("اشرح الفكرة"), false);
    assert.equal(JSON.stringify(plain.orchestration).includes("اسم المشروع"), false);

    const searchedResponse = await worker.fetch(new Request("https://aion.test/v1/chat", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        mode: "fast",
        forceWebSearch: true,
        messages: [{ role: "user", content: "تحقق من الخبر" }],
      }),
    }), env);
    const searched = await searchedResponse.json();
    assert.equal(searchedResponse.status, 200);
    assert.equal(searched.orchestration.search.required, true);
    assert.equal(searched.orchestration.search.reason, "forced");
    assert.equal(searched.orchestration.tool.route, "web.search");
    assert.deepEqual(searched.orchestration.tool.permissions, ["network"]);
    assert.equal(searched.orchestration.tool.timeoutMs, 22000);
    assert.equal(searched.toolExecution.route, "web.search");
    assert.equal(searched.toolExecution.status, "succeeded");
    assert.equal(searched.toolExecution.failureCode, "");
    assert.equal(searched.orchestration.response.profile, "concise");
    assert.equal(searched.orchestration.memory.policy, "none");
    assert.equal(searched.orchestration.memory.attached, false);

    const fallbackResponse = await worker.fetch(new Request("https://aion.test/v1/chat", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ mode: "auto", forceWebSearch: true, messages: [{ role: "user", content: "ابحث عن تحديث" }] }),
    }), {
      AI: {
        run: async () => ({ response: "workers fallback", citations: [] }),
        toMarkdown: async () => ({ data: "" }),
      },
    });
    const fallback = await fallbackResponse.json();
    assert.equal(fallbackResponse.status, 200);
    assert.equal(fallback.toolExecution.route, "web.search");
    assert.equal(fallback.toolExecution.status, "failed");
    assert.equal(fallback.toolExecution.failureCode, "unavailable");
    assert.equal(fallback.webSearchProvider, "workers-ai");

    const streamResponse = await worker.fetch(new Request("https://aion.test/v1/chat/stream", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ mode: "deep", messages: [{ role: "user", content: "حلل هذا بعمق" }] }),
    }), {
      AI: {
        run: async () => sseStream(['data: {"response":"تم"}\n\n', 'data: [DONE]\n\n']),
        toMarkdown: async () => ({ data: "" }),
      },
    });
    const streamText = await streamResponse.text();
    assert.equal(streamResponse.status, 200);
    assert.match(streamText, /event: orchestration/);
    assert.match(streamText, /"contract":1/);
    assert.match(streamText, /"profile":"deep"/);
    assert.equal(streamText.includes("حلل هذا بعمق"), false);
  } finally {
    globalThis.fetch = originalFetch;
  }
}

async function testClaudeSyncProvider() {
  const originalFetch = globalThis.fetch;
  let capturedBody = null;
  let capturedHeaders = null;
  let aiCalls = 0;
  try {
    globalThis.fetch = async (url, options = {}) => {
      assert.equal(String(url), "https://api.anthropic.com/v1/messages");
      capturedHeaders = options.headers;
      capturedBody = JSON.parse(options.body);
      return new Response(JSON.stringify({
        id: "msg_test",
        type: "message",
        role: "assistant",
        model: "claude-sonnet-5",
        content: [{ type: "text", text: "رد Claude الحقيقي" }],
        stop_reason: "end_turn",
      }), { status: 200, headers: { "content-type": "application/json" } });
    };

    const env = {
      ANTHROPIC_API_KEY: "anthropic-secret-server-only",
      AION_CLAUDE_MODEL: "claude-sonnet-5",
      AI: {
        run: async () => { aiCalls += 1; return { response: "wrong backend" }; },
        toMarkdown: async () => ({ data: "" }),
      },
    };
    const response = await worker.fetch(new Request("https://aion.test/v1/chat", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        mode: "claude",
        customInstructions: "اجب بدقة",
        messages: [{ role: "user", content: "مرحبا Claude" }],
      }),
    }), env);
    const body = await response.json();
    assert.equal(response.status, 200);
    assert.equal(body.response, "رد Claude الحقيقي");
    assert.equal(body.routing.providerKey, "anthropic");
    assert.equal(body.routing.policy, "pinned-external");
    assert.equal(body.routing.fallbackUsed, false);
    assert.equal(body.routing.modelId, "claude-sonnet-5");
    assert.equal(body.model, "claude-sonnet-5");
    assert.equal(body.selectedModel, "claude");
    assert.equal(aiCalls, 0);
    assert.equal(capturedHeaders["x-api-key"], env.ANTHROPIC_API_KEY);
    assert.equal(capturedHeaders["anthropic-version"], "2023-06-01");
    assert.equal(capturedBody.model, "claude-sonnet-5");
    assert.equal(capturedBody.stream, false);
    assert.ok(typeof capturedBody.system === "string" && capturedBody.system.includes("AION"));
    assert.ok(capturedBody.system.includes("اجب بدقة"));
    assert.equal(capturedBody.messages.at(-1).role, "user");
    assert.equal(capturedBody.messages.at(-1).content[0].text, "مرحبا Claude");
    assert.equal(JSON.stringify(body).includes(env.ANTHROPIC_API_KEY), false);
  } finally {
    globalThis.fetch = originalFetch;
  }
}

async function testClaudeStreamingProvider() {
  const originalFetch = globalThis.fetch;
  let aiCalls = 0;
  try {
    globalThis.fetch = async (url, options = {}) => {
      assert.equal(String(url), "https://api.anthropic.com/v1/messages");
      const requestBody = JSON.parse(options.body);
      assert.equal(requestBody.stream, true);
      return new Response(sseStream([
        'event: message_start\ndata: {"type":"message_start","message":{"id":"msg_stream"}}\n\n',
        'event: content_block_start\ndata: {"type":"content_block_start","index":0,"content_block":{"type":"text","text":""}}\n\n',
        'event: content_block_delta\ndata: {"type":"content_block_delta","index":0,"delta":{"type":"text_delta","text":"مرح"}}\n\n',
        'event: content_block_delta\ndata: {"type":"content_block_delta","index":0,"delta":{"type":"text_delta","text":"با"}}\n\n',
        'event: message_delta\ndata: {"type":"message_delta","delta":{"stop_reason":"end_turn"}}\n\n',
        'event: message_stop\ndata: {"type":"message_stop"}\n\n',
      ]), { status: 200, headers: { "content-type": "text/event-stream" } });
    };

    const env = {
      ANTHROPIC_API_KEY: "anthropic-secret-server-only",
      AION_CLAUDE_MODEL: "claude-sonnet-5",
      AI: {
        run: async () => { aiCalls += 1; return { response: "wrong backend" }; },
        toMarkdown: async () => ({ data: "" }),
      },
    };
    const response = await worker.fetch(new Request("https://aion.test/v1/chat/stream", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ mode: "claude", messages: [{ role: "user", content: "هلا" }] }),
    }), env);
    const text = await response.text();
    assert.equal(response.status, 200);
    assert.equal(aiCalls, 0);
    assert.match(text, /event: delta/);
    assert.match(text, /"text":"مرح"/);
    assert.match(text, /"text":"با"/);
    assert.match(text, /"model":"claude-sonnet-5"/);
    assert.match(text, /"selectedModel":"claude"/);
  } finally {
    globalThis.fetch = originalFetch;
  }
}

async function testClaudeVisionTranslation() {
  const originalFetch = globalThis.fetch;
  let capturedBody = null;
  try {
    globalThis.fetch = async (_url, options = {}) => {
      capturedBody = JSON.parse(options.body);
      return new Response(JSON.stringify({
        content: [{ type: "text", text: "أرى الصورة" }],
      }), { status: 200, headers: { "content-type": "application/json" } });
    };
    const env = {
      ANTHROPIC_API_KEY: "anthropic-secret-server-only",
      AION_CLAUDE_MODEL: "claude-sonnet-5",
      AI: {
        run: async () => ({ response: "wrong" }),
        toMarkdown: async () => { throw new Error("image must stay native"); },
      },
    };
    const imageData = Buffer.from("fake-image", "utf8").toString("base64");
    const response = await worker.fetch(new Request("https://aion.test/v1/chat", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        mode: "claude",
        messages: [{
          role: "user",
          content: "حلل الصورة",
          attachments: [{ name: "img.jpg", mimeType: "image/jpeg", kind: "IMAGE", sizeBytes: 10, data: imageData }],
        }],
      }),
    }), env);
    assert.equal(response.status, 200);
    const blocks = capturedBody.messages.at(-1).content;
    assert.equal(blocks[0].type, "text");
    assert.equal(blocks[1].type, "image");
    assert.equal(blocks[1].source.type, "base64");
    assert.equal(blocks[1].source.media_type, "image/jpeg");
    assert.equal(blocks[1].source.data, imageData);
  } finally {
    globalThis.fetch = originalFetch;
  }
}


async function testClaudeSearchWithFirecrawl() {
  const originalFetch = globalThis.fetch;
  const calls = [];
  try {
    globalThis.fetch = async (url, options = {}) => {
      calls.push(String(url));
      if (String(url) === "https://api.firecrawl.dev/v2/search") {
        return new Response(JSON.stringify({
          data: { web: [{ title: "مصدر حي", url: "https://example.com/live", description: "معلومة حديثة موثقة" }] },
        }), { status: 200, headers: { "content-type": "application/json" } });
      }
      if (String(url) === "https://api.anthropic.com/v1/messages") {
        const body = JSON.parse(options.body);
        assert.ok(body.system.includes("مصادر البحث الحية"));
        assert.ok(body.system.includes("https://example.com/live"));
        return new Response(JSON.stringify({
          content: [{ type: "text", text: "النتيجة مدعومة بالمصدر [1]" }],
        }), { status: 200, headers: { "content-type": "application/json" } });
      }
      throw new Error(`unexpected fetch ${url}`);
    };
    const env = {
      ANTHROPIC_API_KEY: "anthropic-secret-server-only",
      AION_CLAUDE_MODEL: "claude-sonnet-5",
      FIRECRAWL_API_KEY: "firecrawl-server-secret",
      AI: { run: async () => ({ response: "wrong" }), toMarkdown: async () => ({ data: "" }) },
    };
    const response = await worker.fetch(new Request("https://aion.test/v1/chat", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ mode: "claude", forceWebSearch: true, messages: [{ role: "user", content: "ابحث عن الخبر" }] }),
    }), env);
    const body = await response.json();
    assert.equal(response.status, 200);
    assert.equal(body.selectedModel, "claude");
    assert.equal(body.webSearchProvider, "firecrawl");
    assert.equal(body.sources.length, 1);
    assert.deepEqual(calls, ["https://api.firecrawl.dev/v2/search", "https://api.anthropic.com/v1/messages"]);
  } finally {
    globalThis.fetch = originalFetch;
  }
}

async function testClaudeSearchRequiresFirecrawl() {
  const originalFetch = globalThis.fetch;
  let upstreamCalls = 0;
  try {
    globalThis.fetch = async () => { upstreamCalls += 1; throw new Error("should not call Anthropic"); };
    const env = {
      ANTHROPIC_API_KEY: "anthropic-secret-server-only",
      AION_CLAUDE_MODEL: "claude-sonnet-5",
      AI: { run: async () => ({ response: "wrong" }), toMarkdown: async () => ({ data: "" }) },
    };
    const response = await worker.fetch(new Request("https://aion.test/v1/chat", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ mode: "claude", forceWebSearch: true, messages: [{ role: "user", content: "ابحث عن الخبر" }] }),
    }), env);
    assert.equal(response.status, 503);
    const body = await response.json();
    assert.match(body.error, /Firecrawl/);
    assert.equal(upstreamCalls, 0);
  } finally {
    globalThis.fetch = originalFetch;
  }
}

async function testGeminiSyncProvider() {
  const originalFetch = globalThis.fetch;
  let capturedBody = null;
  let capturedHeaders = null;
  let aiCalls = 0;
  try {
    globalThis.fetch = async (url, options = {}) => {
      assert.equal(String(url), "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.8-flash:generateContent");
      capturedHeaders = options.headers;
      capturedBody = JSON.parse(options.body);
      return new Response(JSON.stringify({
        candidates: [{ content: { role: "model", parts: [{ text: "رد Gemini الحقيقي" }] }, finishReason: "STOP" }],
      }), { status: 200, headers: { "content-type": "application/json" } });
    };

    const env = {
      GEMINI_API_KEY: "gemini-secret-server-only",
      AION_GEMINI_MODEL: "gemini-3.8-flash",
      AI: {
        run: async () => { aiCalls += 1; return { response: "wrong backend" }; },
        toMarkdown: async () => ({ data: "" }),
      },
    };
    const response = await worker.fetch(new Request("https://aion.test/v1/chat", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        mode: "gemini",
        customInstructions: "اجب بدقة",
        messages: [{ role: "user", content: "مرحبا Gemini" }],
      }),
    }), env);
    const body = await response.json();
    assert.equal(response.status, 200);
    assert.equal(body.response, "رد Gemini الحقيقي");
    assert.equal(body.routing.providerKey, "gemini");
    assert.equal(body.routing.policy, "pinned-external");
    assert.equal(body.routing.fallbackUsed, false);
    assert.equal(body.model, "gemini-3.8-flash");
    assert.equal(body.selectedModel, "gemini");
    assert.equal(aiCalls, 0);
    assert.equal(capturedHeaders["x-goog-api-key"], env.GEMINI_API_KEY);
    assert.ok(capturedBody.systemInstruction.parts[0].text.includes("AION"));
    assert.ok(capturedBody.systemInstruction.parts[0].text.includes("اجب بدقة"));
    assert.equal(capturedBody.contents.at(-1).role, "user");
    assert.equal(capturedBody.contents.at(-1).parts[0].text, "مرحبا Gemini");
    assert.equal(capturedBody.generationConfig.maxOutputTokens, 6000);
    assert.equal(JSON.stringify(body).includes(env.GEMINI_API_KEY), false);
  } finally {
    globalThis.fetch = originalFetch;
  }
}

async function testGeminiStreamingProvider() {
  const originalFetch = globalThis.fetch;
  let aiCalls = 0;
  try {
    globalThis.fetch = async (url, options = {}) => {
      assert.equal(String(url), "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.8-flash:streamGenerateContent?alt=sse");
      const requestBody = JSON.parse(options.body);
      assert.equal(requestBody.contents.at(-1).parts[0].text, "تكلم");
      return new Response(sseStream([
        'data: {"candidates":[{"content":{"role":"model","parts":[{"text":"مرح"}]}}]}\n\n',
        'data: {"candidates":[{"content":{"role":"model","parts":[{"text":"با بك"}]},"finishReason":"STOP"}]}\n\n',
      ]), { status: 200, headers: { "content-type": "text/event-stream" } });
    };
    const env = {
      GEMINI_API_KEY: "gemini-secret-server-only",
      AION_GEMINI_MODEL: "gemini-3.8-flash",
      AI: { run: async () => { aiCalls += 1; return { response: "wrong" }; }, toMarkdown: async () => ({ data: "" }) },
    };
    const response = await worker.fetch(new Request("https://aion.test/v1/chat/stream", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ mode: "gemini", messages: [{ role: "user", content: "تكلم" }] }),
    }), env);
    const text = await response.text();
    assert.equal(response.status, 200);
    assert.match(text, /"text":"مرح"/);
    assert.match(text, /"text":"با بك"/);
    assert.match(text, /"model":"gemini-3.8-flash"/);
    assert.match(text, /"selectedModel":"gemini"/);
    assert.equal(aiCalls, 0);
  } finally {
    globalThis.fetch = originalFetch;
  }
}

async function testGeminiVisionTranslation() {
  const originalFetch = globalThis.fetch;
  let capturedBody = null;
  try {
    globalThis.fetch = async (url, options = {}) => {
      assert.equal(String(url), "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.8-flash:generateContent");
      capturedBody = JSON.parse(options.body);
      return new Response(JSON.stringify({
        candidates: [{ content: { parts: [{ text: "أرى الصورة" }] }, finishReason: "STOP" }],
      }), { status: 200, headers: { "content-type": "application/json" } });
    };
    const env = {
      GEMINI_API_KEY: "gemini-secret-server-only",
      AION_GEMINI_MODEL: "gemini-3.8-flash",
      AI: {
        run: async () => ({ response: "wrong" }),
        toMarkdown: async () => { throw new Error("image must stay native"); },
      },
    };
    const imageData = Buffer.from("fake-image", "utf8").toString("base64");
    const response = await worker.fetch(new Request("https://aion.test/v1/chat", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        mode: "gemini",
        messages: [{
          role: "user",
          content: "حلل الصورة",
          attachments: [{ name: "img.jpg", mimeType: "image/jpeg", kind: "IMAGE", sizeBytes: 10, data: imageData }],
        }],
      }),
    }), env);
    assert.equal(response.status, 200);
    const parts = capturedBody.contents.at(-1).parts;
    assert.equal(parts[0].text, "حلل الصورة");
    assert.equal(parts[1].inline_data.mime_type, "image/jpeg");
    assert.equal(parts[1].inline_data.data, imageData);
  } finally {
    globalThis.fetch = originalFetch;
  }
}

async function testGeminiSearchWithFirecrawl() {
  const originalFetch = globalThis.fetch;
  const calls = [];
  try {
    globalThis.fetch = async (url, options = {}) => {
      calls.push(String(url));
      if (String(url) === "https://api.firecrawl.dev/v2/search") {
        return new Response(JSON.stringify({
          data: { web: [{ title: "مصدر حي", url: "https://example.com/live", description: "معلومة حديثة موثقة" }] },
        }), { status: 200, headers: { "content-type": "application/json" } });
      }
      if (String(url) === "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.8-flash:generateContent") {
        const body = JSON.parse(options.body);
        assert.ok(body.systemInstruction.parts[0].text.includes("مصادر البحث الحية"));
        assert.ok(body.systemInstruction.parts[0].text.includes("https://example.com/live"));
        assert.equal(body.tools, undefined);
        return new Response(JSON.stringify({
          candidates: [{ content: { parts: [{ text: "النتيجة مدعومة بالمصدر [1]" }] }, finishReason: "STOP" }],
        }), { status: 200, headers: { "content-type": "application/json" } });
      }
      throw new Error(`unexpected fetch ${url}`);
    };
    const env = {
      GEMINI_API_KEY: "gemini-secret-server-only",
      AION_GEMINI_MODEL: "gemini-3.8-flash",
      FIRECRAWL_API_KEY: "firecrawl-server-secret",
      AI: { run: async () => ({ response: "wrong" }), toMarkdown: async () => ({ data: "" }) },
    };
    const response = await worker.fetch(new Request("https://aion.test/v1/chat", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ mode: "gemini", forceWebSearch: true, messages: [{ role: "user", content: "ابحث عن الخبر" }] }),
    }), env);
    const body = await response.json();
    assert.equal(response.status, 200);
    assert.equal(body.selectedModel, "gemini");
    assert.equal(body.webSearchProvider, "firecrawl");
    assert.equal(body.sources.length, 1);
    assert.deepEqual(calls, ["https://api.firecrawl.dev/v2/search", "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.8-flash:generateContent"]);
  } finally {
    globalThis.fetch = originalFetch;
  }
}

async function testGeminiSearchRequiresFirecrawl() {
  const originalFetch = globalThis.fetch;
  let upstreamCalls = 0;
  try {
    globalThis.fetch = async () => { upstreamCalls += 1; throw new Error("should not call Gemini"); };
    const env = {
      GEMINI_API_KEY: "gemini-secret-server-only",
      AION_GEMINI_MODEL: "gemini-3.8-flash",
      AI: { run: async () => ({ response: "wrong" }), toMarkdown: async () => ({ data: "" }) },
    };
    const response = await worker.fetch(new Request("https://aion.test/v1/chat", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ mode: "gemini", forceWebSearch: true, messages: [{ role: "user", content: "ابحث عن الخبر" }] }),
    }), env);
    assert.equal(response.status, 503);
    const body = await response.json();
    assert.match(body.error, /Firecrawl/);
    assert.equal(upstreamCalls, 0);
  } finally {
    globalThis.fetch = originalFetch;
  }
}

async function testGrokSyncProvider() {
  const originalFetch = globalThis.fetch;
  let capturedBody = null;
  let capturedHeaders = null;
  let aiCalls = 0;
  try {
    globalThis.fetch = async (url, options = {}) => {
      assert.equal(String(url), "https://api.x.ai/v1/responses");
      capturedHeaders = options.headers;
      capturedBody = JSON.parse(options.body);
      return new Response(JSON.stringify({
        id: "resp_grok_test",
        object: "response",
        status: "completed",
        model: "grok-test-1",
        output: [{
          type: "message",
          role: "assistant",
          status: "completed",
          content: [{ type: "output_text", text: "رد Grok الحقيقي", annotations: [] }],
        }],
      }), { status: 200, headers: { "content-type": "application/json" } });
    };
    const env = {
      XAI_API_KEY: "xai-secret-server-only",
      AION_GROK_MODEL: "grok-test-1",
      AI: {
        run: async () => { aiCalls += 1; return { response: "wrong backend" }; },
        toMarkdown: async () => ({ data: "" }),
      },
    };
    const response = await worker.fetch(new Request("https://aion.test/v1/chat", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        mode: "grok",
        customInstructions: "اجب بدقة",
        messages: [{ role: "user", content: "مرحبا Grok" }],
      }),
    }), env);
    const body = await response.json();
    assert.equal(response.status, 200);
    assert.equal(body.response, "رد Grok الحقيقي");
    assert.equal(body.routing.providerKey, "xai");
    assert.equal(body.routing.policy, "pinned-external");
    assert.equal(body.routing.fallbackUsed, false);
    assert.equal(body.model, "grok-test-1");
    assert.equal(body.selectedModel, "grok");
    assert.equal(aiCalls, 0);
    assert.equal(capturedHeaders.authorization, `Bearer ${env.XAI_API_KEY}`);
    assert.equal(capturedBody.model, "grok-test-1");
    assert.equal(capturedBody.stream, false);
    assert.equal(capturedBody.store, false);
    assert.equal(capturedBody.max_output_tokens, 6000);
    assert.ok(capturedBody.instructions.includes("AION"));
    assert.ok(capturedBody.instructions.includes("اجب بدقة"));
    assert.equal(capturedBody.input.at(-1).role, "user");
    assert.equal(capturedBody.input.at(-1).content, "مرحبا Grok");
    assert.equal(JSON.stringify(body).includes(env.XAI_API_KEY), false);
  } finally {
    globalThis.fetch = originalFetch;
  }
}

async function testGrokStreamingProvider() {
  const originalFetch = globalThis.fetch;
  let aiCalls = 0;
  try {
    globalThis.fetch = async (url, options = {}) => {
      assert.equal(String(url), "https://api.x.ai/v1/responses");
      const requestBody = JSON.parse(options.body);
      assert.equal(requestBody.stream, true);
      assert.equal(requestBody.store, false);
      assert.equal(requestBody.input.at(-1).content, "تكلم");
      return new Response(sseStream([
        'event: response.output_text.delta\ndata: {"type":"response.output_text.delta","delta":"مرح"}\n\n',
        'event: response.output_text.delta\ndata: {"type":"response.output_text.delta","delta":"با بك"}\n\n',
        'event: response.completed\ndata: {"type":"response.completed","response":{"status":"completed"}}\n\n',
      ]), { status: 200, headers: { "content-type": "text/event-stream" } });
    };
    const env = {
      XAI_API_KEY: "xai-secret-server-only",
      AION_GROK_MODEL: "grok-test-1",
      AI: { run: async () => { aiCalls += 1; return { response: "wrong" }; }, toMarkdown: async () => ({ data: "" }) },
    };
    const response = await worker.fetch(new Request("https://aion.test/v1/chat/stream", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ mode: "grok", messages: [{ role: "user", content: "تكلم" }] }),
    }), env);
    const text = await response.text();
    assert.equal(response.status, 200);
    assert.match(text, /"text":"مرح"/);
    assert.match(text, /"text":"با بك"/);
    assert.match(text, /"model":"grok-test-1"/);
    assert.match(text, /"selectedModel":"grok"/);
    assert.equal(aiCalls, 0);
  } finally {
    globalThis.fetch = originalFetch;
  }
}

async function testGrokVisionTranslation() {
  const originalFetch = globalThis.fetch;
  let capturedBody = null;
  try {
    globalThis.fetch = async (url, options = {}) => {
      assert.equal(String(url), "https://api.x.ai/v1/responses");
      capturedBody = JSON.parse(options.body);
      return new Response(JSON.stringify({
        status: "completed",
        output: [{ type: "message", role: "assistant", content: [{ type: "output_text", text: "أرى الصورة" }] }],
      }), { status: 200, headers: { "content-type": "application/json" } });
    };
    const env = {
      XAI_API_KEY: "xai-secret-server-only",
      AION_GROK_MODEL: "grok-test-1",
      AI: {
        run: async () => ({ response: "wrong" }),
        toMarkdown: async () => { throw new Error("image must stay native"); },
      },
    };
    const imageData = Buffer.from("fake-image", "utf8").toString("base64");
    const response = await worker.fetch(new Request("https://aion.test/v1/chat", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        mode: "grok",
        messages: [{
          role: "user",
          content: "حلل الصورة",
          attachments: [{ name: "img.jpg", mimeType: "image/jpeg", kind: "IMAGE", sizeBytes: 10, data: imageData }],
        }],
      }),
    }), env);
    assert.equal(response.status, 200);
    const parts = capturedBody.input.at(-1).content;
    assert.equal(parts[0].type, "input_text");
    assert.equal(parts[0].text, "حلل الصورة");
    assert.equal(parts[1].type, "input_image");
    assert.equal(parts[1].image_url, `data:image/jpeg;base64,${imageData}`);
    assert.equal(parts[1].detail, "auto");
  } finally {
    globalThis.fetch = originalFetch;
  }
}

async function testGrokSearchWithFirecrawl() {
  const originalFetch = globalThis.fetch;
  const calls = [];
  try {
    globalThis.fetch = async (url, options = {}) => {
      calls.push(String(url));
      if (String(url) === "https://api.firecrawl.dev/v2/search") {
        return new Response(JSON.stringify({
          data: { web: [{ title: "مصدر حي", url: "https://example.com/live", description: "معلومة حديثة موثقة" }] },
        }), { status: 200, headers: { "content-type": "application/json" } });
      }
      if (String(url) === "https://api.x.ai/v1/responses") {
        const body = JSON.parse(options.body);
        assert.ok(body.instructions.includes("مصادر البحث الحية"));
        assert.ok(body.instructions.includes("https://example.com/live"));
        assert.equal(body.tools, undefined);
        return new Response(JSON.stringify({
          status: "completed",
          output: [{ type: "message", role: "assistant", content: [{ type: "output_text", text: "النتيجة مدعومة بالمصدر [1]" }] }],
        }), { status: 200, headers: { "content-type": "application/json" } });
      }
      throw new Error(`unexpected fetch ${url}`);
    };
    const env = {
      XAI_API_KEY: "xai-secret-server-only",
      AION_GROK_MODEL: "grok-test-1",
      FIRECRAWL_API_KEY: "firecrawl-server-secret",
      AI: { run: async () => ({ response: "wrong" }), toMarkdown: async () => ({ data: "" }) },
    };
    const response = await worker.fetch(new Request("https://aion.test/v1/chat", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ mode: "grok", forceWebSearch: true, messages: [{ role: "user", content: "ابحث عن الخبر" }] }),
    }), env);
    const body = await response.json();
    assert.equal(response.status, 200);
    assert.equal(body.selectedModel, "grok");
    assert.equal(body.webSearchProvider, "firecrawl");
    assert.equal(body.sources.length, 1);
    assert.deepEqual(calls, ["https://api.firecrawl.dev/v2/search", "https://api.x.ai/v1/responses"]);
  } finally {
    globalThis.fetch = originalFetch;
  }
}

async function testGrokSearchRequiresFirecrawl() {
  const originalFetch = globalThis.fetch;
  let upstreamCalls = 0;
  try {
    globalThis.fetch = async () => { upstreamCalls += 1; throw new Error("should not call xAI"); };
    const env = {
      XAI_API_KEY: "xai-secret-server-only",
      AION_GROK_MODEL: "grok-test-1",
      AI: { run: async () => ({ response: "wrong" }), toMarkdown: async () => ({ data: "" }) },
    };
    const response = await worker.fetch(new Request("https://aion.test/v1/chat", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ mode: "grok", forceWebSearch: true, messages: [{ role: "user", content: "ابحث عن الخبر" }] }),
    }), env);
    assert.equal(response.status, 503);
    const body = await response.json();
    assert.match(body.error, /Firecrawl/);
    assert.equal(upstreamCalls, 0);
  } finally {
    globalThis.fetch = originalFetch;
  }
}


async function testStep7ContextAndMemoryRetrievalContracts() {
  let seenSystem = "";
  const env = {
    AI: {
      run: async (_model, payload) => {
        seenSystem = String(payload?.messages?.[0]?.content || "");
        return { response: "context memory ok" };
      },
      toMarkdown: async () => ({ data: "" }),
    },
  };

  const statusResponse = await worker.fetch(new Request("https://aion.test/v1/status"), env);
  const status = await statusResponse.json();
  assert.equal(statusResponse.status, 200);
  assert.equal(status.version, "7.3.0-dev21");
  assert.equal(status.intelligence.orchestrator.context.contract, 1);
  assert.equal(status.intelligence.orchestrator.context.policy, "budgeted-extractive-v1");
  assert.equal(status.intelligence.orchestrator.context.generatedSummary, false);
  assert.equal(status.intelligence.orchestrator.memoryRetrieval.contract, 1);
  assert.equal(status.intelligence.orchestrator.memoryRetrieval.policy, "hybrid-lexical-scoped-v1");
  assert.equal(status.intelligence.orchestrator.memoryRetrieval.hardScopeIsolation, true);

  const response = await worker.fetch(new Request("https://aion.test/v1/chat", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({
      mode: "auto",
      memoryContext: "ذاكرة AION المسترجعة لهذا الطلب: المستخدم يفضّل العربية",
      contextContext: "مقتطف حرفي قديم: قرار المشروع اسمه AION",
      messages: [{ role: "user", content: "كمل من وين وقفنا" }],
    }),
  }), env);
  const body = await response.json();
  assert.equal(response.status, 200);
  assert.equal(body.orchestration.memory.policy, "memory-v1-retrieved-scoped");
  assert.equal(body.orchestration.memory.retrievalPolicy, "hybrid-lexical-scoped-v1");
  assert.equal(body.orchestration.memory.attached, true);
  assert.equal(body.orchestration.context.policy, "budgeted-extractive-v1");
  assert.equal(body.orchestration.context.supplementalAttached, true);
  assert.equal(body.orchestration.context.generatedSummary, false);
  assert.ok(seenSystem.includes("المستخدم يفضّل العربية"));
  assert.ok(seenSystem.includes("قرار المشروع اسمه AION"));
  const serialized = JSON.stringify(body.orchestration);
  assert.equal(serialized.includes("يفضّل العربية"), false);
  assert.equal(serialized.includes("قرار المشروع"), false);

  const healthResponse = await worker.fetch(new Request("https://aion.test/health"), env);
  const health = await healthResponse.json();
  assert.ok(health.capabilities.includes("context-engine-v1"));
  assert.ok(health.capabilities.includes("memory-retrieval-v1"));
}

async function testStep6IntegratedClosureContract() {
  const env = {
    ANTHROPIC_API_KEY: ["anthropic", "closure", "key"].join("-"),
    AION_CLAUDE_MODEL: "claude-closure-model",
    GEMINI_API_KEY: ["gemini", "closure", "key"].join("-"),
    AION_GEMINI_MODEL: "gemini-closure-model",
    XAI_API_KEY: ["xai", "closure", "key"].join("-"),
    AION_GROK_MODEL: "grok-closure-model",
    FIRECRAWL_API_KEY: "firecrawl-closure-key",
    AI: {
      run: async () => ({ response: "ok" }),
      toMarkdown: async () => ({ data: "" }),
    },
  };

  const statusResponse = await worker.fetch(new Request("https://aion.test/v1/status"), env);
  const status = await statusResponse.json();
  assert.equal(statusResponse.status, 200);
  assert.equal(status.version, "7.3.0-dev21");
  assert.deepEqual(status.modes, ["auto", "fast", "deep", "research"]);
  assert.equal(status.trueStreaming, true);
  assert.equal(status.models.contract, 2);
  assert.deepEqual(status.models.builtIn, ["auto", "fast", "deep", "research"]);
  assert.equal(status.models.routing.contract, 1);
  assert.equal(status.models.routing.explicitExternal, "pinned");
  assert.equal(status.models.routing.builtInFallback, "workers-ai-only");
  assert.equal(status.models.routing.crossProviderFailover, false);
  assert.equal(status.models.context.contract, 1);
  assert.equal(status.models.context.canonicalHistory, "provider-neutral");
  assert.deepEqual(status.models.context.externalAdapters, ["anthropic", "gemini", "xai"]);
  assert.equal(status.models.context.crossModelSwitching, true);

  const expected = new Map([
    ["claude", ["Anthropic • Claude", "claude-closure-model"]],
    ["gemini", ["Google • Gemini", "gemini-closure-model"]],
    ["grok", ["xAI • Grok", "grok-closure-model"]],
  ]);
  for (const entry of status.models.external) {
    const contract = expected.get(entry.key);
    assert.ok(contract, `unexpected external model ${entry.key}`);
    assert.equal(entry.provider, contract[0]);
    assert.equal(entry.modelId, contract[1]);
    assert.equal(entry.configured, true);
    assert.equal(entry.chatReady, true);
    assert.equal(entry.enabled, true);
    assert.equal(entry.badge, "جاهز");
  }
  assert.equal(status.models.external.length, 3);

  const healthResponse = await worker.fetch(new Request("https://aion.test/health"), env);
  const health = await healthResponse.json();
  assert.equal(healthResponse.status, 200);
  assert.ok(health.capabilities.includes("claude-chat"));
  assert.ok(health.capabilities.includes("gemini-chat"));
  assert.ok(health.capabilities.includes("grok-chat"));
  assert.ok(health.capabilities.includes("multi-provider-catalog"));
  assert.ok(health.capabilities.includes("aion-orchestrator-v1"));
  assert.equal(health.intelligence.orchestrator.contract, 1);

  const serialized = JSON.stringify({ status, health });
  assert.equal(serialized.includes(env.ANTHROPIC_API_KEY), false);
  assert.equal(serialized.includes(env.GEMINI_API_KEY), false);
  assert.equal(serialized.includes(env.XAI_API_KEY), false);
  assert.equal(serialized.includes(env.FIRECRAWL_API_KEY), false);
}

await testTrueStreaming();
await testTextAttachmentContext();
await testBinaryAttachmentConversion();
await testStreamingFallbackBeforeFirstToken();
await testModelRouting();
await testPersonalizationAndLongContext();
await testNativeVisionRouting();
await testNoFallbackAfterPartialToken();
await testLargeSingleMessageLimit();
await testSessionAffinity();
await testNativeSearchCitations();
await testVoiceStatusAndUnavailableFallback();
await testNeuralVoiceProxy();
await testNeuralVoiceCatalogAndTuning();
await testMyVoiceEnrollmentAndUse();
await testMultiProviderFoundationCatalog();
await testRoutingMetadataForWorkersFallback();
await testPinnedExternalNeverCrossProviderFallback();
await testCrossProviderConversationContinuity();
await testCrossModelContextTranslationContract();
await testStep7OrchestratorContract();
await testStep7ContextAndMemoryRetrievalContracts();
await testClaudeSyncProvider();
await testClaudeStreamingProvider();
await testClaudeVisionTranslation();
await testClaudeSearchWithFirecrawl();
await testClaudeSearchRequiresFirecrawl();
await testGeminiSyncProvider();
await testGeminiStreamingProvider();
await testGeminiVisionTranslation();
await testGeminiSearchWithFirecrawl();
await testGeminiSearchRequiresFirecrawl();
await testGrokSyncProvider();
await testGrokStreamingProvider();
await testGrokVisionTranslation();
await testGrokSearchWithFirecrawl();
await testGrokSearchRequiresFirecrawl();
await testStep6IntegratedClosureContract();
await testStep6IntegratedClosureMatrix();
console.log("AION worker tests: PASS");
