# AION α7.3 — Step 7 Intelligence Core

## الهدف
تحويل AION من واجهة متعددة المزودات إلى طبقة ذكاء مستقلة تملك قرار التشغيل قبل استدعاء أي نموذج.

## Step 7.1 — AION Core + Orchestrator Contract
Step 7.1 أُغلقت على `2.0.0-alpha7.3-dev17 / versionCode 31` بعد GitHub Gate أخضر.
Step 7.2 Memory Engine v1 أُغلقت رسميًا على `2.0.0-alpha7.3-dev18 / versionCode 32` بعد GitHub Gate أخضر.
Step 7.3 + 7.4 أُغلقتا رسميًا على `2.0.0-alpha7.3-dev19 / versionCode 33` بعد GitHub Gate أخضر.
Step 7.5 + 7.6 منفذتان محليًا على `2.0.0-alpha7.3-dev20 / versionCode 34` وتنتظران GitHub Gate مشتركة.

### العقد v1
كل طلب Chat في AION Cloud يُنشئ خطة تشغيل versioned قبل التنفيذ، وتحتوي metadata آمنة فقط:
- `model`: اختيار المستخدم وسياسة routing الحالية.
- `memory`: تستخدم `memory-v1-retrieved-scoped` بعد hard-scope retrieval محلي، وتخضع الآن لـMemory Privacy user controls.
- `context`: Context Engine v1 يبني budgeted verbatim window + extractive digest بلا generated summary.
- `search`: قرار واحد مركزي مع سبب typed (`research-mode`, `forced`, `explicit-request`, `freshness-signal`, `not-required`).
- `tool`: Universal Tool Router v1 فعلي؛ البحث الحالي يمر كـ`web.search` مع permissions/timeout/typed failures.
- `clarification`: العقد يثبت سياسة `single-question-when-blocking` لكن التقييم الآلي مؤجل لخطوته المخصصة.
- `response`: profile مشتق من mode (`concise`, `balanced`, `deep`, `research`) بدون فرض token caps جامدة في هذه النقطة.

### Trace
- لكل طلب `traceId` عشوائي.
- الـtrace لا يحمل نص المستخدم أو محتوى الذاكرة أو مفاتيح المزودات.
- Android يتحقق من contract والقيم المسموحة قبل حفظ metadata مع رد AION.
- unknown/future values تفشل مغلقة إلى قيم فارغة بدل الثقة بها.

### التكامل مع Step 6
- Claude/Gemini/Grok تبقى pinned ولا cross-provider fallback صامت.
- Workers AI internal fallback يبقى كما اعتمد في 6.5.
- provider-neutral history في 6.6 لم يتغير.
- Voice / My Voice / AION Live لم تتغير.

### ما ليس ضمن 7.1
- لا Memory Engine تلقائي بعد.
- لا Vector/RAG memory retrieval بعد.
- لا Calculator أو Code Sandbox بعد.
- لا Generic Tool Loop بعد.
- لا تغيير نهائي للـSystem Prompt أو Temperature policy.

7.1–7.4 مغلقة رسميًا. الدفعة الحالية: **Step 7.5 + 7.6 — Memory Controls & Privacy + Universal Tool Router**.


## Step 7.2 — Memory Engine v1
راجع `AION_ALPHA73_STEP7_MEMORY_ENGINE_AR.md`.


## Step 7.3 + 7.4 — Context + Retrieval
راجع `AION_ALPHA73_STEP7_CONTEXT_MEMORY_RETRIEVAL_AR.md`.


## Step 7.5 + 7.6 — Memory Privacy + Tool Router
راجع `AION_ALPHA73_STEP7_MEMORY_PRIVACY_TOOL_ROUTER_AR.md`.
