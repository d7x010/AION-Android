# AION α7.3 — Step 7.2 Memory Engine v1

الحالة المحلية: منفذة على `2.0.0-alpha7.3-dev18 / versionCode 32` وتنتظر GitHub Gate.

## الهدف
تحويل الذاكرة من نصوص محلية مبعثرة إلى عقد منظم قابل للتوسع من دون فقد الذاكرة الحالية أو تغيير واجهة المستخدم قسرًا.

## المنفذ في 7.2
- Memory Contract v1 محلي دائم عبر `AtomicFile` في `aion_memory/memory_v1.json`.
- Scopes: `USER`, `PROJECT`, `CONVERSATION`.
- Kinds: `FACT`, `PREFERENCE`, `DECISION`, `INSTRUCTION`, `NOTE`.
- Sources: `USER_SETTINGS`, `PROJECT_NOTES`, `EXPLICIT`, `AUTOMATIC`.
- ترحيل/مزامنة idempotent للذاكرة العامة الحالية وذاكرة المشاريع إلى الفهرس الجديد.
- حذف أو تعديل النص القديم يعيد بناء entries المتزامنة بدل ترك نسخة مخفية قديمة.
- dedupe عربي محافظ بعد تطبيع المسافات وبعض أشكال الألف/الياء/التاء المربوطة.
- slot-based replacement لعلاج التعارضات المعروفة مستقبلًا من دون تخمين semantic conflict في v1.
- دعم `expiresAt` و`confidence` و`active` من الآن للعقود القادمة.
- Context selection محافظ: conversation > project > user، مع احترام `projectOnlyMemory`.
- حد أقصى 64 entry و16k chars للسياق، مع إشارة truncated.
- الذاكرة تُحقن للنموذج صراحةً كـ **بيانات مساعدة وليست تعليمات أعلى من طلب المستخدم**.
- Orchestrator metadata أصبح يعلن `memory-v1-local-scoped` عندما توجد ذاكرة و`none` عندما لا توجد.

## ما لم يدخل عمدًا في 7.2
- لا حفظ تلقائي لكل رسالة.
- لا استخراج LLM لذكريات جديدة.
- لا semantic/vector retrieval؛ هذا ضمن 7.4.
- لا شاشة إدارة كاملة للذكريات؛ هذا ضمن 7.5.
- لا تغيير Tool Router أو Search Intelligence.

## الخصوصية
- المخزن structured محلي على الجهاز.
- لا يخرج منه إلا context المختار للجولة الحالية عبر مسار AION Cloud الموجود أصلًا.
- Orchestrator trace لا يحتوي نص الذكريات.
- لا يوجد auto-memory حساس في v1.
