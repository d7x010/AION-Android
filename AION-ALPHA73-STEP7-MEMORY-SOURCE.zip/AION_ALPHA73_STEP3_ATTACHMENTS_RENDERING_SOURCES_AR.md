# AION α7.3 — Step 3: Attachments + Images + PDF + Markdown + Code + Tables + Sources

الحالة: مكتملة محليًا — dev4

## المرفقات والصور
- توحيد بطاقات المرفقات وفق AION Obsidian بدل chips نصية بسيطة.
- الصور المرفقة تظهر كمعاينة فعلية داخل الرسالة، مع Fullscreen viewer.
- دعم pinch-to-zoom وdouble-tap zoom للصورة الكاملة.
- تصحيح اتجاه صور JPEG عند وجود EXIF orientation في المعاينة، وكذلك قبل إعادة ترميز الصور الكبيرة.
- دعم HEIC/HEIF كمصادر صور إضافية بدل رفضها مباشرة.
- Downsampling للمعاينات يتم على IO لتقليل استهلاك الذاكرة.
- كل المرفقات تحفظ نسخة داخلية فقط ضمن aion_attachments.
- إضافة FileProvider آمن لفتح النسخة الداخلية في تطبيق متوافق عند الضغط على ملف/PDF.
- منع تسريب ملفات المرفقات المؤقتة: الملفات المرفوضة بسبب حد الحجم، أو التي يزيلها المستخدم قبل الإرسال، أو التي تترك عند تبديل المحادثة يتم حذف نسختها المحلية.

## PDF والملفات
- تمييز PDF / مستند / جدول / كود / نص بصريًا.
- PDF يعرض عدد الصفحات فعليًا عندما تكون النسخة المحلية سليمة، باستخدام PdfRenderer على IO.
- البطاقة تعرض النوع + عدد الصفحات عند توفره + الحجم.
- الضغط على ملف مرسل أو قيد الإرسال يفتحه عبر FileProvider إذا يوجد تطبيق متوافق.
- لا توجد قراءة صفحات PDF مزيفة؛ العدد لا يظهر إذا تعذر استخراجه فعليًا.

## Markdown
- نقل parser الأساسي إلى MarkdownRenderPolicy قابل للاختبار بدل إبقائه داخل Composable.
- دعم headings حتى H4، فواصل، اقتباسات متعددة الأسطر، bullets، numbered lists، والجداول.
- دعم inline bold وitalic وstrikethrough وinline code.
- دعم Markdown links بصريًا وفتح HTTP/HTTPS فقط.
- دعم citations من نوع [1] وربطها بالمصدر المناظر عند توفر مصادر الرد.
- fenced code غير المكتمل أثناء Streaming يبقى Code Block ولا يقفز إلى نص عادي حتى يصل closing fence.

## Code Blocks
- LTR ثابت للكود داخل واجهة RTL.
- اسم اللغة normalized مثل Kotlin / Python / JavaScript.
- إظهار عدد الأسطر.
- نسخ الكود كاملًا مع feedback ✓ لمدة قصيرة.
- الكود الطويل يطوى افتراضيًا بعد 28 سطرًا مع «عرض الكود كاملًا» / «طي الكود».
- أثناء Streaming يظهر «جارٍ الإكمال» داخل رأس الكود إذا لم يصل closing fence بعد.

## Tables
- الجدول يملك horizontal scroll داخليًا فقط، ولا يجعل المحادثة كلها تتحرك أفقيًا.
- أحجام الأعمدة تتكيف ضمن حدود ثابتة بدل عرض 150dp لكل عمود دائمًا.
- Header أوضح، وصفوف متناوبة خفيفة، وخط 13sp / line-height 20sp.

## Sources
- ChatSource يدعم snippet اختياريًا مع backward compatibility.
- Firecrawl snippets تنتقل من Worker إلى Android وتُحفظ محليًا بحد 600 حرف.
- Source chips تبقى منفصلة عن أزرار Copy/Listen/More.
- Sources Sheet تعرض title + domain + snippet عند توفره + فتح المصدر.
- لا يفتح AION روابط Markdown أو Sources إلا http/https.

## Design system
- إضافة Attachment radius ومقاسات ثابتة للـthumbnail / card width / image height إلى Design Tokens.
- المرفقات والمصادر تستخدم الأزرق بوصفها «سياقًا خارجيًا»، بدل نشر البنفسجي على كل عنصر.

## السلامة والأداء
- PdfRenderer وBitmap decoding على Dispatchers.IO.
- previews تستخدم downsampling.
- عدم الاحتفاظ بصور كاملة غير ضرورية في مسار العرض.
- FileProvider exported=false + grantUriPermissions فقط.
- cleanup لمسارات pending/rejected attachments.

## الفحوص المحلية
- MarkdownRenderPolicy + AttachmentPresentationPolicy core smoke: PASS.
- structural delimiter scan للملفات المعدلة: PASS.
- Kotlin parser smoke: لا توجد diagnostics من نوع expecting/unclosed/unexpected tokens.
- XML parse لكل Manifest/resources: PASS.
- Worker JS syntax: PASS.
- Worker regression suite: AION worker tests: PASS.
- Full Android Gradle Unit/Lint/assembleDebug مؤجل لبوابة GitHub بعد إغلاق الخطوات التطويرية المتفق عليها.

الإصدار الداخلي: 2.0.0-alpha7.3-dev4 / versionCode 18.
