# AION α7.3 — Step 6.1 Multi‑Provider Core

الحالة: LOCAL READY / OFFICIAL GATE PENDING

الإصدار:
- versionCode = 24
- versionName = 2.0.0-alpha7.3-dev10

## منفذ محليًا
- Provider Catalog خادمي: Anthropic / Gemini / xAI.
- Model Catalog contract=1 عبر `/v1/status`.
- فصل `configured` عن `chatReady`.
- model IDs خادمية وليست مثبتة داخل APK.
- `ModelCatalogPolicy` في Android للتحقق من entries القادمة من Cloud.
- Model Picker يدمج الخيارات الخارجية ديناميكيًا وتبقى Disabled حتى `chatReady=true`.
- fallback آمن إلى AION Auto إذا كان الاختيار المحفوظ لم يعد صالحًا.
- رفض explicit external model selection غير الجاهز بـHTTP 409 بدل fallback صامت.
- اختبارات تمنع تسريب API keys في status.

## خارج النطاق
- لا Anthropic inference فعلي في 6.1.
- لا Gemini inference فعلي في 6.1.
- لا Grok inference فعلي في 6.1.
- لا Conversation Fusion/Memory changes.
- لا تغييرات على Voice/My Voice/Live.

## فحوص محلية
- Worker JavaScript syntax: PASS
- Worker regression + provider catalog tests: PASS
- ModelCatalogPolicy JVM smoke: PASS
- XML parse: PASS
- Duplicate Kotlin imports: PASS
- Provider secret pattern scan: PASS
- Kotlin targeted syntax diagnostic scan: no syntax diagnostics

الإغلاق الرسمي مشروط بـ:
GitHub Actions Unit + Lint + assembleDebug + apksigner + artifact upload.
