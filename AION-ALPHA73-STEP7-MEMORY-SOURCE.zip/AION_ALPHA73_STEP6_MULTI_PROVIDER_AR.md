# AION α7.3 — Step 6: Multi‑Provider Models — FINAL CLOSURE

## الحالة الحالية
Step 6.1–6.6: مكتملة وظيفيًا ومحليًا.
Step 6 Final Closure: LOCAL PASS / GitHub Final Gate pending.

الإصدار النهائي المرشح لهذه المرحلة:
- versionCode: 30
- versionName: 2.0.0-alpha7.3-dev16
- Worker status version: 7.3.0-dev16

## هدف Step 6 النهائي
جعل AION متعدد المزودات فعليًا مع إبقاء AION Cloud مصدر الحقيقة للـprovider/model catalog، ومنع تسريب مفاتيح المزودات إلى APK، والحفاظ على اختيار المستخدم وسياق المحادثة عند التبديل بين النماذج.

## Step 6.1 — Multi‑Provider Core
- Provider Catalog خادمي لـAnthropic / Gemini / xAI.
- `/v1/status.models.contract = 2`.
- model IDs تأتي من الخادم عبر `AION_CLAUDE_MODEL` و`AION_GEMINI_MODEL` و`AION_GROK_MODEL` ولا تثبت داخل APK.
- فصل `configured` عن `chatReady`.
- Android يتحقق من catalog قبل تمكين أي external model.
- الاختيار المحفوظ غير المتاح يعود عند حد الاختيار إلى AION Auto بدل إبقاء خيار ميت.
- لا API keys أو provider secrets داخل status أو APK.

## Step 6.2 — Claude Execution
- تنفيذ فعلي عبر Anthropic Messages API من AION Cloud.
- Sync + SSE Streaming + Vision.
- system context يترجم إلى Anthropic `system`.
- model ID خادمي فقط ومفتاح Anthropic لا يدخل APK.
- بحث Claude الحي يستخدم Firecrawl في هذه المرحلة.
- اختيار Claude pinned ولا يسقط بصمت إلى مزود آخر.

## Step 6.3 — Gemini Execution
- تنفيذ فعلي عبر Gemini Generate Content REST API من AION Cloud.
- Sync + SSE Streaming + Vision.
- system context يترجم إلى `systemInstruction` ورسائل assistant إلى role=`model`.
- model ID خادمي فقط ومفتاح Gemini لا يدخل APK.
- بحث Gemini الحي يستخدم Firecrawl في هذه المرحلة.
- اختيار Gemini pinned ولا يسقط بصمت إلى مزود آخر.

## Step 6.4 — Grok/xAI Execution
- تنفيذ فعلي عبر xAI Responses API.
- Sync + SSE Streaming + Vision لـJPEG/PNG.
- `store=false` في مسار Responses الحالي.
- model ID خادمي فقط ومفتاح xAI لا يدخل APK.
- بحث Grok الحي يستخدم Firecrawl في هذه المرحلة.
- اختيار Grok pinned ولا يسقط بصمت إلى مزود آخر.

## Step 6.5 — Provider Routing & Failover
- فصل **Selection** عن **Execution provenance**.
- Claude/Gemini/Grok اختيارات pinned.
- `crossProviderFailover=false` لكل المسارات الحالية.
- Auto/Fast/Deep/Research يسمح فقط بـWorkers AI internal fallback وقبل أول token.
- sync وSSE done يعيدان provider/model/policy/fallback/attempts metadata.
- Android يحفظ execution metadata بصورة backward-compatible ويعرض provenance الفعلي دون تغيير selection key.
- fallback الداخلي بعد أول token ممنوع حتى لا يعاد الرد من الصفر فوق نص جزئي.

## Step 6.6 — Cross‑Model Context Compatibility
- `providerNeutralConversation` هو المصدر الحاكم لتطبيع history قبل أي external adapter.
- system context يبقى منفصلًا عن user/assistant history.
- same-role turns تدمج مع الحفاظ على ترتيب المعنى.
- leading orphan assistant من نافذة مقطوعة يهمل بدل رفعه إلى system أو user.
- آخر turn يجب أن يكون user قبل توليد رد جديد.
- Claude adapter: user/assistant blocks.
- Gemini adapter: user/model parts.
- xAI adapter: Responses input.
- current-turn Vision يبقى native لكل مزود.
- `/v1/status.models.context.contract = 1` و`canonicalHistory=provider-neutral` و`crossModelSwitching=true`.

## Final Step 6 Contracts
يجب أن تبقى هذه العقود ثابتة بعد dev16 ما لم يتم تغييرها في إصدار لاحق بصورة صريحة ومختبرة:
- `models.contract = 2`.
- `models.routing.contract = 1`.
- `models.context.contract = 1`.
- External selections pinned.
- `crossProviderFailover = false`.
- Built-in fallback = Workers AI only وقبل أول token.
- API keys خادمية فقط.
- Provider/model IDs المعروضة مصدرها الخادم وليست hard-coded داخل APK.
- Cross-model switching يحافظ على provider-neutral history.
- Execution provenance لا يغير selection key.
- Step 4/5 Voice / My Voice / AION Live لا تتغير ضمن Step 6 Closure.

## Final Closure Matrix
إغلاق Step 6 لا يعتمد على نجاح كل نقطة منفصلة فقط؛ dev16 يضيف مصفوفة تكامل نهائية تتحقق في تشغيل واحد من:
- Catalog وstatus contracts.
- Claude/Gemini/Grok جميعها READY عند تهيئة أسرارها وموديلاتها.
- تنفيذ حقيقي mock-isolated لكل من Claude ثم Gemini ثم Grok مع نفس history.
- الأدوار المترجمة صحيحة لكل provider adapter.
- كل external response يعيد pinned routing provenance الصحيح.
- Workers AI internal fallback يعمل وحده ولا يتحول إلى external provider.
- status/health لا يسرب API keys أو Firecrawl secret.

## Android Final Contract Test
`Step6IntegrationContractTest` يجمع في اختبار واحد:
- allowlist وتمكين external catalog.
- fallback عند حد selection فقط للخيار غير المتاح.
- pinned external routing.
- Workers-only built-in fallback policy.
- الفصل بين selection وexecution provenance.

## بوابة الإغلاق الرسمية
لا تصبح Step 6 `CLOSED` رسميًا قبل نجاح GitHub Actions في:
1. Worker regression + Step 6 final integration matrix.
2. Android Unit Tests، بما فيها `Step6IntegrationContractTest`.
3. Android Lint.
4. `assembleDebug`.
5. APK signature verification.
6. Artifact upload.

بعد نجاح هذه البوابة يصبح `2.0.0-alpha7.3-dev16 / code30` خط الأساس الرسمي لأي مرحلة تطوير جديدة.
