# AION α7.1 — إصلاح البحث والرؤية والاتصال

تاريخ الجولة: 2026-09-09

## ما تم إصلاحه

1. **بحث الويب**
   - لم يعد غياب `FIRECRAWL_API_KEY` يمنع البحث بالكامل.
   - عند غياب Firecrawl أو فشله يستخدم Worker بحث Workers AI المدمج عبر `web_search_options` ونموذج Gemma 4.
   - يبقى Firecrawl مسارًا اختياريًا عند توفره لإرجاع قائمة مصادر مستقلة للواجهة.

2. **فهم الصور**
   - أزيل تمرير الصور إلى Markdown Conversion.
   - الصور ترسل كـ `image_url` structured content مباشرة إلى `@cf/google/gemma-4-26b-a4b-it` لأنه يدعم Vision.
   - أي طلب يحتوي صورة يُوجّه إلى نموذج الرؤية بدل GLM النصي.

3. **Connection reset على أندرويد**
   - طلبات Android تستخدم fixed-length request bodies.
   - عند قطع اتصال SSE يعيد التطبيق المحاولة تلقائيًا عبر `/v1/chat`.
   - إذا كان جزء من الرد وصل بالفعل، لا يكرر النص إلا عندما يمكن مطابقة بادئة الرد بأمان.
   - رسائل الخطأ الشبكية أصبحت عربية وأوضح.

4. **إصدارات**
   - Android: `2.0.0-alpha7.1`, versionCode 12.
   - Worker status: `7.1.0`.

## اختبارات Worker

`node cloudflare/aion-core/test-worker.mjs`

النتيجة: `AION worker tests: PASS`

تشمل الاختبارات: streaming، fallback قبل أول token، منع fallback المكرر بعد partial stream، ملفات نصية، PDF conversion، context طويل، personalization، routing، البحث المدمج بدون Firecrawl، وVision routing للصورة.
