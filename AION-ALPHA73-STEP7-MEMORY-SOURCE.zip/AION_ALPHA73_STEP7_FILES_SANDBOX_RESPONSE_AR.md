# AION α7.3 — Step 7.9 + 7.10

## Version
`2.0.0-alpha7.3-dev23 / versionCode 37`

## 7.9 — Files + Safe Code Sandbox
- `files.read` is now a first-class Universal Tool Router route and may participate in the bounded multi-step loop.
- It reads only non-image attachments selected by the user and uses the existing AION text/Workers AI Markdown conversion path.
- File contents are inserted as untrusted tool data, never as system instructions.
- Tool metadata returns only safe execution facts/counts; file names/content are excluded from the orchestration trace.
- `code.execute` is a first-class route but execution is remote-only. Android وAION Core لا يحتويان eval أو shell أو child-process path.
- أضيف backend قابل للنشر داخل `cloudflare/aion-sandbox` مبني على Cloudflare Sandbox SDK/Containers، مع VM/container isolation و`enableInternet=false`.
- backend v1 يدعم Python وJavaScript فقط؛ الكود يُكتب إلى ملف ثابت ثم يُشغّل بأمر ثابت، وليس عبر interpolation داخل command.
- كل تنفيذ يحصل على sandbox ID جديد ثم `destroy()` في `finally` لمسح الملفات والعمليات.
- Safe sandbox policy: `remote-isolated-fail-closed-v1`. A server-administered HTTPS endpoint and server-side token are required.
- Code is sent only to that fixed server configuration with `network:false`, a bounded timeout, input/output size caps, and typed failure states.
- If the sandbox is unavailable/timeout/fails, AION explicitly records failure and the response policy forbids claiming execution.

## 7.10 — Response Intelligence / System Prompt v2
- Contract: `response-intelligence-v2`, contract 2.
- Current explicit user request outranks older memory/context/custom instructions when they conflict.
- Clarification policy is evaluated, not only documented: `single-question-when-blocking-v2`. Narrow deterministic blocking cases skip inference and return one question.
- Tool result discipline: succeeded/partial results may be used; failed/unavailable/timeout results cannot be described as successful.
- Search/source discipline: no claim of live/current verification without actual live search or sources.
- File/web contents remain untrusted data with prompt-injection isolation.
- Response profile remains concise/balanced/deep/research, now under the v2 policy.
- Orchestration metadata no longer carries raw tool inputs.

## Boundaries
- This is not an unrestricted autonomous agent or a local shell.
- Safe Code Sandbox source is bundled under `cloudflare/aion-sandbox`, but live execution remains unavailable until that Worker/Container is deployed and AION Core receives its HTTPS URL/token. Cloudflare Sandbox/Containers requires Workers Paid; AION fails closed rather than faking execution.
- Images still use the established native-vision path.
- Provider routing/pinned external-provider rules from Step 6 remain unchanged.
- Memory/Context/Privacy contracts from 7.1–7.8 remain unchanged.
- Voice / My Voice / AION Live are unchanged.
