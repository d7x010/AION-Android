# AION α7 — ملف انتقال مختصر

المرجع الحاكم لهذه الجولة هو مشروع Android في هذا الأرشيف مع Worker داخل `cloudflare/aion-core`.

## ما تغير جوهريًا
- Streaming حقيقي على Workers AI.
- مرفقات حقيقية وقراءة مستندات/صور.
- Multi-conversation + بحث محلي في السجل + مسودات مستقلة.
- ربط مهام الخلفية بمعرّف المحادثة.
- اختيار الوضع في Top Bar.
- Code blocks + copy.
- Voice RMS/TTS محسّن.
- ذاكرة محلية وتعليمات شخصية صريحة.
- Routing: Auto/Fast=GLM 4.7 Flash، Deep=GPT-OSS-120B، Research=Gemma 4، مع fallback.

## لا تعتبر مكتملًا
- Full-duplex voice الحقيقي.
- Agents/Projects كاملة.
- أدوات/Agent runtime كامل متعدد الأدوات.
- ذاكرة تلقائية شاملة.

## بوابة البناء
Gradle tasks المطلوبة: `:app:testDebugUnitTest :app:lintDebug :app:assembleDebug`. لا تعتمد APK قبل نجاحها.


## خط أساس Step 6 النهائي
- الإصدار: AION 2.0.0-alpha7.3-dev16 / versionCode 30.
- Step 6.1–6.6 مكتملة تكامليًا عند نجاح Gate النهائية.
- Claude/Gemini/Grok مزودات تنفيذ فعلية عند تهيئة مفاتيحها/model IDs على AION Cloud.
- external providers pinned بلا cross-provider fallback صامت.
- Workers AI fallback داخلي فقط وقبل أول token.
- provider-neutral context يحكم التبديل بين النماذج داخل نفس المحادثة.
- Voice/My Voice/AION Live تبقى على عقود Step 4/5 دون تغيير.

## CURRENT — Step 7.7 + 7.8 / dev22
- Step 6 مغلق رسميًا عند dev16/code30.
- Step 7.1 Orchestrator Contract مغلق رسميًا عند dev17/code31.
- Step 7.2 Memory Engine v1 مغلق رسميًا عند dev18/code32.
- Step 7.3 + 7.4 Context Engine + Memory Retrieval مغلقان رسميًا عند dev19/code33.
- Step 7.5 + 7.6 Memory Privacy + Universal Tool Router مغلقان رسميًا عند dev21/code35، Gate Run #5 / 34446316478 أخضر.
- dev20/code34 يبقى سجل فشل تاريخي بسبب JVM setter clash فقط؛ لا يُستخدم كbaseline.
- الدفعة الحالية تجمع 7.7 Search Intelligence + Deterministic Calculator مع 7.8 bounded Multi-Step Tool Loop في dev22/code36.
- Search decision أوسع للـfreshness/current-entity/time-sensitive مع تنقية URLs المكررة وغير HTTP(S).
- Calculator deterministic محلي/Worker، بلا LLM أو eval، ويدعم الأرقام العربية والأقواس و+ - * / % ^ وpi/e.
- Tool Loop v1 تنفذ أكثر من أداة صريحة في الطلب نفسه بحد أقصى 4 خطوات، وتحافظ على ترتيب النية المكتشفة.
- v1 لا تدعي Agent planning ديناميكيًا أو recursion مفتوحًا؛ هذه مرحلة لاحقة.
- 7.9 Files & Safe Code Sandbox و7.10 Response Intelligence لم تدخلا dev22.
- لا تعلن 7.7/7.8 CLOSED قبل GitHub Gate خضراء تشمل Unit + Lint + assembleDebug + APK verification.


## Step 7 current
- 7.1 Orchestrator Contract: CLOSED/GREEN on dev17/code31.
- 7.2 Memory Engine v1: CLOSED/GREEN on dev18/code32.
- 7.3 + 7.4 Context Engine + Memory Retrieval: CLOSED/GREEN on dev19/code33.
- 7.5 + 7.6 Memory Privacy + Tool Router: CLOSED/GREEN on dev21/code35.
- 7.7 + 7.8 Search Intelligence + Calculator + Tool Loop: local PASS on dev22/code36; GitHub Gate pending.
- New cadence after 7.2: two related roadmap points per development batch/Gate.


## Step 7.9 + 7.10 — dev23/code37 local
- Files Tool: `files.read`, scoped to user attachments, max 8, existing 5 MB attachment limit, prompt-injection isolated.
- Safe Code Sandbox: `code.execute`, remote HTTPS only from AION Core, server secret only, no local eval/shell. Bundled deployable backend: `cloudflare/aion-sandbox`, Cloudflare Sandbox SDK 0.12.9, `enableInternet=false`, Python/JavaScript v1, unique sandbox + destroy, fail-closed until deployed/configured.
- Response Intelligence v2 contract 2 + deterministic narrow clarification gate.
- Orchestrator public trace contains no raw tool inputs.
- Local Worker regression + Kotlin compile/runtime smoke PASS; GitHub Android Gate required before CLOSED.
- Next after green: Step 7 Final Closure only.
