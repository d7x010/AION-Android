package com.aion.mobile.core.ai

/**
 * Pure policy for provider execution metadata returned by AION Cloud.
 * Selection and execution are intentionally separate: a user selection key is not a provider model id.
 */
object ProviderRoutingPolicy {
    private val safeKey = Regex("^[a-z][a-z0-9_-]{0,31}$")
    private val pinnedExternal = setOf("claude", "gemini", "grok")

    fun normalizeProviderKey(value: String?): String =
        value.orEmpty().trim().lowercase().takeIf { safeKey.matches(it) }.orEmpty()

    fun normalizeProviderLabel(value: String?): String =
        value.orEmpty().replace(Regex("[\r\n\u0000]"), " ").trim().take(64)

    fun normalizeExecutionModelId(value: String?): String =
        value.orEmpty().trim().take(160).takeIf { it.isNotBlank() && it.none(Char::isISOControl) }.orEmpty()

    fun normalizePolicy(value: String?): String = when (value.orEmpty().trim().lowercase()) {
        "pinned-external" -> "pinned-external"
        "aion-workers-internal-fallback" -> "aion-workers-internal-fallback"
        else -> ""
    }

    fun canCrossProviderFailover(@Suppress("UNUSED_PARAMETER") selectionKey: String?): Boolean = false

    fun expectedPolicy(selectionKey: String?): String =
        if (ModelCatalogPolicy.normalizeKey(selectionKey) in pinnedExternal) "pinned-external"
        else "aion-workers-internal-fallback"

    fun displayLabel(providerLabel: String?, executionModelId: String?, fallbackUsed: Boolean): String {
        val provider = normalizeProviderLabel(providerLabel)
        val model = normalizeExecutionModelId(executionModelId)
        if (provider.isBlank() && model.isBlank()) return ""
        val base = when {
            provider.isNotBlank() && model.isNotBlank() -> "$provider • $model"
            provider.isNotBlank() -> provider
            else -> model
        }
        return if (fallbackUsed) "$base • احتياطي" else base
    }
}
