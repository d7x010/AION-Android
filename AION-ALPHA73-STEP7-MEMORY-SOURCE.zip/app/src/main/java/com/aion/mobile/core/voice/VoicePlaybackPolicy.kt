package com.aion.mobile.core.voice

/** Pure handoff rules shared by Read Aloud and AION Live. */
object VoicePlaybackPolicy {
    /**
     * If a neural chunk failed before first PCM, local TTS may safely repeat that whole chunk.
     * If PCM already started, skip the current chunk to avoid speaking duplicated words and
     * continue from the next natural chunk instead of truncating the entire answer.
     */
    fun localFallbackText(chunks: List<String>, failedIndex: Int, failedChunkStarted: Boolean): String {
        if (chunks.isEmpty() || failedIndex !in chunks.indices) return ""
        val start = (failedIndex + if (failedChunkStarted) 1 else 0).coerceAtMost(chunks.size)
        return chunks.drop(start).joinToString(" ").trim()
    }
}
