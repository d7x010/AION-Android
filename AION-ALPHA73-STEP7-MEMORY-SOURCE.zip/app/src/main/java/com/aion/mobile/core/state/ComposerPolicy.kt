package com.aion.mobile.core.state

/**
 * Single source of truth for the action slot at the edge of the AION composer.
 * Keeping this logic outside Compose prevents visual/state drift between text,
 * attachments, dictation and streaming.
 */
enum class ComposerPrimaryAction {
    LIVE_AND_DICTATION,
    SEND,
    STOP
}

object ComposerPolicy {
    fun primaryAction(
        isSending: Boolean,
        draftHasText: Boolean,
        hasAttachments: Boolean
    ): ComposerPrimaryAction = when {
        isSending -> ComposerPrimaryAction.STOP
        draftHasText || hasAttachments -> ComposerPrimaryAction.SEND
        else -> ComposerPrimaryAction.LIVE_AND_DICTATION
    }
}
