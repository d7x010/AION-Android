package com.aion.mobile.core.voice

import android.content.Context

enum class AionVoiceProfile(
    val key: String,
    val label: String,
    val description: String,
    val defaultSpeed: Float,
    val defaultExpression: Float,
    val defaultClarity: Float
) {
    CALM(
        key = "calm",
        label = "هادئ",
        description = "أبطأ قليلًا ونبرة أكثر ثباتًا",
        defaultSpeed = 0.94f,
        defaultExpression = 0.14f,
        defaultClarity = 0.78f
    ),
    BALANCED(
        key = "balanced",
        label = "متوازن",
        description = "النبرة الافتراضية للمحادثة اليومية",
        defaultSpeed = 0.96f,
        defaultExpression = 0.23f,
        defaultClarity = 0.80f
    ),
    EXPRESSIVE(
        key = "expressive",
        label = "تعبيري",
        description = "تنوّع أكبر في الإلقاء مع ثبات أقل",
        defaultSpeed = 0.98f,
        defaultExpression = 0.51f,
        defaultClarity = 0.80f
    );

    companion object {
        fun fromKey(key: String?): AionVoiceProfile = entries.firstOrNull { it.key == key } ?: BALANCED
    }
}

data class AionVoiceSettings(
    val voiceKey: String = "",
    val profile: AionVoiceProfile = AionVoiceProfile.BALANCED,
    val speed: Float = profile.defaultSpeed,
    val expression: Float = profile.defaultExpression,
    val clarity: Float = profile.defaultClarity
) {
    fun normalized(): AionVoiceSettings = copy(
        voiceKey = NeuralVoiceContract.normalizedVoiceKey(voiceKey),
        speed = NeuralVoiceContract.clampSpeed(speed) ?: profile.defaultSpeed,
        expression = NeuralVoiceContract.clampExpression(expression) ?: profile.defaultExpression,
        clarity = NeuralVoiceContract.clampClarity(clarity) ?: profile.defaultClarity
    )

    /** Selecting a preset intentionally resets tuning to that preset's reference values. */
    fun applyProfilePreset(nextProfile: AionVoiceProfile): AionVoiceSettings = copy(
        profile = nextProfile,
        speed = nextProfile.defaultSpeed,
        expression = nextProfile.defaultExpression,
        clarity = nextProfile.defaultClarity
    )
}

object VoicePreferences {
    private const val PREFS = "aion_voice_preferences"
    private const val KEY_PROFILE = "profile"
    private const val KEY_VOICE = "voice_key"
    private const val KEY_SPEED = "speed"
    private const val KEY_EXPRESSION = "expression"
    private const val KEY_CLARITY = "clarity"

    fun loadSettings(context: Context): AionVoiceSettings {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val profile = AionVoiceProfile.fromKey(
            runCatching { prefs.getString(KEY_PROFILE, AionVoiceProfile.BALANCED.key) }.getOrNull()
        )
        return AionVoiceSettings(
            voiceKey = runCatching { prefs.getString(KEY_VOICE, "") }.getOrNull().orEmpty(),
            profile = profile,
            speed = runCatching { prefs.getFloat(KEY_SPEED, profile.defaultSpeed) }.getOrDefault(profile.defaultSpeed),
            expression = runCatching { prefs.getFloat(KEY_EXPRESSION, profile.defaultExpression) }.getOrDefault(profile.defaultExpression),
            clarity = runCatching { prefs.getFloat(KEY_CLARITY, profile.defaultClarity) }.getOrDefault(profile.defaultClarity)
        ).normalized()
    }

    fun saveSettings(context: Context, settings: AionVoiceSettings) {
        val clean = settings.normalized()
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_PROFILE, clean.profile.key)
            .putString(KEY_VOICE, clean.voiceKey)
            .putFloat(KEY_SPEED, clean.speed)
            .putFloat(KEY_EXPRESSION, clean.expression)
            .putFloat(KEY_CLARITY, clean.clarity)
            .apply()
    }

    // Compatibility helpers for older call sites / migrations.
    fun loadProfile(context: Context): AionVoiceProfile = loadSettings(context).profile

    fun saveProfile(context: Context, profile: AionVoiceProfile) {
        saveSettings(context, loadSettings(context).copy(profile = profile))
    }
}
