package com.aion.mobile.core.storage

import android.content.Context
import android.util.AtomicFile
import java.io.File
import com.aion.mobile.model.AttachmentKind
import com.aion.mobile.core.search.ConversationSearchHit
import com.aion.mobile.core.search.ConversationSearchPolicy
import com.aion.mobile.model.ChatAttachment
import com.aion.mobile.model.ChatMessage
import com.aion.mobile.model.ChatSource
import com.aion.mobile.model.MessageRole
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/** وصف خفيف يظهر في درج المحادثات من دون تحميل سجل كل محادثة. */
data class ConversationSummary(
    val id: String,
    val title: String,
    val preview: String = "",
    val searchText: String = "",
    val updatedAt: Long,
    val messageCount: Int,
    val customTitle: Boolean = false,
    val pinned: Boolean = false,
    val archived: Boolean = false,
    val projectId: String? = null
)

data class ConversationBuckets(
    val active: List<ConversationSummary>,
    val archived: List<ConversationSummary>
)

/**
 * تخزين محلي للمحادثات والمسودات.
 * لا نخزن Base64 للمرفقات حتى لا يتضخم التخزين؛ نحفظ بياناتها الوصفية فقط.
 * يدعم ترحيل الجلسة الوحيدة من α6 إلى سجل محادثات متعدد من دون فقدها.
 */
object ChatSessionStore {
    private const val PREFS = "aion_chat_session"
    private const val KEY_LEGACY_MESSAGES = "messages"
    private const val KEY_LEGACY_DRAFT = "draft"
    private const val KEY_SELECTED_MODEL = "selected_model"
    private const val KEY_ACTIVE_CONVERSATION = "active_conversation_id"
    private const val KEY_CONVERSATIONS = "conversation_index_v2"
    private const val KEY_SEARCH_INDEX_VERSION = "search_index_version"
    private const val KEY_SCHEMA_VERSION = "storage_schema_version"
    private const val SEARCH_INDEX_VERSION = 1
    private const val CURRENT_SCHEMA_VERSION = 5
    private const val MAX_CONVERSATIONS = 500
    private const val MAX_MESSAGES_PER_CONVERSATION = 1000

    private val summaryCacheLock = Any()
    @Volatile private var cachedSummaryRaw: String? = null
    @Volatile private var cachedSummaries: List<ConversationSummary> = emptyList()

    fun ensureActiveConversation(context: Context): String {
        migrateLegacyIfNeeded(context)
        val prefs = prefs(context)
        val indexed = loadConversationsInternal(prefs).filterNot { it.archived }
        val savedActive = safeGetString(prefs, KEY_ACTIVE_CONVERSATION, null)
        if (!savedActive.isNullOrBlank() && indexed.any { it.id == savedActive }) return savedActive
        if (indexed.isNotEmpty()) {
            val id = indexed.first().id
            prefs.edit().putString(KEY_ACTIVE_CONVERSATION, id).apply()
            return id
        }
        return createConversation(context)
    }

    fun createConversation(context: Context, projectId: String? = null): String {
        migrateLegacyIfNeeded(context)
        val prefs = prefs(context)
        val id = UUID.randomUUID().toString()
        val summary = ConversationSummary(
            id = id,
            title = "محادثة جديدة",
            preview = "",
            searchText = "",
            updatedAt = System.currentTimeMillis(),
            messageCount = 0,
            projectId = projectId?.takeIf { it.isNotBlank() }
        )
        val updated = (listOf(summary) + loadConversationsInternal(prefs))
            .distinctBy { it.id }
            .take(MAX_CONVERSATIONS)
        prefs.edit()
            .putString(KEY_CONVERSATIONS, encodeSummariesCached(updated))
            .putString(KEY_ACTIVE_CONVERSATION, id)
            .putString(draftKey(id), "")
            .putString(modelKey(id), loadSelectedModel(context))
            .apply()
        return id
    }

    fun setActiveConversation(context: Context, conversationId: String) {
        migrateLegacyIfNeeded(context)
        if (loadConversationsInternal(prefs(context)).none { it.id == conversationId }) return
        prefs(context).edit().putString(KEY_ACTIVE_CONVERSATION, conversationId).apply()
    }

    fun loadConversationBuckets(context: Context): ConversationBuckets {
        migrateLegacyIfNeeded(context)
        // لا نبني فهرس البحث أثناء الإقلاع. في التحديث من α7.1 قد يعني ذلك
        // فك JSON لكل المحادثات وكتابتها على الخيط الرئيسي قبل ظهور أول إطار.
        // الفهرسة الثقيلة تُنفذ لاحقًا على Dispatchers.IO من ChatViewModel.
        val items = loadConversationsInternal(prefs(context))
        return ConversationBuckets(
            active = items
                .asSequence()
                .filterNot { it.archived }
                .sortedWith(compareByDescending<ConversationSummary> { it.pinned }.thenByDescending { it.updatedAt })
                .toList(),
            archived = items
                .asSequence()
                .filter { it.archived }
                .sortedByDescending { it.updatedAt }
                .toList()
        )
    }

    fun loadConversations(context: Context, includeArchived: Boolean = false): List<ConversationSummary> {
        val buckets = loadConversationBuckets(context)
        return if (includeArchived) {
            (buckets.active + buckets.archived)
                .sortedWith(compareByDescending<ConversationSummary> { it.pinned }.thenByDescending { it.updatedAt })
        } else buckets.active
    }

    fun loadArchivedConversations(context: Context): List<ConversationSummary> =
        loadConversationBuckets(context).archived

    /**
     * بحث محلي دقيق داخل الرسائل مع إرجاع messageId للقفز إلى الموضع نفسه.
     * نستخدم searchText الخفيف لاختيار المحادثات المرشحة أولًا، ثم نقرأ الرسائل
     * للمرشحين فقط على خيط IO من ViewModel، حتى لا يصبح البحث سببًا لتقطّع الواجهة.
     */
    fun searchMessages(
        context: Context,
        query: String,
        maxResults: Int = 24
    ): List<ConversationSearchHit> {
        val normalizedQuery = ConversationSearchPolicy.normalize(query)
        if (normalizedQuery.length < 2) return emptyList()

        val summaries = loadConversationsInternal(prefs(context))
            .asSequence()
            .filterNot { it.archived }
            .filter { summary ->
                val searchable = buildString {
                    append(summary.title).append('\n')
                    append(summary.preview).append('\n')
                    append(summary.searchText)
                }
                ConversationSearchPolicy.normalize(searchable).contains(normalizedQuery)
            }
            .sortedByDescending { it.updatedAt }
            .take(48)
            .toList()

        if (summaries.isEmpty()) return emptyList()

        val hits = ArrayList<ConversationSearchHit>(maxResults.coerceAtMost(32))
        for (summary in summaries) {
            var perConversation = 0
            val messages = loadMessages(context, summary.id)
            for (message in messages.asReversed()) {
                if (message.isError || message.text.isBlank()) continue
                val attachmentNames = message.attachments.joinToString(" ") { it.name }
                val searchBody = if (attachmentNames.isBlank()) message.text else "${message.text} $attachmentNames"
                if (!ConversationSearchPolicy.matches(searchBody, normalizedQuery)) continue

                hits += ConversationSearchHit(
                    conversationId = summary.id,
                    messageId = message.id,
                    conversationTitle = summary.title,
                    snippet = ConversationSearchPolicy.snippet(message.text.ifBlank { attachmentNames }, query),
                    role = message.role,
                    updatedAt = summary.updatedAt,
                    projectId = summary.projectId
                )
                perConversation += 1
                if (hits.size >= maxResults) return hits
                if (perConversation >= 3) break
            }
        }
        return hits
    }

    fun togglePinned(context: Context, conversationId: String) {
        updateSummary(context, conversationId) { it.copy(pinned = !it.pinned, updatedAt = System.currentTimeMillis()) }
    }

    fun setArchived(context: Context, conversationId: String, archived: Boolean) {
        updateSummary(context, conversationId) { it.copy(archived = archived, pinned = if (archived) false else it.pinned, updatedAt = System.currentTimeMillis()) }
    }

    fun moveToProject(context: Context, conversationId: String, projectId: String?) {
        updateSummary(context, conversationId) {
            it.copy(projectId = projectId?.takeIf { value -> value.isNotBlank() }, updatedAt = System.currentTimeMillis())
        }
    }

    fun detachProject(context: Context, projectId: String) {
        migrateLegacyIfNeeded(context)
        val items = loadConversationsInternal(prefs(context)).map {
            if (it.projectId == projectId) it.copy(projectId = null, updatedAt = System.currentTimeMillis()) else it
        }
        prefs(context).edit().putString(KEY_CONVERSATIONS, encodeSummariesCached(items)).apply()
    }

    fun projectContext(context: Context, projectId: String, activeConversationId: String): String {
        if (projectId.isBlank()) return ""
        val related = loadConversationsInternal(prefs(context))
            .filter { it.projectId == projectId && it.id != activeConversationId && !it.archived }
            .sortedByDescending { it.updatedAt }
            .take(3)
        if (related.isEmpty()) return ""
        return buildString {
            append("سياق من محادثات أخرى في المشروع:\n")
            related.forEach { summary ->
                append("\n### ").append(summary.title).append('\n')
                val messages = loadMessages(context, summary.id)
                    .filter { !it.isError && !it.wasStopped && it.text.isNotBlank() }
                    .takeLast(4)
                messages.forEach { message ->
                    append(if (message.role == MessageRole.USER) "المستخدم: " else "AION: ")
                    append(message.text.replace(Regex("\\s+"), " ").trim().take(1_200))
                    append('\n')
                }
            }
        }.take(8_000)
    }

    private fun updateSummary(context: Context, conversationId: String, transform: (ConversationSummary) -> ConversationSummary) {
        migrateLegacyIfNeeded(context)
        val prefs = prefs(context)
        val items = loadConversationsInternal(prefs)
        if (items.none { it.id == conversationId }) return
        val updated = items.map { if (it.id == conversationId) transform(it) else it }
        prefs.edit().putString(KEY_CONVERSATIONS, encodeSummariesCached(updated)).apply()
    }

    fun saveMessages(context: Context, conversationId: String, messages: List<ChatMessage>) {
        migrateLegacyIfNeeded(context)
        val prefs = prefs(context)
        val existing = loadConversationsInternal(prefs)
        val old = existing.firstOrNull { it.id == conversationId }
        val trimmed = messages.takeLast(MAX_MESSAGES_PER_CONVERSATION)

        // القراءة الكاملة للسجل القديم مكلفة، ولا نحتاجها عند الإضافة الطبيعية للرسائل.
        // نفحص المرفقات القديمة فقط عند حذف/اقتطاع رسائل أو عند إسقاط أقدم الرسائل بسبب الحد.
        val mayHaveDetachedAttachments = old != null && (
            trimmed.size < old.messageCount || messages.size > MAX_MESSAGES_PER_CONVERSATION
        )
        if (mayHaveDetachedAttachments) {
            cleanupDetachedAttachments(context, loadMessages(context, conversationId), trimmed)
        }

        val array = encodeMessages(trimmed)
        val derivedTitle = deriveTitle(trimmed)
        val summary = ConversationSummary(
            id = conversationId,
            title = if (old?.customTitle == true) old.title else derivedTitle.ifBlank { old?.title ?: "محادثة جديدة" },
            preview = derivePreview(trimmed),
            searchText = deriveSearchText(trimmed),
            updatedAt = System.currentTimeMillis(),
            messageCount = trimmed.size,
            customTitle = old?.customTitle == true,
            pinned = old?.pinned == true,
            archived = old?.archived == true,
            projectId = old?.projectId
        )
        val updated = (listOf(summary) + existing.filterNot { it.id == conversationId })
            .sortedByDescending { it.updatedAt }
            .take(MAX_CONVERSATIONS)

        persistConversationRaw(context, conversationId, array.toString(), prefs)
        deleteStreamingCheckpoint(context, conversationId)
        prefs.edit()
            .putString(KEY_CONVERSATIONS, encodeSummariesCached(updated))
            .apply()
    }

    /**
     * نقطة حفظ خفيفة أثناء Streaming. تحفظ الرد الجاري وحده في sidecar ذري صغير،
     * بدل إعادة كتابة سجل المحادثة كاملًا. يُدمج تلقائيًا عند الاستعادة ويُحذف عند الحفظ النهائي.
     */
    fun checkpointMessages(context: Context, conversationId: String, messages: List<ChatMessage>) {
        migrateLegacyIfNeeded(context)
        if (conversationId.isBlank()) return
        val streaming = messages.lastOrNull { it.role == MessageRole.AION && it.isStreaming } ?: return
        writeStreamingCheckpoint(context, conversationId, encodeMessage(streaming).toString())
    }

    fun loadMessages(context: Context, conversationId: String): List<ChatMessage> {
        migrateLegacyIfNeeded(context)
        readConversationFile(context, conversationId)?.let {
            return mergeStreamingCheckpoint(context, conversationId, decodeMessages(it))
        }

        // ترحيل كسول من تخزين α7.1 وما قبله. بهذه الطريقة لا نفقد المحادثات عند التحديث.
        val preferences = prefs(context)
        val legacyRaw = safeGetString(preferences, messageKey(conversationId), null) ?: return emptyList()
        val messages = decodeMessages(legacyRaw)
        if (writeConversationFile(context, conversationId, encodeMessages(messages).toString())) {
            preferences.edit().remove(messageKey(conversationId)).apply()
        }
        return mergeStreamingCheckpoint(context, conversationId, messages)
    }

    fun clearMessages(context: Context, conversationId: String) {
        saveMessages(context, conversationId, emptyList())
    }

    fun deleteConversation(context: Context, conversationId: String): String {
        migrateLegacyIfNeeded(context)
        val prefs = prefs(context)
        cleanupDetachedAttachments(context, loadMessages(context, conversationId), emptyList())
        val remaining = loadConversationsInternal(prefs).filterNot { it.id == conversationId }
        val visibleRemaining = remaining.filterNot { it.archived }
        val currentActive = safeGetString(prefs, KEY_ACTIVE_CONVERSATION, null)
        deleteConversationFile(context, conversationId)
        val editor = prefs.edit()
            .remove(messageKey(conversationId))
            .remove(draftKey(conversationId))
            .remove(modelKey(conversationId))

        if (remaining.isEmpty()) {
            editor.putString(KEY_CONVERSATIONS, "[]").remove(KEY_ACTIVE_CONVERSATION).apply()
            return createConversation(context)
        }

        if (visibleRemaining.isEmpty()) {
            editor
                .putString(KEY_CONVERSATIONS, encodeSummariesCached(remaining))
                .remove(KEY_ACTIVE_CONVERSATION)
                .apply()
            return createConversation(context)
        }

        val next = if (!currentActive.isNullOrBlank() && currentActive != conversationId && visibleRemaining.any { it.id == currentActive }) {
            currentActive
        } else {
            visibleRemaining.maxByOrNull { it.updatedAt }!!.id
        }
        editor
            .putString(KEY_CONVERSATIONS, encodeSummariesCached(remaining))
            .putString(KEY_ACTIVE_CONVERSATION, next)
            .apply()
        return next
    }

    fun renameConversation(context: Context, conversationId: String, title: String) {
        migrateLegacyIfNeeded(context)
        val prefs = prefs(context)
        val clean = title.replace(Regex("\\s+"), " ").trim().take(60)
        if (clean.isBlank()) return
        val items = loadConversationsInternal(prefs)
        val updated = items.map { item ->
            if (item.id == conversationId) item.copy(title = clean, customTitle = true, updatedAt = System.currentTimeMillis()) else item
        }.sortedByDescending { it.updatedAt }
        prefs.edit().putString(KEY_CONVERSATIONS, encodeSummariesCached(updated)).apply()
    }

    fun saveDraft(context: Context, conversationId: String, draft: String) {
        prefs(context).edit().putString(draftKey(conversationId), draft).apply()
    }

    fun loadDraft(context: Context, conversationId: String): String =
        safeGetString(prefs(context), draftKey(conversationId), "").orEmpty()

    fun saveSelectedModel(context: Context, key: String) {
        prefs(context).edit().putString(KEY_SELECTED_MODEL, key).apply()
    }

    fun loadSelectedModel(context: Context): String =
        safeGetString(prefs(context), KEY_SELECTED_MODEL, "auto").orEmpty().ifBlank { "auto" }

    fun saveConversationModel(context: Context, conversationId: String, key: String) {
        if (conversationId.isBlank() || key.isBlank()) return
        prefs(context).edit().putString(modelKey(conversationId), key).apply()
    }

    fun loadConversationModel(context: Context, conversationId: String): String =
        safeGetString(prefs(context), modelKey(conversationId), null)
            ?.takeIf { it.isNotBlank() }
            ?: loadSelectedModel(context)

    private fun deriveTitle(messages: List<ChatMessage>): String {
        val firstUser = messages.firstOrNull { it.role == MessageRole.USER }
        val source = firstUser?.text?.trim().orEmpty().ifBlank {
            firstUser?.attachments?.firstOrNull()?.name.orEmpty()
        }
        return source.replace(Regex("\\s+"), " ").trim().take(46)
    }

    private fun derivePreview(messages: List<ChatMessage>): String {
        val last = messages.lastOrNull { it.text.isNotBlank() } ?: return ""
        val clean = last.text.replace(Regex("\\s+"), " ").trim()
        return if (clean.length <= 74) clean else clean.take(73).trimEnd() + "…"
    }

    private fun deriveSearchText(messages: List<ChatMessage>): String {
        val parts = mutableListOf<String>()
        var collectedChars = 0
        for (message in messages.asReversed()) {
            if (message.isError || message.wasStopped) continue
            val text = message.text.replace(Regex("\\s+"), " ").trim()
            if (text.isNotBlank()) {
                val part = text.take(1_200)
                parts += part
                collectedChars += part.length
            }
            if (message.attachments.isNotEmpty()) {
                val names = message.attachments.joinToString(" ") { it.name }.take(600)
                parts += names
                collectedChars += names.length
            }
            if (collectedChars >= 6_000) break
        }
        return parts.asReversed().joinToString(" ").take(6_000)
    }

    private fun cleanupDetachedAttachments(
        context: Context,
        previous: List<ChatMessage>,
        current: List<ChatMessage>
    ) {
        if (previous.isEmpty()) return
        val kept = current
            .flatMap { it.attachments }
            .mapNotNull { it.localPath.takeIf(String::isNotBlank) }
            .toHashSet()
        val root = runCatching { java.io.File(context.filesDir, "aion_attachments").canonicalFile }.getOrNull() ?: return
        previous
            .flatMap { it.attachments }
            .map { it.localPath }
            .filter { it.isNotBlank() && it !in kept }
            .distinct()
            .forEach { path ->
                runCatching {
                    val file = java.io.File(path).canonicalFile
                    if (file.path.startsWith(root.path + java.io.File.separator)) file.delete()
                }
            }
    }

    private fun encodeMessage(message: ChatMessage): JSONObject = JSONObject().apply {
        put("id", message.id)
        put("role", message.role.name)
        put("text", message.text)
        put("modelId", message.modelId ?: JSONObject.NULL)
        put("modelLabel", message.modelLabel ?: JSONObject.NULL)
        put("executionProviderKey", message.executionProviderKey ?: JSONObject.NULL)
        put("executionProviderLabel", message.executionProviderLabel ?: JSONObject.NULL)
        put("executionModelId", message.executionModelId ?: JSONObject.NULL)
        put("routingPolicy", message.routingPolicy ?: JSONObject.NULL)
        put("fallbackUsed", message.fallbackUsed)
        put("executionAttempts", message.executionAttempts.coerceIn(1, 8))
        put("orchestratorContract", message.orchestratorContract.coerceAtLeast(0))
        put("orchestratorTraceId", message.orchestratorTraceId ?: JSONObject.NULL)
        put("orchestratorSearchReason", message.orchestratorSearchReason ?: JSONObject.NULL)
        put("orchestratorMemoryPolicy", message.orchestratorMemoryPolicy ?: JSONObject.NULL)
        put("orchestratorToolRoute", message.orchestratorToolRoute ?: JSONObject.NULL)
        put("orchestratorResponseProfile", message.orchestratorResponseProfile ?: JSONObject.NULL)
        put("isError", message.isError)
        put("isStreaming", message.isStreaming)
        put("wasStopped", message.wasStopped)

        put("sources", JSONArray().apply {
            message.sources.forEach { source ->
                put(JSONObject().apply {
                    put("title", source.title)
                    put("url", source.url)
                    put("snippet", source.snippet)
                })
            }
        })

        put("attachments", JSONArray().apply {
            message.attachments.forEach { attachment ->
                put(JSONObject().apply {
                    put("id", attachment.id)
                    put("name", attachment.name)
                    put("mimeType", attachment.mimeType)
                    put("kind", attachment.kind.name)
                    put("sizeBytes", attachment.sizeBytes)
                    put("localPath", attachment.localPath)
                })
            }
        })
    }

    private fun encodeMessages(messages: List<ChatMessage>): JSONArray = JSONArray().apply {
        messages.forEach { put(encodeMessage(it)) }
    }

    private fun decodeMessage(item: JSONObject): ChatMessage {
        val role = runCatching { MessageRole.valueOf(item.optString("role")) }
            .getOrDefault(MessageRole.AION)
        val sources = buildList {
            val sourceArray = item.optJSONArray("sources") ?: JSONArray()
            for (j in 0 until sourceArray.length()) {
                val source = sourceArray.optJSONObject(j) ?: continue
                add(
                    ChatSource(
                        title = source.optString("title"),
                        url = source.optString("url"),
                        snippet = source.optString("snippet").take(600)
                    )
                )
            }
        }
        val attachments = buildList {
            val attachmentArray = item.optJSONArray("attachments") ?: JSONArray()
            for (j in 0 until attachmentArray.length()) {
                val attachment = attachmentArray.optJSONObject(j) ?: continue
                add(
                    ChatAttachment(
                        id = attachment.optLong("id"),
                        name = attachment.optString("name"),
                        mimeType = attachment.optString("mimeType"),
                        base64Data = "",
                        kind = runCatching { AttachmentKind.valueOf(attachment.optString("kind")) }
                            .getOrDefault(AttachmentKind.FILE),
                        sizeBytes = attachment.optLong("sizeBytes"),
                        localPath = attachment.optString("localPath")
                    )
                )
            }
        }
        return ChatMessage(
            id = item.optLong("id"),
            role = role,
            text = item.optString("text"),
            modelId = item.optString("modelId").takeIf { it.isNotBlank() && it != "null" },
            modelLabel = item.optString("modelLabel").takeIf { it.isNotBlank() && it != "null" },
            executionProviderKey = item.optString("executionProviderKey").takeIf { it.isNotBlank() && it != "null" },
            executionProviderLabel = item.optString("executionProviderLabel").takeIf { it.isNotBlank() && it != "null" },
            executionModelId = item.optString("executionModelId").takeIf { it.isNotBlank() && it != "null" },
            routingPolicy = item.optString("routingPolicy").takeIf { it.isNotBlank() && it != "null" },
            fallbackUsed = item.optBoolean("fallbackUsed", false),
            executionAttempts = item.optInt("executionAttempts", 1).coerceIn(1, 8),
            orchestratorContract = item.optInt("orchestratorContract", 0).coerceAtLeast(0),
            orchestratorTraceId = item.optString("orchestratorTraceId").takeIf { it.isNotBlank() && it != "null" },
            orchestratorSearchReason = item.optString("orchestratorSearchReason").takeIf { it.isNotBlank() && it != "null" },
            orchestratorMemoryPolicy = item.optString("orchestratorMemoryPolicy").takeIf { it.isNotBlank() && it != "null" },
            orchestratorToolRoute = item.optString("orchestratorToolRoute").takeIf { it.isNotBlank() && it != "null" },
            orchestratorResponseProfile = item.optString("orchestratorResponseProfile").takeIf { it.isNotBlank() && it != "null" },
            attachments = attachments,
            sources = sources,
            isError = item.optBoolean("isError"),
            isStreaming = item.optBoolean("isStreaming"),
            wasStopped = item.optBoolean("wasStopped")
        )
    }

    private fun decodeMessages(raw: String): List<ChatMessage> = runCatching {
        val array = JSONArray(raw)
        val decoded = buildList {
            for (i in 0 until array.length()) {
                val item = array.optJSONObject(i) ?: continue
                add(decodeMessage(item))
            }
        }
        normalizeMessageIds(decoded)
    }.getOrDefault(emptyList())

    /**
     * بعض نسخ AION التجريبية المبكرة لم تكن تضمن id موجبًا وفريدًا لكل رسالة.
     * Compose LazyColumn يرفض المفاتيح المكررة وقد يغلق الشاشة أثناء ترقية سجل قديم.
     * نصلح المعرفات في الذاكرة من دون حذف أي نص أو مرفق.
     */
    private fun normalizeMessageIds(messages: List<ChatMessage>): List<ChatMessage> {
        if (messages.isEmpty()) return messages
        val used = HashSet<Long>(messages.size)
        var next = (messages.maxOfOrNull { it.id } ?: 0L).coerceAtLeast(0L) + 1L
        return messages.map { message ->
            val valid = message.id > 0L && used.add(message.id)
            if (valid) message else {
                while (next <= 0L || !used.add(next)) next++
                message.copy(id = next++)
            }
        }
    }

    private fun encodeSummaries(items: List<ConversationSummary>): JSONArray = JSONArray().apply {
        items.forEach { item ->
            put(JSONObject().apply {
                put("id", item.id)
                put("title", item.title)
                put("preview", item.preview)
                put("searchText", item.searchText)
                put("updatedAt", item.updatedAt)
                put("messageCount", item.messageCount)
                put("customTitle", item.customTitle)
                put("pinned", item.pinned)
                put("archived", item.archived)
                put("projectId", item.projectId ?: JSONObject.NULL)
            })
        }
    }

    private fun loadConversationsInternal(prefs: android.content.SharedPreferences): List<ConversationSummary> {
        val raw = safeGetString(prefs, KEY_CONVERSATIONS, null) ?: return emptyList()
        synchronized(summaryCacheLock) {
            if (raw == cachedSummaryRaw) return cachedSummaries
        }

        val decoded = runCatching {
            val array = JSONArray(raw)
            buildList {
                for (i in 0 until array.length()) {
                    val item = array.optJSONObject(i) ?: continue
                    val id = item.optString("id").trim()
                    if (id.isBlank()) continue
                    add(
                        ConversationSummary(
                            id = id,
                            title = item.optString("title").ifBlank { "محادثة" },
                            preview = item.optString("preview"),
                            searchText = item.optString("searchText"),
                            updatedAt = item.optLong("updatedAt"),
                            messageCount = item.optInt("messageCount"),
                            customTitle = item.optBoolean("customTitle", false),
                            pinned = item.optBoolean("pinned", false),
                            archived = item.optBoolean("archived", false),
                            projectId = item.optString("projectId").takeIf { it.isNotBlank() && it != "null" }
                        )
                    )
                }
            }.distinctBy { it.id }
        }.getOrDefault(emptyList())

        synchronized(summaryCacheLock) {
            cachedSummaryRaw = raw
            cachedSummaries = decoded
        }
        return decoded
    }

    /** يجهز JSON للفهرس ويحدث نسخة RAM قبل الكتابة؛ القراءة التالية لا تعيد parse لمئات العناصر. */
    private fun encodeSummariesCached(items: List<ConversationSummary>): String {
        val immutable = items.toList()
        val raw = encodeSummaries(immutable).toString()
        synchronized(summaryCacheLock) {
            cachedSummaryRaw = raw
            cachedSummaries = immutable
        }
        return raw
    }

    fun rebuildSearchIndexIfNeeded(context: Context): Boolean = runCatching {
        val prefs = prefs(context)
        if (safeGetInt(prefs, KEY_SEARCH_INDEX_VERSION, 0) >= SEARCH_INDEX_VERSION) return@runCatching false
        val items = loadConversationsInternal(prefs)
        if (items.isEmpty()) {
            prefs.edit().putInt(KEY_SEARCH_INDEX_VERSION, SEARCH_INDEX_VERSION).apply()
            return@runCatching true
        }
        val indexed = items.map { summary ->
            if (summary.searchText.isNotBlank() || summary.messageCount <= 0) summary
            else {
                summary.copy(searchText = deriveSearchText(loadMessages(context, summary.id)))
            }
        }
        prefs.edit()
            .putString(KEY_CONVERSATIONS, encodeSummariesCached(indexed))
            .putInt(KEY_SEARCH_INDEX_VERSION, SEARCH_INDEX_VERSION)
            .apply()
        true
    }.getOrDefault(false)

    private fun migrateLegacyIfNeeded(context: Context) {
        val prefs = prefs(context)
        if (prefs.contains(KEY_CONVERSATIONS)) {
            ensureSchemaVersion(prefs)
            return
        }
        val legacyRaw = safeGetString(prefs, KEY_LEGACY_MESSAGES, null)
        val legacyDraft = safeGetString(prefs, KEY_LEGACY_DRAFT, "").orEmpty()
        if (legacyRaw.isNullOrBlank()) {
            prefs.edit()
                .putString(KEY_CONVERSATIONS, encodeSummariesCached(emptyList()))
                .putInt(KEY_SCHEMA_VERSION, CURRENT_SCHEMA_VERSION)
                .apply()
            return
        }

        val id = "migrated-alpha6"
        val messages = decodeMessages(legacyRaw)
        val summary = ConversationSummary(
            id = id,
            title = deriveTitle(messages).ifBlank { "المحادثة السابقة" },
            preview = derivePreview(messages),
            searchText = deriveSearchText(messages),
            updatedAt = System.currentTimeMillis(),
            messageCount = messages.size
        )
        persistConversationRaw(context, id, encodeMessages(messages).toString(), prefs)
        prefs.edit()
            .putString(KEY_CONVERSATIONS, encodeSummariesCached(listOf(summary)))
            .putString(KEY_ACTIVE_CONVERSATION, id)
            .putString(draftKey(id), legacyDraft)
            .remove(KEY_LEGACY_MESSAGES)
            .remove(KEY_LEGACY_DRAFT)
            .putInt(KEY_SCHEMA_VERSION, CURRENT_SCHEMA_VERSION)
            .apply()
    }

    /** Metadata foundation for explicit upgrade tests from α7.3 onward. */
    fun storageSchemaVersion(context: Context): Int =
        safeGetInt(prefs(context), KEY_SCHEMA_VERSION, 0)

    private fun ensureSchemaVersion(preferences: android.content.SharedPreferences) {
        val current = safeGetInt(preferences, KEY_SCHEMA_VERSION, 0)
        if (current < CURRENT_SCHEMA_VERSION) {
            // α7.3 does not destructively rewrite existing conversations; the number marks
            // which tolerant migration pipeline has observed the local data.
            preferences.edit().putInt(KEY_SCHEMA_VERSION, CURRENT_SCHEMA_VERSION).apply()
        }
    }

    private fun conversationDirectory(context: Context): File =
        File(context.filesDir, "aion_conversations").apply { if (!exists()) mkdirs() }

    private fun conversationFile(context: Context, id: String): File {
        // UUID هو الشكل المعتاد، لكن التنظيف يمنع تحويل المعرف إلى مسار خارج مجلد AION.
        val safeId = id.replace(Regex("[^A-Za-z0-9._-]"), "_").take(96)
        return File(conversationDirectory(context), "$safeId.json")
    }

    private fun readConversationFile(context: Context, id: String): String? = runCatching {
        val file = conversationFile(context, id)
        if (!file.isFile) return@runCatching null
        file.readText(Charsets.UTF_8)
    }.getOrNull()

    private fun writeConversationFile(context: Context, id: String, raw: String): Boolean = runCatching {
        val atomic = AtomicFile(conversationFile(context, id))
        val output = atomic.startWrite()
        try {
            output.write(raw.toByteArray(Charsets.UTF_8))
            atomic.finishWrite(output)
        } catch (error: Throwable) {
            atomic.failWrite(output)
            throw error
        }
        true
    }.getOrDefault(false)

    private fun deleteConversationFile(context: Context, id: String) {
        runCatching { AtomicFile(conversationFile(context, id)).delete() }
        deleteStreamingCheckpoint(context, id)
    }

    private fun streamingCheckpointFile(context: Context, id: String): File {
        val base = conversationFile(context, id)
        return File(base.parentFile, base.nameWithoutExtension + ".stream.json")
    }

    private fun writeStreamingCheckpoint(context: Context, id: String, raw: String): Boolean = runCatching {
        val atomic = AtomicFile(streamingCheckpointFile(context, id))
        val output = atomic.startWrite()
        try {
            output.write(raw.toByteArray(Charsets.UTF_8))
            atomic.finishWrite(output)
        } catch (error: Throwable) {
            atomic.failWrite(output)
            throw error
        }
        true
    }.getOrDefault(false)

    private fun readStreamingCheckpoint(context: Context, id: String): ChatMessage? = runCatching {
        val file = streamingCheckpointFile(context, id)
        if (!file.isFile) return@runCatching null
        decodeMessage(JSONObject(file.readText(Charsets.UTF_8)))
    }.getOrNull()

    private fun deleteStreamingCheckpoint(context: Context, id: String) {
        runCatching { AtomicFile(streamingCheckpointFile(context, id)).delete() }
    }

    private fun mergeStreamingCheckpoint(
        context: Context,
        conversationId: String,
        messages: List<ChatMessage>
    ): List<ChatMessage> {
        val checkpoint = readStreamingCheckpoint(context, conversationId) ?: return messages
        if (!checkpoint.isStreaming) {
            deleteStreamingCheckpoint(context, conversationId)
            return messages
        }
        val index = messages.indexOfFirst { it.id == checkpoint.id }
        if (index >= 0 && !messages[index].isStreaming) {
            // السجل النهائي أحدث من checkpoint متروك؛ لا نعيد ردًا قديمًا إلى حالة البث.
            deleteStreamingCheckpoint(context, conversationId)
            return messages
        }
        return if (index >= 0) {
            messages.toMutableList().apply { this[index] = checkpoint }
        } else {
            (messages + checkpoint).takeLast(MAX_MESSAGES_PER_CONVERSATION)
        }
    }

    private fun persistConversationRaw(
        context: Context,
        id: String,
        raw: String,
        preferences: android.content.SharedPreferences = prefs(context)
    ) {
        if (writeConversationFile(context, id, raw)) {
            if (preferences.contains(messageKey(id))) {
                preferences.edit().remove(messageKey(id)).apply()
            }
        } else {
            // مسار احتياطي نادر: إذا تعذر ملف التخزين لا نخسر المحادثة.
            preferences.edit().putString(messageKey(id), raw).apply()
        }
    }


    /** قراءة متسامحة مع قيم SharedPreferences من إصدارات تجريبية أقدم. */
    private fun safeGetString(
        preferences: android.content.SharedPreferences,
        key: String,
        defaultValue: String?
    ): String? = runCatching {
        preferences.getString(key, defaultValue)
    }.getOrElse {
        when (val value = preferences.all[key]) {
            null -> defaultValue
            is String -> value
            else -> value.toString()
        }
    }

    /** يمنع ClassCastException إذا كانت نسخة قديمة كتبت رقم الإصدار كنص أو Long. */
    private fun safeGetInt(
        preferences: android.content.SharedPreferences,
        key: String,
        defaultValue: Int
    ): Int = runCatching {
        preferences.getInt(key, defaultValue)
    }.getOrElse {
        when (val value = preferences.all[key]) {
            is Number -> value.toInt()
            is String -> value.toIntOrNull() ?: defaultValue
            else -> defaultValue
        }
    }

    private fun messageKey(id: String) = "messages_v2_$id" // مفتاح ترحيل للنسخ القديمة فقط
    private fun draftKey(id: String) = "draft_v2_$id"
    private fun modelKey(id: String) = "model_v3_$id"
    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
}
