package com.aion.mobile.core.release

/**
 * Compile-time rollback points for large α7.3 experiments. These are intentionally
 * centralized so a risky UI path can be disabled without removing the underlying work.
 */
object AionFeatureFlags {
    const val OBSIDIAN_DESIGN_SYSTEM = true
    const val ACTIVITY_SYSTEM_V2 = true
    const val COMPOSER_LIVE_ENTRY = true

    // Controller/lifecycle refactor is required before a minimized live session can remain active.
    const val MINI_LIVE_SESSION = false
    const val NEURAL_VOICE = false
}
