package com.aion.mobile.core.files

import java.util.Locale

object AttachmentPresentationPolicy {
    fun extension(name: String): String = name.substringAfterLast('.', "").lowercase(Locale.ROOT)

    fun typeLabel(name: String, mimeType: String): String {
        val ext = extension(name)
        return when {
            mimeType == "application/pdf" || ext == "pdf" -> "PDF"
            mimeType.startsWith("image/") -> "صورة"
            ext in setOf("doc", "docx", "odt", "rtf") -> "مستند"
            ext in setOf("xls", "xlsx", "csv") -> "جدول"
            ext in setOf("ppt", "pptx") -> "عرض"
            ext in setOf("kt", "kts", "java", "py", "js", "ts", "tsx", "jsx", "css", "c", "cpp", "h", "hpp", "cs", "go", "rs", "swift", "rb", "php", "sql") -> "كود"
            ext in setOf("json", "xml", "yaml", "yml", "toml", "ini") -> ext.uppercase(Locale.ROOT)
            mimeType.startsWith("text/") || ext in setOf("txt", "md", "log") -> "نص"
            ext.isNotBlank() -> ext.uppercase(Locale.ROOT).take(8)
            else -> "ملف"
        }
    }

    fun isPdf(name: String, mimeType: String): Boolean =
        mimeType == "application/pdf" || extension(name) == "pdf"

    fun secondaryLabel(name: String, mimeType: String, sizeBytes: Long, pdfPages: Int? = null): String {
        val parts = mutableListOf(typeLabel(name, mimeType))
        if (pdfPages != null && pdfPages > 0) {
            parts += when (pdfPages) {
                1 -> "صفحة واحدة"
                2 -> "صفحتان"
                in 3..10 -> "$pdfPages صفحات"
                else -> "$pdfPages صفحة"
            }
        }
        parts += formatSize(sizeBytes)
        return parts.joinToString(" · ")
    }

    fun formatSize(bytes: Long): String = when {
        bytes < 1024L -> "$bytes B"
        bytes < 1024L * 1024L -> "%.1f KB".format(Locale.US, bytes / 1024.0)
        else -> "%.1f MB".format(Locale.US, bytes / (1024.0 * 1024.0))
    }
}
