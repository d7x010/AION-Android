package com.aion.mobile.core

enum class CapabilityState {
    READY,
    FOUNDATION,
    PLANNED
}

data class AionCapability(
    val key: String,
    val title: String,
    val description: String,
    val state: CapabilityState
)

object FeatureRegistry {
    val capabilities = listOf(
        AionCapability("chat", "الدردشة", "واجهة المحادثة الأساسية", CapabilityState.READY),
        AionCapability("project", "المشاريع", "مساحات عمل تجمع محادثات وتعليمات وذاكرة سياقية مستقلة", CapabilityState.READY),
        AionCapability("agent", "الوكيل الذكي", "Tool Loop محدود متعدد الخطوات؛ التخطيط الوكيلي الكامل ما زال Foundation", CapabilityState.FOUNDATION),
        AionCapability("memory", "الذاكرة", "Memory Engine محلي منظم متعدد النطاقات مع تحكم المستخدم", CapabilityState.READY),
        AionCapability("files", "الملفات", "إرفاق الصور والملفات وقراءتها داخل المحادثة", CapabilityState.READY),
        AionCapability("voice", "الصوت", "إملاء وقراءة ومكالمة دورية تفاعلية؛ Full-Duplex الحقيقي مرحلة لاحقة", CapabilityState.FOUNDATION),
        AionCapability("search", "البحث", "بحث ويب حي بقرار freshness وتنقية المصادر", CapabilityState.READY),
        AionCapability("tools", "الأدوات", "Tool Router + Calculator deterministic + Search + Tool Loop محدود", CapabilityState.READY)
    )
}
