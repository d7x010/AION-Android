package com.aion.mobile.core.tools

import kotlin.math.E
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.pow
import kotlin.math.round

/** حاسبة deterministic: لا تستخدم LLM ولا eval ولا الشبكة. */
object DeterministicCalculator {
    const val POLICY = "deterministic-calculator-v1"
    const val MAX_EXPRESSION_CHARS = 512

    sealed interface Result {
        data class Success(val value: Double, val text: String) : Result
        data class Failure(val code: ToolFailureCode, val message: String) : Result
    }

    fun evaluate(raw: String): Result {
        val expression = normalizeDigits(raw).trim()
        if (expression.isBlank() || expression.length > MAX_EXPRESSION_CHARS) {
            return Result.Failure(ToolFailureCode.INVALID_INPUT, "تعبير الحساب غير صالح.")
        }
        return runCatching {
            val parser = Parser(expression)
            val value = parser.parseExpression()
            parser.skipSpaces()
            require(parser.finished()) { "رموز غير مدعومة في التعبير." }
            require(value.isFinite()) { "النتيجة غير محدودة أو غير رقمية." }
            Result.Success(value, format(value))
        }.getOrElse {
            Result.Failure(ToolFailureCode.INVALID_INPUT, it.message ?: "تعذر حساب التعبير.")
        }
    }

    private fun format(value: Double): String {
        val rounded = round(value)
        return if (abs(value - rounded) < 1e-12 && rounded in Long.MIN_VALUE.toDouble()..Long.MAX_VALUE.toDouble()) {
            rounded.toLong().toString()
        } else {
            java.lang.Double.toString(value)
        }
    }

    private fun normalizeDigits(value: String): String = buildString(value.length) {
        value.forEach { ch ->
            append(
                when (ch) {
                    '٠', '۰' -> '0'; '١', '۱' -> '1'; '٢', '۲' -> '2'; '٣', '۳' -> '3'; '٤', '۴' -> '4'
                    '٥', '۵' -> '5'; '٦', '۶' -> '6'; '٧', '۷' -> '7'; '٨', '۸' -> '8'; '٩', '۹' -> '9'
                    '×' -> '*'; '÷' -> '/'; '−' -> '-'; else -> ch
                }
            )
        }
    }

    private class Parser(private val text: String) {
        private var index = 0
        fun finished(): Boolean = index >= text.length
        fun skipSpaces() { while (index < text.length && text[index].isWhitespace()) index++ }

        fun parseExpression(): Double {
            var value = parseTerm()
            while (true) {
                skipSpaces()
                value = when {
                    take('+') -> value + parseTerm()
                    take('-') -> value - parseTerm()
                    else -> return value
                }
            }
        }

        private fun parseTerm(): Double {
            var value = parseUnary()
            while (true) {
                skipSpaces()
                value = when {
                    take('*') -> value * parseUnary()
                    take('/') -> {
                        val rhs = parseUnary()
                        require(rhs != 0.0) { "القسمة على صفر غير مسموحة." }
                        value / rhs
                    }
                    take('%') -> {
                        val rhs = parseUnary()
                        require(rhs != 0.0) { "القسمة على صفر غير مسموحة." }
                        value % rhs
                    }
                    else -> return value
                }
            }
        }

        private fun parseUnary(): Double {
            skipSpaces()
            return when {
                take('+') -> parseUnary()
                take('-') -> -parseUnary()
                else -> parsePower()
            }
        }

        private fun parsePower(): Double {
            var value = parsePrimary()
            skipSpaces()
            if (take('^')) value = value.pow(parseUnary())
            return value
        }

        private fun parsePrimary(): Double {
            skipSpaces()
            if (take('(')) {
                val value = parseExpression()
                skipSpaces()
                require(take(')')) { "قوس إغلاق مفقود." }
                return value
            }
            if (peekWord("pi")) { index += 2; return PI }
            if (peekWord("e")) { index += 1; return E }
            val start = index
            var dotSeen = false
            while (index < text.length) {
                val c = text[index]
                if (c.isDigit()) index++
                else if (c == '.' && !dotSeen) { dotSeen = true; index++ }
                else break
            }
            require(index > start) { "رمز غير مدعوم قرب الموضع $index." }
            return text.substring(start, index).toDouble()
        }

        private fun take(c: Char): Boolean {
            if (index < text.length && text[index] == c) { index++; return true }
            return false
        }

        private fun peekWord(word: String): Boolean =
            text.regionMatches(index, word, 0, word.length, ignoreCase = true)
    }
}

class CalculatorTool : AionTool {
    override val descriptor = ToolDescriptor(
        id = "calculator",
        title = "Calculator",
        permissions = setOf(ToolPermission.COMPUTE),
        timeoutMs = 1_500L
    )

    override suspend fun execute(input: String): ToolResult = when (val result = DeterministicCalculator.evaluate(input)) {
        is DeterministicCalculator.Result.Success -> ToolResult(
            output = result.text,
            success = true,
            toolId = descriptor.id
        )
        is DeterministicCalculator.Result.Failure -> ToolResult(
            success = false,
            toolId = descriptor.id,
            failureCode = result.code,
            failureMessage = result.message
        )
    }
}
