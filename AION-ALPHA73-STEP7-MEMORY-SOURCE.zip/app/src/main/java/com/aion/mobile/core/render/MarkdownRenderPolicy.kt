package com.aion.mobile.core.render

enum class MarkdownBlockKind {
    PARAGRAPH,
    HEADING,
    BULLET,
    NUMBERED,
    QUOTE,
    DIVIDER,
    TABLE
}

data class MarkdownBlock(
    val kind: MarkdownBlockKind,
    val text: String,
    val level: Int = 0,
    val rows: List<List<String>> = emptyList()
)

data class MessageSegment(
    val text: String,
    val code: Boolean,
    val language: String = "",
    val fenceClosed: Boolean = true
)

object MarkdownRenderPolicy {
    private val headingRegex = Regex("^#{1,4}\\s+.*")
    private val dividerRegex = Regex("^[-*_]{3,}$")
    private val bulletRegex = Regex("^[-*+]\\s+.*")
    private val numberedRegex = Regex("^(\\d+)[.)]\\s+(.*)$")

    /**
     * Splits fenced code from prose without requiring the closing fence to have arrived yet.
     * This matters during streaming, where AION may still be inside a code block.
     */
    fun splitSegments(text: String): List<MessageSegment> {
        if (!text.contains("```")) return listOf(MessageSegment(text, code = false))
        val result = mutableListOf<MessageSegment>()
        var cursor = 0
        while (cursor < text.length) {
            val open = text.indexOf("```", cursor)
            if (open < 0) {
                if (cursor < text.length) result += MessageSegment(text.substring(cursor), code = false)
                break
            }
            if (open > cursor) result += MessageSegment(text.substring(cursor, open), code = false)

            val languageStart = open + 3
            val newline = text.indexOf('\n', languageStart)
            if (newline < 0) {
                // A streaming fence can arrive before its first newline. Render it as prose until
                // enough content exists to identify the block safely.
                result += MessageSegment(text.substring(open), code = false)
                break
            }

            val language = text.substring(languageStart, newline).trim().take(32)
            val close = text.indexOf("```", newline + 1)
            if (close < 0) {
                result += MessageSegment(
                    text = text.substring(newline + 1).trimEnd(),
                    code = true,
                    language = language,
                    fenceClosed = false
                )
                break
            }

            result += MessageSegment(
                text = text.substring(newline + 1, close).trimEnd(),
                code = true,
                language = language,
                fenceClosed = true
            )
            cursor = close + 3
        }
        return result.ifEmpty { listOf(MessageSegment(text, code = false)) }
    }

    fun parseBlocks(text: String): List<MarkdownBlock> {
        val blocks = mutableListOf<MarkdownBlock>()
        val paragraph = mutableListOf<String>()
        val lines = text.replace("\r\n", "\n").lines()

        fun flushParagraph() {
            if (paragraph.isNotEmpty()) {
                blocks += MarkdownBlock(
                    kind = MarkdownBlockKind.PARAGRAPH,
                    text = paragraph.joinToString("\n").trim()
                )
                paragraph.clear()
            }
        }

        var index = 0
        while (index < lines.size) {
            val line = lines[index].trimEnd()
            val trimmed = line.trim()

            if (
                trimmed.contains('|') &&
                index + 1 < lines.size &&
                isTableSeparator(lines[index + 1])
            ) {
                flushParagraph()
                val rows = mutableListOf(parseTableRow(trimmed))
                index += 2
                while (index < lines.size) {
                    val candidate = lines[index].trim()
                    if (candidate.isBlank() || !candidate.contains('|')) break
                    rows += parseTableRow(candidate)
                    index++
                }
                blocks += MarkdownBlock(MarkdownBlockKind.TABLE, text = "", rows = rows)
                continue
            }

            when {
                trimmed.isBlank() -> flushParagraph()
                headingRegex.matches(trimmed) -> {
                    flushParagraph()
                    val level = trimmed.takeWhile { it == '#' }.length
                    blocks += MarkdownBlock(MarkdownBlockKind.HEADING, trimmed.drop(level).trim(), level)
                }
                dividerRegex.matches(trimmed) -> {
                    flushParagraph()
                    blocks += MarkdownBlock(MarkdownBlockKind.DIVIDER, "")
                }
                trimmed.startsWith(">") -> {
                    flushParagraph()
                    val quoteLines = mutableListOf<String>()
                    while (index < lines.size) {
                        val quote = lines[index].trim()
                        if (!quote.startsWith(">")) break
                        quoteLines += quote.removePrefix(">").trimStart()
                        index++
                    }
                    blocks += MarkdownBlock(MarkdownBlockKind.QUOTE, quoteLines.joinToString("\n").trim())
                    continue
                }
                bulletRegex.matches(trimmed) -> {
                    flushParagraph()
                    blocks += MarkdownBlock(
                        MarkdownBlockKind.BULLET,
                        trimmed.replaceFirst(Regex("^[-*+]\\s+"), "")
                    )
                }
                numberedRegex.matches(trimmed) -> {
                    flushParagraph()
                    val match = numberedRegex.find(trimmed)
                    blocks += MarkdownBlock(
                        kind = MarkdownBlockKind.NUMBERED,
                        text = match?.groupValues?.getOrNull(2).orEmpty(),
                        level = match?.groupValues?.getOrNull(1)?.toIntOrNull() ?: 1
                    )
                }
                else -> paragraph += line
            }
            index++
        }
        flushParagraph()
        return blocks
    }

    fun normalizeLanguageLabel(raw: String): String = when (raw.trim().lowercase()) {
        "", "text", "txt" -> "code"
        "js", "javascript" -> "JavaScript"
        "ts", "typescript" -> "TypeScript"
        "py", "python" -> "Python"
        "kt", "kotlin" -> "Kotlin"
        "kts" -> "Kotlin Script"
        "sh", "bash", "shell" -> "Shell"
        "html" -> "HTML"
        "css" -> "CSS"
        "json" -> "JSON"
        "xml" -> "XML"
        "sql" -> "SQL"
        "java" -> "Java"
        "cpp", "c++" -> "C++"
        "c" -> "C"
        "cs", "csharp" -> "C#"
        "swift" -> "Swift"
        "go" -> "Go"
        "rs", "rust" -> "Rust"
        else -> raw.trim().take(24)
    }

    fun shouldCollapseCode(code: String): Boolean =
        code.length > 2_400 || code.lineSequence().take(30).count() > 28

    fun collapsedCode(code: String, maxLines: Int = 28): String {
        val lines = code.lines()
        return if (lines.size <= maxLines) code else lines.take(maxLines).joinToString("\n")
    }

    fun tableColumnWidthDp(rows: List<List<String>>, columnIndex: Int): Int {
        val maxChars = rows.maxOfOrNull { it.getOrNull(columnIndex).orEmpty().length } ?: 0
        return (96 + maxChars.coerceAtMost(28) * 4).coerceIn(120, 208)
    }

    private fun parseTableRow(line: String): List<String> = line
        .trim()
        .trim('|')
        .split('|')
        .map { it.trim() }

    private fun isTableSeparator(line: String): Boolean {
        val cells = parseTableRow(line)
        return cells.isNotEmpty() && cells.all { it.matches(Regex(":?-{3,}:?")) }
    }
}
