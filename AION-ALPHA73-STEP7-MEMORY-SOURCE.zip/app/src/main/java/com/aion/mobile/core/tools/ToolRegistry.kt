package com.aion.mobile.core.tools

private val TOOL_ID_PATTERN = Regex("^[a-z][a-z0-9_.-]{1,63}$")

enum class ToolPermission { NETWORK, READ_LOCAL, WRITE_LOCAL, COMPUTE }
enum class ToolAvailability { READY, DISABLED, PLANNED }
enum class ToolFailureCode { NOT_FOUND, DISABLED, PERMISSION_DENIED, INVALID_INPUT, TIMEOUT, UNAVAILABLE, EXECUTION_ERROR }

data class ToolDescriptor(
    val id: String,
    val title: String,
    val permissions: Set<ToolPermission> = emptySet(),
    val availability: ToolAvailability = ToolAvailability.READY,
    val timeoutMs: Long = 15_000L
) {
    init {
        require(TOOL_ID_PATTERN.matches(id)) { "Invalid AION tool id" }
        require(timeoutMs in 500L..120_000L) { "Invalid AION tool timeout" }
    }
}

interface AionTool {
    val descriptor: ToolDescriptor
    val id: String get() = descriptor.id
    val title: String get() = descriptor.title
    suspend fun execute(input: String): ToolResult
}

data class ToolResult(
    val output: String = "",
    val success: Boolean,
    val toolId: String = "",
    val failureCode: ToolFailureCode? = null,
    val failureMessage: String = ""
)

data class ToolRouteRequest(
    val toolId: String,
    val input: String,
    val grantedPermissions: Set<ToolPermission>,
    val maxTimeoutMs: Long = 30_000L
)

data class ToolRoutePlan(
    val contract: Int = ToolRegistry.CONTRACT,
    val accepted: Boolean,
    val toolId: String,
    val permissions: Set<ToolPermission> = emptySet(),
    val timeoutMs: Long = 0L,
    val failureCode: ToolFailureCode? = null
)

/**
 * Universal client-side registry contract. Step 7.6 plans and validates tool execution;
 * Calculator/Search/Files/Safe Code Sandbox use the same permission-aware contract. Concrete execution remains in the owning layer; code execution is remote-only and fail-closed.
 */
class ToolRegistry(tools: List<AionTool> = emptyList()) {
    private val toolsById = tools.associateBy { it.id }

    fun find(id: String): AionTool? = toolsById[id.trim().lowercase()]
    fun all(): List<AionTool> = toolsById.values.sortedBy { it.id }

    fun plan(request: ToolRouteRequest): ToolRoutePlan {
        val cleanId = request.toolId.trim().lowercase()
        if (!TOOL_ID_PATTERN.matches(cleanId) || request.input.length > MAX_INPUT_CHARS) {
            return rejected(cleanId, ToolFailureCode.INVALID_INPUT)
        }
        val tool = find(cleanId) ?: return rejected(cleanId, ToolFailureCode.NOT_FOUND)
        if (tool.descriptor.availability != ToolAvailability.READY) {
            return rejected(cleanId, ToolFailureCode.DISABLED)
        }
        if (!request.grantedPermissions.containsAll(tool.descriptor.permissions)) {
            return rejected(cleanId, ToolFailureCode.PERMISSION_DENIED)
        }
        val timeout = minOf(tool.descriptor.timeoutMs, request.maxTimeoutMs.coerceIn(500L, 120_000L))
        return ToolRoutePlan(
            accepted = true,
            toolId = cleanId,
            permissions = tool.descriptor.permissions,
            timeoutMs = timeout
        )
    }

    private fun rejected(id: String, code: ToolFailureCode) = ToolRoutePlan(
        accepted = false,
        toolId = id.take(64),
        failureCode = code
    )

    companion object {
        const val CONTRACT = 1
        const val POLICY = "universal-tool-router-v1"
        const val MAX_INPUT_CHARS = 64_000
    }
}
