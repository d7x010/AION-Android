package com.aion.mobile.core.tools

data class ToolLoopStep(val toolId: String, val requiredPermissions: Set<ToolPermission>)
data class ToolLoopPlan(val policy: String, val steps: List<ToolLoopStep>, val maxSteps: Int)

/**
 * Step 7.8 + 7.9: حلقة أدوات محدودة قبل inference. تنفذ أكثر من أداة صريحة في الطلب نفسه
 * بترتيب الخطة، من دون recursion غير محدود أو تشغيل أدوات غير معروفة.
 */
object ToolLoopPolicy {
    const val CONTRACT = 1
    const val POLICY = "bounded-multi-step-tool-loop-v1"
    const val MAX_STEPS = 4
    private val supported = setOf("calculator", "web.search", "files.read", "code.execute")

    fun plan(requestedToolIds: List<String>): ToolLoopPlan {
        val seen = linkedSetOf<String>()
        requestedToolIds.asSequence()
            .map { it.trim().lowercase() }
            .filter { it in supported }
            .forEach { seen += it }
        val steps = seen.take(MAX_STEPS).map { id ->
            ToolLoopStep(
                toolId = id,
                requiredPermissions = when (id) {
                    "calculator" -> setOf(ToolPermission.COMPUTE)
                    "web.search" -> setOf(ToolPermission.NETWORK)
                    "files.read" -> setOf(ToolPermission.READ_LOCAL)
                    "code.execute" -> setOf(ToolPermission.COMPUTE, ToolPermission.NETWORK)
                    else -> emptySet()
                }
            )
        }
        return ToolLoopPlan(POLICY, steps, MAX_STEPS)
    }
}
