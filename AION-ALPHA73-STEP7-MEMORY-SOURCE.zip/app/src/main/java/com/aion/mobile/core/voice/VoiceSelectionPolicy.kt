package com.aion.mobile.core.voice

/** Pure selection rules so UI, Live and read-aloud resolve the same server voice. */
object VoiceSelectionPolicy {
    fun resolve(
        savedKey: String?,
        defaultKey: String?,
        availableKeys: List<String>
    ): String {
        val available = availableKeys
            .map(NeuralVoiceContract::normalizedVoiceKey)
            .filter { it.isNotBlank() }
            .distinct()
        if (available.isEmpty()) return NeuralVoiceContract.normalizedVoiceKey(savedKey)

        val saved = NeuralVoiceContract.normalizedVoiceKey(savedKey)
        if (saved in available) return saved

        val default = NeuralVoiceContract.normalizedVoiceKey(defaultKey)
        if (default in available) return default

        return available.first()
    }

    fun genderLabel(value: String?): String = when (value.orEmpty().trim().lowercase()) {
        "male" -> "ذكر"
        "female" -> "أنثى"
        else -> "محايد"
    }
}
