package com.aion.mobile.core.memory

/**
 * Small, deterministic first pass for continuity memory.
 *
 * It deliberately saves only clear, user-authored preferences/instructions/facts. It never
 * guesses from an assistant answer, and it rejects sensitive or volatile material. A model
 * based extractor can be added later, but this gives new conversations useful continuity now.
 */
object AutomaticMemoryPolicy {
    const val CONTRACT = 1
    private const val MAX_CANDIDATES = 3

    data class Candidate(
        val kind: MemoryKind,
        val text: String,
        val slot: String = "",
        val confidence: Float = 0.94f
    )

    fun extract(userText: String): List<Candidate> {
        val clean = MemoryEnginePolicy.normalizeText(userText)
        if (clean.length < 4 || isSensitive(clean)) return emptyList()

        val candidates = buildList {
            nameCandidate(clean)?.let(::add)
            preferenceCandidate(clean)?.let(::add)
            instructionCandidate(clean)?.let(::add)
            stableFactCandidate(clean)?.let(::add)
        }
        return candidates
            .distinctBy { "${it.kind}:${MemoryEnginePolicy.canonical(it.text)}" }
            .take(MAX_CANDIDATES)
    }

    private fun nameCandidate(text: String): Candidate? {
        val match = Regex("(?:^|[،,.]\\s*)(?:اسمي|أنا اسمي)\\s+([\\p{L}]{2,40})(?:\\s|$|[،,.])")
            .find(text) ?: return null
        val name = match.groupValues[1]
        return Candidate(MemoryKind.FACT, "اسم المستخدم $name", "profile.name", 0.99f)
    }

    private fun preferenceCandidate(text: String): Candidate? {
        if (!Regex("(?:احب|أحب|افضل|أفضل|ما احب|ما أحب|اكره|أكره)", RegexOption.IGNORE_CASE).containsMatchIn(text)) return null
        return Candidate(MemoryKind.PREFERENCE, text.take(320), confidence = 0.94f)
    }

    private fun instructionCandidate(text: String): Candidate? {
        if (!Regex("(?:اريدك|أريدك|دائما|دائمًا|لا تسوي|لا تفعل|جاوبني|أجبني)", RegexOption.IGNORE_CASE).containsMatchIn(text)) return null
        return Candidate(MemoryKind.INSTRUCTION, text.take(420), confidence = 0.96f)
    }

    private fun stableFactCandidate(text: String): Candidate? {
        if (!Regex("(?:عمري|طولي|لغتي|اشتغل|أعمل|ادرس|أدرس|عندي مشروع|لدي مشروع)", RegexOption.IGNORE_CASE).containsMatchIn(text)) return null
        return Candidate(MemoryKind.FACT, text.take(320), confidence = 0.90f)
    }

    private fun isSensitive(text: String): Boolean = Regex(
        "(?:كلمة المرور|رمز التحقق|بطاقة|رقم الحساب|cvv|otp|api[_ -]?key|مفتاح|عنواني|موقعي|رقم هاتفي|هاتف|مرض|دواء|تشخيص)",
        RegexOption.IGNORE_CASE
    ).containsMatchIn(text)
}
