package com.aion.mobile.core.run

/**
 * سياسة خفيفة لتحديث واجهة الرد المتدفق.
 * الهدف منع إعادة تركيب Compose لكل token مع إبقاء الإحساس بالكتابة حيًا.
 */
object StreamingRenderPolicy {
    const val FRAME_INTERVAL_MS = 48L
    const val MIN_CHARS = 96

    fun shouldPublish(
        nowMs: Long,
        lastPublishAtMs: Long,
        currentChars: Int,
        lastPublishChars: Int,
        force: Boolean = false
    ): Boolean {
        if (force) return true
        if (currentChars <= 0) return false
        return nowMs - lastPublishAtMs >= FRAME_INTERVAL_MS ||
            currentChars - lastPublishChars >= MIN_CHARS
    }
}
