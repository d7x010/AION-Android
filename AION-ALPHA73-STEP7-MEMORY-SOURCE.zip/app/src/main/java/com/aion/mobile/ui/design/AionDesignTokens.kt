package com.aion.mobile.ui.design

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * AION α7.3 design tokens. UI code should consume these tokens instead of inventing
 * one-off colors, radii or touch sizes in individual screens.
 */
object AionColors {
    val Background = Color(0xFF0B0B0E)
    val Surface = Color(0xFF111116)
    val SurfaceRaised = Color(0xFF18181F)
    val SurfaceInteractive = Color(0xFF1E1E25)
    val SurfaceMuted = Color(0xFF15151A)
    val SurfaceSelected = Color(0xFF171221)
    val Border = Color(0xFF292932)
    val BorderStrong = Color(0xFF353540)
    val BorderFocused = Color(0xFF4B3D78)

    val TextPrimary = Color(0xFFF4F4F6)
    val TextSecondary = Color(0xFFA6A6B0)
    // Raised from the earlier α7.3 draft so tertiary labels remain comfortable on raised surfaces.
    val TextTertiary = Color(0xFF8A8A96)
    val TextDisabled = Color(0xFF666671)

    val Intelligence = Color(0xFF825CFF)
    val IntelligenceStrong = Color(0xFF7146F6)
    val IntelligenceSoft = Color(0xFFC8B6FF)

    val External = Color(0xFF4B8DFF)
    val ExternalSoft = Color(0xFF9CC0FF)

    val Success = Color(0xFF39D98A)
    val Warning = Color(0xFFE9B85D)
    val Error = Color(0xFFEF6A73)
}

object AionSpacing {
    val Xs: Dp = 4.dp
    val Sm: Dp = 8.dp
    val Md: Dp = 12.dp
    val Lg: Dp = 16.dp
    val Xl: Dp = 20.dp
    val Xxl: Dp = 24.dp
    val Xxxl: Dp = 32.dp
}

object AionRadii {
    val Chip: Dp = 13.dp
    val Card: Dp = 18.dp
    val Attachment: Dp = 18.dp
    val UserBubble: Dp = 22.dp
    val Composer: Dp = 28.dp
}

object AionSizes {
    val Icon: Dp = 24.dp
    val SmallIcon: Dp = 18.dp
    val TouchTarget: Dp = 48.dp
    val ComposerMinHeight: Dp = 58.dp
    val LiveButton: Dp = 48.dp
    val ActivityMark: Dp = 18.dp
    val AttachmentThumb: Dp = 46.dp
    val AttachmentIconBox: Dp = 38.dp
    val AttachmentCardMinWidth: Dp = 184.dp
    val AttachmentCardMaxWidth: Dp = 286.dp
    val AttachmentImageHeight: Dp = 168.dp
    val ContentMaxWidth: Dp = 760.dp
    val DrawerMaxWidth: Dp = 372.dp
    val MiniLiveOrb: Dp = 56.dp
}

object AionLayout {
    /** Maximum width of a user bubble relative to the readable content column. */
    const val UserBubbleMaxFraction: Float = 0.78f

    val ChatHorizontalPadding: Dp = 16.dp
    val ChatVerticalPadding: Dp = 12.dp
    val MessageSpacing: Dp = 20.dp

    val ComposerOuterHorizontal: Dp = 10.dp
    val ComposerOuterTop: Dp = 5.dp
    val ComposerOuterBottom: Dp = 5.dp

    val UserBubbleHorizontalPadding: Dp = 14.dp
    val UserBubbleVerticalPadding: Dp = 10.dp
    val AssistantTextEdgePadding: Dp = 2.dp

    val ScrollReturnBottomGap: Dp = 12.dp
}

object AionMotion {
    const val FastMs = 160
    const val StandardMs = 200
    const val SheetMs = 220
}
