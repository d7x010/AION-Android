package com.aion.mobile.core.ai

import com.aion.mobile.model.ChatMessage
import java.util.ArrayDeque

/**
 * يبني نافذة سياق مستقرة للمحادثات الطويلة:
 * - يحافظ على مرساة صغيرة من بداية المهمة.
 * - يحتفظ بأحدث الرسائل قدر الإمكان.
 * - يلتزم بحدي عدد الرسائل والحروف حتى لا تتضخم الحمولة.
 *
 * لا يلخص المحتوى هنا عمدًا؛ التلخيص التلقائي قد يغيّر معنى طلب المستخدم.
 */
internal object ContextWindow {
    fun select(
        messages: List<ChatMessage>,
        maxMessages: Int,
        maxChars: Int = Int.MAX_VALUE,
        anchorMessages: Int = 4,
        maxAnchorChars: Int = Int.MAX_VALUE,
        maxMessageChars: Int = Int.MAX_VALUE
    ): List<ChatMessage> {
        if (messages.isEmpty() || maxMessages <= 0 || maxChars <= 0) return emptyList()
        if (messages.size <= maxMessages && estimatedChars(messages, maxMessageChars) <= maxChars) return messages

        fun cost(message: ChatMessage): Int = message.text.length.coerceAtMost(maxMessageChars) + 24

        val anchors = ArrayList<ChatMessage>(anchorMessages.coerceAtLeast(0))
        var anchorChars = 0
        for (message in messages.take(anchorMessages.coerceAtLeast(0))) {
            if (anchors.size >= maxMessages) break
            val messageCost = cost(message)
            if (anchors.isNotEmpty() && anchorChars + messageCost > maxAnchorChars) break
            if (messageCost > maxChars && anchors.isEmpty()) {
                // نحافظ على أول رسالة حتى لو كانت ضخمة؛ طبقة الإرسال ستقص النص إلى maxMessageChars.
                anchors += message
                anchorChars = messageCost.coerceAtMost(maxChars)
                break
            }
            if (anchorChars + messageCost > maxChars) break
            anchors += message
            anchorChars += messageCost
        }

        val anchorIds = anchors.mapTo(HashSet()) { it.id }
        val recent = ArrayDeque<ChatMessage>()
        var totalChars = anchorChars

        for (message in messages.asReversed()) {
            if (message.id in anchorIds) continue
            if (anchors.size + recent.size >= maxMessages) break
            val messageCost = cost(message)
            if (recent.isNotEmpty() && totalChars + messageCost > maxChars) break
            if (recent.isEmpty() && totalChars + messageCost > maxChars && anchors.isNotEmpty()) continue
            if (messageCost > maxChars && anchors.isEmpty()) {
                recent.addFirst(message)
                break
            }
            recent.addFirst(message)
            totalChars += messageCost
        }

        return (anchors + recent).distinctBy { it.id }
    }

    private fun estimatedChars(messages: List<ChatMessage>, maxMessageChars: Int): Int {
        var total = 0L
        for (message in messages) {
            total += message.text.length.coerceAtMost(maxMessageChars) + 24L
            if (total >= Int.MAX_VALUE) return Int.MAX_VALUE
        }
        return total.toInt()
    }
}
