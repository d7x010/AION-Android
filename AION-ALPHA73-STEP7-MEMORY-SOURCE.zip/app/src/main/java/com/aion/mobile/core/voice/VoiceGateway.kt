package com.aion.mobile.core.voice

interface VoiceGateway {
    suspend fun transcribe(audio: ByteArray): String
    suspend fun synthesize(text: String): ByteArray
}
