package com.aion.mobile.core.voice

import java.io.File
import java.io.RandomAccessFile

/** Pure validation rules for STEP5.3 My Voice. */
object MyVoicePolicy {
    const val SAMPLE_RATE_HZ = 16_000
    const val CHANNELS = 1
    const val BITS_PER_SAMPLE = 16
    const val BYTES_PER_SAMPLE = 2
    const val MIN_DURATION_MS = 15_000L
    const val MAX_DURATION_MS = 90_000L
    const val MAX_SAMPLE_BYTES = 3_600_000L
    const val MY_VOICE_KEY = "my_voice"

    data class WavInfo(
        val sampleRateHz: Int,
        val channels: Int,
        val bitsPerSample: Int,
        val audioFormat: Int,
        val dataBytes: Long,
        val durationMs: Long
    ) {
        val compatible: Boolean
            get() = audioFormat == 1 &&
                sampleRateHz == SAMPLE_RATE_HZ &&
                channels == CHANNELS &&
                bitsPerSample == BITS_PER_SAMPLE
    }

    fun normalizedName(value: String?): String = value.orEmpty()
        .replace(Regex("[\\r\\n\\u0000]+"), " ")
        .replace(Regex("\\s+"), " ")
        .trim()
        .take(48)
        .ifBlank { "صوتي في AION" }

    fun inspectWav(file: File?): WavInfo? {
        if (file == null || !file.isFile || file.length() < 44L || file.length() > MAX_SAMPLE_BYTES) return null
        return runCatching {
            RandomAccessFile(file, "r").use { input ->
                fun readAscii(count: Int): String {
                    val data = ByteArray(count)
                    input.readFully(data)
                    return data.toString(Charsets.US_ASCII)
                }
                fun readLe16(): Int {
                    val a = input.readUnsignedByte()
                    val b = input.readUnsignedByte()
                    return a or (b shl 8)
                }
                fun readLe32(): Long {
                    var value = 0L
                    repeat(4) { shift -> value = value or (input.readUnsignedByte().toLong() shl (shift * 8)) }
                    return value and 0xffff_ffffL
                }

                if (readAscii(4) != "RIFF") return@use null
                readLe32()
                if (readAscii(4) != "WAVE") return@use null

                var audioFormat = -1
                var channels = -1
                var sampleRate = -1
                var byteRate = -1L
                var bitsPerSample = -1
                var dataBytes = -1L

                while (input.filePointer + 8L <= input.length()) {
                    val chunkId = readAscii(4)
                    val chunkSize = readLe32()
                    val chunkStart = input.filePointer
                    val chunkEnd = (chunkStart + chunkSize).coerceAtMost(input.length())
                    when (chunkId) {
                        "fmt " -> if (chunkSize >= 16L && chunkStart + 16L <= input.length()) {
                            audioFormat = readLe16()
                            channels = readLe16()
                            sampleRate = readLe32().toInt()
                            byteRate = readLe32()
                            readLe16() // block align
                            bitsPerSample = readLe16()
                        }
                        "data" -> dataBytes = (chunkEnd - chunkStart).coerceAtLeast(0L)
                    }
                    val paddedEnd = (chunkStart + chunkSize + (chunkSize and 1L)).coerceAtMost(input.length())
                    input.seek(paddedEnd)
                    if (audioFormat > 0 && dataBytes >= 0L) break
                }

                if (audioFormat <= 0 || channels <= 0 || sampleRate <= 0 || byteRate <= 0L || bitsPerSample <= 0 || dataBytes <= 0L) {
                    return@use null
                }
                WavInfo(
                    sampleRateHz = sampleRate,
                    channels = channels,
                    bitsPerSample = bitsPerSample,
                    audioFormat = audioFormat,
                    dataBytes = dataBytes,
                    durationMs = (dataBytes * 1000L) / byteRate
                )
            }
        }.getOrNull()
    }

    fun durationMsFromPcmBytes(bytes: Long): Long {
        if (bytes <= 0L) return 0L
        val bytesPerSecond = SAMPLE_RATE_HZ.toLong() * BYTES_PER_SAMPLE
        return (bytes * 1000L) / bytesPerSecond
    }

    fun durationMsFromWav(file: File?): Long = inspectWav(file)?.durationMs ?: 0L

    fun sampleReady(file: File?): Boolean {
        val info = inspectWav(file) ?: return false
        return info.compatible && info.durationMs in MIN_DURATION_MS..MAX_DURATION_MS
    }

    fun canEnroll(
        cloudAvailable: Boolean,
        sampleReady: Boolean,
        consent: Boolean,
        enrollmentSecret: String
    ): Boolean = cloudAvailable && sampleReady && consent && enrollmentSecret.trim().length >= 16

    fun formatDuration(ms: Long): String {
        val seconds = (ms.coerceAtLeast(0L) / 1000L).toInt()
        val minutes = seconds / 60
        val rest = seconds % 60
        return "%d:%02d".format(minutes, rest)
    }
}

data class MyVoiceCredential(
    val token: String = "",
    val label: String = "صوتي",
    val cloudEndpoint: String = "",
    val createdAtEpochMs: Long = 0L,
    val requiresVerification: Boolean = false
) {
    val exists: Boolean get() = token.isNotBlank()
    val usable: Boolean get() = exists && !requiresVerification
}
