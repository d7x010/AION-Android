package com.aion.mobile.core.ai

import com.aion.mobile.model.AttachmentKind
import com.aion.mobile.model.ChatMessage
import com.aion.mobile.model.ChatSource
import com.aion.mobile.model.MessageRole
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL

/** حالات تشغيل حقيقية نستطيع إظهارها للمستخدم بدون كشف التفكير الداخلي للنموذج. */
enum class GatewayActivity {
    THINKING,
    READING_FILES,
    SEARCHING_WEB,
    COMPARING,
    WRITING
}

data class GatewayExecution(
    val providerKey: String = "",
    val providerLabel: String = "",
    val modelId: String = "",
    val routingPolicy: String = "",
    val fallbackUsed: Boolean = false,
    val attempts: Int = 1
)

data class GatewayOrchestration(
    val contract: Int = 0,
    val traceId: String = "",
    val searchReason: String = "",
    val memoryPolicy: String = "",
    val memoryAttached: Boolean = false,
    val toolRoute: String = "",
    val responseProfile: String = ""
)

data class GatewayResult(
    val text: String,
    val sources: List<ChatSource> = emptyList(),
    val execution: GatewayExecution = GatewayExecution(),
    val orchestration: GatewayOrchestration = GatewayOrchestration()
)

class OpenAiGateway {
    /**
     * بث حي لواجهة Responses API.
     * - المستخدم: input_text + input_image/input_file عند وجود مرفقات.
     * - المساعد في السجل: output_text.
     * - البحث في الويب متاح تلقائيًا، ويظهر SEARCHING_WEB فقط عند وصول حدث بحث فعلي.
     */
    suspend fun streamComplete(
        apiKey: String,
        model: String,
        messages: List<ChatMessage>,
        forceWebSearch: Boolean = false,
        onDelta: suspend (String) -> Unit,
        onActivity: suspend (GatewayActivity) -> Unit
    ): GatewayResult = withContext(Dispatchers.IO) {
        val connection = (URL("https://api.openai.com/v1/responses").openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 30_000
            readTimeout = 180_000
            doOutput = true
            setRequestProperty("Authorization", "Bearer $apiKey")
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("Accept", "text/event-stream")
        }

        val body = buildRequestBody(model = model, messages = messages, stream = true, forceWebSearch = forceWebSearch)
        val cancellationHandle = currentCoroutineContext()[Job]?.invokeOnCompletion { cause ->
            if (cause is CancellationException) connection.disconnect()
        }

        try {
            onActivity(GatewayActivity.THINKING)
            connection.outputStream.use { out ->
                out.write(body.toString().toByteArray(Charsets.UTF_8))
            }

            val code = connection.responseCode
            if (code !in 200..299) {
                val raw = connection.errorStream?.let { stream ->
                    BufferedReader(InputStreamReader(stream, Charsets.UTF_8)).use { it.readText() }
                }.orEmpty()
                throw toOpenAiException(code, raw)
            }

            val streamedText = StringBuilder()
            var completedResponse: JSONObject? = null
            var currentActivity = GatewayActivity.THINKING

            BufferedReader(InputStreamReader(connection.inputStream, Charsets.UTF_8)).use { reader ->
                val dataBuffer = StringBuilder()

                fun processEventData(rawData: String) {
                    if (rawData.isBlank() || rawData == "[DONE]") return
                    val event = runCatching { JSONObject(rawData) }.getOrNull() ?: return
                    when (event.optString("type")) {
                        "response.web_search_call.in_progress",
                        "response.web_search_call.searching" -> {
                            currentActivity = GatewayActivity.SEARCHING_WEB
                        }

                        "response.output_text.delta" -> {
                            val delta = event.optString("delta")
                            if (delta.isNotEmpty()) {
                                streamedText.append(delta)
                                currentActivity = GatewayActivity.WRITING
                            }
                        }

                        "response.refusal.delta" -> {
                            val delta = event.optString("delta")
                            if (delta.isNotEmpty()) {
                                streamedText.append(delta)
                                currentActivity = GatewayActivity.WRITING
                            }
                        }

                        "response.completed" -> {
                            completedResponse = event.optJSONObject("response")
                        }

                        "response.failed" -> {
                            val response = event.optJSONObject("response")
                            val error = response?.optJSONObject("error")
                            val statusCode = error?.optInt("code", 500)?.takeIf { it > 0 } ?: 500
                            val message = error?.optString("message").orEmpty()
                            throw OpenAiException(statusCode, message.ifBlank { "فشل إنشاء الرد من الخادم." })
                        }

                        "error" -> {
                            val nested = event.optJSONObject("error")
                            val statusCode = nested?.optInt("code", 500)?.takeIf { it > 0 } ?: 500
                            val message = event.optString("message").ifBlank {
                                nested?.optString("message").orEmpty()
                            }
                            throw OpenAiException(statusCode, message.ifBlank { "حدث خطأ غير موصوف أثناء بث الرد." })
                        }
                    }
                }

                while (true) {
                    currentCoroutineContext().ensureActive()
                    val line = reader.readLine() ?: break
                    if (line.isBlank()) {
                        if (dataBuffer.isNotEmpty()) {
                            val beforeLength = streamedText.length
                            val beforeActivity = currentActivity
                            processEventData(dataBuffer.toString())
                            dataBuffer.clear()

                            if (currentActivity != beforeActivity) {
                                onActivity(currentActivity)
                            }
                            if (streamedText.length > beforeLength) {
                                onDelta(streamedText.substring(beforeLength))
                            }
                        }
                        continue
                    }
                    if (line.startsWith("data:")) {
                        if (dataBuffer.isNotEmpty()) dataBuffer.append('\n')
                        dataBuffer.append(line.removePrefix("data:").trimStart())
                    }
                }

                if (dataBuffer.isNotEmpty()) {
                    val beforeLength = streamedText.length
                    val beforeActivity = currentActivity
                    processEventData(dataBuffer.toString())
                    if (currentActivity != beforeActivity) onActivity(currentActivity)
                    if (streamedText.length > beforeLength) onDelta(streamedText.substring(beforeLength))
                }
            }

            val finalResponse = completedResponse
            val finalTextFromResponse = finalResponse?.let(::extractText).orEmpty().trim()
            val finalText = finalTextFromResponse.ifBlank { streamedText.toString().trim() }
            if (finalText.isBlank()) {
                throw OpenAiException(502, "انتهى بث الرد بدون نص. سيتم استخدام مسار احتياطي.")
            }
            val sources = finalResponse?.let(::extractSources).orEmpty()

            GatewayResult(text = finalText, sources = sources)
        } finally {
            cancellationHandle?.dispose()
            connection.disconnect()
        }
    }


    /**
     * مسار احتياطي غير متدفق. نستخدمه فقط إذا تعثر البث قبل وصول أي نص،
     * حتى لا تبقى الرسالة معلقة بلا جواب.
     */
    suspend fun completeFallback(
        apiKey: String,
        model: String,
        messages: List<ChatMessage>,
        forceWebSearch: Boolean = false
    ): GatewayResult = withContext(Dispatchers.IO) {
        val connection = (URL("https://api.openai.com/v1/responses").openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 30_000
            readTimeout = 180_000
            doOutput = true
            setRequestProperty("Authorization", "Bearer $apiKey")
            setRequestProperty("Content-Type", "application/json")
        }

        val body = buildRequestBody(
            model = model,
            messages = messages,
            stream = false,
            forceWebSearch = forceWebSearch
        )

        try {
            connection.outputStream.use { out ->
                out.write(body.toString().toByteArray(Charsets.UTF_8))
            }
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val raw = stream?.let { input ->
                BufferedReader(InputStreamReader(input, Charsets.UTF_8)).use { it.readText() }
            }.orEmpty()
            if (code !in 200..299) throw toOpenAiException(code, raw)

            val response = JSONObject(raw)
            val text = extractText(response).trim().ifBlank { "لم يصل رد نصي من النموذج." }
            GatewayResult(text = text, sources = extractSources(response))
        } finally {
            connection.disconnect()
        }
    }

    private fun buildRequestBody(model: String, messages: List<ChatMessage>, stream: Boolean, forceWebSearch: Boolean): JSONObject {
        val input = JSONArray()

        messages.forEach { message ->
            val isUser = message.role == MessageRole.USER
            val content = JSONArray()

            if (isUser) {
                if (message.text.isNotBlank()) {
                    content.put(
                        JSONObject().apply {
                            put("type", "input_text")
                            put("text", message.text)
                        }
                    )
                }

                message.attachments.forEach { attachment ->
                    when (attachment.kind) {
                        AttachmentKind.IMAGE -> content.put(
                            JSONObject().apply {
                                put("type", "input_image")
                                put("image_url", "data:${attachment.mimeType};base64,${attachment.base64Data}")
                                put("detail", "auto")
                            }
                        )

                        AttachmentKind.FILE -> content.put(
                            JSONObject().apply {
                                put("type", "input_file")
                                put("filename", attachment.name)
                                put("file_data", "data:${attachment.mimeType};base64,${attachment.base64Data}")
                                if (attachment.mimeType == "application/pdf") put("detail", "auto")
                            }
                        )
                    }
                }

                if (content.length() == 0) {
                    content.put(JSONObject().apply {
                        put("type", "input_text")
                        put("text", "")
                    })
                }
            } else {
                content.put(
                    JSONObject().apply {
                        put("type", "output_text")
                        put("text", message.text)
                    }
                )
            }

            input.put(
                JSONObject().apply {
                    put("role", if (isUser) "user" else "assistant")
                    put("content", content)
                }
            )
        }

        return JSONObject().apply {
            put("model", model)
            put("input", input)
            put("stream", stream)
            put("store", false)
            put(
                "instructions",
                """
                أنت AION، رفيق ذكاء شخصي على أندرويد. أجب بالعربية افتراضيًا ما لم يطلب المستخدم لغة أخرى.
                اجعل طول الإجابة متكيفًا مع النية: السؤال البسيط يستحق جوابًا قصيرًا، والطلب المعقد يستحق شرحًا عميقًا ومنظمًا.
                لا تكرر سؤال المستخدم، لا تستخدم مقدمات فارغة، ولا تمدح المستخدم دون سبب. كن طبيعيًا ودقيقًا وعمليًا.
                تعامل مع كل رسالة كجزء من حوار مستمر لا كسؤال مستقل: فرّق بين الإجابة، والتصحيح، والمتابعة، والتفكير بصوت عالٍ، والموافقة، والرفض.
                إذا كانت رسالة المستخدم قصيرة أو مجرد تأكيد، فغالبًا يكفي رد طبيعي قصير بدل فقرة كاملة. لا تختم كل رد بعرض مساعدة عام أو سؤال آلي.
                إذا صحح المستخدم المقصود، اعتمد التصحيح فورًا وأكمل من السياق الجديد دون إعادة الحوار من الصفر.
                ميّز الحقائق عن الرأي والافتراض عند الحاجة، وقل بوضوح عندما لا تكون المعلومة مؤكدة.
                استخدم البحث في الويب عندما تكون المعلومة حديثة أو عندما يطلب المستخدم البحث، واعتمد المصادر الجيدة.
                عند وجود صور أو ملفات، تعامل معها كجزء أصلي من الطلب ولا تتجاهلها.
                """.trimIndent()
            )
            // لا نحمّل المحادثة العادية أداة الويب بلا حاجة. عند طلب البحث صراحة
            // نضيف الأداة فقط ونطلب استخدامها إلزاميًا. هذا أبسط وأكثر استقرارًا.
            if (forceWebSearch) {
                put(
                    "tools",
                    JSONArray().put(
                        JSONObject().apply { put("type", "web_search") }
                    )
                )
                put("tool_choice", "required")
                put(
                    "include",
                    JSONArray().put("web_search_call.action.sources")
                )
            }
        }
    }

    private fun extractText(response: JSONObject): String {
        val output = response.optJSONArray("output") ?: JSONArray()
        val text = StringBuilder()
        for (i in 0 until output.length()) {
            val item = output.optJSONObject(i) ?: continue
            val content = item.optJSONArray("content") ?: continue
            for (j in 0 until content.length()) {
                val part = content.optJSONObject(j) ?: continue
                when (part.optString("type")) {
                    "output_text" -> text.append(part.optString("text"))
                    "refusal" -> text.append(part.optString("refusal"))
                }
            }
        }
        return text.toString()
    }

    private fun extractSources(response: JSONObject): List<ChatSource> {
        val sources = linkedMapOf<String, String>()
        val output = response.optJSONArray("output") ?: JSONArray()
        for (i in 0 until output.length()) {
            val item = output.optJSONObject(i) ?: continue
            val content = item.optJSONArray("content") ?: continue
            for (j in 0 until content.length()) {
                val part = content.optJSONObject(j) ?: continue
                val annotations = part.optJSONArray("annotations") ?: continue
                for (k in 0 until annotations.length()) {
                    val annotation = annotations.optJSONObject(k) ?: continue
                    if (annotation.optString("type") == "url_citation") {
                        val url = annotation.optString("url").trim()
                        if (url.isNotEmpty()) {
                            val title = annotation.optString("title").trim().ifBlank { url }
                            sources.putIfAbsent(url, title)
                        }
                    }
                }
            }
        }
        return sources.entries.take(12).map { (url, title) -> ChatSource(title = title, url = url) }
    }

    private fun toOpenAiException(code: Int, raw: String): OpenAiException {
        val message = runCatching {
            JSONObject(raw).optJSONObject("error")?.optString("message")
        }.getOrNull().orEmpty()
        return OpenAiException(code, message.ifBlank { "تعذر الاتصال بخدمة الذكاء الاصطناعي." })
    }
}

class OpenAiException(val statusCode: Int, override val message: String) : Exception(message)
