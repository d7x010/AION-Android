package com.aion.mobile.core.search

import com.aion.mobile.model.MessageRole

/** نتيجة بحث دقيقة داخل رسالة واحدة، وتسمح للواجهة بالقفز إلى الرسالة نفسها. */
data class ConversationSearchHit(
    val conversationId: String,
    val messageId: Long,
    val conversationTitle: String,
    val snippet: String,
    val role: MessageRole,
    val updatedAt: Long,
    val projectId: String? = null
)

/**
 * قواعد البحث المحلي في AION.
 * التطبيع هنا متعمد وخفيف حتى تتطابق أشكال الألف/الياء والتشكيل في العربية.
 */
object ConversationSearchPolicy {
    fun normalize(value: String): String = value
        .trim()
        .lowercase()
        .replace(Regex("[\u064B-\u065F\u0670]"), "")
        .replace('إ', 'ا')
        .replace('أ', 'ا')
        .replace('آ', 'ا')
        .replace('ى', 'ي')
        .replace('ة', 'ه')
        .replace(Regex("\\s+"), " ")

    fun matches(text: String, query: String): Boolean {
        val cleanQuery = normalize(query)
        if (cleanQuery.length < 2) return false
        return normalize(text).contains(cleanQuery)
    }

    fun snippet(text: String, query: String, maxChars: Int = 180): String {
        val clean = text.replace(Regex("\\s+"), " ").trim()
        if (clean.length <= maxChars) return clean

        val directIndex = clean.indexOf(query.trim(), ignoreCase = true)
        if (directIndex >= 0) {
            val needleLength = query.trim().length.coerceAtMost(maxChars)
            val ellipsisBudget = 2
            val contextBudget = (maxChars - needleLength - ellipsisBudget).coerceAtLeast(0)
            val before = contextBudget / 2
            val after = contextBudget - before
            val start = (directIndex - before).coerceAtLeast(0)
            val end = (directIndex + needleLength + after).coerceAtMost(clean.length)
            return buildString {
                if (start > 0) append('…')
                append(clean.substring(start, end).trim())
                if (end < clean.length) append('…')
            }.take(maxChars)
        }

        // عند التطابق بعد التطبيع العربي قد لا تتطابق الفهارس مع النص الأصلي.
        // نعرض بداية نظيفة بدل محاولة Highlight خاطئ.
        return clean.take(maxChars - 1).trimEnd() + "…"
    }
}
