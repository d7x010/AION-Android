package com.aion.mobile.core.memory

import android.content.Context
import android.util.AtomicFile
import com.aion.mobile.core.project.AionProject
import java.io.File
import java.util.UUID
import org.json.JSONArray
import org.json.JSONObject

/** Durable local store for Memory Engine v1. Content never leaves the device except selected context for the current inference. */
object AionMemoryStore {
    private const val FILE_SCHEMA = 1

    fun load(context: Context): List<AionMemoryEntry> = readRaw(context)?.let(::decode).orEmpty()

    fun syncLegacy(context: Context, globalNotes: String, projects: List<AionProject>, now: Long = System.currentTimeMillis()): List<AionMemoryEntry> {
        val before = load(context)
        var entries = before
        val global = preserveSyncedTimestamps(
            existing = entries,
            incoming = MemoryEnginePolicy.entriesFromNotes(
                raw = globalNotes,
                scope = MemoryScope.USER,
                ownerId = "",
                source = MemorySource.USER_SETTINGS,
                now = now
            )
        )
        entries = MemoryEnginePolicy.replaceSynchronizedSource(
            entries, MemoryScope.USER, "", MemorySource.USER_SETTINGS, global
        )

        val projectIds = projects.mapTo(hashSetOf()) { it.id }
        entries = entries.filterNot {
            it.source == MemorySource.PROJECT_NOTES && it.scope == MemoryScope.PROJECT && it.ownerId !in projectIds
        }
        projects.forEach { project ->
            val rows = preserveSyncedTimestamps(
                existing = entries,
                incoming = MemoryEnginePolicy.entriesFromNotes(
                    raw = project.memoryNotes,
                    scope = MemoryScope.PROJECT,
                    ownerId = project.id,
                    source = MemorySource.PROJECT_NOTES,
                    now = now
                )
            )
            entries = MemoryEnginePolicy.replaceSynchronizedSource(
                entries, MemoryScope.PROJECT, project.id, MemorySource.PROJECT_NOTES, rows
            )
        }
        val merged = MemoryEnginePolicy.merge(entries)
        if (merged != before) persist(context, merged)
        return merged
    }

    fun buildContext(
        context: Context,
        globalNotes: String,
        projects: List<AionProject>,
        activeProjectId: String?,
        activeConversationId: String?,
        projectOnlyMemory: Boolean,
        queryText: String = "",
        allowedScopes: Set<MemoryScope> = MemoryScope.entries.toSet(),
        now: Long = System.currentTimeMillis()
    ): AionMemoryContext {
        val entries = syncLegacy(context, globalNotes, projects, now)
        val base = MemoryEnginePolicy.selectForContext(
            entries = entries,
            activeProjectId = activeProjectId,
            activeConversationId = activeConversationId,
            projectOnlyMemory = projectOnlyMemory,
            now = now,
            queryText = queryText,
            allowedScopes = allowedScopes
        )
        return base
    }

    /** Future-facing API used by automatic/explicit structured memory without touching legacy notes. */
    fun upsert(
        context: Context,
        scope: MemoryScope,
        ownerId: String = "",
        kind: MemoryKind,
        text: String,
        slot: String = "",
        source: MemorySource,
        confidence: Float = 1f,
        expiresAt: Long = 0L,
        now: Long = System.currentTimeMillis()
    ): AionMemoryEntry? {
        val candidate = AionMemoryEntry(
            id = UUID.randomUUID().toString(),
            scope = scope,
            ownerId = ownerId,
            kind = kind,
            text = text,
            slot = slot,
            source = source,
            confidence = confidence,
            createdAt = now,
            updatedAt = now,
            expiresAt = expiresAt
        )
        val updated = MemoryEnginePolicy.upsert(load(context), candidate)
        val saved = updated.firstOrNull { it.id == candidate.id }
            ?: updated.firstOrNull { it.scope == candidate.scope && it.ownerId == candidate.ownerId && it.slot.isNotBlank() && it.slot == candidate.slot }
            ?: updated.firstOrNull { it.scope == candidate.scope && it.ownerId == candidate.ownerId && MemoryEnginePolicy.canonical(it.text) == MemoryEnginePolicy.canonical(candidate.text) }
        persist(context, updated)
        return saved
    }

    fun forget(context: Context, entryId: String) {
        if (entryId.isBlank()) return
        persist(context, load(context).filterNot { it.id == entryId })
    }

    fun clearScope(context: Context, scope: MemoryScope, ownerId: String = "") {
        val cleanOwner = ownerId.trim()
        persist(context, load(context).filterNot { it.scope == scope && it.ownerId == cleanOwner })
    }


    private fun preserveSyncedTimestamps(
        existing: List<AionMemoryEntry>,
        incoming: List<AionMemoryEntry>
    ): List<AionMemoryEntry> {
        val byId = existing.associateBy { it.id }
        return incoming.map { row ->
            val old = byId[row.id]
            if (old != null && MemoryEnginePolicy.canonical(old.text) == MemoryEnginePolicy.canonical(row.text)) {
                row.copy(createdAt = old.createdAt, updatedAt = old.updatedAt)
            } else row
        }
    }

    private fun memoryFile(context: Context): File {
        val dir = File(context.filesDir, "aion_memory")
        if (!dir.exists()) dir.mkdirs()
        return File(dir, "memory_v1.json")
    }

    private fun readRaw(context: Context): String? = runCatching {
        val file = memoryFile(context)
        if (!file.exists()) return@runCatching null
        AtomicFile(file).openRead().bufferedReader(Charsets.UTF_8).use { it.readText() }
    }.getOrNull()

    private fun persist(context: Context, entries: List<AionMemoryEntry>): Boolean = runCatching {
        val atomic = AtomicFile(memoryFile(context))
        val output = atomic.startWrite()
        try {
            output.write(encode(entries).toString().toByteArray(Charsets.UTF_8))
            atomic.finishWrite(output)
        } catch (error: Throwable) {
            atomic.failWrite(output)
            throw error
        }
        true
    }.getOrDefault(false)

    private fun encode(entries: List<AionMemoryEntry>): JSONObject = JSONObject().apply {
        put("schema", FILE_SCHEMA)
        put("contract", MemoryEnginePolicy.CONTRACT)
        put("entries", JSONArray().apply {
            MemoryEnginePolicy.merge(entries).forEach { entry ->
                put(JSONObject().apply {
                    put("id", entry.id)
                    put("scope", entry.scope.name.lowercase())
                    put("ownerId", entry.ownerId)
                    put("kind", entry.kind.name.lowercase())
                    put("text", entry.text)
                    put("slot", entry.slot)
                    put("source", entry.source.name.lowercase())
                    put("confidence", entry.confidence.toDouble())
                    put("createdAt", entry.createdAt)
                    put("updatedAt", entry.updatedAt)
                    put("expiresAt", entry.expiresAt)
                    put("active", entry.active)
                })
            }
        })
    }

    private fun decode(raw: String): List<AionMemoryEntry> = runCatching {
        val root = JSONObject(raw)
        if (root.optInt("schema") != FILE_SCHEMA) return@runCatching emptyList()
        val array = root.optJSONArray("entries") ?: JSONArray()
        buildList {
            for (i in 0 until array.length()) {
                val row = array.optJSONObject(i) ?: continue
                val scope = runCatching { MemoryScope.valueOf(row.optString("scope").uppercase()) }.getOrNull() ?: continue
                val kind = runCatching { MemoryKind.valueOf(row.optString("kind").uppercase()) }.getOrNull() ?: MemoryKind.NOTE
                val source = runCatching { MemorySource.valueOf(row.optString("source").uppercase()) }.getOrNull() ?: continue
                val id = row.optString("id").trim()
                val text = row.optString("text")
                if (id.isBlank() || MemoryEnginePolicy.normalizeText(text).isBlank()) continue
                add(
                    AionMemoryEntry(
                        id = id,
                        scope = scope,
                        ownerId = row.optString("ownerId"),
                        kind = kind,
                        text = text,
                        slot = row.optString("slot"),
                        source = source,
                        confidence = row.optDouble("confidence", 1.0).toFloat(),
                        createdAt = row.optLong("createdAt"),
                        updatedAt = row.optLong("updatedAt"),
                        expiresAt = row.optLong("expiresAt"),
                        active = row.optBoolean("active", true)
                    )
                )
            }
        }.let(MemoryEnginePolicy::merge)
    }.getOrDefault(emptyList())
}
