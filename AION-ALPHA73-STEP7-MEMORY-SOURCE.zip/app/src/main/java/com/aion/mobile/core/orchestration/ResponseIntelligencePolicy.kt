package com.aion.mobile.core.orchestration

/** Step 7.10 provider-neutral response policy contract mirrored by AION Core. */
object ResponseIntelligencePolicy {
    const val CONTRACT = 2
    const val POLICY = "response-intelligence-v2"
    const val CLARIFICATION_POLICY = "single-question-when-blocking-v2"

    private val profiles = setOf("concise", "balanced", "deep", "research")

    fun normalizeProfile(value: String?): String =
        value.orEmpty().trim().lowercase().takeIf { it in profiles }.orEmpty()

    fun shouldTrustToolResult(status: String?): Boolean =
        status.orEmpty().trim().lowercase() in setOf("succeeded", "partial")

    fun mayClaimCodeExecuted(status: String?): Boolean =
        status.orEmpty().trim().lowercase() == "succeeded"
}
