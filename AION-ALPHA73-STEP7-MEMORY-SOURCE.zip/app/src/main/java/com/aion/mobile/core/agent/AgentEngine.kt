package com.aion.mobile.core.agent

interface AgentEngine {
    suspend fun run(goal: String): AgentResult
}

data class AgentResult(
    val summary: String,
    val completed: Boolean,
    val executedSteps: Int
)
