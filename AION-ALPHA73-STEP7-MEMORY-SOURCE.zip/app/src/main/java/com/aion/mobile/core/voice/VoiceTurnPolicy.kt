package com.aion.mobile.core.voice

/** سياسات صغيرة قابلة للاختبار لمنع حلقات إعادة الاستماع العدوانية. */
object VoiceTurnPolicy {
    fun passivePhase(muted: Boolean): AionLivePhase =
        if (muted) AionLivePhase.IDLE else AionLivePhase.LISTENING

    /** A typed/voice turn may start while old assistant audio is still playing. */
    fun shouldInterruptPlaybackOnRequest(currentPhase: AionLivePhase): Boolean =
        currentPhase == AionLivePhase.SPEAKING

    /** Listening is only resumed automatically when the live session is not muted or busy. */
    fun canAutoResumeListening(phase: AionLivePhase, muted: Boolean, requestInFlight: Boolean): Boolean =
        !muted && !requestInFlight && phase !in setOf(
            AionLivePhase.SPEAKING,
            AionLivePhase.THINKING,
            AionLivePhase.READING_FILES,
            AionLivePhase.SEARCHING,
            AionLivePhase.COMPARING,
            AionLivePhase.WRITING
        )

    fun retryDelayMs(consecutiveFailures: Int, networkRelated: Boolean): Long {
        val failures = consecutiveFailures.coerceIn(0, 5)
        val base = if (networkRelated) 720L else 280L
        val step = if (networkRelated) 320L else 180L
        return (base + (failures * step)).coerceAtMost(2_200L)
    }

    fun shouldRequireManualResume(consecutiveNetworkFailures: Int): Boolean =
        consecutiveNetworkFailures >= 4
}
