package com.aion.mobile.core.memory

import android.content.Context

/**
 * ذاكرة محلية صريحة يملكها المستخدم بالكامل.
 * لا تستنتج معلومات حساسة تلقائيًا؛ المستخدم يكتب ما يريد الاحتفاظ به ويمكنه مسحه من الإعدادات.
 */
object LocalMemoryStore {
    private const val PREFS = "aion_local_memory"
    private const val KEY_INSTRUCTIONS = "custom_instructions"
    private const val KEY_MEMORY = "memory_notes"
    private const val MAX_INSTRUCTIONS = 8_000
    private const val MAX_MEMORY = 16_000

    data class Snapshot(
        val instructions: String,
        val memory: String
    )

    fun load(context: Context): Snapshot {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return Snapshot(
            instructions = safeString(prefs, KEY_INSTRUCTIONS),
            memory = safeString(prefs, KEY_MEMORY)
        )
    }

    private fun safeString(prefs: android.content.SharedPreferences, key: String): String =
        runCatching { prefs.getString(key, "").orEmpty() }.getOrElse {
            prefs.all[key]?.toString().orEmpty()
        }

    fun save(context: Context, instructions: String, memory: String) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_INSTRUCTIONS, instructions.trim().take(MAX_INSTRUCTIONS))
            .putString(KEY_MEMORY, memory.trim().take(MAX_MEMORY))
            .apply()
    }

    fun clear(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().clear().apply()
    }
}
