package com.aion.mobile.core.voice

import java.util.concurrent.atomic.AtomicLong

enum class AionVoicePlaybackOwner {
    READ_ALOUD,
    PREVIEW,
    LIVE
}

/**
 * Process-local arbitration for every audible AION surface.
 *
 * Only one voice surface may own playback at a time. Claiming a new owner synchronously
 * interrupts the previous owner's local stop callback. Tokens make stale completion callbacks
 * harmless: an old playback can never release a newer lease that already replaced it.
 */
class AionVoicePlaybackArbiter {
    private data class Active(
        val owner: AionVoicePlaybackOwner,
        val token: Long,
        val stop: () -> Unit,
    )

    private val lock = Any()
    private val sequence = AtomicLong(0L)
    private var active: Active? = null
    private val ownerListeners = LinkedHashSet<(AionVoicePlaybackOwner?) -> Unit>()

    fun claim(owner: AionVoicePlaybackOwner, stop: () -> Unit): Long {
        val token = sequence.incrementAndGet()
        val snapshot = synchronized(lock) {
            val old = active
            active = Active(owner, token, stop)
            old to ownerListeners.toList()
        }
        // Invoke outside the lock: stop/listener callbacks may call back into the arbiter.
        runCatching { snapshot.first?.stop?.invoke() }
        notifyOwner(snapshot.second, owner)
        return token
    }

    fun release(owner: AionVoicePlaybackOwner, token: Long) {
        val listeners = synchronized(lock) {
            val current = active
            if (current?.owner == owner && current.token == token) {
                active = null
                ownerListeners.toList()
            } else null
        } ?: return
        notifyOwner(listeners, null)
    }

    fun isCurrent(owner: AionVoicePlaybackOwner, token: Long): Boolean = synchronized(lock) {
        val current = active
        current?.owner == owner && current.token == token
    }

    fun isOwnedByOther(owner: AionVoicePlaybackOwner): Boolean = synchronized(lock) {
        active?.owner?.let { it != owner } == true
    }

    fun interrupt(owner: AionVoicePlaybackOwner): Boolean {
        val result = synchronized(lock) {
            val current = active
            if (current?.owner == owner) {
                active = null
                current to ownerListeners.toList()
            } else null
        } ?: return false
        runCatching { result.first.stop() }
        notifyOwner(result.second, null)
        return true
    }

    fun interruptAll(): Boolean {
        val result = synchronized(lock) {
            val current = active
            if (current != null) {
                active = null
                current to ownerListeners.toList()
            } else null
        } ?: return false
        runCatching { result.first.stop() }
        notifyOwner(result.second, null)
        return true
    }

    /**
     * Observe playback-owner changes. The callback may arrive from a background thread; UI users
     * should marshal to their main dispatcher/handler. The returned function unregisters it.
     */
    fun addOwnerListener(listener: (AionVoicePlaybackOwner?) -> Unit): () -> Unit {
        val current = synchronized(lock) {
            ownerListeners += listener
            active?.owner
        }
        runCatching { listener(current) }
        return {
            synchronized(lock) { ownerListeners -= listener }
        }
    }

    internal fun activeOwnerForTest(): AionVoicePlaybackOwner? = synchronized(lock) { active?.owner }

    private fun notifyOwner(
        listeners: List<(AionVoicePlaybackOwner?) -> Unit>,
        owner: AionVoicePlaybackOwner?,
    ) {
        listeners.forEach { listener -> runCatching { listener(owner) } }
    }
}
