package com.aion.mobile.core.voice

import kotlin.math.abs
import kotlin.math.sqrt

/**
 * يحول عينات PCM الخارجة من Android TTS إلى مستوى بصري 0..1.
 * النتيجة ليست مقياس dB؛ هي قيمة مهيأة لتحريك واجهة المكالمة فقط.
 */
object VoiceAmplitude {
    fun pcm16LittleEndian(bytes: ByteArray): Float {
        if (bytes.size < 2) return 0f
        var sumSquares = 0.0
        var peak = 0.0
        var samples = 0
        var index = 0
        while (index + 1 < bytes.size) {
            val lo = bytes[index].toInt() and 0xff
            val hi = bytes[index + 1].toInt()
            val sample = ((hi shl 8) or lo).toShort().toInt() / 32768.0
            val magnitude = abs(sample)
            sumSquares += sample * sample
            if (magnitude > peak) peak = magnitude
            samples += 1
            index += 2
        }
        if (samples == 0) return 0f
        val rms = sqrt(sumSquares / samples)
        // المزج بين RMS والذروة يجعل الحركة واضحة للكلام من دون القفز مع ضوضاء صغيرة.
        return ((rms * 3.15) + (peak * 0.28)).coerceIn(0.0, 1.0).toFloat()
    }

    fun pcm8Unsigned(bytes: ByteArray): Float {
        if (bytes.isEmpty()) return 0f
        var sumSquares = 0.0
        var peak = 0.0
        bytes.forEach { byte ->
            val sample = ((byte.toInt() and 0xff) - 128) / 128.0
            val magnitude = abs(sample)
            sumSquares += sample * sample
            if (magnitude > peak) peak = magnitude
        }
        val rms = sqrt(sumSquares / bytes.size)
        return ((rms * 3.0) + (peak * 0.25)).coerceIn(0.0, 1.0).toFloat()
    }


    fun pcmFloatLittleEndian(bytes: ByteArray): Float {
        if (bytes.size < 4) return 0f
        var sumSquares = 0.0
        var peak = 0.0
        var samples = 0
        var index = 0
        while (index + 3 < bytes.size) {
            val bits = (bytes[index].toInt() and 0xff) or
                ((bytes[index + 1].toInt() and 0xff) shl 8) or
                ((bytes[index + 2].toInt() and 0xff) shl 16) or
                ((bytes[index + 3].toInt() and 0xff) shl 24)
            val value = Float.fromBits(bits)
            if (value.isFinite()) {
                val sample = value.coerceIn(-1f, 1f).toDouble()
                val magnitude = abs(sample)
                sumSquares += sample * sample
                if (magnitude > peak) peak = magnitude
                samples += 1
            }
            index += 4
        }
        if (samples == 0) return 0f
        val rms = sqrt(sumSquares / samples)
        return ((rms * 3.15) + (peak * 0.28)).coerceIn(0.0, 1.0).toFloat()
    }

    fun smooth(previous: Float, incoming: Float): Float {
        val next = incoming.coerceIn(0f, 1f)
        // ارتفاع سريع حتى تستجيب الدائرة للكلمة، وانخفاض أهدأ حتى لا ترتجف بين المقاطع.
        val weight = if (next >= previous) 0.68f else 0.26f
        return (previous + ((next - previous) * weight)).coerceIn(0f, 1f)
    }
}
