package com.aion.mobile.core.voice

/** Keeps a live voice session from silently jumping to another conversation context. */
object AionLiveNavigationPolicy {
    fun canOpenConversation(session: AionLiveSessionState, targetConversationId: String): Boolean =
        !session.isActive || targetConversationId == session.conversationId

    fun canCreateOrOpenDifferentContext(session: AionLiveSessionState): Boolean = !session.isActive

    fun canRemoveConversation(session: AionLiveSessionState, conversationId: String): Boolean =
        !session.isActive || conversationId != session.conversationId

    fun canMoveConversation(session: AionLiveSessionState, conversationId: String): Boolean =
        !session.isActive || conversationId != session.conversationId

    /** Project instructions/memory may affect the live conversation's next turn. */
    fun canMutateProjectContext(session: AionLiveSessionState): Boolean = !session.isActive
}
