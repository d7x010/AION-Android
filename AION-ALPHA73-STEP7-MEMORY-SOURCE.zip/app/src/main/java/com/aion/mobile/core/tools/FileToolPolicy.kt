package com.aion.mobile.core.tools

/**
 * Step 7.9 client contract for files.read. The Android client may stage user-selected files,
 * but file contents are interpreted only as untrusted user data and never as system instructions.
 */
object FileToolPolicy {
    const val CONTRACT = 1
    const val TOOL_ID = "files.read"
    const val POLICY = "scoped-user-attachment-read-v1"
    const val MAX_FILES_PER_TOOL_CALL = 8
    const val MAX_FILE_BYTES = 5L * 1024L * 1024L

    fun accepts(sizeBytes: Long, isImage: Boolean): Boolean =
        !isImage && sizeBytes in 0..MAX_FILE_BYTES

    fun requiredPermissions(): Set<ToolPermission> = setOf(ToolPermission.READ_LOCAL)
}
