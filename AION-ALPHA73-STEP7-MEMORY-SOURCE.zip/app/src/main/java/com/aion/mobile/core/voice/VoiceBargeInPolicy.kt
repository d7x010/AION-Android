package com.aion.mobile.core.voice

import kotlin.math.max

/** Pure thresholds kept separate so false-interruption tuning is testable. */
object VoiceBargeInPolicy {
    const val RequiredSpeechFrames = 6

    fun triggerThreshold(noiseFloor: Float): Float =
        max(0.105f, (noiseFloor * 2.8f) + 0.018f).coerceAtMost(0.42f)

    fun shouldTrigger(level: Float, noiseFloor: Float, consecutiveSpeechFrames: Int): Boolean =
        consecutiveSpeechFrames >= RequiredSpeechFrames && level >= triggerThreshold(noiseFloor)
}
