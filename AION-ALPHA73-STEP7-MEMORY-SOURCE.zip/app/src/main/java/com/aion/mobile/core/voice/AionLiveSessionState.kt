package com.aion.mobile.core.voice

import com.aion.mobile.core.ai.GatewayActivity

/** Presentation survives Fullscreen <-> Mini transitions without ending the live session. */
enum class AionLivePresentation {
    HIDDEN,
    FULLSCREEN,
    MINIMIZED
}

/**
 * الحالة الدلالية الواحدة لـ AION Live.
 *
 * هذه ليست سلسلة تفكير داخلية للنموذج؛ بل حالة تشغيل قابلة للإثبات من التطبيق نفسه
 * (استماع، قراءة ملفات، بحث ويب، بث إجابة، كلام...).
 */
enum class AionLivePhase {
    IDLE,
    INITIALIZING,
    LISTENING,
    THINKING,
    READING_FILES,
    SEARCHING,
    COMPARING,
    WRITING,
    SPEAKING,
    RECONNECTING,
    ERROR
}

data class AionLiveSessionState(
    val presentation: AionLivePresentation = AionLivePresentation.HIDDEN,
    val phase: AionLivePhase = AionLivePhase.IDLE,
    val conversationId: String? = null,
    val muted: Boolean = false
) {
    val isActive: Boolean get() = presentation != AionLivePresentation.HIDDEN
    val isMinimized: Boolean get() = presentation == AionLivePresentation.MINIMIZED
    val isFullscreen: Boolean get() = presentation == AionLivePresentation.FULLSCREEN
}

sealed interface AionLiveEvent {
    data class Start(val conversationId: String) : AionLiveEvent
    data object Minimize : AionLiveEvent
    data object Restore : AionLiveEvent
    data object End : AionLiveEvent
    data class PhaseChanged(val phase: AionLivePhase) : AionLiveEvent
    data class SetMuted(val muted: Boolean) : AionLiveEvent
}

object AionLiveReducer {
    fun reduce(state: AionLiveSessionState, event: AionLiveEvent): AionLiveSessionState = when (event) {
        is AionLiveEvent.Start -> AionLiveSessionState(
            presentation = AionLivePresentation.FULLSCREEN,
            phase = AionLivePhase.INITIALIZING,
            conversationId = event.conversationId,
            muted = false
        )
        AionLiveEvent.Minimize -> if (state.isActive) state.copy(presentation = AionLivePresentation.MINIMIZED) else state
        AionLiveEvent.Restore -> if (state.isActive) state.copy(presentation = AionLivePresentation.FULLSCREEN) else state
        AionLiveEvent.End -> AionLiveSessionState()
        is AionLiveEvent.PhaseChanged -> if (state.isActive) state.copy(phase = event.phase) else state
        is AionLiveEvent.SetMuted -> if (state.isActive) state.copy(muted = event.muted) else state
    }
}

/** Pure policy shared by Voice UI and tests; keeps labels/behavior consistent. */
object AionLivePhasePolicy {
    fun fromGatewayActivity(activity: GatewayActivity?): AionLivePhase = when (activity) {
        GatewayActivity.READING_FILES -> AionLivePhase.READING_FILES
        GatewayActivity.SEARCHING_WEB -> AionLivePhase.SEARCHING
        GatewayActivity.COMPARING -> AionLivePhase.COMPARING
        GatewayActivity.WRITING -> AionLivePhase.WRITING
        GatewayActivity.THINKING, null -> AionLivePhase.THINKING
    }

    fun statusLabel(phase: AionLivePhase, muted: Boolean = false): String = when {
        muted && phase == AionLivePhase.LISTENING -> "الميكروفون مكتوم"
        else -> when (phase) {
            AionLivePhase.IDLE -> "AION Live"
            AionLivePhase.INITIALIZING -> "تهيئة الصوت…"
            AionLivePhase.LISTENING -> "أسمعك…"
            AionLivePhase.THINKING -> "جارٍ التفكير…"
            AionLivePhase.READING_FILES -> "أقرأ المرفقات…"
            AionLivePhase.SEARCHING -> "أبحث في الويب…"
            AionLivePhase.COMPARING -> "أقارن النتائج…"
            AionLivePhase.WRITING -> "أصيغ الإجابة…"
            AionLivePhase.SPEAKING -> "AION يتحدث…"
            AionLivePhase.RECONNECTING -> "إعادة الاتصال بالصوت…"
            AionLivePhase.ERROR -> "الصوت متوقف — اضغط للمتابعة"
        }
    }

    fun isBusy(phase: AionLivePhase): Boolean = phase in setOf(
        AionLivePhase.THINKING,
        AionLivePhase.READING_FILES,
        AionLivePhase.SEARCHING,
        AionLivePhase.COMPARING,
        AionLivePhase.WRITING
    )

    fun usesExternalAccent(phase: AionLivePhase): Boolean = phase == AionLivePhase.SEARCHING
}
