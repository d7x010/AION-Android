package com.aion.mobile.core.memory

/**
 * قواعد ذاكرة المشاريع مستقلة عن Android حتى يمكن اختبارها بدقة.
 *
 * - وجود مشروع نشط يعني أن زر «تذكّر» يكتب في ذاكرة ذلك المشروع دائمًا.
 * - projectOnlyMemory يتحكم في قراءة الذاكرة العامة داخل المشروع، لا في مكان الحفظ.
 * - الإدخالات المكررة تُمنع بعد تطبيع المسافات وعلامة التعداد.
 */
object ProjectMemoryPolicy {
    const val MAX_ENTRY_CHARS = 1_500
    const val MAX_MEMORY_CHARS = 16_000

    enum class WriteTarget { GLOBAL, PROJECT }

    fun writeTarget(activeProjectId: String?): WriteTarget =
        if (activeProjectId.isNullOrBlank()) WriteTarget.GLOBAL else WriteTarget.PROJECT

    fun normalizeEntry(raw: String): String = raw
        .replace("\u0000", "")
        .replace(Regex("\\s+"), " ")
        .trim()
        .removePrefix("•")
        .removePrefix("-")
        .trim()
        .take(MAX_ENTRY_CHARS)

    fun append(existing: String, rawEntry: String): String {
        val entry = normalizeEntry(rawEntry)
        if (entry.isBlank()) return existing.trim().takeLast(MAX_MEMORY_CHARS)

        val canonicalEntry = canonical(entry)
        val alreadyExists = existing
            .lineSequence()
            .map(::normalizeEntry)
            .filter(String::isNotBlank)
            .any { canonical(it) == canonicalEntry }
        if (alreadyExists) return existing.trim().takeLast(MAX_MEMORY_CHARS)

        val merged = buildString {
            if (existing.isNotBlank()) append(existing.trim()).append('\n')
            append("• ").append(entry)
        }
        return trimOldestWholeLines(merged, MAX_MEMORY_CHARS)
    }

    fun composeContext(
        globalMemory: String,
        projectName: String?,
        projectMemory: String,
        projectOnlyMemory: Boolean,
        relatedProjectContext: String
    ): String {
        val sections = mutableListOf<String>()
        if (!projectOnlyMemory && globalMemory.isNotBlank()) {
            sections += globalMemory.trim()
        }
        if (projectMemory.isNotBlank()) {
            val title = projectName?.trim().orEmpty().ifBlank { "المشروع" }
            sections += "ذاكرة المشروع «$title»:\n${projectMemory.trim()}"
        }
        if (relatedProjectContext.isNotBlank()) sections += relatedProjectContext.trim()
        return trimOldestWholeLines(sections.joinToString("\n\n"), MAX_MEMORY_CHARS)
    }

    private fun canonical(value: String): String = value
        .lowercase()
        .replace("أ", "ا")
        .replace("إ", "ا")
        .replace("آ", "ا")
        .replace("ى", "ي")
        .replace("ة", "ه")
        .replace(Regex("[\\p{Punct}\\s]+"), " ")
        .trim()

    private fun trimOldestWholeLines(value: String, maxChars: Int): String {
        if (value.length <= maxChars) return value.trim()
        val tail = value.takeLast(maxChars)
        val firstBreak = tail.indexOf('\n')
        return if (firstBreak >= 0 && firstBreak < tail.lastIndex) {
            tail.substring(firstBreak + 1).trim()
        } else {
            tail.trim()
        }
    }
}
