package com.aion.mobile.core.ai

/**
 * Pure validation for model/provider entries announced by AION Cloud.
 * Provider API keys never enter this contract or the APK.
 */
object ModelCatalogPolicy {
    private val keyRegex = Regex("^[a-z][a-z0-9_-]{0,31}$")
    private val reservedBuiltIns = setOf("auto", "fast", "deep", "research")
    private val supportedExternalKeys = setOf("claude", "gemini", "grok")

    fun normalizeKey(value: String?): String =
        value.orEmpty().trim().lowercase().takeIf { keyRegex.matches(it) }.orEmpty()

    fun isKnownExternalKey(value: String?): Boolean =
        normalizeKey(value) in supportedExternalKeys

    fun isSafeExternalKey(value: String?): Boolean {
        val key = normalizeKey(value)
        return key.isNotBlank() && key !in reservedBuiltIns && key in supportedExternalKeys
    }

    fun normalizeModelId(value: String?): String =
        value.orEmpty()
            .trim()
            .take(120)
            .takeIf { it.isNotBlank() && it.none(Char::isISOControl) }
            .orEmpty()

    fun normalizeLabel(value: String?, fallback: String): String =
        value.orEmpty()
            .replace(Regex("[\\r\\n\\u0000]"), " ")
            .trim()
            .take(48)
            .ifBlank { fallback.take(48) }

    fun normalizeProvider(value: String?): String =
        value.orEmpty()
            .replace(Regex("[\\r\\n\\u0000]"), " ")
            .trim()
            .take(64)

    fun canEnableExternal(key: String?, modelId: String?, chatReady: Boolean): Boolean =
        isSafeExternalKey(key) && normalizeModelId(modelId).isNotBlank() && chatReady

    fun resolveSelection(savedKey: String?, availableKeys: Collection<String>): String {
        val saved = normalizeKey(savedKey)
        return if (saved.isNotBlank() && saved in availableKeys) saved else "auto"
    }
}
