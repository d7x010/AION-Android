package com.aion.mobile.core.voice

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.atomic.AtomicLong
import kotlin.math.max

enum class NeuralVoicePlaybackResult {
    PLAYED,
    UNAVAILABLE,
    INTERRUPTED,
    FAILED
}

/**
 * Streams server-side neural PCM directly into AudioTrack.
 *
 * Playback is generation-owned. Every speak() gets a monotonically increasing generation and
 * preempts any older request. Resource registration is protected by one lock, so a stale
 * coroutine cannot overwrite the active connection/AudioTrack after a newer request has begun.
 * This is important when Live, Preview, and Read Aloud are interrupted in quick succession.
 *
 * Provider keys never enter the APK. AION Cloud either exposes /v1/voice/tts or returns a
 * fallback-compatible status, in which case the caller may continue with Android TextToSpeech.
 */
class NeuralVoicePlayer {
    private data class Resources(
        val connection: HttpURLConnection?,
        val track: AudioTrack?,
    )

    private val generation = AtomicLong(0L)
    private val resourceLock = Any()
    private var activeSessionId: Long = 0L
    private var activeConnection: HttpURLConnection? = null
    private var activeTrack: AudioTrack? = null

    fun stop() {
        generation.incrementAndGet()
        closeResources(takeActiveResources())
    }

    suspend fun speak(
        endpoint: String,
        text: String,
        profile: String = "balanced",
        voiceKey: String = "",
        speed: Float? = null,
        expression: Float? = null,
        clarity: Float? = null,
        myVoiceToken: String = "",
        onStarted: () -> Unit = {},
        onLevel: (Float) -> Unit = {},
    ): NeuralVoicePlaybackResult = withContext(Dispatchers.IO) {
        val cleanEndpoint = endpoint.trim().trimEnd('/')
        val cleanText = text.trim()
        if (!cleanEndpoint.startsWith("https://") || cleanText.isBlank()) {
            return@withContext NeuralVoicePlaybackResult.UNAVAILABLE
        }

        val sessionId = beginSession()
        fun isCurrent(): Boolean = generation.get() == sessionId
        if (!isCurrent()) return@withContext NeuralVoicePlaybackResult.INTERRUPTED

        var connection: HttpURLConnection? = null
        var track: AudioTrack? = null
        val cancellationHandle = currentCoroutineContext()[Job]?.invokeOnCompletion { cause ->
            if (cause is CancellationException) cancelSession(sessionId, connection, track)
        }

        try {
            connection = (URL("$cleanEndpoint/v1/voice/tts").openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                doOutput = true
                useCaches = false
                // Conversational fail-fast: a local voice fallback is more useful than prolonged silence.
                connectTimeout = 7_000
                readTimeout = 30_000
                setRequestProperty("Accept", "audio/pcm")
                setRequestProperty("Content-Type", "application/json; charset=utf-8")
                setRequestProperty("Connection", "keep-alive")
                setRequestProperty("X-Aion-Client", "AION-Android/alpha7.3")
            }
            if (!registerConnection(sessionId, connection)) {
                return@withContext NeuralVoicePlaybackResult.INTERRUPTED
            }

            val payloadJson = JSONObject()
                .put("text", cleanText)
                .put("profile", NeuralVoiceContract.normalizedProfile(profile))
            NeuralVoiceContract.normalizedVoiceKey(voiceKey).takeIf { it.isNotBlank() }?.let {
                payloadJson.put("voice", it)
                if (it == MyVoicePolicy.MY_VOICE_KEY && myVoiceToken.isNotBlank()) {
                    payloadJson.put("myVoiceToken", myVoiceToken)
                }
            }
            val settings = JSONObject()
            NeuralVoiceContract.clampSpeed(speed)?.let { settings.put("speed", it.toDouble()) }
            NeuralVoiceContract.clampExpression(expression)?.let { settings.put("expression", it.toDouble()) }
            NeuralVoiceContract.clampClarity(clarity)?.let { settings.put("clarity", it.toDouble()) }
            if (settings.length() > 0) payloadJson.put("settings", settings)
            val payload = payloadJson.toString().toByteArray(Charsets.UTF_8)
            connection.setFixedLengthStreamingMode(payload.size)
            connection.outputStream.use { it.write(payload) }

            if (!isCurrent()) return@withContext NeuralVoicePlaybackResult.INTERRUPTED
            val code = connection.responseCode
            if (NeuralVoiceContract.shouldUseLocalFallback(code)) {
                return@withContext NeuralVoicePlaybackResult.UNAVAILABLE
            }
            if (code !in 200..299) {
                connection.errorStream?.let { stream ->
                    runCatching {
                        BufferedReader(InputStreamReader(stream, Charsets.UTF_8)).use { it.readLine() }
                    }
                }
                return@withContext NeuralVoicePlaybackResult.FAILED
            }

            if (!NeuralVoiceContract.acceptsPcm(
                    contentType = connection.contentType,
                    audioFormat = connection.getHeaderField("x-aion-audio-format")
                )) {
                return@withContext NeuralVoicePlaybackResult.FAILED
            }

            val sampleRate = connection.getHeaderField("x-aion-sample-rate")
                ?.toIntOrNull()
                ?.coerceIn(8_000, 48_000)
                ?: 24_000
            val minBuffer = AudioTrack.getMinBufferSize(
                sampleRate,
                AudioFormat.CHANNEL_OUT_MONO,
                AudioFormat.ENCODING_PCM_16BIT
            )
            if (minBuffer <= 0) return@withContext NeuralVoicePlaybackResult.FAILED

            val audioTrack = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ASSISTANT)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(sampleRate)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(max(minBuffer * 2, 16_384))
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()
            if (audioTrack.state != AudioTrack.STATE_INITIALIZED) {
                releaseTrack(audioTrack)
                return@withContext NeuralVoicePlaybackResult.FAILED
            }
            track = audioTrack
            if (!registerTrack(sessionId, audioTrack)) {
                releaseTrack(audioTrack)
                track = null
                return@withContext NeuralVoicePlaybackResult.INTERRUPTED
            }

            // Frequent PCM level updates keep the Orb responsive to real speech without a fake loop.
            val buffer = ByteArray(4_096)
            var playbackStarted = false
            connection.inputStream.use { input ->
                while (true) {
                    currentCoroutineContext().ensureActive()
                    if (!isCurrent()) return@withContext NeuralVoicePlaybackResult.INTERRUPTED
                    val read = input.read(buffer)
                    if (read < 0) break
                    if (read == 0) continue
                    if (!playbackStarted) {
                        onStarted()
                        audioTrack.play()
                        playbackStarted = true
                    }
                    val levelBytes = if (read == buffer.size) buffer else buffer.copyOf(read)
                    onLevel(VoiceAmplitude.pcm16LittleEndian(levelBytes))

                    var written = 0
                    while (written < read) {
                        currentCoroutineContext().ensureActive()
                        if (!isCurrent()) return@withContext NeuralVoicePlaybackResult.INTERRUPTED
                        val count = audioTrack.write(buffer, written, read - written, AudioTrack.WRITE_BLOCKING)
                        if (count <= 0) return@withContext NeuralVoicePlaybackResult.FAILED
                        written += count
                    }
                }
            }
            onLevel(0f)
            when {
                !isCurrent() -> NeuralVoicePlaybackResult.INTERRUPTED
                !playbackStarted -> NeuralVoicePlaybackResult.FAILED
                else -> NeuralVoicePlaybackResult.PLAYED
            }
        } catch (error: CancellationException) {
            throw error
        } catch (_: Throwable) {
            if (!isCurrent()) NeuralVoicePlaybackResult.INTERRUPTED else NeuralVoicePlaybackResult.FAILED
        } finally {
            cancellationHandle?.dispose()
            clearOwnedResources(sessionId, connection, track)
            runCatching { connection?.disconnect() }
            track?.let(::releaseTrack)
            onLevel(0f)
        }
    }

    /** The newest session wins even if two callers race into speak() concurrently. */
    private fun beginSession(): Long {
        val sessionId = generation.incrementAndGet()
        val old = synchronized(resourceLock) {
            if (generation.get() != sessionId) {
                Resources(null, null)
            } else {
                val resources = Resources(activeConnection, activeTrack)
                activeSessionId = sessionId
                activeConnection = null
                activeTrack = null
                resources
            }
        }
        closeResources(old)
        return sessionId
    }

    private fun registerConnection(sessionId: Long, connection: HttpURLConnection): Boolean = synchronized(resourceLock) {
        if (generation.get() != sessionId || activeSessionId != sessionId) false
        else {
            activeConnection = connection
            true
        }
    }

    private fun registerTrack(sessionId: Long, track: AudioTrack): Boolean = synchronized(resourceLock) {
        if (generation.get() != sessionId || activeSessionId != sessionId) false
        else {
            activeTrack = track
            true
        }
    }

    private fun cancelSession(sessionId: Long, connection: HttpURLConnection?, track: AudioTrack?) {
        // Only the still-current generation may invalidate itself. A stale cancellation must not
        // increment past or close a newer playback generation.
        generation.compareAndSet(sessionId, sessionId + 1L)
        clearOwnedResources(sessionId, connection, track)
        runCatching { connection?.disconnect() }
        track?.let(::releaseTrack)
    }

    private fun clearOwnedResources(sessionId: Long, connection: HttpURLConnection?, track: AudioTrack?) {
        synchronized(resourceLock) {
            if (activeSessionId != sessionId) return
            if (activeConnection === connection) activeConnection = null
            if (activeTrack === track) activeTrack = null
            if (activeConnection == null && activeTrack == null) activeSessionId = 0L
        }
    }

    private fun takeActiveResources(): Resources = synchronized(resourceLock) {
        val resources = Resources(activeConnection, activeTrack)
        activeSessionId = 0L
        activeConnection = null
        activeTrack = null
        resources
    }

    private fun closeResources(resources: Resources) {
        runCatching { resources.connection?.disconnect() }
        resources.track?.let(::releaseTrack)
    }

    private fun releaseTrack(track: AudioTrack) {
        runCatching { if (track.playState == AudioTrack.PLAYSTATE_PLAYING) track.pause() }
        runCatching { track.flush() }
        runCatching { track.stop() }
        runCatching { track.release() }
    }
}
