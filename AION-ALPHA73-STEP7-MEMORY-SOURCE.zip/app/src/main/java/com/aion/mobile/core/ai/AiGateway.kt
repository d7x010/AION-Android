package com.aion.mobile.core.ai

/**
 * نقطة الربط المستقبلية مع مزود الذكاء الاصطناعي.
 * لا توضع مفاتيح API داخل تطبيق Android نفسه في النسخة الإنتاجية.
 */
interface AiGateway {
    suspend fun complete(request: AiRequest): AiResponse
}

data class AiRequest(
    val prompt: String,
    val conversationId: String? = null
)

data class AiResponse(
    val text: String,
    val provider: String
)
