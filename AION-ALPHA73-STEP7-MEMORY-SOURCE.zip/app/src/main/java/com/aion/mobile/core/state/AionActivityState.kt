package com.aion.mobile.core.state

import com.aion.mobile.core.ai.GatewayActivity

/**
 * UI/product activity state. It deliberately describes observable work only and must
 * never expose hidden chain-of-thought.
 */
enum class AionActivityKind {
    IDLE,
    THINKING,
    READING_FILES,
    SEARCHING_WEB,
    COMPARING,
    WRITING,
    UPLOADING,
    RECONNECTING,
    LISTENING,
    SPEAKING,
    ERROR
}

data class AionActivityState(
    val kind: AionActivityKind,
    val detail: String? = null,
    val completedUnits: Int? = null,
    val totalUnits: Int? = null
) {
    val isExternalWork: Boolean
        get() = kind == AionActivityKind.SEARCHING_WEB || kind == AionActivityKind.UPLOADING

    val hasProgress: Boolean
        get() = completedUnits != null && totalUnits != null && totalUnits > 0
}

fun GatewayActivity.toAionActivityState(): AionActivityState = when (this) {
    GatewayActivity.THINKING -> AionActivityState(AionActivityKind.THINKING)
    GatewayActivity.READING_FILES -> AionActivityState(AionActivityKind.READING_FILES)
    GatewayActivity.SEARCHING_WEB -> AionActivityState(AionActivityKind.SEARCHING_WEB)
    GatewayActivity.COMPARING -> AionActivityState(AionActivityKind.COMPARING)
    GatewayActivity.WRITING -> AionActivityState(AionActivityKind.WRITING)
}
