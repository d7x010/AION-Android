package com.aion.mobile.core.voice

/**
 * Pure transport contract for AION Neural Voice.
 *
 * Keeps validation and fallback rules outside Compose so later STEP5 points can add voice
 * selection and tuning without duplicating network policy across Live / Preview / Read Aloud.
 */
object NeuralVoiceContract {
    private val voiceKeyPattern = Regex("^[a-z0-9][a-z0-9_-]{0,31}$")

    fun normalizedVoiceKey(value: String?): String {
        val clean = value.orEmpty().trim().lowercase()
        return if (voiceKeyPattern.matches(clean)) clean else ""
    }

    fun normalizedProfile(value: String?): String = when (value.orEmpty().trim().lowercase()) {
        "calm" -> "calm"
        "expressive" -> "expressive"
        else -> "balanced"
    }

    fun shouldUseLocalFallback(httpStatus: Int): Boolean =
        httpStatus == 404 || httpStatus == 408 || httpStatus == 429 || httpStatus >= 500

    fun acceptsPcm(contentType: String?, audioFormat: String?): Boolean {
        val type = contentType.orEmpty().substringBefore(';').trim().lowercase()
        val format = audioFormat.orEmpty().trim().lowercase()
        val typeOk = type == "audio/pcm" || type == "application/octet-stream"
        val formatOk = format.isBlank() || format == "pcm_s16le"
        return typeOk && formatOk
    }

    fun clampSpeed(value: Float?): Float? = value?.coerceIn(0.72f, 1.20f)
    fun clampExpression(value: Float?): Float? = value?.coerceIn(0f, 1f)
    fun clampClarity(value: Float?): Float? = value?.coerceIn(0f, 1f)
}
