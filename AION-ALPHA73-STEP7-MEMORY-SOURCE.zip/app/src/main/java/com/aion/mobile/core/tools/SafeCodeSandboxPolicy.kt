package com.aion.mobile.core.tools

/**
 * Step 7.9 contract for code.execute. AION never evaluates arbitrary user code in the Android
 * process. Execution is allowed only through a separately isolated remote sandbox owned by AION Cloud.
 */
object SafeCodeSandboxPolicy {
    const val CONTRACT = 1
    const val TOOL_ID = "code.execute"
    const val POLICY = "remote-isolated-fail-closed-v1"
    const val MAX_CODE_CHARS = 20_000

    private val aliases = mapOf(
        "py" to "python", "python" to "python",
        "js" to "javascript", "javascript" to "javascript"
    )

    fun normalizeLanguage(value: String?): String =
        aliases[value.orEmpty().trim().lowercase()].orEmpty()

    fun accepts(language: String?, code: String?): Boolean =
        normalizeLanguage(language).isNotBlank() &&
            !code.isNullOrBlank() &&
            code.length <= MAX_CODE_CHARS &&
            '\u0000' !in code

    fun requiredPermissions(): Set<ToolPermission> =
        setOf(ToolPermission.COMPUTE, ToolPermission.NETWORK)

    fun allowsLocalExecution(): Boolean = false
}
