package com.aion.mobile

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.lifecycleScope
import com.aion.mobile.core.release.StartupCrashGuard
import com.aion.mobile.ui.AionApp
import com.aion.mobile.ui.theme.AionTheme
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val safeMode = StartupCrashGuard.begin(this)
        setContent {
            AionTheme {
                AionApp(safeMode = safeMode)
            }
        }
        lifecycleScope.launch {
            delay(6_000L)
            StartupCrashGuard.markStable(this@MainActivity)
        }
    }
}
