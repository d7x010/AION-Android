package com.aion.mobile.core.voice

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Owns the temporary Android audio session used by AION Live.
 *
 * We do not force a speaker/Bluetooth device; Android keeps the user's chosen route. We only
 * request conversational audio focus and MODE_IN_COMMUNICATION so OEM echo cancellation has the
 * best chance to work, then restore the previous mode when Live ends.
 */
class AionLiveAudioSession(context: Context) {
    private val audioManager = context.applicationContext.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val active = AtomicBoolean(false)
    private var previousMode: Int = AudioManager.MODE_NORMAL
    private var focusRequest: AudioFocusRequest? = null

    fun acquire(): Boolean {
        if (!active.compareAndSet(false, true)) return true
        previousMode = runCatching { audioManager.mode }.getOrDefault(AudioManager.MODE_NORMAL)

        val request = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANT)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            .setAcceptsDelayedFocusGain(false)
            .setOnAudioFocusChangeListener { _ ->
                // Playback/listening components react to their own state. Keep lifecycle ownership
                // here until release() so previous MODE_IN_COMMUNICATION is always restored.
            }
            .build()
        focusRequest = request

        val focusGranted = runCatching {
            audioManager.requestAudioFocus(request) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
        }.getOrDefault(false)

        runCatching { audioManager.mode = AudioManager.MODE_IN_COMMUNICATION }
        return focusGranted
    }

    fun release() {
        if (!active.getAndSet(false) && focusRequest == null) return
        focusRequest?.let { request -> runCatching { audioManager.abandonAudioFocusRequest(request) } }
        focusRequest = null
        runCatching { audioManager.mode = previousMode }
    }
}
