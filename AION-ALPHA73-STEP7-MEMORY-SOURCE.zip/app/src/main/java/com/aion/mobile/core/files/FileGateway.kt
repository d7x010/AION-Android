package com.aion.mobile.core.files

data class AionFile(
    val name: String,
    val mimeType: String,
    val uri: String
)

interface FileGateway {
    suspend fun read(file: AionFile): ByteArray
}
