package com.aion.mobile.core.voice

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.net.Uri
import androidx.core.content.ContextCompat
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.concurrent.thread
import kotlin.math.max

class MyVoiceSampleRecorder {
    enum class StartResult { STARTED, PERMISSION_REQUIRED, AUDIO_UNAVAILABLE, ALREADY_RECORDING }
    enum class ImportResult { IMPORTED, TOO_LARGE, INVALID_WAV, READ_FAILED }

    private val recording = AtomicBoolean(false)
    @Volatile private var worker: Thread? = null
    @Volatile private var recorder: AudioRecord? = null
    @Volatile private var pcmBytes: Long = 0L

    val isRecording: Boolean get() = recording.get()
    val durationMs: Long get() = MyVoicePolicy.durationMsFromPcmBytes(pcmBytes)

    fun sampleFile(context: Context): File = File(context.filesDir, "my_voice/sample.wav")

    fun start(context: Context, onAutoStopped: (File?) -> Unit = {}): StartResult {
        if (!recording.compareAndSet(false, true)) return StartResult.ALREADY_RECORDING
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            recording.set(false)
            return StartResult.PERMISSION_REQUIRED
        }

        val minBuffer = AudioRecord.getMinBufferSize(
            MyVoicePolicy.SAMPLE_RATE_HZ,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        )
        if (minBuffer <= 0) {
            recording.set(false)
            return StartResult.AUDIO_UNAVAILABLE
        }

        // The permission check above is in this same control-flow path so Lint can verify it.
        val audioRecord = try {
            AudioRecord.Builder()
                .setAudioSource(MediaRecorder.AudioSource.VOICE_RECOGNITION)
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(MyVoicePolicy.SAMPLE_RATE_HZ)
                        .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
                        .build()
                )
                .setBufferSizeInBytes(max(minBuffer * 2, 8_192))
                .build()
        } catch (_: SecurityException) {
            recording.set(false)
            return StartResult.PERMISSION_REQUIRED
        } catch (_: Throwable) {
            recording.set(false)
            return StartResult.AUDIO_UNAVAILABLE
        }

        if (audioRecord.state != AudioRecord.STATE_INITIALIZED) {
            runCatching { audioRecord.release() }
            recording.set(false)
            return StartResult.AUDIO_UNAVAILABLE
        }

        val dir = File(context.filesDir, "my_voice").apply { mkdirs() }
        val pcm = File(dir, "sample.tmp.pcm")
        runCatching { pcm.delete() }
        runCatching { sampleFile(context).delete() }
        pcmBytes = 0L
        recorder = audioRecord

        worker = thread(name = "aion-my-voice-recorder", isDaemon = true) {
            var output: FileOutputStream? = null
            var completed: File? = null
            try {
                if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return@thread
                audioRecord.startRecording()
                if (audioRecord.recordingState != AudioRecord.RECORDSTATE_RECORDING) return@thread
                output = FileOutputStream(pcm, false)
                val buffer = ByteArray(max(minBuffer, 4_096))
                while (recording.get()) {
                    val count = audioRecord.read(buffer, 0, buffer.size)
                    if (count <= 0) continue
                    output.write(buffer, 0, count)
                    pcmBytes += count
                    if (durationMs >= MyVoicePolicy.MAX_DURATION_MS || pcmBytes >= (MyVoicePolicy.MAX_SAMPLE_BYTES - 44L)) {
                        recording.set(false)
                    }
                }
            } catch (_: SecurityException) {
                recording.set(false)
            } catch (_: Throwable) {
                recording.set(false)
            } finally {
                runCatching { output?.flush() }
                runCatching { output?.close() }
                runCatching { if (audioRecord.recordingState == AudioRecord.RECORDSTATE_RECORDING) audioRecord.stop() }
                runCatching { audioRecord.release() }
                recorder = null
                if (pcm.isFile && pcm.length() > 0L) {
                    completed = runCatching { writeWav(pcm, sampleFile(context)) }.getOrNull()
                }
                runCatching { pcm.delete() }
                recording.set(false)
                onAutoStopped(completed)
            }
        }
        return StartResult.STARTED
    }

    fun stop(context: Context): File? {
        recording.set(false)
        runCatching { recorder?.stop() }
        worker?.join(1_500L)
        worker = null
        return sampleFile(context).takeIf { MyVoicePolicy.sampleReady(it) || it.isFile }
    }

    fun importWav(context: Context, uri: Uri): ImportResult {
        stop(context)
        val dir = File(context.filesDir, "my_voice").apply { mkdirs() }
        val temp = File(dir, "sample.import.tmp.wav")
        runCatching { temp.delete() }
        return try {
            val input = context.contentResolver.openInputStream(uri) ?: return ImportResult.READ_FAILED
            input.use { source ->
                FileOutputStream(temp, false).use { target ->
                    val buffer = ByteArray(16_384)
                    var total = 0L
                    while (true) {
                        val read = source.read(buffer)
                        if (read < 0) break
                        if (read == 0) continue
                        total += read
                        if (total > MyVoicePolicy.MAX_SAMPLE_BYTES) {
                            runCatching { temp.delete() }
                            return ImportResult.TOO_LARGE
                        }
                        target.write(buffer, 0, read)
                    }
                }
            }
            if (!MyVoicePolicy.sampleReady(temp)) {
                runCatching { temp.delete() }
                ImportResult.INVALID_WAV
            } else {
                val finalFile = sampleFile(context)
                runCatching { finalFile.delete() }
                if (temp.renameTo(finalFile) || runCatching { temp.copyTo(finalFile, overwrite = true); temp.delete(); true }.getOrDefault(false)) {
                    ImportResult.IMPORTED
                } else {
                    runCatching { temp.delete() }
                    ImportResult.READ_FAILED
                }
            }
        } catch (_: Throwable) {
            runCatching { temp.delete() }
            ImportResult.READ_FAILED
        }
    }

    fun deleteSample(context: Context): Boolean {
        stop(context)
        val dir = File(context.filesDir, "my_voice")
        runCatching { File(dir, "sample.tmp.pcm").delete() }
        runCatching { File(dir, "sample.import.tmp.wav").delete() }
        return runCatching { sampleFile(context).delete() }.getOrDefault(false)
    }

    private fun writeWav(pcm: File, wav: File): File {
        val dataSize = pcm.length().coerceAtMost(Int.MAX_VALUE.toLong()).toInt()
        FileOutputStream(wav, false).use { out ->
            fun writeAscii(value: String) = out.write(value.toByteArray(Charsets.US_ASCII))
            fun writeLeInt(value: Int) {
                out.write(value and 0xff)
                out.write((value shr 8) and 0xff)
                out.write((value shr 16) and 0xff)
                out.write((value shr 24) and 0xff)
            }
            fun writeLeShort(value: Int) {
                out.write(value and 0xff)
                out.write((value shr 8) and 0xff)
            }
            writeAscii("RIFF")
            writeLeInt(36 + dataSize)
            writeAscii("WAVE")
            writeAscii("fmt ")
            writeLeInt(16)
            writeLeShort(1)
            writeLeShort(MyVoicePolicy.CHANNELS)
            writeLeInt(MyVoicePolicy.SAMPLE_RATE_HZ)
            writeLeInt(MyVoicePolicy.SAMPLE_RATE_HZ * MyVoicePolicy.BYTES_PER_SAMPLE)
            writeLeShort(MyVoicePolicy.BYTES_PER_SAMPLE)
            writeLeShort(MyVoicePolicy.BITS_PER_SAMPLE)
            writeAscii("data")
            writeLeInt(dataSize)
            FileInputStream(pcm).use { input -> input.copyTo(out) }
        }
        return wav
    }
}
