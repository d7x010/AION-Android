package com.aion.mobile.core.memory

import android.content.Context

/** User-owned privacy switches. Conversation temporary mode is local-only and never sent as text. */
object MemoryPrivacyStore {
    private const val PREFS = "aion_memory_privacy_v1"
    private const val KEY_ENABLED = "enabled"
    private const val KEY_USER_SCOPE = "user_scope"
    private const val KEY_PROJECT_SCOPE = "project_scope"
    private const val KEY_CONVERSATION_SCOPE = "conversation_scope"
    private const val KEY_AUTOMATIC = "automatic"
    private const val KEY_TEMPORARY = "temporary_conversations"

    fun load(context: Context): MemoryPrivacySettings {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return MemoryPrivacySettings(
            memoryEnabled = prefs.getBoolean(KEY_ENABLED, true),
            allowUserScope = prefs.getBoolean(KEY_USER_SCOPE, true),
            allowProjectScope = prefs.getBoolean(KEY_PROJECT_SCOPE, true),
            allowConversationScope = prefs.getBoolean(KEY_CONVERSATION_SCOPE, true),
            automaticMemoryEnabled = prefs.getBoolean(KEY_AUTOMATIC, true)
        )
    }

    fun save(context: Context, settings: MemoryPrivacySettings) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putBoolean(KEY_ENABLED, settings.memoryEnabled)
            .putBoolean(KEY_USER_SCOPE, settings.allowUserScope)
            .putBoolean(KEY_PROJECT_SCOPE, settings.allowProjectScope)
            .putBoolean(KEY_CONVERSATION_SCOPE, settings.allowConversationScope)
            .putBoolean(KEY_AUTOMATIC, settings.automaticMemoryEnabled)
            .apply()
    }

    fun mode(context: Context, conversationId: String): ConversationMemoryMode =
        if (conversationId.isNotBlank() && temporaryIds(context).contains(conversationId)) {
            ConversationMemoryMode.TEMPORARY
        } else ConversationMemoryMode.NORMAL

    fun setTemporary(context: Context, conversationId: String, temporary: Boolean) {
        if (conversationId.isBlank()) return
        val next = temporaryIds(context).toMutableSet().apply {
            if (temporary) add(conversationId) else remove(conversationId)
        }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putStringSet(KEY_TEMPORARY, next)
            .apply()
    }

    fun removeConversation(context: Context, conversationId: String) =
        setTemporary(context, conversationId, false)

    private fun temporaryIds(context: Context): Set<String> =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getStringSet(KEY_TEMPORARY, emptySet())
            ?.filterTo(linkedSetOf()) { it.isNotBlank() }
            .orEmpty()
}
