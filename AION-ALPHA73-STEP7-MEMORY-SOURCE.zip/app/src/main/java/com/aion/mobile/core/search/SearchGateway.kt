package com.aion.mobile.core.search

data class SearchResult(
    val title: String,
    val snippet: String,
    val url: String
)

interface SearchGateway {
    suspend fun search(query: String): List<SearchResult>
}
