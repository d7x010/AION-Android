package com.aion.mobile.core.tools

import org.junit.Assert.assertEquals
import org.junit.Test

class ToolLoopPolicyTest {
    @Test fun keepsExplicitOrderAndDeduplicates() {
        val plan = ToolLoopPolicy.plan(listOf("web.search", "calculator", "web.search"))
        assertEquals(listOf("web.search", "calculator"), plan.steps.map { it.toolId })
        assertEquals(ToolLoopPolicy.MAX_STEPS, plan.maxSteps)
    }

    @Test fun supportsFilesAndRemoteCodeButIgnoresShell() {
        val plan = ToolLoopPolicy.plan(listOf("files.read", "shell", "code.execute", "calculator"))
        assertEquals(listOf("files.read", "code.execute", "calculator"), plan.steps.map { it.toolId })
        assertEquals(setOf(ToolPermission.READ_LOCAL), plan.steps[0].requiredPermissions)
        assertEquals(setOf(ToolPermission.COMPUTE, ToolPermission.NETWORK), plan.steps[1].requiredPermissions)
    }
}
