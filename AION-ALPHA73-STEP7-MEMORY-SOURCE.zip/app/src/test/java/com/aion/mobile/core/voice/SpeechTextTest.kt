package com.aion.mobile.core.voice

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class SpeechTextTest {
    @Test
    fun cleanRemovesMarkdownNoiseFromSpeech() {
        val cleaned = SpeechText.clean("## عنوان\n- **مرحبا** [المصدر](https://example.com)\n```kotlin\nprintln(1)\n```")
        assertTrue(cleaned.contains("عنوان"))
        assertTrue(cleaned.contains("مرحبا"))
        assertTrue(cleaned.contains("المصدر"))
        assertTrue(!cleaned.contains("https://"))
        assertTrue(!cleaned.contains("println"))
    }

    @Test
    fun naturalSplitPrefersSentenceBoundaries() {
        val input = ("هذه جملة واضحة. وهذه جملة ثانية أطول قليلًا، وفيها تفاصيل مفيدة. ").repeat(14)
        val parts = SpeechText.splitNatural(input, hardLimit = 420)
        assertTrue(parts.size > 1)
        assertTrue(parts.all { it.length <= 420 })
        assertTrue(parts.dropLast(1).all { it.endsWith('.') || it.endsWith('؟') || it.endsWith('!') || it.endsWith('،') || it.endsWith('؛') })
    }

    @Test
    fun shortTextRemainsOneSegment() {
        assertEquals(listOf("مرحبا بك في AION."), SpeechText.splitNatural("مرحبا بك في AION.", 420))
    }
}
