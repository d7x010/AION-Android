package com.aion.mobile.core.ai

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ModelCatalogPolicyTest {
    @Test fun externalKeysAreAllowlisted() {
        assertTrue(ModelCatalogPolicy.isSafeExternalKey("claude"))
        assertTrue(ModelCatalogPolicy.isSafeExternalKey("gemini"))
        assertTrue(ModelCatalogPolicy.isSafeExternalKey("grok"))
        assertFalse(ModelCatalogPolicy.isSafeExternalKey("auto"))
        assertFalse(ModelCatalogPolicy.isSafeExternalKey("provider/../../bad"))
    }

    @Test fun externalModelsNeedRealChatReadiness() {
        assertFalse(ModelCatalogPolicy.canEnableExternal("claude", "claude-sonnet", false))
        assertFalse(ModelCatalogPolicy.canEnableExternal("claude", "", true))
        assertTrue(ModelCatalogPolicy.canEnableExternal("claude", "claude-sonnet", true))
    }

    @Test fun invalidSavedSelectionFallsBackToAuto() {
        assertEquals("claude", ModelCatalogPolicy.resolveSelection("claude", setOf("auto", "claude")))
        assertEquals("auto", ModelCatalogPolicy.resolveSelection("gemini", setOf("auto", "claude")))
    }

    @Test fun modelIdRejectsControlCharacters() {
        assertEquals("", ModelCatalogPolicy.normalizeModelId("bad\nmodel"))
        assertEquals("claude-sonnet-5", ModelCatalogPolicy.normalizeModelId(" claude-sonnet-5 "))
    }
}
