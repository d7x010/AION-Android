package com.aion.mobile.core.voice

import org.junit.Assert.assertEquals
import org.junit.Test

class AionVoiceSettingsTest {
    @Test
    fun normalizationSanitizesVoiceAndBoundsTuning() {
        val clean = AionVoiceSettings(
            voiceKey = " FEMALE_1 ",
            profile = AionVoiceProfile.BALANCED,
            speed = 4f,
            expression = -2f,
            clarity = 3f
        ).normalized()

        assertEquals("female_1", clean.voiceKey)
        assertEquals(1.20f, clean.speed, 0.0001f)
        assertEquals(0f, clean.expression, 0.0001f)
        assertEquals(1f, clean.clarity, 0.0001f)
    }

    @Test
    fun profilePresetPreservesVoiceButResetsTuning() {
        val current = AionVoiceSettings(
            voiceKey = "male_1",
            profile = AionVoiceProfile.BALANCED,
            speed = 1.18f,
            expression = 0.91f,
            clarity = 0.22f
        )

        val calm = current.applyProfilePreset(AionVoiceProfile.CALM)
        assertEquals("male_1", calm.voiceKey)
        assertEquals(AionVoiceProfile.CALM, calm.profile)
        assertEquals(AionVoiceProfile.CALM.defaultSpeed, calm.speed, 0.0001f)
        assertEquals(AionVoiceProfile.CALM.defaultExpression, calm.expression, 0.0001f)
        assertEquals(AionVoiceProfile.CALM.defaultClarity, calm.clarity, 0.0001f)
    }
}
