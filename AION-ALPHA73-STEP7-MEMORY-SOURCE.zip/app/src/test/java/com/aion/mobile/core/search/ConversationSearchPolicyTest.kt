package com.aion.mobile.core.search

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Assert.assertEquals
import org.junit.Test

class ConversationSearchPolicyTest {
    @Test
    fun arabicNormalizationMatchesAlefAndDiacriticsVariants() {
        assertTrue(ConversationSearchPolicy.matches("إعداداتُ المشروع", "اعدادات المشروع"))
        assertTrue(ConversationSearchPolicy.matches("ذاكرة مستقلة", "ذاكره مستقله"))
    }

    @Test
    fun oneCharacterQueryDoesNotTriggerMessageSearch() {
        assertFalse(ConversationSearchPolicy.matches("AION", "ا"))
    }

    @Test
    fun snippetKeepsNearbyDirectMatch() {
        val text = "بداية ".repeat(20) + "الكلمة المطلوبة" + " نهاية".repeat(20)
        val snippet = ConversationSearchPolicy.snippet(text, "الكلمة المطلوبة", 90)
        assertTrue(snippet.contains("الكلمة المطلوبة"))
        assertTrue(snippet.length <= 100)
    }

    @Test
    fun shortTextIsReturnedCleanly() {
        assertEquals("نص قصير", ConversationSearchPolicy.snippet("  نص   قصير  ", "قصير"))
    }
}
