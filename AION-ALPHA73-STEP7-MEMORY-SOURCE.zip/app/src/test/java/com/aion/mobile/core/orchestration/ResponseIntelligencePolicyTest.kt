package com.aion.mobile.core.orchestration

import org.junit.Assert.*
import org.junit.Test

class ResponseIntelligencePolicyTest {
    @Test fun trustsOnlyCompletedToolStatesAndCodeNeedsSuccess() {
        assertEquals("deep", ResponseIntelligencePolicy.normalizeProfile("DEEP"))
        assertTrue(ResponseIntelligencePolicy.shouldTrustToolResult("partial"))
        assertFalse(ResponseIntelligencePolicy.shouldTrustToolResult("failed"))
        assertTrue(ResponseIntelligencePolicy.mayClaimCodeExecuted("succeeded"))
        assertFalse(ResponseIntelligencePolicy.mayClaimCodeExecuted("partial"))
        assertEquals(2, ResponseIntelligencePolicy.CONTRACT)
    }
}
