package com.aion.mobile.core

import com.aion.mobile.core.run.StreamingRenderPolicy
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class StreamingRenderPolicyTest {
    @Test
    fun firstVisibleChunkPublishesImmediately() {
        assertTrue(
            StreamingRenderPolicy.shouldPublish(
                nowMs = 1_000,
                lastPublishAtMs = 0,
                currentChars = 1,
                lastPublishChars = 0
            )
        )
    }

    @Test
    fun tinyRapidChunksAreCoalesced() {
        assertFalse(
            StreamingRenderPolicy.shouldPublish(
                nowMs = 1_020,
                lastPublishAtMs = 1_000,
                currentChars = 20,
                lastPublishChars = 10
            )
        )
    }

    @Test
    fun timeOrLargeChunkAllowsRefresh() {
        assertTrue(StreamingRenderPolicy.shouldPublish(1_048, 1_000, 20, 10))
        assertTrue(StreamingRenderPolicy.shouldPublish(1_010, 1_000, 110, 10))
    }
}
