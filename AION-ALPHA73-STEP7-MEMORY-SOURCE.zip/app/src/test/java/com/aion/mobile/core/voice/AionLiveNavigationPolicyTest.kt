package com.aion.mobile.core.voice

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class AionLiveNavigationPolicyTest {
    private val live = AionLiveReducer.reduce(AionLiveSessionState(), AionLiveEvent.Start("chat-live"))

    @Test
    fun sameConversation_remainsUsableWhileLiveIsMinimized() {
        val minimized = AionLiveReducer.reduce(live, AionLiveEvent.Minimize)
        assertTrue(AionLiveNavigationPolicy.canOpenConversation(minimized, "chat-live"))
    }

    @Test
    fun differentConversation_isBlockedUntilLiveEnds() {
        assertFalse(AionLiveNavigationPolicy.canOpenConversation(live, "chat-other"))
        assertFalse(AionLiveNavigationPolicy.canCreateOrOpenDifferentContext(live))
    }

    @Test
    fun liveConversation_cannotBeDeletedArchivedOrMovedMidSession() {
        assertFalse(AionLiveNavigationPolicy.canRemoveConversation(live, "chat-live"))
        assertFalse(AionLiveNavigationPolicy.canMoveConversation(live, "chat-live"))
        assertTrue(AionLiveNavigationPolicy.canRemoveConversation(live, "chat-other"))
        assertTrue(AionLiveNavigationPolicy.canMoveConversation(live, "chat-other"))
    }

    @Test
    fun projectContextChanges_waitUntilLiveEnds() {
        assertFalse(AionLiveNavigationPolicy.canMutateProjectContext(live))
        assertTrue(AionLiveNavigationPolicy.canMutateProjectContext(AionLiveSessionState()))
    }
}
