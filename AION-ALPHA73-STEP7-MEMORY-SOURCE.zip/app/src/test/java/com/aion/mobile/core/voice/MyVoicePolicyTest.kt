package com.aion.mobile.core.voice

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File
import java.io.FileOutputStream

class MyVoicePolicyTest {
    @Test
    fun acceptsExactCompatibleWavAtMinimumDuration() {
        val file = wav(seconds = 15, sampleRate = 16_000)
        try {
            assertTrue(MyVoicePolicy.sampleReady(file))
            assertEquals(15_000L, MyVoicePolicy.durationMsFromWav(file))
            val info = MyVoicePolicy.inspectWav(file)
            assertTrue(info?.compatible == true)
        } finally {
            file.delete()
        }
    }

    @Test
    fun rejectsShortOrWrongRateSamples() {
        val short = wav(seconds = 14, sampleRate = 16_000)
        val wrongRate = wav(seconds = 15, sampleRate = 8_000)
        try {
            assertFalse(MyVoicePolicy.sampleReady(short))
            assertFalse(MyVoicePolicy.sampleReady(wrongRate))
        } finally {
            short.delete()
            wrongRate.delete()
        }
    }

    @Test
    fun enrollmentRequiresCloudSampleConsentAndOwnerSecret() {
        assertTrue(MyVoicePolicy.canEnroll(true, true, true, "1234567890abcdef"))
        assertFalse(MyVoicePolicy.canEnroll(false, true, true, "1234567890abcdef"))
        assertFalse(MyVoicePolicy.canEnroll(true, false, true, "1234567890abcdef"))
        assertFalse(MyVoicePolicy.canEnroll(true, true, false, "1234567890abcdef"))
        assertFalse(MyVoicePolicy.canEnroll(true, true, true, "short"))
    }

    @Test
    fun nameIsSanitizedAndBounded() {
        val clean = MyVoicePolicy.normalizedName("  صوتي\n\u0000 الخاص   ")
        assertEquals("صوتي الخاص", clean)
        assertTrue(MyVoicePolicy.normalizedName("x".repeat(80)).length <= 48)
    }

    private fun wav(seconds: Int, sampleRate: Int): File {
        val dataSize = sampleRate * MyVoicePolicy.BYTES_PER_SAMPLE * seconds
        val file = File.createTempFile("aion-my-voice-test", ".wav")
        FileOutputStream(file).use { out ->
            fun ascii(value: String) = out.write(value.toByteArray(Charsets.US_ASCII))
            fun leInt(value: Int) {
                out.write(value and 0xff)
                out.write((value shr 8) and 0xff)
                out.write((value shr 16) and 0xff)
                out.write((value shr 24) and 0xff)
            }
            fun leShort(value: Int) {
                out.write(value and 0xff)
                out.write((value shr 8) and 0xff)
            }
            ascii("RIFF")
            leInt(36 + dataSize)
            ascii("WAVE")
            ascii("fmt ")
            leInt(16)
            leShort(1)
            leShort(1)
            leInt(sampleRate)
            leInt(sampleRate * 2)
            leShort(2)
            leShort(16)
            ascii("data")
            leInt(dataSize)
            out.write(ByteArray(dataSize))
        }
        return file
    }
}
