package com.aion.mobile.core.release

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** Pure companion policy test for the threshold documented by StartupCrashGuard. */
class StartupGuardPolicyTest {
    private fun shouldUseSafeMode(consecutiveStartupFailures: Int): Boolean = consecutiveStartupFailures >= 2

    @Test fun oneFailureDoesNotForceSafeMode() = assertFalse(shouldUseSafeMode(1))
    @Test fun repeatedFailuresEnableSafeMode() = assertTrue(shouldUseSafeMode(2))
}
