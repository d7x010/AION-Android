package com.aion.mobile.core.tools

import org.junit.Assert.*
import org.junit.Test

class SafeCodeSandboxPolicyTest {
    @Test fun normalizesOnlyKnownLanguagesAndNeverAllowsLocalExecution() {
        assertEquals("python", SafeCodeSandboxPolicy.normalizeLanguage("py"))
        assertEquals("javascript", SafeCodeSandboxPolicy.normalizeLanguage("JS"))
        assertEquals("", SafeCodeSandboxPolicy.normalizeLanguage("Kotlin"))
        assertEquals("", SafeCodeSandboxPolicy.normalizeLanguage("bash"))
        assertTrue(SafeCodeSandboxPolicy.accepts("python", "print(1)"))
        assertFalse(SafeCodeSandboxPolicy.accepts("bash", "rm -rf /"))
        assertFalse(SafeCodeSandboxPolicy.allowsLocalExecution())
    }
}
