package com.aion.mobile.core

import com.aion.mobile.core.memory.ProjectMemoryPolicy
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ProjectMemoryPolicyTest {
    @Test
    fun activeProjectAlwaysReceivesRememberedText() {
        assertEquals(
            ProjectMemoryPolicy.WriteTarget.PROJECT,
            ProjectMemoryPolicy.writeTarget("project-1")
        )
        assertEquals(
            ProjectMemoryPolicy.WriteTarget.GLOBAL,
            ProjectMemoryPolicy.writeTarget(null)
        )
    }

    @Test
    fun duplicateMemoryIsNotAddedTwice() {
        val first = ProjectMemoryPolicy.append("", "المستخدم يفضل الرد بالعربية")
        val second = ProjectMemoryPolicy.append(first, "• المستخدم يفضل الرد بالعربية")
        assertEquals(first, second)
    }

    @Test
    fun isolatedProjectDoesNotReceiveGlobalMemory() {
        val context = ProjectMemoryPolicy.composeContext(
            globalMemory = "سر عام لا يجب أن يدخل المشروع",
            projectName = "الرواية",
            projectMemory = "اسم البطل رين",
            projectOnlyMemory = true,
            relatedProjectContext = "سياق من محادثات أخرى في المشروع"
        )
        assertFalse(context.contains("سر عام"))
        assertTrue(context.contains("اسم البطل رين"))
        assertTrue(context.contains("سياق من محادثات أخرى"))
    }

    @Test
    fun sharedProjectCanUseGlobalAndProjectMemory() {
        val context = ProjectMemoryPolicy.composeContext(
            globalMemory = "استخدم العربية",
            projectName = "AION",
            projectMemory = "اللون الأساسي بنفسجي",
            projectOnlyMemory = false,
            relatedProjectContext = ""
        )
        assertTrue(context.contains("استخدم العربية"))
        assertTrue(context.contains("اللون الأساسي بنفسجي"))
    }

    @Test
    fun memoryLimitDropsOldestWholeLines() {
        val existing = (1..1200).joinToString("\n") { "• ذاكرة قديمة رقم $it" }
        val result = ProjectMemoryPolicy.append(existing, "هذه أحدث ذكرى مهمة")
        assertTrue(result.length <= ProjectMemoryPolicy.MAX_MEMORY_CHARS)
        assertTrue(result.endsWith("• هذه أحدث ذكرى مهمة"))
        assertFalse(result.startsWith("مة قديمة"))
    }
}
