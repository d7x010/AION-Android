package com.aion.mobile.core.ai

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class Step6IntegrationContractTest {
    @Test fun externalCatalogAndRoutingFormOneStableContract() {
        val available = setOf("auto", "fast", "deep", "research", "claude", "gemini", "grok")

        listOf("claude", "gemini", "grok").forEach { key ->
            assertTrue(ModelCatalogPolicy.isSafeExternalKey(key))
            assertTrue(ModelCatalogPolicy.canEnableExternal(key, "$key-server-model", chatReady = true))
            assertEquals(key, ModelCatalogPolicy.resolveSelection(key, available))
            assertEquals("pinned-external", ProviderRoutingPolicy.expectedPolicy(key))
            assertFalse(ProviderRoutingPolicy.canCrossProviderFailover(key))
        }

        listOf("auto", "fast", "deep", "research").forEach { key ->
            assertEquals("aion-workers-internal-fallback", ProviderRoutingPolicy.expectedPolicy(key))
            assertFalse(ProviderRoutingPolicy.canCrossProviderFailover(key))
        }
    }

    @Test fun invalidOrUnavailableExternalSelectionFallsBackOnlyAtSelectionBoundary() {
        val available = setOf("auto", "fast", "deep", "research", "claude")
        assertEquals("claude", ModelCatalogPolicy.resolveSelection("claude", available))
        assertEquals("auto", ModelCatalogPolicy.resolveSelection("gemini", available))
        assertEquals("auto", ModelCatalogPolicy.resolveSelection("unknown", available))
        assertFalse(ModelCatalogPolicy.canEnableExternal("gemini", "", chatReady = true))
        assertFalse(ModelCatalogPolicy.canEnableExternal("grok", "grok-model", chatReady = false))
    }

    @Test fun executionProvenanceRemainsDistinctFromSelection() {
        assertEquals(
            "Anthropic • claude-runtime-model",
            ProviderRoutingPolicy.displayLabel("Anthropic", "claude-runtime-model", fallbackUsed = false)
        )
        assertEquals(
            "Cloudflare Workers AI • @cf/qwen/qwen3.8-27b • احتياطي",
            ProviderRoutingPolicy.displayLabel(
                "Cloudflare Workers AI",
                "@cf/qwen/qwen3.8-27b",
                fallbackUsed = true
            )
        )
    }
}
