package com.aion.mobile.core.voice

import org.junit.Assert.assertEquals
import org.junit.Test

class VoiceSelectionPolicyTest {
    @Test
    fun savedVoiceWinsWhenStillAdvertised() {
        assertEquals(
            "female_1",
            VoiceSelectionPolicy.resolve(
                savedKey = "female_1",
                defaultKey = "male_1",
                availableKeys = listOf("male_1", "female_1")
            )
        )
    }

    @Test
    fun missingSavedVoiceFallsBackToServerDefault() {
        assertEquals(
            "male_1",
            VoiceSelectionPolicy.resolve(
                savedKey = "retired_voice",
                defaultKey = "male_1",
                availableKeys = listOf("male_1", "female_1")
            )
        )
    }

    @Test
    fun missingDefaultFallsBackToFirstAdvertisedVoice() {
        assertEquals(
            "female_1",
            VoiceSelectionPolicy.resolve(
                savedKey = "retired_voice",
                defaultKey = "missing_default",
                availableKeys = listOf("female_1", "male_1")
            )
        )
    }

    @Test
    fun keepsSavedVoiceWhenCatalogIsTemporarilyUnavailable() {
        assertEquals(
            "female_1",
            VoiceSelectionPolicy.resolve(
                savedKey = "FEMALE_1",
                defaultKey = null,
                availableKeys = emptyList()
            )
        )
    }

    @Test
    fun genderLabelsAreStableArabicUiCopy() {
        assertEquals("ذكر", VoiceSelectionPolicy.genderLabel("male"))
        assertEquals("أنثى", VoiceSelectionPolicy.genderLabel("FEMALE"))
        assertEquals("محايد", VoiceSelectionPolicy.genderLabel("unknown"))
    }
}
