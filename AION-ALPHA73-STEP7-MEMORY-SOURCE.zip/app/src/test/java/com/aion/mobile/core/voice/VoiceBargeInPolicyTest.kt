package com.aion.mobile.core.voice

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class VoiceBargeInPolicyTest {
    @Test
    fun quietAudio_doesNotTrigger() {
        assertFalse(VoiceBargeInPolicy.shouldTrigger(0.04f, 0.02f, 12))
    }

    @Test
    fun singleSpike_doesNotTrigger() {
        assertFalse(VoiceBargeInPolicy.shouldTrigger(0.40f, 0.02f, 1))
    }

    @Test
    fun sustainedSpeech_aboveAdaptiveThresholdTriggers() {
        val threshold = VoiceBargeInPolicy.triggerThreshold(0.02f)
        assertTrue(VoiceBargeInPolicy.shouldTrigger(threshold + 0.04f, 0.02f, VoiceBargeInPolicy.RequiredSpeechFrames))
    }

    @Test
    fun noisyRoom_raisesThreshold() {
        assertTrue(VoiceBargeInPolicy.triggerThreshold(0.08f) > VoiceBargeInPolicy.triggerThreshold(0.02f))
    }
}
