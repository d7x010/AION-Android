package com.aion.mobile.core.render

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class MarkdownRenderPolicyTest {
    @Test
    fun `streaming code fence remains a code block before closing fence arrives`() {
        val parts = MarkdownRenderPolicy.splitSegments("قبل\n```kotlin\nval x = 1")
        assertEquals(2, parts.size)
        assertFalse(parts[0].code)
        assertTrue(parts[1].code)
        assertFalse(parts[1].fenceClosed)
        assertEquals("kotlin", parts[1].language)
    }

    @Test
    fun `table and headings parse without leaking separator row`() {
        val blocks = MarkdownRenderPolicy.parseBlocks("## عنوان\n\n| الاسم | القيمة |\n|---|---|\n| AION | 7.3 |")
        assertEquals(MarkdownBlockKind.HEADING, blocks[0].kind)
        assertEquals(MarkdownBlockKind.TABLE, blocks[1].kind)
        assertEquals(2, blocks[1].rows.size)
    }

    @Test
    fun `multiline quote is grouped`() {
        val blocks = MarkdownRenderPolicy.parseBlocks("> سطر أول\n> سطر ثان")
        assertEquals(1, blocks.size)
        assertEquals("سطر أول\nسطر ثان", blocks.single().text)
    }

    @Test
    fun `long code collapses`() {
        val code = (1..40).joinToString("\n") { "line $it" }
        assertTrue(MarkdownRenderPolicy.shouldCollapseCode(code))
        assertEquals(28, MarkdownRenderPolicy.collapsedCode(code).lines().size)
    }
}
