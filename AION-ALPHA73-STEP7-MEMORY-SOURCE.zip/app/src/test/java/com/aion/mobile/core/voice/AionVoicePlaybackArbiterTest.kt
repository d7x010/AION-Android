package com.aion.mobile.core.voice

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class AionVoicePlaybackArbiterTest {
    @Test
    fun newOwnerInterruptsPreviousOwner() {
        val arbiter = AionVoicePlaybackArbiter()
        var readStopped = false
        arbiter.claim(AionVoicePlaybackOwner.READ_ALOUD) { readStopped = true }

        arbiter.claim(AionVoicePlaybackOwner.LIVE) { }

        assertTrue(readStopped)
        assertEquals(AionVoicePlaybackOwner.LIVE, arbiter.activeOwnerForTest())
    }

    @Test
    fun currentTokenDistinguishesOldAndNewLeaseFromSameOwner() {
        val arbiter = AionVoicePlaybackArbiter()
        val oldToken = arbiter.claim(AionVoicePlaybackOwner.LIVE) { }
        val newToken = arbiter.claim(AionVoicePlaybackOwner.LIVE) { }

        assertFalse(arbiter.isCurrent(AionVoicePlaybackOwner.LIVE, oldToken))
        assertTrue(arbiter.isCurrent(AionVoicePlaybackOwner.LIVE, newToken))
    }

    @Test
    fun staleReleaseCannotClearNewPlayback() {
        val arbiter = AionVoicePlaybackArbiter()
        val oldToken = arbiter.claim(AionVoicePlaybackOwner.PREVIEW) { }
        arbiter.claim(AionVoicePlaybackOwner.LIVE) { }

        arbiter.release(AionVoicePlaybackOwner.PREVIEW, oldToken)

        assertEquals(AionVoicePlaybackOwner.LIVE, arbiter.activeOwnerForTest())
    }

    @Test
    fun ownerSpecificInterruptDoesNotStopAnotherOwner() {
        val arbiter = AionVoicePlaybackArbiter()
        var stopped = false
        arbiter.claim(AionVoicePlaybackOwner.LIVE) { stopped = true }

        assertFalse(arbiter.interrupt(AionVoicePlaybackOwner.PREVIEW))
        assertFalse(stopped)
        assertEquals(AionVoicePlaybackOwner.LIVE, arbiter.activeOwnerForTest())

        assertTrue(arbiter.interrupt(AionVoicePlaybackOwner.LIVE))
        assertTrue(stopped)
        assertNull(arbiter.activeOwnerForTest())
    }

    @Test
    fun listenersSeeCrossSurfaceOwnershipAndRelease() {
        val arbiter = AionVoicePlaybackArbiter()
        val owners = mutableListOf<AionVoicePlaybackOwner?>()
        val remove = arbiter.addOwnerListener { owners += it }

        val token = arbiter.claim(AionVoicePlaybackOwner.PREVIEW) { }
        arbiter.release(AionVoicePlaybackOwner.PREVIEW, token)
        remove()

        assertEquals(listOf(null, AionVoicePlaybackOwner.PREVIEW, null), owners)
    }

    @Test
    fun detectsPlaybackOwnedByAnotherSurface() {
        val arbiter = AionVoicePlaybackArbiter()
        arbiter.claim(AionVoicePlaybackOwner.READ_ALOUD) { }

        assertTrue(arbiter.isOwnedByOther(AionVoicePlaybackOwner.LIVE))
        assertFalse(arbiter.isOwnedByOther(AionVoicePlaybackOwner.READ_ALOUD))
    }
}
