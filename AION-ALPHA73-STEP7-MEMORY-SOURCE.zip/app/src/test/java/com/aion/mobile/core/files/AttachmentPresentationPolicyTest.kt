package com.aion.mobile.core.files

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class AttachmentPresentationPolicyTest {
    @Test
    fun `pdf metadata is human readable`() {
        val label = AttachmentPresentationPolicy.secondaryLabel("book.pdf", "application/pdf", 2_097_152, 34)
        assertTrue(label.contains("PDF"))
        assertTrue(label.contains("34 صفحة"))
        assertTrue(label.contains("2.0 MB"))
    }

    @Test
    fun `code extensions are classified`() {
        assertEquals("كود", AttachmentPresentationPolicy.typeLabel("MainActivity.kt", "text/plain"))
    }
}
