package com.aion.mobile.core.state

import com.aion.mobile.core.ai.GatewayActivity
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class AionActivityStateTest {
    @Test
    fun gatewaySearch_mapsToExternalSearch() {
        val state = GatewayActivity.SEARCHING_WEB.toAionActivityState()
        assertEquals(AionActivityKind.SEARCHING_WEB, state.kind)
        assertTrue(state.isExternalWork)
    }

    @Test
    fun thinking_isInternalAndHasNoFakeProgress() {
        val state = GatewayActivity.THINKING.toAionActivityState()
        assertFalse(state.isExternalWork)
        assertFalse(state.hasProgress)
    }

    @Test
    fun progress_requiresRealTotal() {
        assertTrue(AionActivityState(AionActivityKind.READING_FILES, completedUnits = 2, totalUnits = 5).hasProgress)
        assertFalse(AionActivityState(AionActivityKind.READING_FILES, completedUnits = 2, totalUnits = 0).hasProgress)
    }
}
