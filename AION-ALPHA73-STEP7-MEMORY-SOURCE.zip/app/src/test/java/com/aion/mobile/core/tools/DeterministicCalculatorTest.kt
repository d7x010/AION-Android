package com.aion.mobile.core.tools

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class DeterministicCalculatorTest {
    @Test fun arabicDigitsAndPrecedenceAreDeterministic() {
        val result = DeterministicCalculator.evaluate("٢ + ٣ × ٤")
        assertTrue(result is DeterministicCalculator.Result.Success)
        assertEquals("14", (result as DeterministicCalculator.Result.Success).text)
    }

    @Test fun powersAreRightAssociative() {
        val result = DeterministicCalculator.evaluate("2^3^2") as DeterministicCalculator.Result.Success
        assertEquals("512", result.text)
    }

    @Test fun divideByZeroFailsClosed() {
        val result = DeterministicCalculator.evaluate("9 / 0")
        assertTrue(result is DeterministicCalculator.Result.Failure)
        assertEquals(ToolFailureCode.INVALID_INPUT, (result as DeterministicCalculator.Result.Failure).code)
    }

    @Test fun proseIsNeverEvaluated() {
        val result = DeterministicCalculator.evaluate("عمري 20 وطولي 172")
        assertTrue(result is DeterministicCalculator.Result.Failure)
    }
}
