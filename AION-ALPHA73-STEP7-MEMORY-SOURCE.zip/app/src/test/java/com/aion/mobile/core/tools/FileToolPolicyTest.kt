package com.aion.mobile.core.tools

import org.junit.Assert.*
import org.junit.Test

class FileToolPolicyTest {
    @Test fun acceptsOnlyBoundedNonImageUserFiles() {
        assertTrue(FileToolPolicy.accepts(1024, isImage = false))
        assertFalse(FileToolPolicy.accepts(1024, isImage = true))
        assertFalse(FileToolPolicy.accepts(6L * 1024L * 1024L, isImage = false))
        assertEquals(setOf(ToolPermission.READ_LOCAL), FileToolPolicy.requiredPermissions())
    }
}
