package com.aion.mobile.core.voice

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class VoiceTurnPolicyTest {
    @Test
    fun retriesBackOffInsteadOfSpinning() {
        assertTrue(VoiceTurnPolicy.retryDelayMs(3, false) > VoiceTurnPolicy.retryDelayMs(0, false))
        assertTrue(VoiceTurnPolicy.retryDelayMs(3, true) > VoiceTurnPolicy.retryDelayMs(3, false))
    }

    @Test
    fun mutedSessionSettlesToIdleAfterSpeech() {
        assertTrue(VoiceTurnPolicy.passivePhase(muted = true) == AionLivePhase.IDLE)
        assertTrue(VoiceTurnPolicy.passivePhase(muted = false) == AionLivePhase.LISTENING)
    }

    @Test
    fun typedTurnInterruptsOnlyActiveAssistantPlayback() {
        assertTrue(VoiceTurnPolicy.shouldInterruptPlaybackOnRequest(AionLivePhase.SPEAKING))
        assertFalse(VoiceTurnPolicy.shouldInterruptPlaybackOnRequest(AionLivePhase.LISTENING))
        assertFalse(VoiceTurnPolicy.shouldInterruptPlaybackOnRequest(AionLivePhase.THINKING))
    }

    @Test
    fun autoListenDoesNotRestartWhileBusyOrMuted() {
        assertTrue(VoiceTurnPolicy.canAutoResumeListening(AionLivePhase.LISTENING, muted = false, requestInFlight = false))
        assertFalse(VoiceTurnPolicy.canAutoResumeListening(AionLivePhase.SPEAKING, muted = false, requestInFlight = false))
        assertFalse(VoiceTurnPolicy.canAutoResumeListening(AionLivePhase.LISTENING, muted = true, requestInFlight = false))
        assertFalse(VoiceTurnPolicy.canAutoResumeListening(AionLivePhase.LISTENING, muted = false, requestInFlight = true))
    }

    @Test
    fun repeatedNetworkFailureEventuallyNeedsTap() {
        assertFalse(VoiceTurnPolicy.shouldRequireManualResume(3))
        assertTrue(VoiceTurnPolicy.shouldRequireManualResume(4))
    }
}
