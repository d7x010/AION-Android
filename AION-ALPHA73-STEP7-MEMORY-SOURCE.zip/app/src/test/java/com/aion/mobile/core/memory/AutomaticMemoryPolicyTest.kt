package com.aion.mobile.core.memory

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class AutomaticMemoryPolicyTest {
    @Test fun extractsClearPreferenceForFutureConversations() {
        val rows = AutomaticMemoryPolicy.extract("أنا أحب أن يكون الرد بالعربية وباختصار")
        assertEquals(MemoryKind.PREFERENCE, rows.single().kind)
    }

    @Test fun savesNameInAReplaceableSlot() {
        val row = AutomaticMemoryPolicy.extract("اسمي علي").single()
        assertEquals("profile.name", row.slot)
        assertEquals(MemoryKind.FACT, row.kind)
    }

    @Test fun neverExtractsSecretsOrMedicalDetails() {
        assertTrue(AutomaticMemoryPolicy.extract("مفتاح API الخاص بي abc").isEmpty())
        assertTrue(AutomaticMemoryPolicy.extract("عندي دواء معين").isEmpty())
    }

    @Test fun ordinaryQuestionIsNotMemory() {
        assertFalse(AutomaticMemoryPolicy.extract("ما هو أفضل هاتف اليوم؟").isNotEmpty())
    }
}
