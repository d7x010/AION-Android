package com.aion.mobile.core.voice

import com.aion.mobile.core.ai.GatewayActivity
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class AionLivePhasePolicyTest {
    @Test
    fun gatewayActivity_mapsToVisibleLivePhase() {
        assertEquals(AionLivePhase.THINKING, AionLivePhasePolicy.fromGatewayActivity(GatewayActivity.THINKING))
        assertEquals(AionLivePhase.READING_FILES, AionLivePhasePolicy.fromGatewayActivity(GatewayActivity.READING_FILES))
        assertEquals(AionLivePhase.SEARCHING, AionLivePhasePolicy.fromGatewayActivity(GatewayActivity.SEARCHING_WEB))
        assertEquals(AionLivePhase.COMPARING, AionLivePhasePolicy.fromGatewayActivity(GatewayActivity.COMPARING))
        assertEquals(AionLivePhase.WRITING, AionLivePhasePolicy.fromGatewayActivity(GatewayActivity.WRITING))
    }

    @Test
    fun visibleLabels_doNotExposeInternalReasoning() {
        assertEquals("جارٍ التفكير…", AionLivePhasePolicy.statusLabel(AionLivePhase.THINKING))
        assertEquals("أبحث في الويب…", AionLivePhasePolicy.statusLabel(AionLivePhase.SEARCHING))
        assertEquals("الميكروفون مكتوم", AionLivePhasePolicy.statusLabel(AionLivePhase.LISTENING, muted = true))
    }

    @Test
    fun onlyRealWorkPhases_areBusy() {
        assertTrue(AionLivePhasePolicy.isBusy(AionLivePhase.READING_FILES))
        assertTrue(AionLivePhasePolicy.isBusy(AionLivePhase.WRITING))
        assertFalse(AionLivePhasePolicy.isBusy(AionLivePhase.LISTENING))
        assertFalse(AionLivePhasePolicy.isBusy(AionLivePhase.SPEAKING))
    }
}
