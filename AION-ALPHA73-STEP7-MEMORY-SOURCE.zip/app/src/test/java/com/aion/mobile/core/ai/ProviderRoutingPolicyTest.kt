package com.aion.mobile.core.ai

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Test

class ProviderRoutingPolicyTest {
    @Test fun externalSelectionsArePinned() {
        assertEquals("pinned-external", ProviderRoutingPolicy.expectedPolicy("claude"))
        assertEquals("pinned-external", ProviderRoutingPolicy.expectedPolicy("gemini"))
        assertEquals("pinned-external", ProviderRoutingPolicy.expectedPolicy("grok"))
        assertFalse(ProviderRoutingPolicy.canCrossProviderFailover("claude"))
    }

    @Test fun builtInsUseOnlyWorkersInternalFallback() {
        assertEquals("aion-workers-internal-fallback", ProviderRoutingPolicy.expectedPolicy("auto"))
        assertEquals("aion-workers-internal-fallback", ProviderRoutingPolicy.expectedPolicy("deep"))
        assertFalse(ProviderRoutingPolicy.canCrossProviderFailover("auto"))
    }

    @Test fun executionLabelIsBoundedAndShowsFallback() {
        assertEquals(
            "Cloudflare Workers AI • @cf/qwen/qwen3.8-27b • احتياطي",
            ProviderRoutingPolicy.displayLabel("Cloudflare Workers AI", "@cf/qwen/qwen3.8-27b", true)
        )
        assertEquals("Anthropic • claude-test", ProviderRoutingPolicy.displayLabel("Anthropic", "claude-test", false))
    }
}
