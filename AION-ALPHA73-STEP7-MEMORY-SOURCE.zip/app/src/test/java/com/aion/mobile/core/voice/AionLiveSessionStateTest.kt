package com.aion.mobile.core.voice

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class AionLiveSessionStateTest {
    @Test
    fun liveSession_minimizeDoesNotEndConversation() {
        val started = AionLiveReducer.reduce(AionLiveSessionState(), AionLiveEvent.Start("chat-1"))
        val minimized = AionLiveReducer.reduce(started, AionLiveEvent.Minimize)
        assertTrue(minimized.isActive)
        assertEquals("chat-1", minimized.conversationId)
        assertEquals(AionLivePresentation.MINIMIZED, minimized.presentation)
    }

    @Test
    fun restoreReturnsToFullscreen() {
        val started = AionLiveReducer.reduce(AionLiveSessionState(), AionLiveEvent.Start("chat-1"))
        val minimized = AionLiveReducer.reduce(started, AionLiveEvent.Minimize)
        val restored = AionLiveReducer.reduce(minimized, AionLiveEvent.Restore)
        assertEquals(AionLivePresentation.FULLSCREEN, restored.presentation)
    }

    @Test
    fun minimizeAndRestore_preservePhaseAndMuteState() {
        var state = AionLiveReducer.reduce(AionLiveSessionState(), AionLiveEvent.Start("chat-1"))
        state = AionLiveReducer.reduce(state, AionLiveEvent.PhaseChanged(AionLivePhase.SPEAKING))
        state = AionLiveReducer.reduce(state, AionLiveEvent.SetMuted(true))

        val minimized = AionLiveReducer.reduce(state, AionLiveEvent.Minimize)
        assertEquals(AionLivePhase.SPEAKING, minimized.phase)
        assertTrue(minimized.muted)

        val restored = AionLiveReducer.reduce(minimized, AionLiveEvent.Restore)
        assertEquals(AionLivePhase.SPEAKING, restored.phase)
        assertTrue(restored.muted)
        assertEquals("chat-1", restored.conversationId)
    }

    @Test
    fun endResetsLiveState() {
        val started = AionLiveReducer.reduce(AionLiveSessionState(), AionLiveEvent.Start("chat-1"))
        val ended = AionLiveReducer.reduce(started, AionLiveEvent.End)
        assertFalse(ended.isActive)
        assertEquals(AionLivePhase.IDLE, ended.phase)
    }
}
