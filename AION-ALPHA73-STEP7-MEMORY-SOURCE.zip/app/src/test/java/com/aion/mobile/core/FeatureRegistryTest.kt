package com.aion.mobile.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class FeatureRegistryTest {
    @Test
    fun chatIsReadyAndFutureCapabilitiesExist() {
        val chat = FeatureRegistry.capabilities.first { it.key == "chat" }
        assertEquals(CapabilityState.READY, chat.state)

        val keys = FeatureRegistry.capabilities.map { it.key }.toSet()
        assertTrue(keys.containsAll(setOf("agent", "memory", "files", "voice", "search", "tools")))
    }
}
