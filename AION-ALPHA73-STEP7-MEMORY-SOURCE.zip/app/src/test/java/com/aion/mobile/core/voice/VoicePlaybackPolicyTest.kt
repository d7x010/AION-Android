package com.aion.mobile.core.voice

import org.junit.Assert.assertEquals
import org.junit.Test

class VoicePlaybackPolicyTest {
    private val chunks = listOf("الأول.", "الثاني.", "الثالث.")

    @Test
    fun fallbackIncludesChunkWhenNeuralNeverStartedIt() {
        assertEquals("الثاني. الثالث.", VoicePlaybackPolicy.localFallbackText(chunks, 1, false))
    }

    @Test
    fun fallbackSkipsPartiallySpokenChunkToAvoidDuplication() {
        assertEquals("الثالث.", VoicePlaybackPolicy.localFallbackText(chunks, 1, true))
    }

    @Test
    fun noRemainderAfterStartedLastChunk() {
        assertEquals("", VoicePlaybackPolicy.localFallbackText(chunks, 2, true))
    }
}
