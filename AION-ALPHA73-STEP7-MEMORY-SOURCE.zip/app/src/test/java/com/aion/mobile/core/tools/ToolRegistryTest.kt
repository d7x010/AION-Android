package com.aion.mobile.core.tools

import org.junit.Assert.*
import org.junit.Test

class ToolRegistryTest {
    private class SearchTool : AionTool {
        override val descriptor = ToolDescriptor(
            id = "web.search",
            title = "Web Search",
            permissions = setOf(ToolPermission.NETWORK),
            timeoutMs = 22_000
        )
        override suspend fun execute(input: String) = ToolResult(output = input, success = true, toolId = id)
    }

    @Test fun acceptsKnownToolWithPermissionAndCapsTimeout() {
        val plan = ToolRegistry(listOf(SearchTool())).plan(
            ToolRouteRequest("web.search", "latest", setOf(ToolPermission.NETWORK), maxTimeoutMs = 10_000)
        )
        assertTrue(plan.accepted)
        assertEquals(10_000L, plan.timeoutMs)
    }

    @Test fun rejectsMissingPermission() {
        val plan = ToolRegistry(listOf(SearchTool())).plan(ToolRouteRequest("web.search", "latest", emptySet()))
        assertFalse(plan.accepted)
        assertEquals(ToolFailureCode.PERMISSION_DENIED, plan.failureCode)
    }

    @Test fun rejectsUnknownAndMalformedTools() {
        val registry = ToolRegistry(listOf(SearchTool()))
        assertEquals(ToolFailureCode.NOT_FOUND, registry.plan(ToolRouteRequest("calculator", "1+1", emptySet())).failureCode)
        assertEquals(ToolFailureCode.INVALID_INPUT, registry.plan(ToolRouteRequest("../shell", "x", emptySet())).failureCode)
    }
}
