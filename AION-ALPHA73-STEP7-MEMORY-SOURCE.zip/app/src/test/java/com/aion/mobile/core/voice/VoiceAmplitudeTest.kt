package com.aion.mobile.core.voice

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class VoiceAmplitudeTest {
    @Test
    fun silenceProducesZeroLevel() {
        assertEquals(0f, VoiceAmplitude.pcm16LittleEndian(ByteArray(128)), 0.0001f)
    }

    @Test
    fun realPcmProducesVisibleLevel() {
        val bytes = ByteArray(400)
        var i = 0
        repeat(200) { sampleIndex ->
            val value = if (sampleIndex % 2 == 0) 11_000 else -11_000
            bytes[i] = (value and 0xff).toByte()
            bytes[i + 1] = ((value shr 8) and 0xff).toByte()
            i += 2
        }
        assertTrue(VoiceAmplitude.pcm16LittleEndian(bytes) > 0.45f)
    }

    @Test
    fun smoothingRisesFasterThanItFalls() {
        val rise = VoiceAmplitude.smooth(0f, 1f)
        val fall = VoiceAmplitude.smooth(1f, 0f)
        assertTrue(rise > 0.6f)
        assertTrue(fall > 0.6f)
    }
}
