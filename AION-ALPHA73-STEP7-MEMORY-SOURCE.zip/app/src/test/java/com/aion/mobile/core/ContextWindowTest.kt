package com.aion.mobile.core

import com.aion.mobile.core.ai.ContextWindow
import com.aion.mobile.model.ChatMessage
import com.aion.mobile.model.MessageRole
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ContextWindowTest {
    private fun message(id: Long, text: String = "m$id") = ChatMessage(
        id = id,
        role = if (id % 2L == 0L) MessageRole.AION else MessageRole.USER,
        text = text
    )

    @Test
    fun keepsOpeningAnchorAndLatestMessages() {
        val input = (1L..20L).map(::message)
        val selected = ContextWindow.select(
            messages = input,
            maxMessages = 8,
            anchorMessages = 3
        )

        assertEquals(listOf(1L, 2L, 3L, 16L, 17L, 18L, 19L, 20L), selected.map { it.id })
    }

    @Test
    fun doesNotDuplicateAnchorsWhenConversationIsShort() {
        val input = (1L..5L).map(::message)
        val selected = ContextWindow.select(input, maxMessages = 10, anchorMessages = 4)
        assertEquals(input.map { it.id }, selected.map { it.id })
    }

    @Test
    fun obeysCharacterBudgetWhileKeepingRecentTail() {
        val input = listOf(
            message(1, "a".repeat(30)),
            message(2, "b".repeat(30)),
            message(3, "c".repeat(30)),
            message(4, "d".repeat(30)),
            message(5, "e".repeat(30)),
            message(6, "f".repeat(30))
        )
        val selected = ContextWindow.select(
            messages = input,
            maxMessages = 6,
            maxChars = 170,
            anchorMessages = 1,
            maxAnchorChars = 60,
            maxMessageChars = 30
        )

        assertTrue(selected.first().id == 1L)
        assertTrue(selected.last().id == 6L)
        assertEquals(selected.size, selected.map { it.id }.toSet().size)
    }
}
