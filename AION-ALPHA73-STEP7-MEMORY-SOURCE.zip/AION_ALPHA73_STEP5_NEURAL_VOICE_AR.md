# AION α7.3 — Step 5: Neural Voice

الحالة: النقاط 1 و2 و3 مغلقة رسميًا ببوابة GitHub، والنقطة 4 مكتملة محليًا وتنتظر البوابة الرسمية.
الإصدار: `2.0.0-alpha7.3-dev9` / versionCode 23.

## النقطة 1 — Neural Voice Core Architecture

- Voice Catalog خادمي حتى 12 صوتًا دون كشف Voice IDs للتطبيق.
- توافق خلفي مع `AION_VOICE_ID`، والإعداد المتعدد الاختياري هو `AION_VOICES_JSON`.
- `/v1/status` يعرض فقط key/label/gender/defaultVoice ومعلومات الصيغة العامة.
- `/v1/voice/tts` يقبل voice + profile + settings اختيارية: speed / expression / clarity.
- القيم تُقيد على الخادم، وAndroid يطبّعها كذلك قبل النقل.
- Android يتحقق من PCM S16LE قبل التشغيل.
- 404 و408 و429 و5xx تعود لمسار Android TTS بدل الصمت.
- AION لا يدخل SPEAKING إلا بعد وصول أول PCM فعلي.
- إضافة `NeuralVoiceContract` واختبارات Worker/Android.

## النقطة 2 — Voice Selection / Preview / Tuning

- حفظ إعداد صوت موحد محليًا: voice key + profile + speed + expression + clarity.
- قراءة Voice Catalog الحقيقي من `/v1/status` مع `defaultVoice` وsample rate، دون إنشاء أصوات وهمية داخل APK.
- سياسة اختيار واحدة: الاختيار المحفوظ إذا ما زال متاحًا، ثم defaultVoice، ثم أول صوت فعلي؛ وإذا اختفى Catalog مؤقتًا لا يُمسح الاختيار المحفوظ.
- عرض label + ذكر/أنثى/محايد، مع وسم الصوت الافتراضي الحقيقي.
- Preview عصبي من داخل الإعدادات بنفس الصوت والإعدادات التي ستستخدمها المحادثة.
- Presets: هادئ / متوازن / تعبيري، مع ضبط يدوي للسرعة والتعبير والوضوح.
- أي تغيير في الصوت أو preset أو sliders يوقف المعاينة الجارية لمنع صوت قديم عالق.
- إغلاق/حفظ نافذة الإعدادات يوقف Preview ويحرر المشغل.
- Read Aloud وAION Live يستخدمان نفس `AionVoiceSettings`.
- Android TTS fallback يطبّق سرعة المستخدم أيضًا.
- إضافة `VoiceSelectionPolicy` واختبارات normalization/fallback/presets.
- قاعدة Step 4 النهائية محفوظة: Conversation binding، Mini Orb، phase state، microphone permission، وAPI 26/27 fixes لم تُستبدل.

## النقطة 3 — My Voice / Self Voice Enrollment

- My Voice مخصص لصوت المستخدم نفسه فقط؛ الواجهة تتطلب تأكيدًا صريحًا أن العينة لصوته شخصيًا.
- تسجيل محلي مباشر بصيغة WAV 16 kHz / Mono / PCM 16-bit، مع إيقاف تلقائي عند 90 ثانية.
- دعم استيراد WAV متوافق من Storage Access Framework؛ الملف يُنسخ إلى مساحة التطبيق الخاصة ولا يحتاج صلاحية تخزين عامة.
- تحقق مزدوج من العينة على Android وعلى AION Cloud: WAV متوافق، 15–90 ثانية، وحد 3.6 MB.
- لا تُرسل العينة إلى الخادم قبل تحديد consent صريح.
- إنشاء الصوت يمر عبر AION Cloud إلى ElevenLabs IVC؛ مفتاح المزود لا يدخل APK.
- Voice ID الخاص بالمزود لا يصل إلى Android حتى داخل token: AION Cloud يضعه في capability token مشفر AES-GCM.
- capability token يُخزن على Android مشفرًا مرة ثانية باستخدام Android Keystore.
- بعد نجاح إنشاء الاعتماد وحفظه بأمان تُحذف العينة المحلية تلقائيًا.
- إذا تعذر حفظ الاعتماد محليًا، يطلب AION حذف النسخة التي أنشئت لدى المزود بدل ترك clone يتيمًا قدر الإمكان.
- إذا أبلغ المزود أن الصوت يحتاج Verification، يُحفظ الاعتماد لكن لا يُستخدم حتى يصبح صالحًا.
- My Voice يدخل نفس مسار Preview + Read Aloud + AION Live من خلال voice key ثابت `my_voice`.
- حذف My Voice مؤكد بواجهة منفصلة؛ يحذف النسخة لدى المزود أولًا ثم يمسح اعتماد الجهاز. عند فشل الحذف يبقى الاعتماد لإعادة المحاولة.
- `/v1/status` لا يعرض أسرار My Voice؛ يعرض فقط availability/provider/maxSampleBytes/requiresConsent.
- إعداد Alpha الخادمي يستخدم `AION_MY_VOICE_ENROLLMENT_SECRET` للمالك و`AION_MY_VOICE_TOKEN_SECRET` لتشفير capability. هذا ليس نظام حسابات متعدد المستخدمين ولا يُقدّم كحل إنتاجي نهائي.

## ليس ضمن النقطة 3
- Playback arbitration / audio focus polish بين Live وPreview وRead Aloud: النقطة 4.
- Full-duplex WebRTC أو Live بالخلفية: ليست ضمن Step 5.3.

## Release gate
يلزم نجاح: Worker regression + `:app:testDebugUnitTest` + `:app:lintDebug` + `:app:assembleDebug` + `apksigner verify`.

### حارس ارتباط My Voice بالخادم
- اعتماد My Voice مرتبط بعنوان AION Cloud الذي أنشأه ولا ينتقل ضمنيًا إلى خادم آخر.
- لا يظهر My Voice كصوت قابل للاستخدام إلا إذا تطابق عنوان الاعتماد مع عنوان Cloud الحالي ومع عنوان آخر فحص Health لنفس الخادم.
- إنشاء My Voice يتطلب فحص اتصال العنوان الحالي وإعلان الخادم نفسه أن My Voice متاح.
- الحذف يستخدم عنوان الخادم المحفوظ داخل الاعتماد حتى لو تغير عنوان AION Cloud لاحقًا.


## النقطة 4 — Voice Experience Polish / Playback Arbitration

- إضافة `AionVoicePlaybackArbiter` كمالك واحد للصوت على مستوى التطبيق؛ Read Aloud وPreview وAION Live لا يمكنها التحدث فوق بعضها.
- كل تشغيل يحصل على lease token مستقل؛ callback قديم لا يستطيع تحرير أو تغيير حالة تشغيل أحدث.
- Live يراقب مالك الصوت المشترك: إذا بدأ Preview/Read Aloud أثناء الاستماع يوقف SpeechRecognizer مؤقتًا حتى لا يلتقط AION صوته الخارج من السماعة، ثم يستأنف بعد انتهاء التشغيل الآخر.
- بدء AION Live يوقف أي Preview/Read Aloud جارٍ فورًا، مع الحفاظ على Conversation binding وقواعد Step 4.
- تقوية `NeuralVoicePlayer` بجيل تشغيل monotonic + resource lock يمنع coroutine قديمة من إغلاق Connection/AudioTrack أحدث عند stop/start سريع.
- تقليل مهلة Neural Voice إلى 7 ثوانٍ للاتصال و30 ثانية للقراءة، مع PCM buffer أصغر 4096 bytes لتحسين الاستجابة وتحديث مستوى Orb من عينات حقيقية بوتيرة أنعم.
- Preview وRead Aloud يملكان Audio Focus transient ويحررانه في completion/interruption/error؛ Live يحتفظ بـ`AionLiveAudioSession` المعتمد في Step 4 دون فرض Speaker/Bluetooth route.
- عند تعطل Neural Voice بعد بدء جزء من الرد، يكمل Android TTS من الجزء غير المنطوق فقط؛ وإذا لم يبدأ الجزء الفاشل أصلًا يُعاد ذلك الجزء مع الباقي.
- utterance IDs في Android TTS تحمل lease token في Live وRead Aloud، لذلك `onDone/onStop/onError/onAudioAvailable` القديمة لا تغير حالة تشغيل أحدث.
- فحص نتيجة `TextToSpeech.speak()`؛ رفض المحرك للطابور يغلق lease/focus بأمان بدل ترك SPEAKING أو Read Aloud عالقًا.
- cleanup عند الإلغاء يوقف neural/TTS/barge-in ويحرر المالك الصحيح فقط، ولا يسمح لـdispose قديم بإيقاف Preview/Read Aloud أحدث.
- إضافة اختبارات مستقلة لـPlayback arbitration وstale token safety وneural-to-local remainder handoff.

## ليس ضمن النقطة 4
- لا Bluetooth route picker مخصص ولا إجبار لمسار السماعة؛ قرار Step 4 باحترام route النظام يبقى كما هو.
- لا Full-duplex WebRTC ولا Foreground Live بالخلفية ضمن Step 5.4.

## Release gate للنقطة 4
يلزم نجاح: Worker regression + `:app:testDebugUnitTest` + `:app:lintDebug` + `:app:assembleDebug` + `apksigner verify` + رفع Artifact قبل إغلاق Step 5 رسميًا.
