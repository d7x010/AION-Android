# Step 6.6 — Local Status

الحالة: PASS محليًا / GitHub Gate pending

الإصدار: AION 2.0.0-alpha7.3-dev15 / versionCode 29

## المنفذ
- provider-neutral context normalizer.
- shared history adaptation لـClaude/Gemini/Grok.
- merge consecutive same-role turns.
- drop leading orphan assistant only.
- require final user turn.
- current-turn vision محفوظ.
- `/v1/status.models.context.contract = 1`.

## اختبارات محلية
- Worker regression: PASS.
- Cross-model same-history test Claude/Gemini/Grok: PASS.
- Provider routing/failover regression: PASS.
- Claude/Gemini/Grok Sync/Streaming/Vision/Search regressions: PASS.

## غير متغير
- Voice / My Voice / AION Live.
- crossProviderFailover=false.
- external selection pinned.

الإغلاق الرسمي يحتاج GitHub Unit + Lint + assembleDebug + APK verify + artifact.
