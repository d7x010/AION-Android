# AION α7.3 — Step 4: AION Live

الإصدار الداخلي بعد هذه الخطوة: **2.0.0-alpha7.3-dev5 / versionCode 19**.

هذه الخطوة أغلقت بنية AION Live داخل نفس المحادثة قبل الانتقال إلى Neural Voice المتقدم.

## 4.1 — حالة الجلسة والـOrb
- توحيد حالات Live في `AionLivePhase` بدل وجود enum منفصل داخل واجهة الصوت.
- إضافة الحالات: IDLE / INITIALIZING / LISTENING / THINKING / READING_FILES / SEARCHING / COMPARING / WRITING / SPEAKING / RECONNECTING / ERROR.
- `AionLivePhasePolicy` يربط GatewayActivity بالحالة المرئية ويمنع عرض التفكير الداخلي.
- مزامنة phase وmute مع `AionLiveSessionState` الخارجي.

## 4.2 — التصغير والاستعادة
- Fullscreen Voice يُسحب للأسفل إلى Mini Orb بدل إنهاء الجلسة.
- Back/dismiss يصغر الجلسة؛ الإنهاء يحتاج زرًا صريحًا.
- Mini Orb تبقى فوق Composer وتتحرك مع IME padding.
- Mini Orb تعرض MicOff إذا كان الميكروفون مكتومًا وتستخدم Accent دلاليًا حسب الحالة.
- Phase + mute + conversationId تبقى محفوظة أثناء minimize/restore.

## 4.3 — Typed interruption
- إرسال نص أثناء كلام AION يوقف الصوت الجاري فقط.
- جلسة Live لا تنتهي ولا يتغير Conversation ID.
- مجرد الكتابة بدون إرسال لا تقاطع AION.
- بعد Stop/turn completion تعود الجلسة إلى LISTENING أو IDLE إذا كان الميكروفون مكتومًا.

## 4.4 — Voice interruption / Barge-in
- إضافة `VoiceBargeInDetector` باستخدام AudioRecord/VOICE_COMMUNICATION.
- المقاطعة التلقائية لا تعمل إلا إذا كان الجهاز يوفر Acoustic Echo Cancellation فعليًا.
- NoiseSuppressor يُستخدم عند توفره.
- Warm-up + adaptive noise floor + عدة إطارات كلام متتالية لتقليل false positives.
- إذا AEC غير متوفر يبقى Tap-to-interrupt هو المسار الآمن بدل أن يسمع AION صوته.

## 4.5 — الجلسة وسياق المحادثة
- Live تُربط بالمحادثة التي بدأت منها.
- أثناء Live لا يسمح التطبيق بالانتقال بصمت إلى محادثة/Project آخر ثم خلط سياق الصوت.
- منع حذف/أرشفة/نقل المحادثة الحية أو تغيير Project context أثناء الجلسة.
- القراءة والكتابة والإرسال داخل نفس المحادثة تبقى متاحة عند التصغير.

## 4.6 — Android audio session
- إضافة `AionLiveAudioSession`.
- طلب Audio Focus مؤقت أثناء Live.
- `MODE_IN_COMMUNICATION` أثناء الجلسة لتحسين فرصة عمل AEC على أجهزة OEM.
- استعادة وضع الصوت السابق عند الإنهاء.
- لا يجبر AION Speaker/Bluetooth يدويًا؛ يبقى اختيار route للنظام/المستخدم.
- إضافة `MODIFY_AUDIO_SETTINGS` في Manifest.

## إصلاحات مكتشفة أثناء الفحص
- منع بقاء حالة SPEAKING بعد انتهاء الصوت إذا كان الميكروفون مكتومًا.
- منع استئناف SpeechRecognizer تلقائيًا أثناء THINKING/SEARCHING/WRITING بسبب callback متأخر.
- منع تغيير Project instructions/memory أثناء جلسة Live حتى لا يتغير سياق الدور التالي بصمت.

## فحوص محلية
- Pure live policies compile/run: PASS.
- Kotlin parser smoke: لا توجد parser errors من نوع expecting/unclosed/unexpected tokens.
- XML parse: PASS.
- Duplicate import scan للملفات المعدلة: PASS.
- Cloud Worker syntax: PASS.
- Cloud Worker regression tests: PASS.

## ما لا نعتبره منجزًا في Step 4
- Neural Voice النهائي/الأصوات البشرية عالية الجودة: Step 5.
- My Voice / voice cloning: Step 5 وبموافقة صريحة.
- Background Live خارج التطبيق + Foreground Service خاص بالميكروفون: مرحلة لاحقة.
- Bluetooth route picker مخصص داخل AION: لاحقًا بعد اختبار الأجهزة.
- Full-duplex WebRTC حقيقي: ليس جزءًا من هذه الخطوة.

## Release gate
لم يتم تشغيل Android Gradle `test + lint + assembleDebug` الكامل محليًا لعدم وجود Android toolchain في بيئة العمل. هذا سيبقى بوابة GitHub الإلزامية قبل APK التجريبي.
