# AION α7.3 — Step 5.3 My Voice

الحالة: LOCAL READY / OFFICIAL GATE PENDING

الإصدار: 2.0.0-alpha7.3-dev8
versionCode: 22

## منفذ محليًا
- تسجيل عينة صوتية ذاتية داخل التطبيق.
- استيراد WAV متوافق.
- موافقة صريحة على أن العينة لصوت المستخدم نفسه قبل أي رفع.
- تحقق مزدوج Android + AION Cloud لصيغة WAV: 16 kHz / Mono / PCM 16-bit / 15–90 ثانية.
- إنشاء My Voice عبر AION Cloud من دون إدخال مفتاح مزود الصوت داخل APK.
- اعتماد قدرة مشفر لا يكشف provider voice ID.
- تخزين الاعتماد محليًا عبر Android Keystore.
- ربط الاعتماد بعنوان AION Cloud الذي أنشأه وعدم نقله ضمنيًا بين الخوادم.
- استخدام My Voice في Preview وRead Aloud وAION Live عند توفر الاعتماد الصحيح.
- حذف remote-first؛ لا يمسح الاعتماد المحلي إن فشل حذف النسخة السحابية.
- حذف ملف العينة المحلي تلقائيًا بعد نجاح الإنشاء والحفظ الآمن.

## خارج النطاق
- Playback Arbiter / Audio arbitration / polish الخاص بـStep 5.4 غير مضاف.

## فحوص محلية
- Worker syntax: PASS
- Worker regression + My Voice tests: PASS
- MyVoicePolicy JVM smoke: PASS
- XML parse: PASS
- Kotlin bracket smoke: PASS
- Duplicate import scan: PASS
- Step 5.4 leakage scan: PASS

الإغلاق الرسمي يبقى مشروطًا بـGitHub Actions:
Unit + Lint + assembleDebug + apksigner + artifact upload.
