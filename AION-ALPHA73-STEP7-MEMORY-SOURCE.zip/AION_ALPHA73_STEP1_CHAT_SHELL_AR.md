# AION α7.3 — الخطوة 1: Chat Shell

الحالة: مكتملة محليًا — بانتظار البناء الكامل على GitHub في بوابة الإصدار.

## ما تم
- تثبيت Top Bar بثلاثة عناصر أساسية: القائمة / AION والوضع / محادثة جديدة.
- تثبيت AION Obsidian وDesign Tokens لمسافات Chat Shell بدل القيم المتفرقة.
- رسالة المستخدم بحد عرض 78% ورد AION بلا Bubble عادية.
- Activity Indicator دلالي: التفكير/قراءة المرفقات/بحث الويب/المقارنة/صياغة الإجابة.
- Composer ديناميكي: Live+Dictation عند الفراغ، Send عند وجود نص/مرفق، Stop أثناء التوليد.
- فصل الإملاء عن AION Live: الإملاء يملأ Draft ولا يرسل تلقائيًا.
- Cursor بنفسجي واضح على الخلفية الداكنة.
- إخفاء تنبيه الدقة أثناء تركيز حقل الكتابة لتقليل الضوضاء فوق لوحة المفاتيح.
- تحسين Chips بحيث تستخدم ألوان نص ذات Contrast أعلى.
- إصلاح Auto-follow: إضافة Bottom Anchor حقيقي حتى يتبع نهاية الرد الطويل لا بداية آخر رسالة.
- عند صعود المستخدم للقراءة يتوقف التتبع القسري ويظهر زر عودة مع صياغة عربية أفضل لعدد الرسائل الجديدة.
- تثبيت max readable width = 760dp لعدم تمديد النص على الشاشات الكبيرة.
- إصلاح أخطاء source-level اكتشفها فحص Kotlin: بارامترات Chat screen للصوت، ونداءات SmallAction.

## قواعد لم تُكسر
- لا Chain-of-Thought.
- لا Spinner عام لكل العمليات.
- لا Voice في Top Bar.
- لا إرسال تلقائي من Dictation.
- لا سحب قسري للمستخدم أثناء قراءته أعلى المحادثة.

## تحقق محلي
- Kotlin parser/type-shape smoke: لا توجد أخطاء بنيوية ظاهرة بعد إضافة ملفات النماذج المطلوبة للفحص؛ unresolved Android/Compose متوقع لغياب Android classpath محليًا.
- Design contrast check: TextPrimary/TextSecondary/TextTertiary أعلى من AA على Obsidian/Raised؛ تم استخدام IntelligenceSoft/ExternalSoft في نصوص Chips بدل درجات Accent الأضعف.
- الخطوة التالية: Drawer + Search + Projects.
