# AION α7.3 — Step 7.3 + 7.4
## Context Engine v1 + Memory Retrieval Intelligence v1

الإصدار المحلي: `2.0.0-alpha7.3-dev19 / versionCode 33`.

## Step 7.3 — Context Engine v1
- نافذة السياق لم تعد تعتمد على عدد الرسائل فقط؛ يوجد budget بالحروف + تقدير tokens محافظ خصوصًا للعربية.
- يبقى أحدث الحوار verbatim، مع Opening Anchor صغير من بداية المهمة.
- إذا حُذف جزء من الوسط، يبني AION **extractive digest** من مقتطفات حرفية مختارة، لا summary مولدًا من نموذج؛ لذلك لا يختلق حقائق جديدة أثناء الضغط.
- سياق محادثات المشروع الأخرى منفصل عن Memory طويلة المدى ويُوسم بوضوح كسياق حديث فقط.
- المرفقات لا يعاد إرسالها من التاريخ كله؛ مرفقات آخر رسالة مستخدم فقط تظل payload فعلية كما في Step 6.
- Context Engine provider-neutral ولا يغير عقود Claude/Gemini/Grok.

## Step 7.4 — Memory Retrieval Intelligence v1
- Memory Engine v1 أصبح query-aware: آخر طلب مستخدم هو query الاسترجاع.
- hard scope isolation قبل scoring: USER / PROJECT / CONVERSATION، مع احترام `projectOnlyMemory`.
- ranking هجين محلي: lexical overlap + light Arabic normalization + slot tokens + kind/source/confidence + recency.
- Decision/Instruction تبقى ذات أولوية أعلى، لكن الذاكرة العامة غير المرتبطة لا تُرسل تلقائيًا لمجرد الحداثة.
- الاسترجاع لا يستخدم embeddings أو خدمة خارجية في v1؛ لا API جديد ولا تكلفة إضافية.
- لا auto-save لكل رسالة في هذه الدفعة؛ الكتابة التلقائية ستبقى مؤجلة حتى Memory Controls/Privacy.

## Security / privacy
- النص المسترجع والسياق الإضافي لا يدخلان orchestration trace.
- Worker يعرض فقط metadata آمنة: policies وattached booleans.
- Context digest وMemory يعاملان كبيانات أقل سلطة من طلب المستخدم الحالي ومن system rules.

## Contracts
- Context Engine contract = 1 / `budgeted-extractive-v1`.
- Memory Retrieval contract = 1 / `hybrid-lexical-scoped-v1`.
- Orchestrator memory policy عند وجود ذاكرة = `memory-v1-retrieved-scoped`.
- Worker version = `7.3.0-dev19`.
