# AION α7.3 — Step 5.4 Voice Playback Arbitration

الحالة: LOCAL READY / OFFICIAL GATE PENDING

الإصدار: `2.0.0-alpha7.3-dev9`
versionCode: 23

## منفذ محليًا
- Process-wide single voice owner بين Read Aloud / Preview / Live.
- Lease tokens ضد stale callback/release.
- Live self-transcription guard أثناء صوت Preview/Read Aloud.
- NeuralVoicePlayer generation/resource ownership + fail-fast + 4096-byte PCM reads.
- Audio Focus لـRead Aloud/Preview مع cleanup.
- Neural -> local remainder handoff بدون تكرار الجزء المنطوق.
- Tokenized Android TTS utterance IDs في Live وRead Aloud.
- فحص queue failures وتنظيف الحالات العالقة.
- لا تغيير في My Voice/Cloud Worker/AionLiveAudioSession/Conversation binding.

## فحوص محلية
- Worker syntax: PASS
- Worker regression: PASS
- XML parse: PASS
- Duplicate imports: PASS
- Kotlin targeted syntax scan: PASS (لا expecting/unexpected/redeclaration).
- Playback Arbiter + fallback JVM smoke: PASS
- Step 5.1–5.3 sensitive-file regression comparison: PASS

الإغلاق الرسمي يبقى مشروطًا بـGitHub Actions:
Unit + Lint + assembleDebug + apksigner + artifact upload.
