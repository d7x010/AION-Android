# AION α7.3 — Step 7.7 + 7.8

## Version
`2.0.0-alpha7.3-dev22 / versionCode 36`

## 7.7 — Search Intelligence + Deterministic Calculator
- Search decision expands beyond explicit search to typed freshness/current-entity/time-sensitive signals.
- Firecrawl results are bounded, HTTP(S)-only, canonically deduplicated, and keep `publishedAt` when available.
- Search query strips an independent calculator clause when a request asks for search and arithmetic together.
- Calculator is implemented twice under the same behavioral contract: Android deterministic parser + Worker deterministic parser.
- No LLM/eval/network is used for arithmetic. Arabic/Persian digits and × ÷ − are normalized.
- Supported v1 grammar: numbers, parentheses, + - * / % ^, pi, e. Divide-by-zero/invalid tokens fail closed.

## 7.8 — Bounded Multi-Step Tool Loop
- Contract: `bounded-multi-step-tool-loop-v1`, max 4 steps.
- Active tool IDs in dev22: `web.search`, `calculator`.
- A request may plan one or both tools; route becomes `multi-step` when more than one tool is required.
- Explicit intent order is preserved when both are requested.
- Each step reports route/status/failureCode; aggregate status is succeeded/partial/failed.
- Calculator output is injected as trusted tool data before inference. Search sources remain citations/context.
- Sync and Streaming use the same plan and execution path; Streaming emits a `tool` SSE event.

## Boundaries
- No File Tool changes in this batch.
- No Code Sandbox in this batch.
- No Response Intelligence/token/temperature policy changes in this batch.
- This is not an autonomous recursive Agent loop; dependent planning across unknown future tool outputs remains a later phase.

## Safety / regression
- Provider routing and pinned external-provider rules from Step 6 remain unchanged.
- Memory/Context/Privacy contracts from 7.1–7.6 remain unchanged.
- Voice / My Voice / AION Live are unchanged.
