# AION α7.2 — قائمة اعتماد الإصدار

## الحالة قبل GitHub
- الإصدار: `2.0.0-alpha7.2` / versionCode 13.
- Worker syntax: PASS.
- Worker regression tests: PASS.
- XML parsing: PASS.
- Kotlin core smoke: PASS.
- فحص أسرار نصي: PASS.

## بوابة GitHub المطلوبة
- `:app:testDebugUnitTest`
- `:app:lintDebug`
- `:app:assembleDebug`
- Upload APK Artifact
- Deploy `aion-core`

لا يعتمد APK إذا فشل أي بند أعلاه.

## Smoke test على الهاتف بعد البناء
1. محادثة نصية قصيرة وطويلة + Stop/Retry.
2. بحث ويب وإظهار المصادر.
3. إرسال صورة وسؤال بصري.
4. إرسال PDF/ملف نصي.
5. إنشاء Project، حفظ ذكرى داخله، والتأكد من العزل.
6. البحث عن كلمة قديمة داخل محادثة طويلة.
7. مكالمة صوتية 10 أدوار، مع مقاطعة AION أثناء الكلام.
8. إغلاق التطبيق أثناء Streaming ثم العودة والتحقق من استمرار/استعادة الحالة.
