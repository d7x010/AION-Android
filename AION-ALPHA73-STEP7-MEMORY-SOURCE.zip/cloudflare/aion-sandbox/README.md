# AION Safe Code Sandbox v1

Backend اختياري لـ `code.execute` في AION. يستخدم Cloudflare Sandbox SDK/Containers، وليس Android أو AION Core لتنفيذ كود غير موثوق.

## عقد الأمان

- `POST /v1/execute` فقط، بعقد JSON رقم 1 وBearer token مستقل (`AION_SANDBOX_TOKEN`).
- Python وJavaScript فقط في v1.
- كود المستخدم يُكتب إلى ملف ثابت داخل `/workspace` ثم يُشغّل بأمر ثابت؛ لا يتم إدخال نص المستخدم داخل command string.
- `AionSandbox.enableInternet = false`: الإنترنت العام داخل الحاوية مغلق افتراضيًا، ولا توجد allowlist.
- sandbox ID جديد لكل تنفيذ، ثم `destroy()` في `finally` لمسح الملفات/العمليات وتحرير الموارد.
- حد الكود 20,000 حرف، المخرجات 20,000 حرف لكل stream، والمهلة حتى 12 ثانية.
- لا تضع token في المصدر. بعد النشر استخدم `npx wrangler secret put AION_SANDBOX_TOKEN`.

## الربط مع AION Core

بعد نشر هذه الخدمة:

1. اضبط `AION_CODE_SANDBOX_URL=https://<sandbox-worker>/v1/execute` في AION Core.
2. اضبط `AION_CODE_SANDBOX_TOKEN` في AION Core بنفس قيمة `AION_SANDBOX_TOKEN` في هذه الخدمة.
3. إذا لم يتم ضبطهما، AION Core يبقى fail-closed ويعيد `unavailable` ولا يدعي تنفيذ الكود.

## التحقق والنشر

```bash
npm install
npm run check
npx wrangler secret put AION_SANDBOX_TOKEN
npm run deploy
```

يتطلب Cloudflare Sandbox/Containers خطة Workers Paid. وجود المصدر داخل AION لا يعني أن التنفيذ الحي مفعل تلقائيًا.
