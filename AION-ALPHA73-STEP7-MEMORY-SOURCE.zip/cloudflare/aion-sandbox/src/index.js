import { Sandbox, ContainerProxy, getSandbox } from "@cloudflare/sandbox";
import {
  CONTRACT,
  MAX_REQUEST_BYTES,
  bearerToken,
  fixedProgram,
  safeOutput,
  validateExecutionPayload,
} from "./policy.js";

export { ContainerProxy };

// Untrusted code runs in a dedicated Cloudflare Container VM with public internet disabled.
// No allowedHosts are configured, so enableInternet=false is deny-by-default.
export class AionSandbox extends Sandbox {
  enableInternet = false;
}

function json(body, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: {
      "content-type": "application/json; charset=utf-8",
      "cache-control": "no-store",
      "x-content-type-options": "nosniff",
    },
  });
}

async function sameSecret(left, right) {
  const a = new TextEncoder().encode(String(left || ""));
  const b = new TextEncoder().encode(String(right || ""));
  const [ha, hb] = await Promise.all([crypto.subtle.digest("SHA-256", a), crypto.subtle.digest("SHA-256", b)]);
  const aa = new Uint8Array(ha);
  const bb = new Uint8Array(hb);
  let diff = aa.length ^ bb.length;
  for (let i = 0; i < Math.max(aa.length, bb.length); i += 1) diff |= (aa[i % aa.length] || 0) ^ (bb[i % bb.length] || 0);
  return diff === 0 && a.length > 0 && b.length > 0;
}

async function authorized(request, env) {
  const configured = String(env?.AION_SANDBOX_TOKEN || "").trim();
  if (!configured) return false;
  return sameSecret(bearerToken(request), configured);
}

async function execute(request, env) {
  if (!(await authorized(request, env))) return json({ ok: false, failureCode: "unauthorized" }, 401);
  const declaredLength = Number(request.headers.get("content-length") || 0);
  if (declaredLength > MAX_REQUEST_BYTES) return json({ ok: false, failureCode: "payload-too-large" }, 413);

  let raw;
  try {
    raw = await request.text();
  } catch (_) {
    return json({ ok: false, failureCode: "invalid-input" }, 400);
  }
  if (raw.length > MAX_REQUEST_BYTES) return json({ ok: false, failureCode: "payload-too-large" }, 413);

  let payload;
  try {
    payload = JSON.parse(raw || "{}");
  } catch (_) {
    return json({ ok: false, failureCode: "invalid-json" }, 400);
  }
  const validated = validateExecutionPayload(payload);
  if (!validated.ok) return json(validated, 400);
  const program = fixedProgram(validated.language);
  if (!program) return json({ ok: false, failureCode: "unsupported-language" }, 400);

  const sandboxId = `aion-exec-${crypto.randomUUID()}`;
  const sandbox = getSandbox(env.Sandbox, sandboxId, {
    enableDefaultSession: false,
    sleepAfter: "1m",
  });

  try {
    await sandbox.writeFile(program.path, validated.code);
    const result = await sandbox.exec(program.command, {
      cwd: "/workspace",
      timeout: validated.timeoutMs,
    });
    return json({
      ok: Boolean(result?.success),
      failureCode: result?.success ? "" : "execution-error",
      stdout: safeOutput(result?.stdout),
      stderr: safeOutput(result?.stderr),
      exitCode: Number.isInteger(result?.exitCode) ? result.exitCode : 1,
      network: false,
      isolation: "cloudflare-container-vm",
    }, result?.success ? 200 : 422);
  } catch (error) {
    const timeout = /timeout/i.test(String(error?.name || "")) || /timeout/i.test(String(error?.message || ""));
    return json({
      ok: false,
      failureCode: timeout ? "timeout" : "execution-error",
      stdout: "",
      stderr: "",
      exitCode: 1,
      network: false,
      isolation: "cloudflare-container-vm",
    }, timeout ? 408 : 500);
  } finally {
    try { await sandbox.destroy(); } catch (_) { /* best-effort cleanup; never expose infrastructure details */ }
  }
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (request.method === "GET" && url.pathname === "/health") {
      return json({
        ok: true,
        service: "aion-safe-sandbox",
        contract: CONTRACT,
        languages: ["python", "javascript"],
        network: false,
        isolation: "cloudflare-container-vm",
        configured: Boolean(String(env?.AION_SANDBOX_TOKEN || "").trim()),
      });
    }
    if (request.method === "POST" && url.pathname === "/v1/execute") return execute(request, env);
    return json({ ok: false, failureCode: "not-found" }, 404);
  },
};
