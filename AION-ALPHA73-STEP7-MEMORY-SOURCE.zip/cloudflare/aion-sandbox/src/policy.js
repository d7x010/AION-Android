export const CONTRACT = 1;
export const MAX_CODE_CHARS = 20_000;
export const MAX_OUTPUT_CHARS = 20_000;
export const MAX_REQUEST_BYTES = 48_000;
export const MIN_TIMEOUT_MS = 500;
export const MAX_TIMEOUT_MS = 12_000;

const LANGUAGE_ALIASES = new Map([
  ["py", "python"],
  ["python", "python"],
  ["js", "javascript"],
  ["javascript", "javascript"],
]);

export function normalizeLanguage(value) {
  return LANGUAGE_ALIASES.get(String(value || "").trim().toLowerCase()) || "";
}

export function clampTimeout(value) {
  const parsed = Number(value);
  if (!Number.isFinite(parsed)) return MAX_TIMEOUT_MS;
  return Math.max(MIN_TIMEOUT_MS, Math.min(MAX_TIMEOUT_MS, Math.trunc(parsed)));
}

export function validateExecutionPayload(payload) {
  if (!payload || typeof payload !== "object") return { ok: false, failureCode: "invalid-input" };
  if (payload.contract !== CONTRACT) return { ok: false, failureCode: "unsupported-contract" };
  if (payload.network !== false) return { ok: false, failureCode: "network-policy-rejected" };
  const language = normalizeLanguage(payload.language);
  if (!language) return { ok: false, failureCode: "unsupported-language" };
  const code = String(payload.code || "").replace(/\u0000/g, "");
  if (!code.trim() || code.length > MAX_CODE_CHARS) return { ok: false, failureCode: "invalid-code" };
  return { ok: true, language, code, timeoutMs: clampTimeout(payload.timeoutMs) };
}

export function fixedProgram(language) {
  if (language === "python") return { path: "/workspace/aion-main.py", command: "python3 /workspace/aion-main.py" };
  if (language === "javascript") return { path: "/workspace/aion-main.js", command: "node /workspace/aion-main.js" };
  return null;
}

export function bearerToken(request) {
  const header = String(request?.headers?.get?.("authorization") || "");
  return header.startsWith("Bearer ") ? header.slice(7).trim() : "";
}

export function safeOutput(value) {
  return String(value || "").replace(/\u0000/g, "").slice(0, MAX_OUTPUT_CHARS);
}
