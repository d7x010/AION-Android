import assert from "node:assert/strict";
import {
  CONTRACT,
  MAX_CODE_CHARS,
  clampTimeout,
  fixedProgram,
  normalizeLanguage,
  validateExecutionPayload,
} from "./src/policy.js";

assert.equal(CONTRACT, 1);
assert.equal(normalizeLanguage("py"), "python");
assert.equal(normalizeLanguage("JavaScript"), "javascript");
assert.equal(normalizeLanguage("bash"), "");
assert.equal(normalizeLanguage("kotlin"), "");
assert.equal(clampTimeout(1), 500);
assert.equal(clampTimeout(99_999), 12_000);
assert.deepEqual(fixedProgram("python"), { path: "/workspace/aion-main.py", command: "python3 /workspace/aion-main.py" });
assert.deepEqual(fixedProgram("javascript"), { path: "/workspace/aion-main.js", command: "node /workspace/aion-main.js" });
assert.equal(fixedProgram("bash"), null);
assert.equal(validateExecutionPayload({ contract: 1, language: "python", code: "print(1)", timeoutMs: 1000, network: false }).ok, true);
assert.equal(validateExecutionPayload({ contract: 1, language: "python", code: "print(1)", network: true }).failureCode, "network-policy-rejected");
assert.equal(validateExecutionPayload({ contract: 1, language: "bash", code: "echo x", network: false }).failureCode, "unsupported-language");
assert.equal(validateExecutionPayload({ contract: 1, language: "python", code: "x".repeat(MAX_CODE_CHARS + 1), network: false }).failureCode, "invalid-code");
console.log("AION safe sandbox policy tests: PASS");
