# AION α7.3 Obsidian Core

Cloudflare Worker لـAION. مفاتيح المزودات تبقى في الخادم ولا تدخل APK.

## المسارات

- `GET /health` فحص عام وقدرات الخادم.
- `GET /v1/status` حالة النسخة والنماذج والصوت.
- `POST /v1/chat` محادثة متزامنة.
- `POST /v1/chat/stream` بث SSE حقيقي للمحادثة.
- `POST /v1/voice/tts` بث PCM 24 kHz للصوت العصبي عند تفعيله.
- `POST /v1/voice/my-voice` إنشاء My Voice من عينة المستخدم بعد موافقته الصريحة.
- `DELETE /v1/voice/my-voice` حذف My Voice باستخدام اعتماد مشفّر خاص بالجهاز.

## Neural Voice (اختياري)

AION يعمل دائمًا مع Android TTS كمسار احتياطي. لتفعيل الصوت العصبي على الخادم:

- Secret: `ELEVENLABS_API_KEY`
- للتوافق الخلفي: `AION_VOICE_ID` لصوت واحد.
- للأصوات المتعددة: `AION_VOICES_JSON` حتى 12 صوتًا، مثل:

```json
[
  {"key":"male_1","label":"AION Male","gender":"male","voiceId":"<provider-voice-id>"},
  {"key":"female_1","label":"AION Female","gender":"female","voiceId":"<provider-voice-id>"}
]
```

- Optional var: `AION_DEFAULT_VOICE_KEY` لاختيار الصوت الافتراضي من الـCatalog.
- Optional var: `ELEVENLABS_MODEL_ID` (الافتراضي `eleven_flash_v2_5`).

`/v1/status` يعرض للتطبيق فقط `key / label / gender / defaultVoice` ولا يعرض `voiceId` أو مفاتيح المزود. `/v1/voice/tts` يقبل `voice` و`profile` وضبطًا اختياريًا `speed / expression / clarity` وتُقيد القيم على الخادم. عند غياب الصوت العصبي أو حدوث فشل مؤقت يعود Android إلى TTS المحلي.


## My Voice (اختياري — Alpha Owner Gate)

My Voice مخصص لصوت صاحب التطبيق/الحساب نفسه فقط، وليس لاستنساخ أصوات أشخاص آخرين.

الإعداد الخادمي:
- `ELEVENLABS_API_KEY` يبقى Secret على Cloudflare.
- `AION_MY_VOICE_ENROLLMENT_SECRET`: رمز مالك لا يقل عن 16 محرفًا، يُدخل عند إنشاء الصوت ولا يُحفظ داخل Android.
- `AION_MY_VOICE_TOKEN_SECRET`: Secret ثابت لا يقل عن 32 محرفًا لتشفير capability token. إذا لم يوجد، يمكن استخدام Enrollment Secret نفسه فقط عندما يكون 32 محرفًا أو أكثر.

قواعد المسار:
- لا تُقبل العينة دون `consent=self`.
- الخادم يعيد فحص WAV: PCM 16-bit، Mono، 16 kHz، ومدتها 15–90 ثانية، بحد 3.6 MB.
- Voice ID الخاص بالمزود لا يُعاد إلى Android. يوضع داخل capability token مشفر AES-GCM.
- Android يشفر capability token مرة ثانية في التخزين باستخدام Android Keystore.
- بعد نجاح الإنشاء يحذف التطبيق العينة المحلية.
- الحذف يتم من المزود أولًا؛ إذا فشل الحذف لا يمسح التطبيق الاعتماد المحلي حتى يمكن إعادة المحاولة.

بوابة `AION_MY_VOICE_ENROLLMENT_SECRET` الحالية مناسبة لاختبار المالك في Alpha فقط. قبل طرح My Voice لمستخدمين متعددين يجب استبدالها بمصادقة حساب/جلسة وصلاحية خادمية لكل مستخدم.

## الحماية الحالية

يطبّق Worker حدًا أوليًا للطلبات لكل IP داخل النسخة التجريبية. قبل النشر العام نحتاج مصادقة مستخدم، Rate Limiting دائم، وحصص مستقلة لمسار الصوت لأنه مدفوع لكل حرف.

## Multi‑Provider Foundation — Step 6.1
`/v1/status` يعرض `models.contract=2` مع provider/model catalog آمن.

إعدادات الخادم الاختيارية:
- `ANTHROPIC_API_KEY` + `AION_CLAUDE_MODEL`
- `GEMINI_API_KEY` + `AION_GEMINI_MODEL`
- `XAI_API_KEY` + `AION_GROK_MODEL`

في Step 6.5:
- Anthropic جاهز عبر `https://api.anthropic.com/v1/messages` عند وجود مفتاحه وmodel id.
- Gemini جاهز عبر Google Generate Content عند وجود مفتاحه وmodel id.
- xAI/Grok جاهز عبر `https://api.x.ai/v1/responses` عند وجود `XAI_API_KEY` + `AION_GROK_MODEL`.
- طلبات Grok تضبط `store=false` ولا تعيد مفتاح xAI في أي response.
- بحث الويب للمزودات الخارجية الثلاثة يحتاج `FIRECRAWL_API_KEY` في هذه المرحلة؛ لا يُحوّل الطلب خفية إلى Workers AI Web Search.



### Routing contract — Step 6.5
- external selections (`claude|gemini|grok`) are pinned and never cross-fallback.
- AION built-ins may fallback only among Workers AI models before the first emitted token.
- sync responses and stream `done` events return safe routing metadata; no provider secret is included.
