# AION α7.3 — Step 7.5 + 7.6 Memory Privacy + Universal Tool Router

## الإصدار
`2.0.0-alpha7.3-dev21 / versionCode 35`

## Step 7.5 — Memory Controls & Privacy
- إعدادات ذاكرة محلية صريحة ومملوكة للمستخدم.
- مفتاح عام لتعطيل قراءة الذاكرة وحفظ الذكريات الجديدة من واجهة AION.
- تحكم مستقل في scopes: USER / PROJECT / CONVERSATION.
- وضع «محادثة مؤقتة» لكل Conversation ID: يمنع memory retrieval والحفظ الصريح لهذه المحادثة، ولا يرسل حالة الخصوصية كنص للنموذج.
- الحفظ التلقائي للذاكرة يبقى OFF في هذه المرحلة ولا يُفعل ضمنيًا.
- scope المعطل لا يُستخدم للقراءة ولا كوجهة لزر «تذكّر».
- تعطيل الذاكرة لا يحذف البيانات المخزنة؛ الحذف يبقى فعلًا منفصلًا حتى لا نفقد بيانات المستخدم بصمت.
- المشروع في المحادثة المؤقتة لا يضيف related-project conversation context إلى الطلب.

## Step 7.6 — Universal Tool Router v1
- عقد موحد versioned للأدوات بدل المسارات الخاصة بكل ميزة.
- Tool IDs ثابتة وآمنة، أولها `web.search`.
- كل أداة تصف permissions وavailability وtimeout.
- التخطيط يفشل typed عند invalid input / unknown tool / disabled / permission denied.
- AION Cloud يوجّه البحث الحالي عبر `universal-tool-router-v1` بدل `legacy-web-search`.
- Search execution على الخادم يخرج Tool Execution metadata آمنة: route/status/failureCode.
- Firecrawl failure أو عدم تهيئته لا يتحول إلى أداة أخرى بصمت؛ Workers AI native web search يبقى fallback معروفًا فقط للمسار المدمج وفق سياسة Step 6.
- Claude/Gemini/Grok لا تعبر إلى Workers AI عند فشل بحثها؛ pinned-provider invariant لم يتغير.

## ما ليس ضمن هذه الدفعة
- Calculator الفعلي يبدأ في 7.7.
- generic multi-step tool loop يبدأ في 7.8.
- Files/Code Sandbox في 7.9.
- لا auto-memory extraction في 7.5.

## معايير الإغلاق
- Worker regression + Tool Router tests PASS.
- Android Unit + Lint + assembleDebug PASS في GitHub Gate.
- Memory privacy pure-policy tests PASS.
- No Voice/My Voice/AION Live changes.
