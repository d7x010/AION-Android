package com.aion.mobile.core.ai

import com.aion.mobile.model.ChatMessage
import com.aion.mobile.model.ChatSource
import com.aion.mobile.model.MessageRole
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

class AionCloudException(val statusCode: Int, message: String) : Exception(message)

data class AionCloudVoiceOption(
    val key: String,
    val label: String,
    val gender: String = "neutral"
)


data class AionCloudModelOption(
    val key: String,
    val label: String,
    val provider: String,
    val modelId: String = "",
    val badge: String = "",
    val configured: Boolean = false,
    val chatReady: Boolean = false
)

data class AionCloudProviderStatus(
    val key: String,
    val label: String,
    val configured: Boolean,
    val chatReady: Boolean
)

data class AionCloudHealth(
    val ok: Boolean,
    val version: String,
    val service: String,
    val neuralVoiceAvailable: Boolean = false,
    val neuralVoiceProvider: String = "",
    val neuralVoiceSampleRate: Int = 24_000,
    val defaultVoiceKey: String = "",
    val voices: List<AionCloudVoiceOption> = emptyList(),
    val myVoiceAvailable: Boolean = false,
    val myVoiceProvider: String = "",
    val myVoiceMaxSampleBytes: Long = 3_600_000L,
    val externalModels: List<AionCloudModelOption> = emptyList(),
    val providers: List<AionCloudProviderStatus> = emptyList()
)

/**
 * عميل AION Cloud. يدعم Streaming حقيقي وحالات تشغيل ومصادر بحث.
 * لا يحتوي APK على أي مفتاح مزود.
 */
class AionCloudGateway {
    suspend fun checkStatus(endpoint: String): AionCloudHealth = withContext(Dispatchers.IO) {
        val cleanEndpoint = endpoint.trim().trimEnd('/')
        if (!cleanEndpoint.startsWith("https://")) {
            throw AionCloudException(400, "يجب أن يبدأ عنوان AION Cloud بـ https://")
        }
        val connection = (URL("$cleanEndpoint/v1/status").openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 10_000
            readTimeout = 12_000
            useCaches = false
            setRequestProperty("Accept", "application/json")
            setRequestProperty("X-Aion-Client", "AION-Android/alpha7.3")
        }
        try {
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val raw = stream?.let {
                BufferedReader(InputStreamReader(it, Charsets.UTF_8)).use { reader -> reader.readText() }
            }.orEmpty()
            val body = runCatching { JSONObject(raw) }.getOrNull()
            if (code !in 200..299) {
                throw AionCloudException(code, body?.optString("error").orEmpty().ifBlank { "فشل فحص AION Cloud." })
            }
            val voice = body?.optJSONObject("voice")
            val voices = buildList {
                val array = voice?.optJSONArray("voices") ?: JSONArray()
                for (i in 0 until array.length()) {
                    val item = array.optJSONObject(i) ?: continue
                    val key = item.optString("key").trim()
                    if (key.isBlank()) continue
                    add(
                        AionCloudVoiceOption(
                            key = key,
                            label = item.optString("label").trim().ifBlank { key },
                            gender = item.optString("gender").trim().ifBlank { "neutral" }
                        )
                    )
                }
            }
            val myVoice = voice?.optJSONObject("myVoice")
            val modelsNode = body?.optJSONObject("models")
            val externalModels = buildList {
                val array = modelsNode?.optJSONArray("external") ?: JSONArray()
                for (i in 0 until array.length()) {
                    val item = array.optJSONObject(i) ?: continue
                    val key = ModelCatalogPolicy.normalizeKey(item.optString("key"))
                    if (!ModelCatalogPolicy.isSafeExternalKey(key)) continue
                    val modelId = ModelCatalogPolicy.normalizeModelId(item.optString("modelId"))
                    val chatReady = item.optBoolean("chatReady", false)
                    add(
                        AionCloudModelOption(
                            key = key,
                            label = ModelCatalogPolicy.normalizeLabel(item.optString("label"), key),
                            provider = ModelCatalogPolicy.normalizeProvider(item.optString("provider")),
                            modelId = modelId,
                            badge = ModelCatalogPolicy.normalizeLabel(
                                item.optString("badge"),
                                if (chatReady) "جاهز" else if (item.optBoolean("configured", false)) "Foundation" else "غير مهيأ"
                            ),
                            configured = item.optBoolean("configured", false),
                            chatReady = chatReady
                        )
                    )
                }
            }
            val providerStatuses = buildList {
                val array = modelsNode?.optJSONArray("providers") ?: JSONArray()
                for (i in 0 until array.length()) {
                    val item = array.optJSONObject(i) ?: continue
                    val key = ModelCatalogPolicy.normalizeKey(item.optString("key"))
                    if (key.isBlank()) continue
                    add(
                        AionCloudProviderStatus(
                            key = key,
                            label = ModelCatalogPolicy.normalizeLabel(item.optString("label"), key),
                            configured = item.optBoolean("configured", false),
                            chatReady = item.optBoolean("chatReady", false)
                        )
                    )
                }
            }
            AionCloudHealth(
                ok = body?.optBoolean("ok", false) == true,
                version = body?.optString("version").orEmpty().ifBlank { "غير معروف" },
                service = body?.optString("service").orEmpty().ifBlank { "AION Cloud" },
                neuralVoiceAvailable = voice?.optBoolean("neural", false) == true,
                neuralVoiceProvider = voice?.optString("provider").orEmpty(),
                neuralVoiceSampleRate = voice?.optInt("sampleRate", 24_000)?.coerceIn(8_000, 48_000) ?: 24_000,
                defaultVoiceKey = voice?.optString("defaultVoice").orEmpty(),
                voices = voices,
                myVoiceAvailable = myVoice?.optBoolean("available", false) == true,
                myVoiceProvider = myVoice?.optString("provider").orEmpty(),
                myVoiceMaxSampleBytes = myVoice?.optLong("maxSampleBytes", 3_600_000L)?.coerceIn(256_000L, 8_000_000L) ?: 3_600_000L,
                externalModels = externalModels,
                providers = providerStatuses
            )
        } finally {
            connection.disconnect()
        }
    }

    suspend fun streamComplete(
        endpoint: String,
        mode: String,
        messages: List<ChatMessage>,
        forceWebSearch: Boolean,
        sessionId: String = "",
        customInstructions: String = "",
        memoryContext: String = "",
        onDelta: suspend (String) -> Unit,
        onActivity: suspend (GatewayActivity) -> Unit
    ): GatewayResult = withContext(Dispatchers.IO) {
        if (endpoint.isBlank()) throw AionCloudException(400, "لم يتم ربط AION Cloud بعد.")

        val connection = openConnection("${endpoint.trimEnd('/')}/v1/chat/stream")
        val body = buildPayload(mode, messages, forceWebSearch, sessionId, customInstructions, memoryContext)
        val bodyBytes = body.toString().toByteArray(Charsets.UTF_8)
        connection.setFixedLengthStreamingMode(bodyBytes.size)
        val sources = linkedMapOf<String, ChatSource>()
        val text = StringBuilder()
        var eventName = "message"
        var dataLines = mutableListOf<String>()
        var receivedDelta = false
        var execution = GatewayExecution()

        val cancellationHandle = currentCoroutineContext()[Job]?.invokeOnCompletion { cause ->
            if (cause is CancellationException) connection.disconnect()
        }

        suspend fun processEvent() {
            if (dataLines.isEmpty()) return
            val raw = dataLines.joinToString("\n")
            dataLines = mutableListOf()
            if (raw == "[DONE]") return
            val json = runCatching { JSONObject(raw) }.getOrNull() ?: return
            when (eventName) {
                "activity" -> when (json.optString("activity")) {
                    "searching_web" -> onActivity(GatewayActivity.SEARCHING_WEB)
                    "reading_files" -> onActivity(GatewayActivity.READING_FILES)
                    "comparing" -> onActivity(GatewayActivity.COMPARING)
                    "writing" -> onActivity(GatewayActivity.WRITING)
                    else -> onActivity(GatewayActivity.THINKING)
                }
                "sources" -> {
                    val array = json.optJSONArray("sources") ?: JSONArray()
                    for (i in 0 until array.length()) {
                        val source = array.optJSONObject(i) ?: continue
                        val url = source.optString("url").trim()
                        if (url.isBlank()) continue
                        val title = source.optString("title").trim().ifBlank { url }
                        sources.putIfAbsent(
                            url,
                            ChatSource(
                                title = title,
                                url = url,
                                snippet = source.optString("snippet").trim().take(600)
                            )
                        )
                    }
                }

                "delta" -> {
                    val delta = json.optString("text")
                    if (delta.isNotEmpty()) {
                        currentCoroutineContext().ensureActive()
                        receivedDelta = true
                        text.append(delta)
                        onDelta(delta)
                    }
                }

                "done" -> {
                    execution = parseExecution(json.optJSONObject("routing"))
                }

                "error" -> {
                    val status = json.optInt("status", 500)
                    throw AionCloudException(status, json.optString("error").ifBlank { "تعذر تنفيذ الطلب." })
                }
            }
        }

        try {
            onActivity(if (forceWebSearch || mode == "research") GatewayActivity.SEARCHING_WEB else GatewayActivity.THINKING)
            connection.outputStream.use { it.write(bodyBytes) }
            val code = connection.responseCode
            if (code !in 200..299) {
                val raw = connection.errorStream?.let {
                    BufferedReader(InputStreamReader(it, Charsets.UTF_8)).use { reader -> reader.readText() }
                }.orEmpty()
                val error = runCatching { JSONObject(raw).optString("error") }.getOrNull().orEmpty()
                throw AionCloudException(code, error.ifBlank { "تعذر الاتصال بـ AION Cloud." })
            }

            BufferedReader(InputStreamReader(connection.inputStream, Charsets.UTF_8)).use { reader ->
                while (true) {
                    currentCoroutineContext().ensureActive()
                    val line = reader.readLine() ?: break
                    when {
                        line.startsWith("event:") -> eventName = line.substringAfter("event:").trim()
                        line.startsWith("data:") -> dataLines += line.substringAfter("data:").trim()
                        line.isBlank() -> {
                            processEvent()
                            eventName = "message"
                        }
                    }
                }
            }
            processEvent()

            if (!receivedDelta || text.isBlank()) {
                return@withContext complete(
                    endpoint = endpoint,
                    mode = mode,
                    messages = messages,
                    forceWebSearch = forceWebSearch,
                    sessionId = sessionId,
                    customInstructions = customInstructions,
                    memoryContext = memoryContext,
                    onActivity = onActivity
                ).also { fallback ->
                    if (fallback.text.isNotBlank()) onDelta(fallback.text)
                }
            }

            GatewayResult(
                text = text.toString(),
                sources = sources.values.take(12),
                execution = execution
            )
        } catch (error: AionCloudException) {
            currentCoroutineContext().ensureActive()
            // أخطاء 429/5xx/timeout قبل وصول أول token تستحق إعادة المحاولة عبر المسار المتزامن.
            // بعد بدء النص لا نعيد الطلب من الصفر حتى لا نكرر أو نغيّر الإجابة على المستخدم.
            if (!receivedDelta && isRetryableStatus(error.statusCode)) {
                val fallback = complete(
                    endpoint = endpoint,
                    mode = mode,
                    messages = messages,
                    forceWebSearch = forceWebSearch,
                    sessionId = sessionId,
                    customInstructions = customInstructions,
                    memoryContext = memoryContext,
                    onActivity = onActivity
                )
                if (fallback.text.isNotBlank()) onDelta(fallback.text)
                fallback
            } else {
                throw error
            }
        } catch (error: IOException) {
            currentCoroutineContext().ensureActive()
            // بعض شبكات أندرويد/HTTP proxies تقطع SSE الطويلة. إذا حدث القطع،
            // نعيد نفس الطلب عبر مسار متزامن ذي retries بدل عرض Connection reset مباشرة.
            val fallback = complete(
                endpoint = endpoint,
                mode = mode,
                messages = messages,
                forceWebSearch = forceWebSearch,
                sessionId = sessionId,
                customInstructions = customInstructions,
                memoryContext = memoryContext,
                onActivity = onActivity
            )

            val partial = text.toString()
            if (partial.isBlank()) {
                if (fallback.text.isNotBlank()) onDelta(fallback.text)
                fallback
            } else if (fallback.text.startsWith(partial)) {
                val remainder = fallback.text.removePrefix(partial)
                if (remainder.isNotBlank()) onDelta(remainder)
                fallback
            } else {
                throw IOException("انقطع اتصال البث بعد بدء الرد. أعد المحاولة لإكمال الإجابة.", error)
            }
        } finally {
            cancellationHandle?.dispose()
            connection.disconnect()
        }
    }

    suspend fun complete(
        endpoint: String,
        mode: String,
        messages: List<ChatMessage>,
        forceWebSearch: Boolean,
        sessionId: String = "",
        customInstructions: String = "",
        memoryContext: String = "",
        onActivity: suspend (GatewayActivity) -> Unit
    ): GatewayResult = withContext(Dispatchers.IO) {
        if (endpoint.isBlank()) throw AionCloudException(400, "لم يتم ربط AION Cloud بعد.")

        val body = buildPayload(mode, messages, forceWebSearch, sessionId, customInstructions, memoryContext)
        val bodyBytes = body.toString().toByteArray(Charsets.UTF_8)
        var lastFailure: Throwable? = null

        repeat(MAX_SYNC_ATTEMPTS) { attempt ->
            currentCoroutineContext().ensureActive()
            val connection = openConnection("${endpoint.trimEnd('/')}/v1/chat", closeAfterResponse = true)
            connection.setFixedLengthStreamingMode(bodyBytes.size)
            try {
                onActivity(if (forceWebSearch || mode == "research") GatewayActivity.SEARCHING_WEB else GatewayActivity.THINKING)
                connection.outputStream.use { it.write(bodyBytes) }
                val code = connection.responseCode
                val stream = if (code in 200..299) connection.inputStream else connection.errorStream
                val raw = stream?.let {
                    BufferedReader(InputStreamReader(it, Charsets.UTF_8)).use { reader -> reader.readText() }
                }.orEmpty()
                val response = runCatching { JSONObject(raw) }.getOrNull()
                if (code !in 200..299) {
                    throw AionCloudException(
                        code,
                        response?.optString("error").orEmpty().ifBlank { "تعذر الاتصال بـ AION Cloud." }
                    )
                }
                val text = response?.optString("response").orEmpty().trim()
                if (text.isBlank()) throw AionCloudException(502, "أنهى الخادم الطلب من دون نص.")
                val sources = parseSources(response?.optJSONArray("sources"))
                val execution = parseExecution(response?.optJSONObject("routing"))
                onActivity(GatewayActivity.WRITING)
                return@withContext GatewayResult(text = text, sources = sources, execution = execution)
            } catch (error: AionCloudException) {
                lastFailure = error
                if (!isRetryableStatus(error.statusCode) || attempt == MAX_SYNC_ATTEMPTS - 1) throw error
            } catch (error: IOException) {
                currentCoroutineContext().ensureActive()
                lastFailure = error
                if (attempt == MAX_SYNC_ATTEMPTS - 1) throw error
            } finally {
                connection.disconnect()
            }

            // Backoff صغير؛ يحسن نجاح 429/5xx/انقطاعات الشبكة القصيرة من دون جعل الواجهة بطيئة.
            delay(RETRY_DELAYS_MS[attempt.coerceAtMost(RETRY_DELAYS_MS.lastIndex)])
        }

        throw lastFailure ?: IOException("تعذر إكمال الطلب بعد إعادة المحاولة.")
    }

    private fun openConnection(url: String, closeAfterResponse: Boolean = false): HttpURLConnection =
        (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 30_000
            readTimeout = 180_000
            doOutput = true
            useCaches = false
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            setRequestProperty("Accept", "application/json, text/event-stream")
            setRequestProperty("Accept-Encoding", "identity")
            setRequestProperty("X-Aion-Client", "AION-Android/alpha7.3")
            if (closeAfterResponse) setRequestProperty("Connection", "close")
            else setRequestProperty("Connection", "keep-alive")
        }

    private fun buildPayload(
        mode: String,
        messages: List<ChatMessage>,
        forceWebSearch: Boolean,
        sessionId: String,
        customInstructions: String,
        memoryContext: String
    ): JSONObject = JSONObject().apply {
            put("mode", mode.ifBlank { "auto" })
            put("forceWebSearch", forceWebSearch)
            put("client", "AION-Android/alpha7.3")
            if (sessionId.isNotBlank()) put("sessionId", sessionId.take(120))
            if (customInstructions.isNotBlank()) put("customInstructions", customInstructions.take(10_000))
            if (memoryContext.isNotBlank()) put("memoryContext", memoryContext.take(16_000))
            put("messages", JSONArray().apply {
                selectContextMessages(messages).forEach { message ->
                    val usableAttachments = if (message.role == MessageRole.USER) {
                        message.attachments.filter { it.base64Data.isNotBlank() }.take(4)
                    } else {
                        emptyList()
                    }
                    val content = message.text.take(MAX_MESSAGE_CHARS)
                    if (content.isNotBlank() || usableAttachments.isNotEmpty()) {
                        put(JSONObject().apply {
                            put("role", if (message.role == MessageRole.USER) "user" else "assistant")
                            put("content", content)
                            if (usableAttachments.isNotEmpty()) {
                                put("attachments", JSONArray().apply {
                                    usableAttachments.forEach { attachment ->
                                        put(JSONObject().apply {
                                            put("name", attachment.name)
                                            put("mimeType", attachment.mimeType)
                                            put("kind", attachment.kind.name)
                                            put("sizeBytes", attachment.sizeBytes)
                                            put("data", attachment.base64Data)
                                        })
                                    }
                                })
                            }
                        })
                    }
                }
            })
        }


    private fun selectContextMessages(messages: List<ChatMessage>): List<ChatMessage> =
        ContextWindow.select(
            messages = messages,
            maxMessages = MAX_CONTEXT_MESSAGES,
            maxChars = MAX_CONTEXT_CHARS,
            anchorMessages = CONTEXT_ANCHOR_MESSAGES,
            maxAnchorChars = MAX_ANCHOR_CHARS,
            maxMessageChars = MAX_MESSAGE_CHARS
        )

    private fun isRetryableStatus(statusCode: Int): Boolean =
        statusCode == 408 || statusCode == 425 || statusCode == 429 || statusCode in 500..599

    private companion object {
        const val MAX_SYNC_ATTEMPTS = 3
        const val MAX_CONTEXT_MESSAGES = 120
        const val MAX_CONTEXT_CHARS = 300_000
        const val MAX_MESSAGE_CHARS = 48_000
        const val CONTEXT_ANCHOR_MESSAGES = 4
        const val MAX_ANCHOR_CHARS = 48_000
        val RETRY_DELAYS_MS = longArrayOf(350L, 900L, 1_700L)
    }
    private fun parseExecution(node: JSONObject?): GatewayExecution {
        if (node == null) return GatewayExecution()
        return GatewayExecution(
            providerKey = ProviderRoutingPolicy.normalizeProviderKey(node.optString("providerKey")),
            providerLabel = ProviderRoutingPolicy.normalizeProviderLabel(node.optString("providerLabel")),
            modelId = ProviderRoutingPolicy.normalizeExecutionModelId(node.optString("modelId")),
            routingPolicy = ProviderRoutingPolicy.normalizePolicy(node.optString("policy")),
            fallbackUsed = node.optBoolean("fallbackUsed", false),
            attempts = node.optInt("attempts", 1).coerceIn(1, 8)
        )
    }

    private fun parseSources(array: JSONArray?): List<ChatSource> {
        if (array == null) return emptyList()
        val seen = linkedMapOf<String, ChatSource>()
        for (i in 0 until array.length()) {
            val item = array.optJSONObject(i) ?: continue
            val url = item.optString("url").trim()
            if (url.isBlank()) continue
            val title = item.optString("title").trim().ifBlank { url }
            seen.putIfAbsent(
                url,
                ChatSource(
                    title = title,
                    url = url,
                    snippet = item.optString("snippet").trim().take(600)
                )
            )
        }
        return seen.values.take(12)
    }
}
