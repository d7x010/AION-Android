# AION α7 — ملف انتقال مختصر

المرجع الحاكم لهذه الجولة هو مشروع Android في هذا الأرشيف مع Worker داخل `cloudflare/aion-core`.

## ما تغير جوهريًا
- Streaming حقيقي على Workers AI.
- مرفقات حقيقية وقراءة مستندات/صور.
- Multi-conversation + بحث محلي في السجل + مسودات مستقلة.
- ربط مهام الخلفية بمعرّف المحادثة.
- اختيار الوضع في Top Bar.
- Code blocks + copy.
- Voice RMS/TTS محسّن.
- ذاكرة محلية وتعليمات شخصية صريحة.
- Routing: Auto/Fast=GLM 4.7 Flash، Deep=GPT-OSS-120B، Research=Gemma 4، مع fallback.

## لا تعتبر مكتملًا
- Full-duplex voice الحقيقي.
- Agents/Projects كاملة.
- أدوات/Agent runtime كامل متعدد الأدوات.
- ذاكرة تلقائية شاملة.

## بوابة البناء
Gradle tasks المطلوبة: `:app:testDebugUnitTest :app:lintDebug :app:assembleDebug`. لا تعتمد APK قبل نجاحها.


## خط أساس Step 6 النهائي
- الإصدار: AION 2.0.0-alpha7.3-dev16 / versionCode 30.
- Step 6.1–6.6 مكتملة تكامليًا عند نجاح Gate النهائية.
- Claude/Gemini/Grok مزودات تنفيذ فعلية عند تهيئة مفاتيحها/model IDs على AION Cloud.
- external providers pinned بلا cross-provider fallback صامت.
- Workers AI fallback داخلي فقط وقبل أول token.
- provider-neutral context يحكم التبديل بين النماذج داخل نفس المحادثة.
- Voice/My Voice/AION Live تبقى على عقود Step 4/5 دون تغيير.
