# سجل AION Mobile V2

## 2.0.0-alpha1

- تأسيس مشروع Android أصلي.
- إنشاء واجهة RTL عربية داكنة.
- إضافة شاشة دردشة أساسية وشريط كتابة ورسائل.
- إضافة درج جانبي لقدرات AION.
- تأسيس طبقات مستقلة للذكاء الاصطناعي والوكيل والذاكرة والملفات والصوت والبحث والأدوات.
- إضافة اختبار وحدة لسجل القدرات.
- إضافة GitHub Actions للاختبار والفحص وبناء APK والتحقق من توقيعه.
- عدم تضمين أي مفتاح API سري داخل التطبيق.


## إصلاح البناء 2026-09-07
- إزالة `org.jetbrains.kotlin.android` لأن AGP 9.4 يستخدم Kotlin المدمجة تلقائيًا.
- الاعتماد على `compileOptions.targetCompatibility = JavaVersion.VERSION_17` لضبط هدف Kotlin تلقائيًا وفق Kotlin المدمجة.
- الإبقاء على `org.jetbrains.kotlin.plugin.compose` لأنه مطلوب لمترجم Compose مع Kotlin 2.x.
