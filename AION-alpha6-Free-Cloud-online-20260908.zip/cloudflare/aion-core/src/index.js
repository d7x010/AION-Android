const DEFAULT_MODEL = "@cf/zai-org/glm-4.7-flash";
const MAX_MESSAGES = 24;
const MAX_MESSAGE_CHARS = 12_000;
const MAX_REQUESTS_PER_WINDOW = 20;
const WINDOW_MS = 10 * 60 * 1000;
const buckets = new Map();
const SYSTEM_PROMPT = `أنت AION، مساعد ذكي عربي مستقل. أجب بلغة المستخدم وبأسلوب طبيعي وواضح.
كيّف عمق الإجابة مع الطلب: مختصر للسؤال البسيط، وعميق ومنظم للسؤال الذي يحتاج تحليلاً.
لا تدّعِ أنك بحثت في الويب أو نفذت أداة إن لم يحدث ذلك. إذا لم تعرف فقل ذلك بوضوح.
تجنب الحشو والافتتاحيات المتكررة، وابدأ بالجواب مباشرة.`;

function json(value, status = 200) {
  return new Response(JSON.stringify(value), {
    status,
    headers: {
      "content-type": "application/json; charset=utf-8",
      "cache-control": "no-store",
      "access-control-allow-origin": "*",
      "access-control-allow-methods": "POST, OPTIONS",
      "access-control-allow-headers": "content-type",
    },
  });
}

function allowRequest(request) {
  const ip = request.headers.get("CF-Connecting-IP") || "unknown";
  const now = Date.now();
  const bucket = buckets.get(ip);
  if (!bucket || now - bucket.startedAt >= WINDOW_MS) {
    buckets.set(ip, { startedAt: now, count: 1 });
    return true;
  }
  if (bucket.count >= MAX_REQUESTS_PER_WINDOW) return false;
  bucket.count += 1;
  return true;
}

function cleanMessages(input) {
  if (!Array.isArray(input) || input.length === 0) throw new Error("messages مطلوبة.");
  if (input.length > MAX_MESSAGES) throw new Error("عدد الرسائل أكبر من الحد المسموح.");
  return input.map((message) => {
    const role = message?.role === "assistant" ? "assistant" : message?.role === "system" ? "system" : "user";
    const content = typeof message?.content === "string" ? message.content.trim() : "";
    if (!content) throw new Error("كل رسالة تحتاج نصًا.");
    if (content.length > MAX_MESSAGE_CHARS) throw new Error("إحدى الرسائل طويلة جدًا.");
    return { role, content };
  });
}

function extractText(result) {
  if (typeof result?.response === "string") return result.response.trim();
  const content = result?.choices?.[0]?.message?.content;
  if (typeof content === "string") return content.trim();
  if (Array.isArray(content)) {
    return content
      .map((part) => typeof part === "string" ? part : part?.text || part?.content || "")
      .join("")
      .trim();
  }
  if (typeof result?.result?.response === "string") return result.result.response.trim();
  return "";
}

async function runModel(env, messages) {
  let lastError;
  for (let attempt = 1; attempt <= 3; attempt += 1) {
    try {
      const result = await env.AI.run(DEFAULT_MODEL, {
        messages: [{ role: "system", content: SYSTEM_PROMPT }, ...messages],
        max_completion_tokens: 1100,
        temperature: 0.65,
      });
      const response = extractText(result);
      if (response) return response;
      lastError = new Error(`empty model response on attempt ${attempt}`);
    } catch (error) {
      lastError = error;
    }
    if (attempt < 3) await new Promise((resolve) => setTimeout(resolve, attempt * 350));
  }
  throw lastError || new Error("empty model response");
}

export default {
  async fetch(request, env) {
    if (request.method === "OPTIONS") return json({ ok: true });
    const url = new URL(request.url);
    if (request.method === "GET" && url.pathname === "/health") {
      return json({ ok: true, service: "AION α6 Free Cloud Core", model: DEFAULT_MODEL });
    }
    if (request.method !== "POST" || url.pathname !== "/v1/chat") {
      return json({ error: "المسار غير موجود." }, 404);
    }
    if (!allowRequest(request)) return json({ error: "تم بلوغ حد التجربة المؤقت. حاول بعد بضع دقائق." }, 429);
    try {
      const payload = await request.json();
      const messages = cleanMessages(payload.messages);
      const response = await runModel(env, messages);
      return json({ response, model: DEFAULT_MODEL });
    } catch (error) {
      console.error("aion-core", error);
      return json({ error: "تعذر تنفيذ طلب الذكاء الاصطناعي." }, 500);
    }
  },
};
