const PRIMARY_MODEL = "@cf/zai-org/glm-4.7-flash";
const FALLBACK_MODEL = "@cf/google/gemma-4-26b-a4b-it";
const MAX_MESSAGES = 28;
const MAX_MESSAGE_CHARS = 12_000;
const MAX_BODY_BYTES = 420_000;
const MAX_REQUESTS_PER_WINDOW = 24;
const WINDOW_MS = 10 * 60 * 1000;
const buckets = new Map();

const AION_SYSTEM_PROMPT = `
أنت AION، رفيق ذكاء شخصي حي ودقيق داخل تطبيق AION.
أجب بالعربية افتراضيًا، وافهم العربية الفصحى واللهجات العربية ومنها العراقية، وانتقل إلى لغة أخرى عندما يطلب المستخدم ذلك.

قواعد الحوار:
- لا تكرر سؤال المستخدم ولا تبدأ بمقدمات فارغة أو مديح تلقائي.
- اجعل طول الجواب متكيفًا مع النية: القصير للطلب البسيط، والتفصيل عندما يحتاج الموضوع فعلًا.
- تعامل مع الرسائل كسياق متصل، واعتمد تصحيح المستخدم فورًا بدل إعادة الحوار من الصفر.
- ميّز الحقيقة عن الرأي والافتراض وعدم اليقين عندما يكون الفرق مهمًا.
- لا تدّعِ أنك بحثت في الويب ما لم تستلم مصادر بحث فعلية في هذه المحادثة.
- إذا زوّدك النظام بمصادر حية، اربط الادعاءات المهمة بها باستخدام [1] و[2]... ولا تخترع مصادر أو روابط.
- لا تكشف سلسلة التفكير الداخلية. أعطِ الخلاصة والأسباب المفيدة فقط.
- إذا كان المستخدم مخطئًا في حقيقة قابلة للتحقق، صححها باختصار ووضوح.
- لا تختم كل رد بسؤال آلي أو عرض عام للمساعدة.
- عندما يكون الطلب برمجيًا، أعطِ نتيجة قابلة للتنفيذ وحافظ على الاتساق مع القرارات السابقة في الحوار.
`;

function headers(extra = {}) {
  return {
    "cache-control": "no-store",
    "access-control-allow-origin": "*",
    "access-control-allow-methods": "GET, POST, OPTIONS",
    "access-control-allow-headers": "content-type",
    ...extra,
  };
}

function json(value, status = 200) {
  return new Response(JSON.stringify(value), {
    status,
    headers: headers({ "content-type": "application/json; charset=utf-8" }),
  });
}

function allowRequest(request) {
  const ip = request.headers.get("CF-Connecting-IP") || "unknown";
  const now = Date.now();
  const bucket = buckets.get(ip);
  if (!bucket || now - bucket.startedAt >= WINDOW_MS) {
    buckets.set(ip, { startedAt: now, count: 1 });
    return true;
  }
  if (bucket.count >= MAX_REQUESTS_PER_WINDOW) return false;
  bucket.count += 1;
  return true;
}

function cleanMessages(input) {
  if (!Array.isArray(input) || input.length === 0) throw new Error("messages مطلوبة.");
  if (input.length > MAX_MESSAGES) throw new Error("عدد الرسائل أكبر من الحد المسموح.");
  return input.map((message) => {
    const role = message?.role === "assistant" ? "assistant" : message?.role === "system" ? "system" : "user";
    const content = typeof message?.content === "string" ? message.content.trim() : "";
    if (!content) throw new Error("كل رسالة تحتاج نصًا.");
    if (content.length > MAX_MESSAGE_CHARS) throw new Error("إحدى الرسائل طويلة جدًا.");
    return { role, content };
  });
}

function normalizeArabic(text) {
  return String(text || "")
    .toLowerCase()
    .replace(/[إأآ]/g, "ا")
    .replace(/ى/g, "ي")
    .replace(/ة/g, "ه");
}

function chooseMode(payload) {
  const value = String(payload?.mode || payload?.model || "auto").toLowerCase();
  return ["auto", "fast", "deep", "research"].includes(value) ? value : "auto";
}

function shouldSearch(payload, messages, mode) {
  if (mode === "research" || payload?.forceWebSearch === true) return true;
  const last = [...messages].reverse().find((m) => m.role === "user")?.content || "";
  const text = normalizeArabic(last);
  const explicit = [
    "ابحث", "بحث في الويب", "فتش في الويب", "دور بالويب", "دور في الويب", "من الانترنت",
    "على الانترنت", "مصادر حديثه", "تحقق من الويب"
  ];
  if (explicit.some((phrase) => text.includes(normalizeArabic(phrase)))) return true;

  const freshness = [
    "اخر الاخبار", "احدث الاخبار", "اخر تحديث", "سعر اليوم", "الطقس", "موعد اليوم",
    "نتيجه المباراه", "نتائج اليوم", "من فاز", "احدث اصدار", "احدث نسخه", "متوفر حاليا"
  ];
  return freshness.some((phrase) => text.includes(normalizeArabic(phrase)));
}

function modeInstruction(mode, researched) {
  const base = {
    fast: "وضع سريع: أعطِ أقل جواب كافٍ ومباشر، وتجنب التفصيل غير الضروري.",
    deep: "وضع عميق: حلل المسألة بصرامة، اختبر الافتراضات، واشرح النتيجة بعمق منظم من دون حشو.",
    research: "وضع بحث: ابنِ الجواب على الأدلة الحية، قارن المصادر عند الاختلاف، واذكر حدود ما يمكن التحقق منه.",
    auto: "وضع تلقائي: اختر بنفسك مقدار العمق والطول المناسبين للطلب.",
  }[mode] || "";
  return researched ? `${base}\nلديك مصادر ويب حية أدناه. لا تنسب إليها ما لا تقوله.` : base;
}

async function searchWeb(query) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 22_000);
  try {
    const response = await fetch("https://api.firecrawl.dev/v2/search", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        query,
        limit: 5,
        sources: ["web"],
        scrapeOptions: {
          formats: ["markdown"],
          onlyMainContent: true,
        },
      }),
      signal: controller.signal,
    });
    if (!response.ok) throw new Error(`web_search_${response.status}`);
    const body = await response.json();
    const raw = Array.isArray(body?.data?.web)
      ? body.data.web
      : Array.isArray(body?.data)
        ? body.data
        : [];
    return raw.slice(0, 5).map((item, index) => ({
      index: index + 1,
      title: String(item?.title || item?.metadata?.title || item?.url || `مصدر ${index + 1}`).slice(0, 240),
      url: String(item?.url || item?.metadata?.sourceURL || "").slice(0, 1200),
      snippet: String(item?.description || item?.markdown || item?.content || "").replace(/\s+/g, " ").trim().slice(0, 2800),
    })).filter((item) => item.url);
  } finally {
    clearTimeout(timeout);
  }
}

function researchContext(sources) {
  if (!sources.length) return "";
  return sources.map((source) =>
    `[${source.index}] ${source.title}\nURL: ${source.url}\nالمحتوى: ${source.snippet}`
  ).join("\n\n");
}

function buildModelMessages(messages, mode, sources) {
  const system = [
    AION_SYSTEM_PROMPT.trim(),
    modeInstruction(mode, sources.length > 0),
    sources.length
      ? `\nمصادر البحث الحية:\n${researchContext(sources)}\n\nاستخدم أرقام المصادر بين أقواس مربعة في مواضع الادعاءات المدعومة.`
      : "",
  ].filter(Boolean).join("\n\n");
  return [{ role: "system", content: system }, ...messages.filter((m) => m.role !== "system")];
}

function modelOptions(mode, stream) {
  const max = mode === "fast" ? 450 : mode === "deep" ? 1500 : mode === "research" ? 1300 : 900;
  return {
    stream,
    max_completion_tokens: max,
    temperature: mode === "research" ? 0.35 : mode === "deep" ? 0.45 : 0.65,
  };
}

function extractText(result) {
  if (typeof result?.response === "string") return result.response.trim();
  if (typeof result?.choices?.[0]?.message?.content === "string") return result.choices[0].message.content.trim();
  if (typeof result?.result?.response === "string") return result.result.response.trim();
  return "";
}

function extractDelta(payload, emitted) {
  const candidate =
    typeof payload?.response === "string" ? payload.response :
    typeof payload?.choices?.[0]?.delta?.content === "string" ? payload.choices[0].delta.content :
    typeof payload?.delta?.content === "string" ? payload.delta.content :
    typeof payload?.text === "string" ? payload.text : "";
  if (!candidate) return "";
  if (candidate.startsWith(emitted)) return candidate.slice(emitted.length);
  return candidate;
}

async function runSync(env, model, messages, mode) {
  return env.AI.run(model, { messages, ...modelOptions(mode, false) });
}

async function runSyncWithFallback(env, messages, mode) {
  try {
    const result = await runSync(env, PRIMARY_MODEL, messages, mode);
    return { result, model: PRIMARY_MODEL };
  } catch (primaryError) {
    console.warn("aion-primary-failed", primaryError);
    const result = await runSync(env, FALLBACK_MODEL, messages, mode);
    return { result, model: FALLBACK_MODEL };
  }
}

async function runStreamWithFallback(env, messages, mode) {
  try {
    const stream = await env.AI.run(PRIMARY_MODEL, { messages, ...modelOptions(mode, true) });
    return { stream, model: PRIMARY_MODEL };
  } catch (primaryError) {
    console.warn("aion-primary-stream-failed", primaryError);
    const stream = await env.AI.run(FALLBACK_MODEL, { messages, ...modelOptions(mode, true) });
    return { stream, model: FALLBACK_MODEL };
  }
}

function event(name, value) {
  return `event: ${name}\ndata: ${JSON.stringify(value)}\n\n`;
}

async function prepare(request) {
  const length = Number(request.headers.get("content-length") || "0");
  if (length > MAX_BODY_BYTES) throw Object.assign(new Error("الطلب كبير جدًا."), { status: 413 });
  const payload = await request.json();
  const messages = cleanMessages(payload.messages);
  const mode = chooseMode(payload);
  const useSearch = shouldSearch(payload, messages, mode);
  return { payload, messages, mode, useSearch };
}

async function syncChat(request, env) {
  const { messages, mode, useSearch } = await prepare(request);
  let sources = [];
  if (useSearch) {
    const query = [...messages].reverse().find((m) => m.role === "user")?.content || "";
    try {
      sources = await searchWeb(query);
    } catch (error) {
      console.error("aion-search", error);
      return json({ error: "تعذر الوصول إلى البحث الحي الآن. لم أستبدله بإجابة قديمة حتى لا أدّعي أنني بحثت." }, 503);
    }
    if (!sources.length) {
      return json({ error: "لم يرجع البحث الحي مصادر قابلة للاستخدام لهذه العبارة." }, 502);
    }
  }

  const modelMessages = buildModelMessages(messages, mode, sources);
  const { result, model } = await runSyncWithFallback(env, modelMessages, mode);
  const response = extractText(result);
  if (!response) return json({ error: "النموذج لم يُرجع نصًا." }, 502);
  return json({ response, model, mode, usedWebSearch: useSearch, sources });
}

async function streamChat(request, env) {
  const prepared = await prepare(request);
  const encoder = new TextEncoder();

  const stream = new ReadableStream({
    async start(controller) {
      let emitted = "";
      let sources = [];
      let selectedModel = PRIMARY_MODEL;
      let wrote = false;
      const send = (name, value) => controller.enqueue(encoder.encode(event(name, value)));
      try {
        if (prepared.useSearch) {
          send("activity", { activity: "searching_web" });
          const query = [...prepared.messages].reverse().find((m) => m.role === "user")?.content || "";
          sources = await searchWeb(query);
          if (!sources.length) throw Object.assign(new Error("لم يرجع البحث الحي مصادر قابلة للاستخدام."), { status: 502 });
          send("sources", { sources });
        } else {
          send("activity", { activity: "thinking" });
        }

        const modelMessages = buildModelMessages(prepared.messages, prepared.mode, sources);
        const running = await runStreamWithFallback(env, modelMessages, prepared.mode);
        selectedModel = running.model;
        const bodyStream = running.stream?.body ?? running.stream;
        if (!bodyStream || typeof bodyStream.getReader !== "function") {
          throw new Error("تعذر فتح بث النموذج.");
        }
        const reader = bodyStream.getReader();
        const decoder = new TextDecoder();
        let buffer = "";

        while (true) {
          const { value, done } = await reader.read();
          if (done) break;
          buffer += decoder.decode(value, { stream: true });
          const lines = buffer.split(/\r?\n/);
          buffer = lines.pop() || "";
          for (const line of lines) {
            if (!line.startsWith("data:")) continue;
            const data = line.slice(5).trim();
            if (!data || data === "[DONE]") continue;
            let payload;
            try { payload = JSON.parse(data); } catch { continue; }
            const delta = extractDelta(payload, emitted);
            if (!delta) continue;
            if (!wrote) {
              send("activity", { activity: "writing" });
              wrote = true;
            }
            emitted += delta;
            send("delta", { text: delta });
          }
        }

        if (!emitted.trim()) {
          const { result, model } = await runSyncWithFallback(env, modelMessages, prepared.mode);
          selectedModel = model;
          const text = extractText(result);
          if (!text) throw Object.assign(new Error("النموذج لم يُرجع نصًا."), { status: 502 });
          if (!wrote) send("activity", { activity: "writing" });
          emitted = text;
          send("delta", { text });
        }

        send("done", {
          model: selectedModel,
          mode: prepared.mode,
          usedWebSearch: prepared.useSearch,
          characters: emitted.length,
        });
      } catch (error) {
        console.error("aion-stream", error);
        send("error", {
          status: Number(error?.status || 500),
          error: prepared.useSearch && String(error?.message || "").includes("search")
            ? "تعذر تنفيذ البحث الحي الآن."
            : String(error?.message || "تعذر تنفيذ الطلب."),
        });
      } finally {
        controller.close();
      }
    },
  });

  return new Response(stream, {
    headers: headers({
      "content-type": "text/event-stream; charset=utf-8",
      "connection": "keep-alive",
      "x-accel-buffering": "no",
    }),
  });
}

export default {
  async fetch(request, env) {
    if (request.method === "OPTIONS") return new Response(null, { status: 204, headers: headers() });
    const url = new URL(request.url);

    if (request.method === "GET" && (url.pathname === "/" || url.pathname === "/health")) {
      return json({
        ok: true,
        service: "AION α6.1 Living Research Core",
        primaryModel: PRIMARY_MODEL,
        fallbackModel: FALLBACK_MODEL,
        capabilities: ["chat", "streaming", "web-research", "sources", "modes", "fallback"],
      });
    }

    if (request.method === "GET" && url.pathname === "/v1/status") {
      return json({ ok: true, version: "6.1", research: "firecrawl-keyless", modes: ["auto", "fast", "deep", "research"] });
    }

    if (request.method !== "POST") return json({ error: "المسار غير موجود." }, 404);
    if (!allowRequest(request)) return json({ error: "تم بلوغ حد الحماية المؤقت. حاول بعد بضع دقائق." }, 429);

    try {
      if (url.pathname === "/v1/chat/stream") return await streamChat(request, env);
      if (url.pathname === "/v1/chat") return await syncChat(request, env);
      return json({ error: "المسار غير موجود." }, 404);
    } catch (error) {
      console.error("aion-core", error);
      return json({ error: error?.message || "تعذر تنفيذ طلب AION." }, Number(error?.status || 500));
    }
  },
};
