package com.aion.mobile.core.ai

import com.aion.mobile.model.ChatMessage
import com.aion.mobile.model.MessageRole
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import kotlinx.coroutines.delay

class AionCloudException(val statusCode: Int, message: String) : Exception(message)

/** عميل α6 لخادم AION: اتصال HTTPS بلا مفاتيح مزود داخل APK. */
class AionCloudGateway {
    suspend fun complete(
        endpoint: String,
        model: String,
        messages: List<ChatMessage>,
        onActivity: suspend (GatewayActivity) -> Unit
    ): GatewayResult = withContext(Dispatchers.IO) {
        if (endpoint.isBlank()) throw AionCloudException(400, "لم يتم ربط AION Cloud بعد.")
        val payload = JSONObject().apply {
            put("model", model)
            put("messages", JSONArray().apply {
                messages.takeLast(24).forEach { message ->
                    put(JSONObject().apply {
                        put("role", if (message.role == MessageRole.USER) "user" else "assistant")
                        put("content", message.text.take(12_000))
                    })
                }
            })
        }

        onActivity(GatewayActivity.THINKING)
        var lastError: Throwable? = null
        repeat(3) { attempt ->
            val connection = (URL("${endpoint.trimEnd('/')}/v1/chat").openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 30_000
                readTimeout = 180_000
                doOutput = true
                setRequestProperty("Content-Type", "application/json; charset=utf-8")
                setRequestProperty("Accept", "application/json")
            }
            try {
                connection.outputStream.use { it.write(payload.toString().toByteArray(Charsets.UTF_8)) }
                val code = connection.responseCode
                val stream = if (code in 200..299) connection.inputStream else connection.errorStream
                val raw = stream?.let { BufferedReader(InputStreamReader(it, Charsets.UTF_8)).use { reader -> reader.readText() } }.orEmpty()
                val body = runCatching { JSONObject(raw) }.getOrNull()
                if (code !in 200..299) {
                    throw AionCloudException(code, body?.optString("error").orEmpty().ifBlank { "تعذر الاتصال بـ AION Cloud." })
                }
                val text = body?.optString("response").orEmpty().trim()
                if (text.isBlank()) throw AionCloudException(502, "أنهى الخادم الطلب من دون نص.")
                onActivity(GatewayActivity.WRITING)
                return@withContext GatewayResult(text = text)
            } catch (error: Throwable) {
                lastError = error
                val retryable = error !is AionCloudException || error.statusCode == 502 || error.statusCode == 503
                if (!retryable || attempt == 2) throw error
                delay((attempt + 1) * 450L)
            } finally {
                connection.disconnect()
            }
        }
        throw lastError ?: AionCloudException(502, "تعذر الحصول على رد نصي.")
    }
}
