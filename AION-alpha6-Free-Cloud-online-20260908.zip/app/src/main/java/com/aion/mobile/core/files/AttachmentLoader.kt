package com.aion.mobile.core.files

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import android.util.Base64
import com.aion.mobile.model.AttachmentKind
import com.aion.mobile.model.ChatAttachment
import java.io.ByteArrayOutputStream
import java.util.Locale

object AttachmentLoader {
    private const val MAX_ATTACHMENT_BYTES = 12L * 1024L * 1024L

    private val fileExtensions = setOf(
        "pdf", "txt", "md", "json", "html", "htm", "xml", "csv",
        "doc", "docx", "rtf", "odt", "ppt", "pptx", "xls", "xlsx",
        "kt", "kts", "java", "py", "js", "ts", "tsx", "jsx", "css",
        "c", "cpp", "h", "hpp", "cs", "go", "rs", "swift", "rb", "php",
        "sql", "yaml", "yml", "toml", "ini", "log"
    )

    fun load(context: Context, uri: Uri): Result<ChatAttachment> = runCatching {
        val resolver = context.contentResolver
        val name = queryName(context, uri) ?: "مرفق"
        val extension = name.substringAfterLast('.', "").lowercase(Locale.ROOT)
        var mime = resolver.getType(uri)?.lowercase(Locale.ROOT).orEmpty()
        if (mime.isBlank() || mime == "application/octet-stream") {
            mime = fallbackMime(extension)
        }

        val isImage = mime.startsWith("image/") && mime in setOf(
            "image/png", "image/jpeg", "image/jpg", "image/webp", "image/gif"
        )
        val isSupportedFile = mime.startsWith("text/") || extension in fileExtensions || mime in setOf(
            "application/pdf",
            "application/json",
            "application/xml",
            "application/rtf",
            "application/msword",
            "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            "application/vnd.ms-powerpoint",
            "application/vnd.openxmlformats-officedocument.presentationml.presentation",
            "application/vnd.ms-excel",
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            "application/vnd.oasis.opendocument.text"
        )

        if (!isImage && !isSupportedFile) {
            error("نوع الملف غير مدعوم حاليًا: $name")
        }

        val reportedSize = querySize(context, uri)
        if (reportedSize != null && reportedSize > MAX_ATTACHMENT_BYTES) {
            error("الملف أكبر من 12 MB. اختر ملفًا أصغر في هذه النسخة.")
        }

        val bytes = resolver.openInputStream(uri)?.use { input ->
            val output = ByteArrayOutputStream()
            val buffer = ByteArray(64 * 1024)
            var total = 0L
            while (true) {
                val read = input.read(buffer)
                if (read <= 0) break
                total += read
                if (total > MAX_ATTACHMENT_BYTES) {
                    error("الملف أكبر من 12 MB. اختر ملفًا أصغر في هذه النسخة.")
                }
                output.write(buffer, 0, read)
            }
            output.toByteArray()
        } ?: error("تعذر قراءة الملف المحدد.")

        ChatAttachment(
            id = System.nanoTime(),
            name = name,
            mimeType = if (mime == "image/jpg") "image/jpeg" else mime,
            base64Data = Base64.encodeToString(bytes, Base64.NO_WRAP),
            kind = if (isImage) AttachmentKind.IMAGE else AttachmentKind.FILE,
            sizeBytes = bytes.size.toLong()
        )
    }

    private fun queryName(context: Context, uri: Uri): String? {
        return context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
            val index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (index >= 0 && cursor.moveToFirst()) cursor.getString(index) else null
        }
    }

    private fun querySize(context: Context, uri: Uri): Long? {
        return context.contentResolver.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)?.use { cursor ->
            val index = cursor.getColumnIndex(OpenableColumns.SIZE)
            if (index >= 0 && cursor.moveToFirst() && !cursor.isNull(index)) cursor.getLong(index) else null
        }
    }

    private fun fallbackMime(extension: String): String = when (extension) {
        "png" -> "image/png"
        "jpg", "jpeg" -> "image/jpeg"
        "webp" -> "image/webp"
        "gif" -> "image/gif"
        "pdf" -> "application/pdf"
        "json" -> "application/json"
        "xml" -> "application/xml"
        "doc" -> "application/msword"
        "docx" -> "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
        "ppt" -> "application/vnd.ms-powerpoint"
        "pptx" -> "application/vnd.openxmlformats-officedocument.presentationml.presentation"
        "xls" -> "application/vnd.ms-excel"
        "xlsx" -> "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        "rtf" -> "application/rtf"
        else -> "text/plain"
    }
}
