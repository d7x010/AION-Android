package com.aion.mobile.core.run

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.aion.mobile.MainActivity
import com.aion.mobile.R
import com.aion.mobile.core.ai.AionCloudException
import com.aion.mobile.core.ai.AionCloudGateway
import com.aion.mobile.core.ai.AionCloudSettings
import com.aion.mobile.core.ai.GatewayActivity
import com.aion.mobile.core.ai.GatewayResult
import com.aion.mobile.core.storage.ChatSessionStore
import com.aion.mobile.model.ChatMessage
import com.aion.mobile.model.MessageRole
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

class AionRunService : Service() {
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val gateway = AionCloudGateway()
    private var activeJob: Job? = null
    private var activeRunId: String? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannels()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                val runId = intent.getStringExtra(EXTRA_RUN_ID)
                if (runId == null || runId == activeRunId) {
                    activeJob?.cancel(CancellationException("أوقف المستخدم الرد"))
                }
                return START_NOT_STICKY
            }

            ACTION_START -> {
                val runId = intent.getStringExtra(EXTRA_RUN_ID) ?: return START_NOT_STICKY
                val request = AionRunRegistry.get(runId) ?: return START_NOT_STICKY
                activeRunId = runId
                startForeground(NOTIFICATION_WORK_ID, buildWorkingNotification("يفهم طلبك…", runId))
                activeJob?.cancel()
                activeJob = serviceScope.launch { execute(request) }
            }
        }
        return START_NOT_STICKY
    }

    private suspend fun execute(request: AionRunRequest) {
        var currentText = ""
        var currentActivity = GatewayActivity.THINKING
        val endpoint = AionCloudSettings.loadEndpoint(this)

        try {
            val finalResult: GatewayResult = gateway.streamComplete(
                endpoint = endpoint,
                mode = request.modelId,
                messages = request.messages,
                forceWebSearch = request.forceWebSearch,
                onDelta = { delta ->
                    currentText += delta
                    AionRunBus.publish(
                        AionRunSnapshot(
                            runId = request.runId,
                            placeholderId = request.placeholderId,
                            modelId = request.modelId,
                            modelLabel = request.modelLabel,
                            text = currentText,
                            activity = GatewayActivity.WRITING,
                            isRunning = true
                        )
                    )
                },
                onActivity = { activity ->
                    currentActivity = activity
                    AionRunBus.publish(AionRunSnapshot(
                        runId = request.runId,
                        placeholderId = request.placeholderId,
                        modelId = request.modelId,
                        modelLabel = request.modelLabel,
                        text = currentText,
                        activity = currentActivity,
                        isRunning = true
                    ))
                    getSystemService(NotificationManager::class.java).notify(
                        NOTIFICATION_WORK_ID,
                        buildWorkingNotification(activityLabel(activity), request.runId)
                    )
                }
            )
            currentText = finalResult.text

            val assistant = ChatMessage(
                id = request.placeholderId,
                role = MessageRole.AION,
                text = finalResult.text,
                modelId = request.modelId,
                modelLabel = request.modelLabel,
                sources = finalResult.sources,
                isStreaming = false
            )
            ChatSessionStore.saveMessages(this, request.sessionMessages + assistant)
            AionRunBus.publish(
                AionRunSnapshot(
                    runId = request.runId,
                    placeholderId = request.placeholderId,
                    modelId = request.modelId,
                    modelLabel = request.modelLabel,
                    text = finalResult.text,
                    activity = GatewayActivity.WRITING,
                    isRunning = false,
                    sources = finalResult.sources
                )
            )
            showCompletedNotification()
        } catch (cancelled: CancellationException) {
            val assistant = if (currentText.isBlank()) null else ChatMessage(
                id = request.placeholderId,
                role = MessageRole.AION,
                text = currentText,
                modelId = request.modelId,
                modelLabel = request.modelLabel,
                isStreaming = false,
                wasStopped = true
            )
            ChatSessionStore.saveMessages(this, request.sessionMessages + listOfNotNull(assistant))
            AionRunBus.publish(
                AionRunSnapshot(
                    runId = request.runId,
                    placeholderId = request.placeholderId,
                    modelId = request.modelId,
                    modelLabel = request.modelLabel,
                    text = currentText,
                    activity = currentActivity,
                    isRunning = false,
                    wasStopped = true
                )
            )
        } catch (throwable: Throwable) {
            val errorText = readableError(throwable)
            val assistant = ChatMessage(
                id = request.placeholderId,
                role = MessageRole.AION,
                text = errorText,
                modelId = request.modelId,
                modelLabel = request.modelLabel,
                isError = true,
                isStreaming = false
            )
            ChatSessionStore.saveMessages(this, request.sessionMessages + assistant)
            AionRunBus.publish(
                AionRunSnapshot(
                    runId = request.runId,
                    placeholderId = request.placeholderId,
                    modelId = request.modelId,
                    modelLabel = request.modelLabel,
                    text = errorText,
                    activity = currentActivity,
                    isRunning = false,
                    errorText = errorText
                )
            )
            showFailedNotification()
        } finally {
            AionRunRegistry.remove(request.runId)
            activeRunId = null
            activeJob = null
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }

    private fun activityLabel(activity: GatewayActivity): String = when (activity) {
        GatewayActivity.THINKING -> "يفهم طلبك…"
        GatewayActivity.SEARCHING_WEB -> "يبحث في الويب…"
        GatewayActivity.WRITING -> "يصيغ الإجابة…"
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(
            NotificationChannel(
                CHANNEL_WORK,
                "مهام AION الجارية",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "حالة البحث والردود والمهام التي تعمل في الخلفية"
                setShowBadge(false)
            }
        )
        manager.createNotificationChannel(
            NotificationChannel(
                CHANNEL_DONE,
                "نتائج AION",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "إشعار عند اكتمال رد أو مهمة أثناء وجودك خارج التطبيق"
            }
        )
    }

    private fun openAppPendingIntent(): PendingIntent = PendingIntent.getActivity(
        this,
        11,
        Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        },
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    private fun buildWorkingNotification(status: String, runId: String): android.app.Notification {
        val stopIntent = PendingIntent.getService(
            this,
            12,
            Intent(this, AionRunService::class.java).apply {
                action = ACTION_STOP
                putExtra(EXTRA_RUN_ID, runId)
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_WORK)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle("AION يعمل على طلبك")
            .setContentText(status)
            .setContentIntent(openAppPendingIntent())
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(NotificationCompat.CATEGORY_PROGRESS)
            .addAction(0, "إلغاء", stopIntent)
            .build()
    }

    private fun showCompletedNotification() {
        getSystemService(NotificationManager::class.java).notify(
            NOTIFICATION_DONE_ID,
            NotificationCompat.Builder(this, CHANNEL_DONE)
                .setSmallIcon(R.drawable.ic_launcher_foreground)
                .setContentTitle("AION أكمل الرد")
                .setContentText("النتيجة جاهزة. اضغط للعودة إلى المحادثة.")
                .setContentIntent(openAppPendingIntent())
                .setAutoCancel(true)
                .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                .build()
        )
    }

    private fun showFailedNotification() {
        getSystemService(NotificationManager::class.java).notify(
            NOTIFICATION_DONE_ID,
            NotificationCompat.Builder(this, CHANNEL_DONE)
                .setSmallIcon(R.drawable.ic_launcher_foreground)
                .setContentTitle("تعذر إكمال طلب AION")
                .setContentText("افتح المحادثة لمعرفة التفاصيل والمحاولة من جديد.")
                .setContentIntent(openAppPendingIntent())
                .setAutoCancel(true)
                .build()
        )
    }

    private fun readableError(error: Throwable): String = when (error) {
        is AionCloudException -> when (error.statusCode) {
            400 -> error.message ?: "اربط عنوان AION Cloud من الإعدادات أولًا."
            429 -> "وصلت التجربة المجانية إلى حد مؤقت. حاول بعد بضع دقائق."
            else -> "تعذر الحصول على رد من AION Cloud: ${error.message}"
        }
        else -> "تعذر الاتصال بالإنترنت أو بـ AION Cloud: ${error.message ?: "خطأ غير معروف"}"
    }

    override fun onDestroy() {
        serviceScope.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_START = "com.aion.mobile.action.START_RUN"
        const val ACTION_STOP = "com.aion.mobile.action.STOP_RUN"
        const val EXTRA_RUN_ID = "run_id"

        private const val CHANNEL_WORK = "aion_work"
        private const val CHANNEL_DONE = "aion_done"
        private const val NOTIFICATION_WORK_ID = 4101
        private const val NOTIFICATION_DONE_ID = 4102
    }
}
