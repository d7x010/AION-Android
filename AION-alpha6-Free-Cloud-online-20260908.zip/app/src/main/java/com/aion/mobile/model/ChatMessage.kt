package com.aion.mobile.model

enum class MessageRole {
    USER,
    AION
}

enum class AttachmentKind {
    IMAGE,
    FILE
}

data class ChatAttachment(
    val id: Long,
    val name: String,
    val mimeType: String,
    val base64Data: String,
    val kind: AttachmentKind,
    val sizeBytes: Long
)

data class ChatSource(
    val title: String,
    val url: String
)

data class ChatMessage(
    val id: Long,
    val role: MessageRole,
    val text: String,
    val modelId: String? = null,
    val modelLabel: String? = null,
    val attachments: List<ChatAttachment> = emptyList(),
    val sources: List<ChatSource> = emptyList(),
    val isError: Boolean = false,
    val isStreaming: Boolean = false,
    val wasStopped: Boolean = false
)
