package com.aion.mobile.core.tools

interface AionTool {
    val id: String
    val title: String
    suspend fun execute(input: String): ToolResult
}

data class ToolResult(
    val output: String,
    val success: Boolean
)

class ToolRegistry(
    tools: List<AionTool> = emptyList()
) {
    private val toolsById = tools.associateBy { it.id }

    fun find(id: String): AionTool? = toolsById[id]
    fun all(): List<AionTool> = toolsById.values.toList()
}
