package com.aion.mobile.core.storage

import android.content.Context
import com.aion.mobile.model.AttachmentKind
import com.aion.mobile.model.ChatAttachment
import com.aion.mobile.model.ChatMessage
import com.aion.mobile.model.ChatSource
import com.aion.mobile.model.MessageRole
import org.json.JSONArray
import org.json.JSONObject

/**
 * تخزين محلي خفيف للمحادثة الحالية والمسودة.
 * لا نخزن base64 للمرفقات حتى لا نضخم SharedPreferences؛ نحفظ بياناتها الوصفية فقط.
 */
object ChatSessionStore {
    private const val PREFS = "aion_chat_session"
    private const val KEY_MESSAGES = "messages"
    private const val KEY_DRAFT = "draft"
    private const val KEY_SELECTED_MODEL = "selected_model"

    fun saveMessages(context: Context, messages: List<ChatMessage>) {
        val array = JSONArray()
        messages.takeLast(150).forEach { message ->
            array.put(
                JSONObject().apply {
                    put("id", message.id)
                    put("role", message.role.name)
                    put("text", message.text)
                    put("modelId", message.modelId ?: JSONObject.NULL)
                    put("modelLabel", message.modelLabel ?: JSONObject.NULL)
                    put("isError", message.isError)
                    put("isStreaming", message.isStreaming)
                    put("wasStopped", message.wasStopped)

                    put("sources", JSONArray().apply {
                        message.sources.forEach { source ->
                            put(JSONObject().apply {
                                put("title", source.title)
                                put("url", source.url)
                            })
                        }
                    })

                    put("attachments", JSONArray().apply {
                        message.attachments.forEach { attachment ->
                            put(JSONObject().apply {
                                put("id", attachment.id)
                                put("name", attachment.name)
                                put("mimeType", attachment.mimeType)
                                put("kind", attachment.kind.name)
                                put("sizeBytes", attachment.sizeBytes)
                            })
                        }
                    })
                }
            )
        }

        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_MESSAGES, array.toString())
            .apply()
    }

    fun loadMessages(context: Context): List<ChatMessage> {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_MESSAGES, null)
            ?: return emptyList()

        return runCatching {
            val array = JSONArray(raw)
            buildList {
                for (i in 0 until array.length()) {
                    val item = array.optJSONObject(i) ?: continue
                    val role = runCatching { MessageRole.valueOf(item.optString("role")) }.getOrDefault(MessageRole.AION)
                    val sources = buildList {
                        val sourceArray = item.optJSONArray("sources") ?: JSONArray()
                        for (j in 0 until sourceArray.length()) {
                            val source = sourceArray.optJSONObject(j) ?: continue
                            add(ChatSource(source.optString("title"), source.optString("url")))
                        }
                    }
                    val attachments = buildList {
                        val attachmentArray = item.optJSONArray("attachments") ?: JSONArray()
                        for (j in 0 until attachmentArray.length()) {
                            val attachment = attachmentArray.optJSONObject(j) ?: continue
                            add(
                                ChatAttachment(
                                    id = attachment.optLong("id"),
                                    name = attachment.optString("name"),
                                    mimeType = attachment.optString("mimeType"),
                                    base64Data = "",
                                    kind = runCatching { AttachmentKind.valueOf(attachment.optString("kind")) }
                                        .getOrDefault(AttachmentKind.FILE),
                                    sizeBytes = attachment.optLong("sizeBytes")
                                )
                            )
                        }
                    }
                    add(
                        ChatMessage(
                            id = item.optLong("id"),
                            role = role,
                            text = item.optString("text"),
                            modelId = item.optString("modelId").takeIf { it.isNotBlank() && it != "null" },
                            modelLabel = item.optString("modelLabel").takeIf { it.isNotBlank() && it != "null" },
                            attachments = attachments,
                            sources = sources,
                            isError = item.optBoolean("isError"),
                            isStreaming = item.optBoolean("isStreaming"),
                            wasStopped = item.optBoolean("wasStopped")
                        )
                    )
                }
            }
        }.getOrDefault(emptyList())
    }

    fun clearMessages(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .remove(KEY_MESSAGES)
            .apply()
    }

    fun saveDraft(context: Context, draft: String) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_DRAFT, draft)
            .apply()
    }

    fun loadDraft(context: Context): String =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_DRAFT, "")
            .orEmpty()

    fun saveSelectedModel(context: Context, key: String) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_SELECTED_MODEL, key)
            .apply()
    }

    fun loadSelectedModel(context: Context): String =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_SELECTED_MODEL, "auto")
            .orEmpty()
            .ifBlank { "auto" }
}
