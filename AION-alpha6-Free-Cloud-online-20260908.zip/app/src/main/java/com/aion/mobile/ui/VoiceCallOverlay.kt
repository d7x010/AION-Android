package com.aion.mobile.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.CallEnd
import androidx.compose.material.icons.outlined.Mic
import androidx.compose.material.icons.outlined.MicOff
import androidx.compose.material.icons.outlined.Stop
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import com.aion.mobile.core.ai.GatewayActivity
import com.aion.mobile.model.ChatMessage
import com.aion.mobile.model.MessageRole
import com.aion.mobile.ui.theme.AionPurpleSoft
import com.aion.mobile.ui.theme.AionPurpleStrong
import kotlinx.coroutines.delay
import java.util.Locale

private enum class VoiceCallState {
    LISTENING,
    THINKING,
    SEARCHING,
    SPEAKING,
    MUTED,
    ERROR
}

/**
 * مكالمة صوتية داخل التطبيق تعمل بدورات صوتية متتابعة:
 * استماع -> إرسال تلقائي -> رد -> قراءة صوتية -> استماع جديد.
 * هذه ليست بعد WebRTC full-duplex؛ البنية مصممة لتُستبدل لاحقًا بمحرك Realtime دون تغيير تجربة الشاشة.
 */
@Composable
internal fun VoiceCallOverlay(
    messages: List<ChatMessage>,
    isSending: Boolean,
    activity: GatewayActivity?,
    onSend: (String) -> Unit,
    onStop: () -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val mainHandler = remember { Handler(Looper.getMainLooper()) }
    val latestSending by rememberUpdatedState(isSending)
    var state by remember { mutableStateOf(VoiceCallState.LISTENING) }
    var partialText by remember { mutableStateOf("") }
    var muted by remember { mutableStateOf(false) }
    var recognizer by remember { mutableStateOf<SpeechRecognizer?>(null) }
    var tts by remember { mutableStateOf<TextToSpeech?>(null) }
    var requestListenTick by remember { mutableStateOf(0) }
    var lastHandledAssistantId by remember {
        mutableStateOf(messages.lastOrNull { it.role == MessageRole.AION }?.id)
    }

    fun stopAudio() {
        runCatching { recognizer?.cancel() }
        runCatching { tts?.stop() }
    }

    fun startListeningNow() {
        if (muted || latestSending) return
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return
        val r = recognizer ?: return
        partialText = ""
        state = VoiceCallState.LISTENING
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag())
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }
        runCatching { r.startListening(intent) }
            .onFailure { state = VoiceCallState.ERROR }
    }

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) {
            requestListenTick += 1
        } else {
            state = VoiceCallState.ERROR
            Toast.makeText(context, "يحتاج AION إذن الميكروفون لبدء المكالمة.", Toast.LENGTH_SHORT).show()
        }
    }

    DisposableEffect(context) {
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            state = VoiceCallState.ERROR
        } else {
            val speech = SpeechRecognizer.createSpeechRecognizer(context)
            speech.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {
                    if (!muted) state = VoiceCallState.LISTENING
                }

                override fun onBeginningOfSpeech() = Unit
                override fun onRmsChanged(rmsdB: Float) = Unit
                override fun onBufferReceived(buffer: ByteArray?) = Unit
                override fun onEndOfSpeech() = Unit

                override fun onError(error: Int) {
                    if (muted || latestSending) return
                    partialText = ""
                    if (error == SpeechRecognizer.ERROR_NO_MATCH || error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT) {
                        mainHandler.postDelayed({ requestListenTick += 1 }, 450L)
                    } else {
                        state = VoiceCallState.ERROR
                    }
                }

                override fun onResults(results: Bundle?) {
                    val spoken = results
                        ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.firstOrNull()
                        ?.trim()
                        .orEmpty()
                    partialText = spoken
                    if (spoken.isNotBlank()) {
                        state = VoiceCallState.THINKING
                        onSend(spoken)
                    } else if (!muted) {
                        mainHandler.postDelayed({ requestListenTick += 1 }, 300L)
                    }
                }

                override fun onPartialResults(partialResults: Bundle?) {
                    partialText = partialResults
                        ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.firstOrNull()
                        .orEmpty()
                }

                override fun onEvent(eventType: Int, params: Bundle?) = Unit
            })
            recognizer = speech
        }

        lateinit var engine: TextToSpeech
        engine = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                engine.language = Locale.getDefault()
                engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {
                        mainHandler.post { state = VoiceCallState.SPEAKING }
                    }

                    override fun onDone(utteranceId: String?) {
                        mainHandler.post {
                            if (!muted) requestListenTick += 1
                        }
                    }

                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        mainHandler.post {
                            state = VoiceCallState.ERROR
                            if (!muted) requestListenTick += 1
                        }
                    }
                })
                tts = engine
            }
        }

        onDispose {
            runCatching { speechRecognizerSafeDestroy(recognizer) }
            runCatching { engine.stop() }
            runCatching { engine.shutdown() }
            recognizer = null
            tts = null
        }
    }

    LaunchedEffect(Unit) {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            requestListenTick += 1
        } else {
            permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    LaunchedEffect(requestListenTick) {
        if (requestListenTick > 0 && !muted && !isSending) {
            delay(120)
            startListeningNow()
        }
    }

    LaunchedEffect(isSending, activity) {
        if (isSending) {
            runCatching { recognizer?.cancel() }
            state = if (activity == GatewayActivity.SEARCHING_WEB) VoiceCallState.SEARCHING else VoiceCallState.THINKING
        }
    }

    LaunchedEffect(messages.lastOrNull()?.id, isSending) {
        if (isSending) return@LaunchedEffect
        val last = messages.lastOrNull() ?: return@LaunchedEffect
        if (last.role != MessageRole.AION || last.id == lastHandledAssistantId) return@LaunchedEffect
        lastHandledAssistantId = last.id

        if (last.isError || last.text.isBlank()) {
            state = VoiceCallState.ERROR
            delay(700)
            if (!muted) requestListenTick += 1
            return@LaunchedEffect
        }

        val engine = tts
        if (engine == null) {
            if (!muted) requestListenTick += 1
        } else {
            state = VoiceCallState.SPEAKING
            engine.speak(last.text, TextToSpeech.QUEUE_FLUSH, null, "aion-call-${last.id}")
        }
    }

    val pulse = rememberInfiniteTransition(label = "voice-call-pulse")
    val pulseScale by pulse.animateFloat(
        initialValue = 0.96f,
        targetValue = when (state) {
            VoiceCallState.LISTENING -> 1.08f
            VoiceCallState.SPEAKING -> 1.12f
            else -> 1.04f
        },
        animationSpec = infiniteRepeatable(
            animation = tween(if (state == VoiceCallState.SPEAKING) 520 else 760),
            repeatMode = RepeatMode.Reverse
        ),
        label = "voice-call-core"
    )

    val status = when (state) {
        VoiceCallState.LISTENING -> "أسمعك…"
        VoiceCallState.THINKING -> "يفهم كلامك…"
        VoiceCallState.SEARCHING -> "يبحث في الويب…"
        VoiceCallState.SPEAKING -> "AION يتحدث"
        VoiceCallState.MUTED -> "الميكروفون متوقف"
        VoiceCallState.ERROR -> "لم ألتقط الصوت جيدًا — اضغط للمتابعة"
    }

    Dialog(
        onDismissRequest = {
            stopAudio()
            onDismiss()
        },
        properties = DialogProperties(
            usePlatformDefaultWidth = false,
            dismissOnBackPress = true,
            dismissOnClickOutside = false
        )
    ) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = Color(0xFF08080D)
        ) {
            Column(
                modifier = Modifier.fillMaxSize().padding(horizontal = 28.dp, vertical = 34.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("AION Voice", fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
                    Spacer(Modifier.height(6.dp))
                    Text("مكالمة داخل المحادثة نفسها", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(
                        modifier = Modifier
                            .size(170.dp)
                            .scale(pulseScale)
                            .background(AionPurpleStrong.copy(alpha = 0.12f), CircleShape)
                            .clickable {
                                when (state) {
                                    VoiceCallState.SPEAKING -> {
                                        tts?.stop()
                                        if (!muted) requestListenTick += 1
                                    }
                                    VoiceCallState.THINKING, VoiceCallState.SEARCHING -> onStop()
                                    else -> if (!muted) requestListenTick += 1
                                }
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = Color(0xFF1C112B),
                            border = BorderStroke(1.dp, AionPurpleSoft.copy(alpha = 0.55f)),
                            modifier = Modifier.size(116.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text("A", fontSize = 42.sp, fontWeight = FontWeight.Black, color = AionPurpleSoft)
                            }
                        }
                    }
                    Spacer(Modifier.height(28.dp))
                    Text(status, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center)
                    if (partialText.isNotBlank()) {
                        Spacer(Modifier.height(14.dp))
                        Text(
                            partialText,
                            modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp),
                            fontSize = 15.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center,
                            maxLines = 4
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        onClick = {
                            muted = !muted
                            if (muted) {
                                state = VoiceCallState.MUTED
                                recognizer?.cancel()
                            } else {
                                requestListenTick += 1
                            }
                        },
                        shape = CircleShape,
                        color = Color(0xFF1A1A22),
                        modifier = Modifier.size(58.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(if (muted) Icons.Outlined.MicOff else Icons.Outlined.Mic, contentDescription = "الميكروفون")
                        }
                    }

                    Surface(
                        onClick = {
                            stopAudio()
                            if (isSending) onStop()
                            onDismiss()
                        },
                        shape = CircleShape,
                        color = Color(0xFF8D2735),
                        modifier = Modifier.size(68.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(Icons.Outlined.CallEnd, contentDescription = "إنهاء المكالمة", tint = Color.White, modifier = Modifier.size(30.dp))
                        }
                    }

                    Surface(
                        onClick = {
                            if (isSending) onStop()
                            else {
                                tts?.stop()
                                requestListenTick += 1
                            }
                        },
                        shape = CircleShape,
                        color = Color(0xFF1A1A22),
                        modifier = Modifier.size(58.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(Icons.Outlined.Stop, contentDescription = "إيقاف/مقاطعة")
                        }
                    }
                }
            }
        }
    }
}

private fun speechRecognizerSafeDestroy(recognizer: SpeechRecognizer?) {
    recognizer?.cancel()
    recognizer?.destroy()
}
