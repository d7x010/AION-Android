package com.aion.mobile.core.ai

import android.content.Context

/**
 * عنوان خادم AION فقط. لا يحتوي التطبيق على مفتاح مزود أو كلمة مرور.
 * يمكن تغييره مؤقتًا أثناء اختبار Worker ثم تثبيته في نسخة الإصدار.
 */
object AionCloudSettings {
    private const val PREFS = "aion_cloud"
    private const val KEY_ENDPOINT = "endpoint"
    private const val DEFAULT_ENDPOINT = "https://aion-core.ali0077880000ali.workers.dev"

    fun loadEndpoint(context: Context): String =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_ENDPOINT, DEFAULT_ENDPOINT)
            .orEmpty()
            .trim()
            .trimEnd('/')

    fun saveEndpoint(context: Context, endpoint: String) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_ENDPOINT, endpoint.trim().trimEnd('/'))
            .apply()
    }
}
