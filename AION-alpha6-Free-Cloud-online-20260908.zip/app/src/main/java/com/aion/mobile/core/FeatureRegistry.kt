package com.aion.mobile.core

enum class CapabilityState {
    READY,
    FOUNDATION,
    PLANNED
}

data class AionCapability(
    val key: String,
    val title: String,
    val description: String,
    val state: CapabilityState
)

object FeatureRegistry {
    val capabilities = listOf(
        AionCapability("chat", "الدردشة", "واجهة المحادثة الأساسية", CapabilityState.READY),
        AionCapability("agent", "الوكيل الذكي", "تنفيذ مهام متعددة الخطوات", CapabilityState.FOUNDATION),
        AionCapability("memory", "الذاكرة", "حفظ السياق والتفضيلات", CapabilityState.FOUNDATION),
        AionCapability("files", "الملفات", "إرفاق الصور والملفات وقراءتها داخل المحادثة", CapabilityState.READY),
        AionCapability("voice", "الصوت", "إملاء صوتي وقراءة الردود؛ المحادثة الحية قيد التطوير", CapabilityState.FOUNDATION),
        AionCapability("search", "البحث", "بحث ويب حي مع عرض المصادر", CapabilityState.READY),
        AionCapability("tools", "الأدوات", "سجل أدوات قابل للتوسعة", CapabilityState.FOUNDATION)
    )
}
