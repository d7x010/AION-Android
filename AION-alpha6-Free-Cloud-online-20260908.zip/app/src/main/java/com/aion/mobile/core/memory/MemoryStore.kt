package com.aion.mobile.core.memory

interface MemoryStore {
    suspend fun remember(key: String, value: String)
    suspend fun recall(key: String): String?
    suspend fun forget(key: String)
}
