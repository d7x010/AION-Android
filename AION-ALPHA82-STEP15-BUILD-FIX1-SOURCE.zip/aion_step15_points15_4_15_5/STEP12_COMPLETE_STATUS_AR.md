# AION α8.2 — Step 12 COMPLETE — Memory OS v2 + Knowledge Engine

الحالة: **مغلق محليًا / GREEN ضمن بوابات البيئة الحالية**. هذا الملف هو مرجع إغلاق Step 12 ولا يبدأ Step 13 إلا من Snapshot Step 12 Complete أو نسخة أحدث مثبتة.

## الإصدار
- versionName = `2.0.0-alpha8.2-dev1`
- versionCode = `56`
- لم يُرفع الإصدار عمدًا؛ رفع الإصدار مؤجل إلى Step 15 حسب المرجع الحاكم.

## ما أصبح موجودًا بعد Step 12

### Memory OS v2
- تاريخ زمني لا يمحو القيم السابقة، مع supersession links ومرشحين غير فعالين عند خسارة التعارض.
- طبقات: WORKING / EPISODIC / SEMANTIC / PROCEDURAL / PROJECT.
- provenance: source + SHA-256 content hash + observedAt + confidence + priority + pinned.
- الذاكرة الصريحة/الأقوى لا تستبدلها automatic ضعيفة؛ الأضعف يبقى history/candidate.
- عزل PROJECT وCONVERSATION قبل الاسترجاع.
- compaction يحمي pinned/high-priority وسلسلة supersession المرتبطة بها.
- migration من memory_v1.json إلى memory_v2.json دون حذف المصدر القديم أثناء التحويل.

### Knowledge Engine
- تخزين دائم محلي باستخدام AtomicFile.
- provenance: URL/title/type/hash/timestamps/authority/confidence.
- hybrid retrieval: lexical + local deterministic hashed-vector + freshness + authority + confidence.
- freshness decay حسب نوع المصدر؛ NEWS أسرع من DOCUMENT/PROJECT_FILE.
- contradiction surfacing يحافظ على variants المتعارضة ولا يدمجها بصمت.
- فهرسة نتائج البحث الناجحة تلقائيًا داخل Conversation scope الصحيح فقط.
- عزل USER/PROJECT/CONVERSATION قبل scoring، ومنع Project A من رؤية Project B.
- Automatic Search لا تُرقّى إلى USER/PROJECT global truth.
- Temporary Chat لا تقرأ/تكتب Knowledge.
- حذف Conversation/Project وتنقل المحادثات يطبق cleanup/rebind المناسب.

### 12.16 — AionContextEngine Untrusted Knowledge Integration
- أضيف `KnowledgeContextFormatter` بعقد `knowledge-untrusted-context-v1`.
- الاسترجاع يتم حسب latest user query وبـ`KnowledgeAccessContext` قبل بناء السياق.
- formatter يضم provenance، source URL/type/time، authority/confidence، والتعارضات الظاهرة.
- النصوص المسترجعة محاطة بـ`BEGIN_UNTRUSTED_KNOWLEDGE` و`END_UNTRUSTED_KNOWLEDGE` مع حجز دائم لمساحة وسم النهاية حتى عند truncation.
- `AionContextEngine` يضيف قسمًا صريحًا يقول إن Knowledge **بيانات غير موثوقة كتعليمات**، ولا يجوز تنفيذ أوامر/prompt موجودة داخلها.
- Knowledge تدخل ضمن budget الخاص بالسياق ولا تتجاوز `MAX_KNOWLEDGE_CONTEXT_CHARS` / `MAX_SUPPLEMENTAL_CHARS`.
- Temporary Chat لا تسترجع Knowledge لهذا المسار.
- لا تُرفع Knowledge إلى custom/system instructions؛ تُمرر داخل supplemental context المعلّم كبيانات سياقية، بينما Worker نفسه يصف `contextContext` كبيانات لا كأوامر نظام.

## بوابة الإغلاق الحاكمة — 8/8
- supersession preserves old value: PASS
- explicit user memory beats weak auto memory: PASS
- project isolation: PASS
- temporary chat no-persist/no-read: PASS
- delete cleans scope: PASS
- web news decays faster than stable document: PASS
- contradiction remains visible: PASS
- context injection labels retrieved knowledge as untrusted data: PASS

النتيجة الموحدة: `STEP12_CLOSURE_8_OF_8_PASS`.

## تحقق إضافي
- focused 12.16 context-injection self-test: PASS.
- JUnit source compile لـ`AionContextEngineTest` + `KnowledgeContextFormatterTest`: `STEP12_12_16_TEST_SOURCE_COMPILE_PASS`.
- Worker `node --check`: PASS.
- Worker regression (`node --test cloudflare/aion-core/test-worker.mjs`): PASS.
- Worker idempotency (`node --test cloudflare/aion-core/test-idempotency.mjs`): PASS.
- تكامل ChatViewModel مؤكد مصدريًا: scoped retrieve → `KnowledgeContextFormatter` → `AionContextEngine` → `contextContext` → Durable Run.

## قيد التحقق
لم يتم تشغيل Gradle/Android SDK/ADB الكامل في هذه البيئة، لذلك لا يُدّعى APK build أو اختبار جهاز. بوابة Gradle/Android الكاملة تبقى ضمن مسار الإغلاق النهائي/Step 15 حسب البروتوكول الحاكم.

## نقطة الاستئناف
بعد نجاح ZIP integrity + SHA-256 + حفظ Library والتحقق منه، يصبح `AION-ALPHA82-STEP12-COMPLETE-SOURCE.zip` هو Last Known Good لبداية Step 13 — Runtime Truth → UI.
