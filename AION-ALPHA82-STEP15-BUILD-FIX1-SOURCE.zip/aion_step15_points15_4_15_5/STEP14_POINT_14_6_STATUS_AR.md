# AION Step 14 — Point 14.6 Supply-chain / Model-pack provenance

الحالة: **مكتملة محليًا ضمن حدود البيئة الحالية**.

## ما نُفذ
- إضافة provenance إلزامية لحزم النماذج عبر `ModelPackProvenance`.
- provenance تشمل نوع المصدر، URI، الناشر، وقت الاكتساب، وقت الإصدار، manifest SHA-256، خوارزمية التوقيع ومعرّف المفتاح.
- إضافة `ModelPackSupplyChainPolicy` كسياسة fail-closed قبل فحص bytes نفسها.
- Remote repositories تقبل HTTPS فقط؛ bundled/user-import محكومة بمخططات URI محددة.
- أي حزمة legacy بلا provenance موثقة تُرفض ولا تُرقّى للثقة بصمت.
- كل حزمة قابلة للتنفيذ تحتاج signature؛ لا يوجد hash-only trust.
- allowlist لخوارزميات التوقيع: Ed25519 / SHA256withECDSA / SHA256withRSA.
- manifest digest يربط هوية النموذج، الإصدار، الحجم، SHA-256، متطلبات التشغيل، المصدر، الناشر، أوقات provenance، الخوارزمية ومعرّف المفتاح.
- `ModelPackVerifier.signaturePayload()` يربط التوقيع بـmanifest digest + pack hash + algorithm + key id.
- الافتراضي `RejectingModelPackSignatureVerifier` بقي fail-closed حتى يُحقن production keyring/verifier حقيقي.
- رفع `local_models` schema إلى v2 مع بقاء قراءة v1 للترحيل.
- v2 يحفظ provenance كاملة في Local Model Registry.
- السجلات القديمة بلا provenance تُخفض إلى FAILED عند الاستعادة بسبب `provenance_required_after_upgrade`.

## الاختبارات
- `STEP14_POINT_14_6_SUPPLY_CHAIN_PASS`
- `STEP14_POINT_14_6_MANAGER_FLOW_PASS`
- `STEP14_POINT_14_6_MANAGER_COMPILE_PASS`
- `STEP14_POINT_14_6_TEST_SOURCE_COMPILE_PASS`

## القيد
- لا يوجد production keyring/verifier حقيقي ضمن هذه النقطة؛ الافتراضي يرفض بدل قبول توقيع وهمي.
- لا يوجد Gradle/Android SDK/ADB كامل في البيئة الحالية.
- لم يبدأ 14.7.
