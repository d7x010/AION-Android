# AION Step 14 — Point 14.6 Supply-chain / Model-pack Provenance

الحالة: **مكتملة محليًا ضمن حدود البيئة الحالية**.

## ما تم تنفيذه
- إضافة `ModelPackSourceType` لتسجيل نوع المصدر صراحة: remote repository / bundled release / user import / legacy unverified.
- توسيع `ModelPackProvenance` ليحفظ:
  - source type + source URI
  - publisher
  - acquiredAt / issuedAt
  - manifest SHA-256
  - signature algorithm
  - signer key id
- إضافة `ModelPackSupplyChainPolicy` بنمط fail-closed:
  - remote repositories يجب أن تكون HTTPS.
  - يمنع URL credentials/query/fragment حتى لا تُحفظ tokens داخل provenance.
  - legacy unverified مرفوض.
  - كل model pack يجب أن يكون موقّعًا؛ `requireSignature=false` القديم لا يسمح بتجاوز السياسة.
  - manifest digest يربط model identity + pack hash + الحجم + requirements + provenance.
  - أي تعديل على requirements أو المصدر بعد seal يؤدي إلى manifest mismatch.
- `ModelPackVerifier` يستخدم Rejecting verifier افتراضيًا؛ بدون keyring حقيقي لا يُقبل أي pack خارجي.
- signature payload يربط أيضًا RAM/storage/background requirements وmanifest digest، وليس hash الملف فقط.
- رفع schema سجل النماذج إلى v2 مع استمرار قراءة v1، وتخزين provenance الجديدة داخل registry.
- إضافة `tools/security/aion_supply_chain_gate.py`:
  - يمنع `mavenLocal()` و`jcenter()` وHTTP repositories.
  - يمنع dynamic/SNAPSHOT dependency versions.
  - يفرض central Gradle repositories.
  - يفرض exact semver لـnpm dependencies.
  - يفحص وجود عقد Model Pack provenance/signature/schema v2 في المصدر.

## الاختبارات
- `STEP14_14_6_SUPPLY_CHAIN_SELFTEST_PASS`
- `AION_SUPPLY_CHAIN_GATE_PASS`
- `AION_SECURITY_GATE_PASS`
- `STEP14_14_6_JUNIT_SOURCE_COMPILE_PASS`
- `STEP14_14_6_STEP11_BATCH2_SOURCE_SANITY_PASS`
- Worker core syntax: PASS
- Sandbox index/policy syntax: PASS

## ملاحظات صريحة
- لا يوجد Android SDK/Gradle/ADB كامل في هذه البيئة، لذلك لم يتم `assembleDebug` أو dependency verification metadata generation.
- عدم وجود keyring production حقيقي مقصود حاليًا: default verifier يرفض model packs بدل قبول توقيع غير قابل للتحقق.
- 14.7 Rollback / Last Known Good **لم يبدأ** في هذه النقطة.
