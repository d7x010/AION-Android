# AION Step 14 — Batch 1 (14.1 → 14.5)

الحالة: **مكتملة محليًا ضمن حدود البيئة الحالية**.

## 14.1 — Security Review
- مراجعة Manifest وFileProvider وbuild signing والتخزين الحساس.
- `android:allowBackup="false"` مثبت.
- `android:usesCleartextTraffic="false"` مثبت.
- المكوّن الوحيد `exported=true` هو MainActivity بوصفها Launcher.
- AionRunService / AionRecoveryJobService / AionRecoveryReceiver / FileProvider غير مصدّرة.
- FileProvider محصور داخل `files/aion_attachments/` فقط.
- لا تغيير في سياسات الموافقة/root security.

## 14.2 — Secrets Scan
- حذف `app/aion-debug.keystore` من المصدر.
- حذف signing config الذي كان يحتوي `storePassword/keyPassword` ثابتين من `app/build.gradle.kts`.
- debug build يعتمد Android debug signing القياسي الذي يُولد خارج المصدر.
- توسيع `.gitignore` ليشمل keystore/JKS/P12/PEM و`.env` و`.dev.vars` و`secrets.properties`.
- إضافة `tools/security/aion_security_gate.py` لفحص الأسرار عالية الثقة ومواد التوقيع.

## 14.3 — Manifest / Permissions Review
- البوابة الأمنية تفرض allowlist من 8 صلاحيات مطلوبة حاليًا فقط:
  INTERNET, ACCESS_NETWORK_STATE, RECEIVE_BOOT_COMPLETED, RECORD_AUDIO,
  MODIFY_AUDIO_SETTINGS, POST_NOTIFICATIONS, FOREGROUND_SERVICE,
  FOREGROUND_SERVICE_DATA_SYNC.
- أي permission إضافية تفشل البوابة بدل المرور بصمت.
- البوابة تفشل إذا ظهر exported component إضافي أو FileProvider أوسع من المسار الداخلي المحدد.

## 14.4 — Storage Migrations / Versioning
- إضافة `AionStorageSchemaRegistry` كسجل مركزي لعقود التخزين:
  - chat = 5 (readable 1..5)
  - memory = 2 (readable 1..2)
  - knowledge = 1
  - local_models = 1
  - run_request = 1
  - sovereign_task = 1
- schema المستقبلية تفشل مغلقًا، لمنع إصدار أقدم من إعادة كتابة بيانات إصدار أحدث.
- ChatSessionStore وMemory OS وKnowledge Codec وLocal Model Registry وRun Request/Task أصبحت مرتبطة بالسجل المركزي.
- migration القديمة للمحادثات وMemory v1→v2 بقيت غير هدامة.

## 14.5 — Corruption Recovery
- إضافة `DurableFileRecovery`:
  - تحقق قبل قبول الملف.
  - Last Known Good sidecar بصيغة `.lkg`.
  - استعادة primary تلقائيًا من LKG صالحة عند فساد primary.
  - إذا فسد primary وLKG معًا: القراءة تفشل مغلقًا والكتابة ترفض overwrite.
  - fsync + atomic move عند الإمكان.
- ربطها بـ:
  - ملفات المحادثات وstream checkpoints.
  - Memory OS v2.
  - Knowledge Engine.
  - Run request + SovereignTask.
  - Local Model Registry الثنائي.
- Memory upsert لم يعد يعيد نجاحًا وهميًا إذا فشل persist.
- Knowledge codec صار يملك `decodeStrict/isReadable` ويرفض header/schema المستقبلية أو الصفوف التالفة بدل إسقاطها بصمت.

## الاختبارات المنفذة
- `AION_SECURITY_GATE_PASS`
- `STEP14_STORAGE_RECOVERY_SELFTEST_PASS`
- `STEP14_KNOWLEDGE_VERSIONING_SELFTEST_PASS`
- `STEP14_LOCAL_REGISTRY_RECOVERY_PASS`
- `STEP14_CHAT_STORE_COMPILE_PASS`
- `STEP14_MEMORY_STORE_COMPILE_PASS`
- `STEP14_KNOWLEDGE_STORE_COMPILE_PASS`
- `STEP14_RUN_STORE_COMPILE_PASS`
- `STEP14_JUNIT_SOURCE_COMPILE_PASS`
- Consistency Recovery regression: **4/4 PASS**
- Step 11 regression: **12/12 PASS**
- Step 12 regression: **27/27 PASS**
- Step 13 runtime regression: **9/9 PASS**
- Worker syntax + regression: **PASS**
- Worker idempotency: **PASS**
- `STEP14_BATCH1_FINAL_SANITY_PASS`

## ما لم يُختبر
- لا يوجد Android SDK/Gradle/ADB كامل في هذه البيئة، لذلك لا يوجد ادعاء `assembleDebug`, lint, APK install أو اختبار جهاز.
- Play/API requirements وsupply-chain provenance وrollback/full release regression هي البنود التالية من Step 14 ولم تبدأ في هذه الدفعة.

## الإصدار
لم يُرفع الإصدار عمدًا:
- `versionName = 2.0.0-alpha8.2-dev1`
- `versionCode = 56`

رفع الإصدار يبقى لـStep 15 بعد استقرار المصدر كما يفرض المرجع الحاكم.
