# AION α8.2 — Step 12 Batch 2 (12.6 → 12.10)

الحالة: مكتملة كدفعة ثانية من Step 12. لا تبدأ 12.11 قبل الاعتماد على هذا الـSnapshot أو Snapshot أحدث محفوظ ومثبت.

## النطاق المنفذ

### 12.6 — Durable Knowledge Store
- إضافة `AionKnowledgeStore` كتخزين دائم على الجهاز باستخدام `AtomicFile`.
- إضافة `KnowledgeStoreCodec` بصيغة مستقرة قابلة لاختبار round-trip خارج Android.
- اختبار فعلي: `upsert -> fresh Context -> load` من القرص نجح.

### 12.7 — Provenance
لكل سجل معرفة:
- source URL
- source title
- source type
- SHA-256 content hash
- observed/fetched/published timestamps
- authority
- confidence

### 12.8 — Hybrid Retrieval
`KnowledgeEnginePolicy` يجمع:
- lexical relevance
- local deterministic hashed-vector similarity (128 dimensions)
- freshness
- authority
- confidence
ولا يحتاج شبكة أو embedding API.

### 12.9 — Freshness Decay
- NEWS: half-life سريع (2.5 days)
- WEB_PAGE: 30 days
- DOCUMENT / PROJECT_FILE: 365 days
- MANUAL: 730 days
- اختبار 30-day stale news مقابل stable document نجح ويثبت أن الخبر يهبط أسرع بكثير.

### 12.10 — Contradiction Surfacing
- السجلات التي تشترك في `claimKey` وتختلف في `claimValue` لا تُدمج كحقيقة واحدة.
- `KnowledgeRetrievalResult.contradictions` يعرض variants مستقلة مع المصدر، النوع، الوقت والثقة.

## ملفات الإنتاج الجديدة
- `app/src/main/java/com/aion/mobile/core/knowledge/AionKnowledgeModels.kt`
- `app/src/main/java/com/aion/mobile/core/knowledge/KnowledgeEnginePolicy.kt`
- `app/src/main/java/com/aion/mobile/core/knowledge/KnowledgeStoreCodec.kt`
- `app/src/main/java/com/aion/mobile/core/knowledge/AionKnowledgeStore.kt`

## الاختبارات
- `STEP12_BATCH2_SELFTEST_PASS`
- `STEP12_KNOWLEDGE_STORE_PERSISTENCE_PASS`
- `STEP12_BATCH2_TEST_SOURCE_COMPILE_PASS`
- `STEP12_BATCH1_SELFTEST_PASS` regression بعد إضافة Knowledge Engine

## حدود هذه الدفعة
لم تُنفذ بعد عناصر Knowledge Engine التالية:
- فهرسة نتائج البحث الناجحة تلقائيًا.
- enforcement الكامل لعزل Project/Conversation داخل Knowledge API.
- منع temporary chats من الكتابة.
- تنظيف knowledge عند حذف project/conversation.
- حقن knowledge داخل `AionContextEngine` كبيانات غير موثوقة نسبيًا.
هذه تبدأ من 12.11 وما بعدها.

## الإصدار
لم يُرفع الإصدار عمدًا:
- versionName = `2.0.0-alpha8.2-dev1`
- versionCode = `56`
رفع الإصدار يبقى مؤجلًا إلى Step 15 حسب المرجع الحاكم.
