# AION α8.2 — Step 12 Batch 1 (12.1 → 12.5)

الحالة: مكتملة كدفعة أولى من Step 12. لا يبدأ Knowledge Engine من هذا الملف قبل متابعة 12.6 وما بعدها.

## ما تم تنفيذه

### 12.1 — Temporal history + supersession
- لم يعد same-slot upsert يحذف القيمة السابقة.
- النسخة السابقة تبقى غير فعالة مع `supersededById`.
- النسخة الجديدة الفائزة تحمل `supersedesId`.
- المرشح الأضعف يبقى history/candidate غير فعال عبر `candidateAgainstId`.

### 12.2 — Memory layers
تم تثبيت الطبقات:
- WORKING
- EPISODIC
- SEMANTIC
- PROCEDURAL
- PROJECT

### 12.3 — Provenance + precedence
كل Memory Entry يدعم:
- source
- SHA-256 contentHash
- observedAt
- confidence
- priority
- pinned

والأولوية الصريحة/الموثوقة تمنع automatic منخفضة الثقة من استبدالها.

### 12.4 — Scope isolation
- PROJECT مرتبط projectId/ownerId.
- CONVERSATION مرتبط conversationId + projectId عند وجود مشروع.
- لا يعبر Project A إلى Project B.
- conversation داخل مشروع لا يُقرأ في مشروع آخر حتى لو حصل تعارض في conversation id.

### 12.5 — Compaction safety
- compaction يحمي pinned/high-priority.
- يحافظ على سلسلة supersession المباشرة للذكريات المحمية.
- بقية العناصر تُخفض وفق النشاط والحداثة ضمن budget.

## Storage migration
- schema الجديد: Memory OS v2.
- التخزين الجديد: `aion_memory/memory_v2.json`.
- عند غيابه تتم قراءة `memory_v1.json` وتحويله إلى بنية v2 ثم حفظه في الملف الجديد.
- الملف القديم لا يُمسح أثناء migration.

## التحقق المنفذ
- `STEP12_BATCH1_SELFTEST_PASS`
  - supersession history
  - explicit > weak automatic
  - required layers
  - project/conversation isolation
  - pinned/high-priority compaction
  - provenance hash/time
- Android store compile check باستخدام Kotlin compiler الحقيقي مع stubs خارج المشروع: PASS.
- Memory v1/v2 JUnit source compile check: PASS.
- `STEP12_BATCH1_SOURCE_SANITY_PASS`.

## قيد التحقق
لم يتم تشغيل Gradle/Android SDK build الكامل في هذه البيئة. هذا مؤجل لبوابة البناء النهائية حسب الخطة الحاكمة، ولا يُدّعى خلاف ذلك.

## نقطة الاستئناف التالية
Step 12 التالي يبدأ من Knowledge Engine ومتطلبات التخزين/الاسترجاع/النطاقات، فوق هذا Snapshot فقط.
