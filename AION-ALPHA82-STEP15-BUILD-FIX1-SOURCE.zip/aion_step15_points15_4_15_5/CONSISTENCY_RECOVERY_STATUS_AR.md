# AION α8.2 — Consistency Recovery Status

**التاريخ:** 2026-09-12  
**القاعدة:** هذه المرحلة أُعيد بناؤها فوق Snapshot Step 10 المؤكد `2.0.0-alpha8.2-dev1 / versionCode 56`.  
**الحالة:** Consistency Recovery مغلقة على مستوى المصدر واختبارات الاستمرارية المحددة في HANDOFF. لم يُنفّذ Gradle/Android SDK build كامل في هذه البيئة، لذلك لا يوجد ادعاء APK أو Build Android كامل.

## ما تم تنفيذه

- تخزين دائم لـ`AionRunRequest` و`SovereignTask` على القرص.
- Execution Lease دائم مع acquire/renew/release وtakeover بعد انتهاء lease ومنع double-run.
- Durable backoff/not-before.
- Durable Tool Receipt / Side-Effect Ledger، مع مزامنة receipt الخادم إلى Android.
- Recovery Engine يعتمد على التخزين الدائم، و`AionRunRegistry` يبقى cache سريعًا فقط.
- `/v1/run/status` reconciliation باستخدام نفس `Idempotency-Key`.
- حالات server: `COMPLETED / TOOLS_COMPLETED / IN_PROGRESS / MISSING / FAILED / UNAVAILABLE`.
- كسر حلقة `IN_PROGRESS` عند انتهاء Server Lease: الانتظار أثناء lease ثم `RESUME_RUN` بعد انتهائها.
- fail-closed للأداة mutating إذا أصبحت نتيجتها غامضة؛ لا replay محلي تلقائي.
- durable cancellation fence قبل الإيقاف، و`cancelAll` يكتب fence لكل Run محفوظ.
- Service guards للحالات terminal/cancelled/backoff/lease.
- Recovery داخل `JobService` نفسه بدل تشغيل Foreground Service جديد من الخلفية على Android 12+.
- فصل General Recovery عن Network Recovery؛ Network Job لا يستخدم `overrideDeadline` الذي قد يسقط شرط الشبكة.
- معالجة دفعة من Runs بدل توقف recovery عند أول Run عليه lease/backoff؛ حد الدورة الحالي 3 Runs.
- منع جدولة موعد متأخر فوق موعد recovery أسبق.
- Worker server-side idempotency عبر Durable Object: نفس المفتاح والطلب لا يعيدان الموديل؛ اختلاف payload يعيد 409.
- lease/heartbeat على Worker و`425 Retry-After` قابل للحفظ كـdurable not-before على Android.
- SSE ↔ Sync replay بنفس `Idempotency-Key` بدون إعادة تنفيذ الموديل.
- حفظ `responseStatus` الدلالي الأصلي حتى لا يتحول 5xx مؤقت إلى 200 أثناء reconciliation.
- Retryable Worker failures تصبح `FAILED_RECOVERABLE` ويمكن استئنافها بنفس المفتاح.
- Worker tool receipt يمر بمراحل فعلية مثل `PREPARED / STARTED / COMPLETED / UNKNOWN` مع حماية mutating ambiguity.
- النتائج الكبيرة تُخزّن في bounded chunks بدل تجاوز حد قيمة Durable Object الواحدة، ثم يعاد تركيبها عند replay مع digest.
- ترتيب بدء Run: persist request/task → schedule durable recovery → registry cache → محاولة تشغيل service.

## الاختبارات التي نجحت

### Worker
- `node --check cloudflare/aion-core/src/index.js` — PASS.
- `node --test cloudflare/aion-core/test-worker.mjs` — PASS.
- `node --test cloudflare/aion-core/test-idempotency.mjs` — PASS.
- `node --test cloudflare/aion-sandbox/test-policy.mjs` — PASS.

تتضمن حالات idempotency المختبرة فعليًا:
- نفس المفتاح + نفس payload لا يعيد تنفيذ الموديل.
- نفس المفتاح + payload مختلف → 409.
- `COMPLETED` replay بلا re-execution.
- `TOOLS_COMPLETED` يكمل الموديل فقط من tool snapshot محفوظ.
- active server lease → 425 + Retry-After.
- mutating tool بحالة `STARTED` بعد فقدان lease → fail-closed ولا replay.
- byte-identical SSE replay.
- SSE مكتمل ثم `/v1/chat` sync replay كـJSON بلا استدعاء موديل جديد.
- 5xx يحتفظ بالحالة الأصلية عبر `/v1/run/status` ثم يستأنف بنفس المفتاح.
- نتيجة أكبر من 2 MB تقريبًا تُقسم إلى chunks ثم replay كامل بلا استدعاء موديل ثانٍ.

### Android durability / fault matrix
تمت إعادة ترجمة وتشغيل `ConsistencyRecoveryJvmSelfTest.kt` من المصدر الحالي نفسه، والنتيجة PASS. وهو يغطي:
- persistence round-trip لـbackoff وtool receipt.
- server tool receipt mirroring إلى التخزين الدائم المحلي.
- process recreation / lease takeover بعد expiry.
- 32-way lease race مع فائز واحد فقط.
- cancellation-vs-restart fence.
- terminal task never resumes.
- ambiguous mutating tool never locally replays.
- server `COMPLETED` → restore final.
- `TOOLS_COMPLETED` → continue model only.
- missing durable request → fail closed.
- server `MISSING` لا يدخل reconciliation loop عاديًا، مع fail-closed إذا كان هناك mutating tool غامض.
- durable not-before/backoff survives restart decision.

### Compile / source invariants
- تم تجميع ملفات Consistency Recovery المعدلة معًا بواسطة `kotlinc 1.9.0` وcoroutines الفعلية، مع Android/API stubs مؤقتة خارج المشروع فقط لتوفير أنواع Android في بيئة لا تحتوي Android SDK — PASS.
- لا يوجد `startForegroundService()` داخل `AionRecovery.kt` — PASS.
- Network recovery يحتفظ بـ`NETWORK_TYPE_ANY` ولا يملك `setOverrideDeadline()` في فرع الشبكة — PASS.
- Android service وJob recovery كلاهما يستوردان server tool receipts — PASS.
- ترتيب persist → schedule recovery → service في `AionRunCoordinator` — PASS.
- Manifest يحتوي `AionRecoveryJobService` و`AionRecoveryReceiver` — PASS.

## ما لم يُختبر في هذه البيئة

- لم يتوفر `gradle` أو Android SDK/`sdkmanager` أو `adb` في البيئة الحالية؛ لذلك لم يتم تشغيل `:app:testDebugUnitTest`, `:app:lintDebug`, أو `:app:assembleDebug` محليًا.
- لم يتم تثبيت APK على جهاز فعلي أو Emulator في هذه المرحلة.
- لم يتم نشر Worker إلى Cloudflare ضمن Consistency Recovery؛ الاختبارات كانت محلية ضد Worker source/Durable Object test harness.

هذه القيود لا تُفسَّر على أنها نجاح Gradle أو APK. بوابة Build/Release الكاملة تبقى مرحلة لاحقة وفق HANDOFF، ولا يبدأ Step 11 إلا من Snapshot هذه المرحلة المحفوظة.

## الملفات الإنتاجية الرئيسية التي تغيرت عن Step 10

- `app/src/main/java/com/aion/mobile/core/ai/AionCloudGateway.kt`
- `app/src/main/java/com/aion/mobile/core/run/AionRunCoordinator.kt`
- `app/src/main/java/com/aion/mobile/core/run/AionRunService.kt`
- `app/src/main/java/com/aion/mobile/core/run/AionRecovery.kt`
- `app/src/main/java/com/aion/mobile/core/run/AionJobRecoveryRunner.kt`
- `app/src/main/java/com/aion/mobile/core/run/DurableRunPrimitives.kt`
- `app/src/main/java/com/aion/mobile/core/run/DurableRunStore.kt`
- `app/src/main/java/com/aion/mobile/core/run/fault/LifecycleFaultMatrix.kt`
- `app/src/main/AndroidManifest.xml`
- `cloudflare/aion-core/src/index.js`
- `cloudflare/aion-core/wrangler.toml`

## اختبارات/أدوات جديدة أو محدثة

- `app/src/test/java/com/aion/mobile/core/run/ConsistencyRecoveryTest.kt`
- `app/src/test/java/com/aion/mobile/core/run/ConsistencyRecoveryDurableStoreTest.kt`
- `cloudflare/aion-core/test-idempotency.mjs`
- `ConsistencyRecoveryJvmSelfTest.kt`
- `app/build.gradle.kts` لدعم JVM JSON tests.

## نقطة الاستئناف التالية

بعد التأكد من ZIP + SHA-256 + Library save، تكون النقطة التالية **Step 11 — Local Intelligence + Model Manager + Resource Governor**. لا يوجد أي كود Step 11 معتمد ضمن هذه الحالة إلا إذا كان موجودًا أصلًا في Step 10 baseline.
