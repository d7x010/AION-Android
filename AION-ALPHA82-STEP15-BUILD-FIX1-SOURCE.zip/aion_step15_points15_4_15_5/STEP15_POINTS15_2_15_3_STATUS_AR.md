# AION — Step 15.2 + 15.3 Status

التاريخ: 2026-09-12

## النطاق
- 15.2: Gradle unit tests / build verification.
- 15.3: Android Lint / quality gate.

## النتيجة الحالية
الحالة: **BLOCKED_EXTERNAL / FAIL-CLOSED**.

لم يتم الادعاء بنجاح Gradle أو Android Lint لأنهما لم يُشغلا فعليًا في بيئة Android مكتملة.

## ما تم إثباته
- Step 15 version gate: PASS.
- Play/API static gate: PASS.
- Security gate: PASS.
- Supply-chain gate: PASS.
- Rollback gate: PASS.
- Full regression gate (Worker + idempotency + sandbox + source gates): PASS.
- fail-closed gate self-test لـ15.2/15.3: PASS.

## البوابة الجديدة
`tools/release/aion_step15_gradle_lint_gate.py`

سلوكها:
1. تتحقق من هوية التطبيق والإصدار وcompileSdk/targetSdk/AGP.
2. تتطلب Gradle >= 9.6.0.
3. تتطلب Android SDK platform android-36 وBuild Tools 36.0.0.
4. تشغّل فعليًا:
   - `:app:testDebugUnitTest`
   - `:app:lintDebug`
5. لا تعلن PASS إلا إذا عاد Gradle بصفر ووجد تقرير Lint فعليًا.
6. عند غياب البيئة تعيد exit code 2 = BLOCKED، ولا تنشئ Evidence نجاح.

اختبار البوابة:
- `STEP15_15_2_15_3_GATE_SELFTEST_PASS`
- البيئة الحالية: `AION_STEP15_GRADLE_LINT_GATE_BLOCKED`
  - `gradle_missing`
  - `android_sdk_missing`
  - `gradle_unit_tests=NOT_RUN`
  - `android_lint=NOT_RUN`

## محاولات فك الحظر
- Java متوفر محليًا.
- الحاوية لا تملك Gradle Wrapper/Gradle/Android SDK.
- DNS/الاتصال الخارجي من shell غير متاح، لذلك لم يمكن bootstrap لـGradle/SDK محليًا.
- GitHub repository قابل للقراءة، ويوجد Workflow قديم يثبت أن GitHub Actions قادر على Android API 36/Gradle/Lint.
- لكن GitHub connector الحالي رفض إنشاء branch ورفض إنشاء ملف Contents API برسالة `403 Resource not accessible by integration`، لذلك لم يمكن رفع Snapshot الحالي وتشغيل CI عليه.

## قرار الأمان
- لا PASS وهمي لـ15.2 أو15.3.
- لا انتقال إلى 15.4 قبل وجود دليل فعلي على `testDebugUnitTest` و`lintDebug`.
- `release/STEP15_GRADLE_LINT_DECISION.json` يسجل الحالة الحالية.

## ما يفك الحظر
أحد المسارين فقط:
1. بيئة تنفيذ فيها Gradle 9.6+ وAndroid SDK 36/Build Tools 36.0.0؛ أو
2. صلاحية GitHub Contents/Actions write فعلية لرفع Snapshot الحالي وتشغيل CI.
