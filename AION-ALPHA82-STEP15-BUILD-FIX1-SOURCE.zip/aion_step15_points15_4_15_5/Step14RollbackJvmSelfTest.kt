import com.aion.mobile.core.release.AionReleaseRollbackPolicy
import com.aion.mobile.core.release.RollbackSchemaRange

private fun checkThat(value: Boolean, message: String) {
    if (!value) error(message)
}

fun main() {
    val oneFailure = AionReleaseRollbackPolicy.evaluateStartup(1)
    checkThat(!oneFailure.enterSafeMode && !oneFailure.requestExternalRollback, "one failure must not trigger rollback")

    val crashLoop = AionReleaseRollbackPolicy.evaluateStartup(2)
    checkThat(crashLoop.enterSafeMode, "two failures must enter safe mode")
    checkThat(crashLoop.requestExternalRollback, "two failures must request external rollback")

    val target = listOf(
        RollbackSchemaRange("chat", 5, 1),
        RollbackSchemaRange("memory", 2, 1),
        RollbackSchemaRange("knowledge", 1, 1),
        RollbackSchemaRange("local_models", 2, 1),
        RollbackSchemaRange("run_request", 1, 1),
        RollbackSchemaRange("sovereign_task", 1, 1),
    )
    val current = mapOf("chat" to 5, "memory" to 2, "knowledge" to 1, "local_models" to 2, "run_request" to 1, "sovereign_task" to 1)
    checkThat(AionReleaseRollbackPolicy.storageCompatible(current, target), "LKG must read all current schemas")

    val oldTarget = target.map { if (it.id == "local_models") it.copy(currentVersion = 1) else it }
    checkThat(!AionReleaseRollbackPolicy.storageCompatible(current, oldTarget), "rollback must reject unreadable current schema")

    checkThat(AionReleaseRollbackPolicy.nextRollbackVersionCode(56, 56) == 57, "rollback rebuild must increase versionCode")
    checkThat(AionReleaseRollbackPolicy.nextRollbackVersionCode(60, 56) == 61, "installed code remains monotonic")

    println("STEP14_14_7_ROLLBACK_POLICY_PASS")
}
