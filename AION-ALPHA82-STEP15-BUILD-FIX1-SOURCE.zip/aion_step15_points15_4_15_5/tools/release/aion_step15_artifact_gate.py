#!/usr/bin/env python3
from __future__ import annotations

import argparse, hashlib, json, os, re, shutil, subprocess, sys, zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
EXPECTED_APP_ID = "com.aion.mobile"
EXPECTED_VERSION_NAME = "2.0.0-alpha8.2-dev2"
EXPECTED_VERSION_CODE = 57


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def read_version(root: Path) -> tuple[str, int, str]:
    text = (root / "app" / "build.gradle.kts").read_text(encoding="utf-8")
    def m(p: str, name: str) -> str:
        x = re.search(p, text)
        if not x: raise ValueError(f"{name}_missing")
        return x.group(1)
    return (
        m(r'applicationId\s*=\s*"([^"]+)"', "application_id"),
        int(m(r'versionCode\s*=\s*(\d+)', "version_code")),
        m(r'versionName\s*=\s*"([^"]+)"', "version_name"),
    )


def verify_zip(path: Path) -> list[str]:
    try:
        with zipfile.ZipFile(path) as z:
            bad = z.testzip()
            if bad: return [f"zip_corrupt:{bad}"]
            if not z.namelist(): return ["zip_empty"]
    except Exception as exc:
        return [f"zip_invalid:{type(exc).__name__}"]
    return []


def verify_signature(path: Path, kind: str) -> tuple[list[str], str]:
    if kind == "aab":
        tool = shutil.which("jarsigner")
        if not tool: return ["jarsigner_missing"], "NOT_RUN"
        p = subprocess.run([tool, "-verify", "-strict", str(path)], text=True,
                           stdout=subprocess.PIPE, stderr=subprocess.STDOUT, check=False, timeout=120)
        return ([] if p.returncode == 0 else [f"aab_signature_invalid:{p.returncode}"]), ("PASS" if p.returncode == 0 else "FAIL")
    tool = shutil.which("apksigner")
    if not tool: return ["apksigner_missing"], "NOT_RUN"
    p = subprocess.run([tool, "verify", "--verbose", str(path)], text=True,
                       stdout=subprocess.PIPE, stderr=subprocess.STDOUT, check=False, timeout=120)
    return ([] if p.returncode == 0 else [f"apk_signature_invalid:{p.returncode}"]), ("PASS" if p.returncode == 0 else "FAIL")


def main() -> int:
    ap = argparse.ArgumentParser(description="AION Step 15.4 fail-closed APK/AAB artifact gate")
    ap.add_argument("--root", type=Path, default=ROOT)
    ap.add_argument("--artifact", type=Path)
    ap.add_argument("--gradle-evidence", type=Path, default=ROOT / "release" / "STEP15_GRADLE_LINT_EVIDENCE.json")
    ap.add_argument("--evidence-out", type=Path)
    ap.add_argument("--skip-signature", action="store_true", help="self-test only; never use for release evidence")
    args = ap.parse_args()
    root = args.root.resolve()

    try:
        app_id, version_code, version_name = read_version(root)
    except Exception as exc:
        print(f"AION_STEP15_ARTIFACT_GATE_FAIL version:{exc}")
        return 1
    errors = []
    if app_id != EXPECTED_APP_ID: errors.append(f"application_id_unexpected:{app_id}")
    if version_code != EXPECTED_VERSION_CODE: errors.append(f"version_code_unexpected:{version_code}")
    if version_name != EXPECTED_VERSION_NAME: errors.append(f"version_name_unexpected:{version_name}")
    if errors:
        print("AION_STEP15_ARTIFACT_GATE_FAIL")
        for e in errors: print("-", e)
        return 1

    ge = args.gradle_evidence.resolve()
    if not ge.is_file():
        print("AION_STEP15_ARTIFACT_GATE_BLOCKED")
        print("- gradle_lint_evidence_missing")
        print("artifact=NOT_BUILT")
        return 2
    try:
        g = json.loads(ge.read_text(encoding="utf-8"))
    except Exception:
        print("AION_STEP15_ARTIFACT_GATE_FAIL gradle_evidence_invalid")
        return 1
    if not (g.get("gradle_unit_tests_pass") is True and g.get("lint_pass") is True):
        print("AION_STEP15_ARTIFACT_GATE_BLOCKED")
        print("- gradle_or_lint_not_pass")
        return 2

    if args.artifact is None:
        print("AION_STEP15_ARTIFACT_GATE_BLOCKED")
        print("- artifact_path_missing")
        return 2
    artifact = args.artifact.resolve()
    if not artifact.is_file() or artifact.stat().st_size == 0:
        print("AION_STEP15_ARTIFACT_GATE_BLOCKED")
        print("- artifact_missing_or_empty")
        return 2
    kind = artifact.suffix.lower().lstrip(".")
    if kind not in {"apk", "aab"}:
        print("AION_STEP15_ARTIFACT_GATE_FAIL unsupported_artifact_type")
        return 1
    z_errors = verify_zip(artifact)
    if z_errors:
        print("AION_STEP15_ARTIFACT_GATE_FAIL")
        for e in z_errors: print("-", e)
        return 1

    signature_status = "SKIPPED_SELFTEST" if args.skip_signature else "NOT_RUN"
    if not args.skip_signature:
        s_errors, signature_status = verify_signature(artifact, kind)
        if s_errors:
            if any(e.endswith("_missing") for e in s_errors):
                print("AION_STEP15_ARTIFACT_GATE_BLOCKED")
                for e in s_errors: print("-", e)
                return 2
            print("AION_STEP15_ARTIFACT_GATE_FAIL")
            for e in s_errors: print("-", e)
            return 1

    digest = sha256(artifact)
    payload = {
        "schema": 1,
        "step": "15.4",
        "application_id": app_id,
        "version_name": version_name,
        "version_code": version_code,
        "artifact_name": artifact.name,
        "artifact_type": kind,
        "artifact_size": artifact.stat().st_size,
        "sha256": digest,
        "signature_verified": signature_status == "PASS",
        "signature_status": signature_status,
        "gradle_unit_tests_pass": True,
        "lint_pass": True,
    }
    if args.evidence_out:
        out = args.evidence_out.resolve(); out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print("AION_STEP15_ARTIFACT_GATE_PASS")
    print(f"artifact={artifact}")
    print(f"sha256={digest}")
    print(f"signature={signature_status}")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
