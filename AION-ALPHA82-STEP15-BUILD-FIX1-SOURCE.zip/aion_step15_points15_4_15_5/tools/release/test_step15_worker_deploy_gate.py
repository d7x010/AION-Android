#!/usr/bin/env python3
from __future__ import annotations
import subprocess
from pathlib import Path
ROOT = Path(__file__).resolve().parents[2]
GATE = ROOT / "tools/release/aion_step15_worker_deploy_gate.py"
p = subprocess.run(["python3", str(GATE), "--root", str(ROOT)], text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
assert p.returncode == 0, p.stdout
assert "worker_tests=PASS" in p.stdout and "idempotency_tests=PASS" in p.stdout
q = subprocess.run(["python3", str(GATE), "--root", str(ROOT), "--require-dry-run"], text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
assert q.returncode in (0,2), q.stdout
if q.returncode == 2: assert "wrangler_missing_for_dry_run" in q.stdout
print("STEP15_15_5_WORKER_DEPLOY_GATE_SELFTEST_PASS")
