#!/usr/bin/env python3
from __future__ import annotations

import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
BUILD = ROOT / "app" / "build.gradle.kts"
LKG = ROOT / "release" / "LAST_KNOWN_GOOD.json"

APP_RE = re.compile(r'applicationId\s*=\s*"([^"]+)"')
NAME_RE = re.compile(r'versionName\s*=\s*"([^"]+)"')
CODE_RE = re.compile(r'versionCode\s*=\s*(\d+)')

EXPECTED_APP = "com.aion.mobile"
EXPECTED_NAME = "2.0.0-alpha8.2-dev2"
EXPECTED_CODE = 57


def parse_build(text: str) -> tuple[str, str, int]:
    app = APP_RE.search(text)
    name = NAME_RE.search(text)
    code = CODE_RE.search(text)
    if not (app and name and code):
        raise ValueError("build_metadata_missing")
    return app.group(1), name.group(1), int(code.group(1))


def validate(app: str, name: str, code: int, lkg: dict[str, object]) -> list[str]:
    errors: list[str] = []
    if app != EXPECTED_APP:
        errors.append("application_id_changed")
    if app != str(lkg.get("application_id", "")):
        errors.append("application_id_differs_from_lkg")
    if name != EXPECTED_NAME:
        errors.append(f"unexpected_version_name:{name}")
    if code != EXPECTED_CODE:
        errors.append(f"unexpected_version_code:{code}")
    if code <= int(lkg.get("version_code", -1)):
        errors.append("version_code_not_monotonic")
    if name == str(lkg.get("version_name", "")):
        errors.append("version_name_not_bumped")
    return errors


def main() -> int:
    try:
        app, name, code = parse_build(BUILD.read_text(encoding="utf-8"))
        lkg = json.loads(LKG.read_text(encoding="utf-8"))
        errors = validate(app, name, code, lkg)
    except Exception as exc:
        print(f"AION_STEP15_VERSION_GATE_FAIL {exc}")
        return 1

    if errors:
        print("AION_STEP15_VERSION_GATE_FAIL")
        for error in errors:
            print("-", error)
        return 1

    print("AION_STEP15_VERSION_GATE_PASS")
    print(f"application_id={app}")
    print(f"version_name={name}")
    print(f"version_code={code}")
    print(f"lkg_version_name={lkg['version_name']}")
    print(f"lkg_version_code={lkg['version_code']}")
    print(f"next_rollback_rebuild_version_code={max(code, int(lkg['version_code'])) + 1}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
