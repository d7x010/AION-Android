#!/usr/bin/env python3
from __future__ import annotations

import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
APP_GRADLE = ROOT / "app" / "build.gradle.kts"
ROOT_GRADLE = ROOT / "build.gradle.kts"
MANIFEST = ROOT / "app" / "src" / "main" / "AndroidManifest.xml"
MAIN_ACTIVITY = ROOT / "app" / "src" / "main" / "java" / "com" / "aion" / "mobile" / "MainActivity.kt"
RUN_SERVICE = ROOT / "app" / "src" / "main" / "java" / "com" / "aion" / "mobile" / "core" / "run" / "AionRunService.kt"
RECOVERY = ROOT / "app" / "src" / "main" / "java" / "com" / "aion" / "mobile" / "core" / "run" / "AionRecovery.kt"

REQUIRED_TARGET_API = 36  # Google Play mobile apps/updates, effective 2026-08-31.
REQUIRED_COMPILE_API = 36 # Android 16 SDK.
MIN_API36_AGP = (8, 9)

class GateError(RuntimeError):
    pass


def read(path: Path) -> str:
    if not path.exists():
        raise GateError(f"missing:{path.relative_to(ROOT)}")
    return path.read_text(encoding="utf-8")


def int_value(text: str, key: str) -> int:
    m = re.search(rf"\b{re.escape(key)}\s*=\s*(\d+)", text)
    if not m:
        raise GateError(f"missing_{key}")
    return int(m.group(1))


def agp_version(text: str) -> tuple[int, int, int]:
    m = re.search(r'id\("com\.android\.application"\)\s+version\s+"(\d+)\.(\d+)\.(\d+)', text)
    if not m:
        raise GateError("missing_agp_version")
    return tuple(map(int, m.groups()))


def assert_true(cond: bool, code: str) -> None:
    if not cond:
        raise GateError(code)


def native_sources() -> list[Path]:
    hits: list[Path] = []
    for p in (ROOT / "app").rglob("*"):
        if not p.is_file():
            continue
        if p.suffix == ".so" or p.name in {"CMakeLists.txt", "Android.mk", "Application.mk"}:
            hits.append(p)
    return hits


def main() -> int:
    try:
        app_gradle = read(APP_GRADLE)
        root_gradle = read(ROOT_GRADLE)
        manifest = read(MANIFEST)
        main_activity = read(MAIN_ACTIVITY)
        run_service = read(RUN_SERVICE)
        recovery = read(RECOVERY)

        compile_sdk = int_value(app_gradle, "compileSdk")
        target_sdk = int_value(app_gradle, "targetSdk")
        assert_true(compile_sdk >= REQUIRED_COMPILE_API, f"compileSdk_too_low:{compile_sdk}")
        assert_true(target_sdk >= REQUIRED_TARGET_API, f"targetSdk_too_low:{target_sdk}")

        agp = agp_version(root_gradle)
        assert_true((agp[0], agp[1]) >= MIN_API36_AGP, f"agp_too_old:{'.'.join(map(str, agp))}")

        # Android 16 edge-to-edge: opt-out no longer works for target 36.
        assert_true("enableEdgeToEdge()" in main_activity, "edge_to_edge_not_enabled")
        assert_true("windowOptOutEdgeToEdgeEnforcement" not in manifest, "edge_to_edge_opt_out_present")

        # Predictive Back: reject legacy interception that Android 16 no longer dispatches.
        src_text = "\n".join(
            p.read_text(encoding="utf-8", errors="ignore")
            for p in (ROOT / "app" / "src" / "main").rglob("*.kt")
        )
        assert_true("KEYCODE_BACK" not in src_text, "legacy_keycode_back_present")
        assert_true("onBackPressed()" not in src_text, "legacy_onBackPressed_present")

        # Android 14+/15+ dataSync foreground service contract.
        assert_true('android.permission.FOREGROUND_SERVICE_DATA_SYNC' in manifest, "missing_fgs_data_sync_permission")
        assert_true('android:foregroundServiceType="dataSync"' in manifest, "missing_fgs_data_sync_type")
        assert_true("override fun onTimeout(startId: Int, fgsType: Int)" in run_service, "missing_data_sync_timeout_handler")
        assert_true("stopSelf(startId)" in run_service, "timeout_does_not_stop_service")
        assert_true("stopForeground(STOP_FOREGROUND_REMOVE)" in run_service, "timeout_does_not_remove_foreground")

        # BOOT_COMPLETED must schedule durable recovery rather than launch dataSync FGS.
        receiver_pos = recovery.find("class AionRecoveryReceiver")
        assert_true(receiver_pos >= 0, "missing_recovery_receiver")
        receiver_body = recovery[receiver_pos:]
        assert_true("AionRecoveryScheduler.scheduleGeneral(context)" in receiver_body, "boot_does_not_schedule_job")
        assert_true("startForegroundService" not in receiver_body, "boot_launches_fgs")

        # Google Play technical quality: Java/Kotlin-only app is compatible with 64-bit/16 KB by default.
        natives = native_sources()
        assert_true(not natives, "native_code_requires_64bit_16kb_artifact_verification:" + ",".join(str(p.relative_to(ROOT)) for p in natives[:5]))

        # Google Play publishing format source readiness: application plugin provides bundle task.
        assert_true('id("com.android.application")' in app_gradle, "android_application_plugin_missing")

        print(f"compileSdk={compile_sdk}")
        print(f"targetSdk={target_sdk}")
        print(f"agp={'.'.join(map(str, agp))}")
        print("edge_to_edge=PASS")
        print("predictive_back_static_check=PASS")
        print("fgs_data_sync_manifest=PASS")
        print("fgs_data_sync_timeout=PASS")
        print("boot_completed_fgs_restriction=PASS")
        print("native_code=NONE java_kotlin_64bit_16kb=PASS")
        print("app_bundle_source_ready=PASS actual_signed_aab=DEFERRED_STEP15")
        print("play_console_external_action=FGS_DATA_SYNC_DECLARATION_REQUIRED")
        print("play_console_external_action=DATA_SAFETY_AND_STORE_DECLARATIONS_REQUIRE_CONSOLE_REVIEW")
        print("AION_PLAY_API_GATE_PASS")
        return 0
    except GateError as exc:
        print(f"AION_PLAY_API_GATE_FAIL {exc}")
        return 1

if __name__ == "__main__":
    raise SystemExit(main())
