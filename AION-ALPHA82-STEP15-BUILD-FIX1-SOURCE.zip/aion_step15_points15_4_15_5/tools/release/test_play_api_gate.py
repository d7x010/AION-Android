import importlib.util
from pathlib import Path

path = Path(__file__).with_name("aion_play_api_gate.py")
spec = importlib.util.spec_from_file_location("aion_play_api_gate", path)
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)

assert mod.REQUIRED_TARGET_API == 36
assert mod.REQUIRED_COMPILE_API == 36
assert mod.MIN_API36_AGP == (8, 9)
assert mod.native_sources() == []
print("STEP14_14_9_PLAY_API_GATE_SELFTEST_PASS")
