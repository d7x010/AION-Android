#!/usr/bin/env python3
from __future__ import annotations
import json, subprocess, tempfile, zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
GATE = ROOT / "tools/release/aion_step15_artifact_gate.py"
with tempfile.TemporaryDirectory() as td:
    td = Path(td)
    missing = subprocess.run(["python3", str(GATE), "--root", str(ROOT)], text=True, stdout=subprocess.PIPE)
    assert missing.returncode == 2 and "gradle_lint_evidence_missing" in missing.stdout

    ge = td / "gradle.json"
    ge.write_text(json.dumps({"gradle_unit_tests_pass": True, "lint_pass": True}), encoding="utf-8")
    artifact = td / "fake.aab"
    with zipfile.ZipFile(artifact, "w") as z: z.writestr("base/manifest/AndroidManifest.xml", "fake")
    out = td / "evidence.json"
    ok = subprocess.run(["python3", str(GATE), "--root", str(ROOT), "--gradle-evidence", str(ge),
                         "--artifact", str(artifact), "--skip-signature", "--evidence-out", str(out)],
                        text=True, stdout=subprocess.PIPE)
    assert ok.returncode == 0, ok.stdout
    data = json.loads(out.read_text())
    assert data["version_code"] == 57 and data["artifact_type"] == "aab" and len(data["sha256"]) == 64
print("STEP15_15_4_ARTIFACT_GATE_SELFTEST_PASS")
