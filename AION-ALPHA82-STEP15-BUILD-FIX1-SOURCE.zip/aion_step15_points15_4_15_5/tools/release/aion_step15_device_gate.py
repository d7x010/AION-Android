#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import re
import shutil
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
DECISION = ROOT / "release" / "STEP15_DEVICE_DECISION.json"
PACKAGE = "com.aion.mobile"
ACTIVITY = "com.aion.mobile/.MainActivity"


def run(cmd: list[str], *, check: bool = False) -> subprocess.CompletedProcess[str]:
    return subprocess.run(cmd, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, check=check)


def online_devices(adb: str) -> list[str]:
    p = run([adb, "devices"])
    if p.returncode != 0:
        return []
    out: list[str] = []
    for line in p.stdout.splitlines()[1:]:
        parts = line.split()
        if len(parts) >= 2 and parts[1] == "device":
            out.append(parts[0])
    return out


def write_decision(payload: dict[str, object], path: Path | None = None) -> None:
    target = DECISION if path is None else path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def get_version(adb: str, serial: str) -> tuple[int | None, str | None]:
    p = run([adb, "-s", serial, "shell", "dumpsys", "package", PACKAGE])
    if p.returncode != 0:
        return None, None
    code = None
    name = None
    m = re.search(r"versionCode=(\d+)", p.stdout)
    if m:
        code = int(m.group(1))
    m = re.search(r"versionName=([^\s]+)", p.stdout)
    if m:
        name = m.group(1)
    return code, name


def probe() -> int:
    adb = shutil.which("adb")
    if not adb:
        write_decision({
            "schema": 1,
            "status": "unavailable",
            "reason": "adb_missing",
            "package": PACKAGE,
            "device_upgrade_status": "unavailable",
        })
        print("AION_STEP15_DEVICE_GATE_UNAVAILABLE adb_missing")
        return 0
    devices = online_devices(adb)
    if not devices:
        write_decision({
            "schema": 1,
            "status": "unavailable",
            "reason": "no_online_device",
            "package": PACKAGE,
            "adb": adb,
            "device_upgrade_status": "unavailable",
        })
        print("AION_STEP15_DEVICE_GATE_UNAVAILABLE no_online_device")
        return 0
    write_decision({
        "schema": 1,
        "status": "ready",
        "package": PACKAGE,
        "adb": adb,
        "devices": devices,
        "device_upgrade_status": "pending",
    })
    print(f"AION_STEP15_DEVICE_GATE_READY devices={len(devices)}")
    return 0


def install(adb: str, serial: str, apk: Path, replace: bool) -> tuple[bool, str]:
    cmd = [adb, "-s", serial, "install"]
    if replace:
        cmd.append("-r")
    cmd.append(str(apk))
    p = run(cmd)
    return p.returncode == 0 and "Success" in p.stdout, p.stdout.strip()


def test_device(candidate: Path, baseline: Path | None) -> int:
    if not candidate.is_file():
        write_decision({"schema": 1, "status": "blocked", "reason": "candidate_apk_missing", "device_upgrade_status": "unavailable"})
        print("AION_STEP15_DEVICE_GATE_BLOCKED candidate_apk_missing")
        return 2
    adb = shutil.which("adb")
    if not adb:
        write_decision({"schema": 1, "status": "unavailable", "reason": "adb_missing", "device_upgrade_status": "unavailable"})
        print("AION_STEP15_DEVICE_GATE_UNAVAILABLE adb_missing")
        return 0
    devices = online_devices(adb)
    if not devices:
        write_decision({"schema": 1, "status": "unavailable", "reason": "no_online_device", "device_upgrade_status": "unavailable"})
        print("AION_STEP15_DEVICE_GATE_UNAVAILABLE no_online_device")
        return 0
    serial = devices[0]

    baseline_result: dict[str, object] | None = None
    if baseline is not None:
        if not baseline.is_file():
            print("AION_STEP15_DEVICE_GATE_BLOCKED baseline_apk_missing")
            return 2
        ok, output = install(adb, serial, baseline, replace=True)
        if not ok:
            write_decision({"schema": 1, "status": "fail", "reason": "baseline_install_failed", "output": output, "device_upgrade_status": "fail"})
            print("AION_STEP15_DEVICE_GATE_FAIL baseline_install_failed")
            return 1
        bcode, bname = get_version(adb, serial)
        baseline_result = {"version_code": bcode, "version_name": bname}

    ok, output = install(adb, serial, candidate, replace=True)
    if not ok:
        write_decision({"schema": 1, "status": "fail", "reason": "candidate_install_failed", "output": output, "device_upgrade_status": "fail"})
        print("AION_STEP15_DEVICE_GATE_FAIL candidate_install_failed")
        return 1

    ccode, cname = get_version(adb, serial)
    launched = run([adb, "-s", serial, "shell", "am", "start", "-W", "-n", ACTIVITY])
    if launched.returncode != 0 or "Error" in launched.stdout:
        write_decision({"schema": 1, "status": "fail", "reason": "launch_failed", "output": launched.stdout.strip(), "device_upgrade_status": "fail"})
        print("AION_STEP15_DEVICE_GATE_FAIL launch_failed")
        return 1

    payload: dict[str, object] = {
        "schema": 1,
        "status": "pass",
        "device_serial": serial,
        "package": PACKAGE,
        "activity": ACTIVITY,
        "candidate_apk": str(candidate),
        "candidate_version_code": ccode,
        "candidate_version_name": cname,
        "fresh_or_replace_install_pass": True,
        "launch_pass": True,
        "device_upgrade_status": "pass" if baseline is not None else "unavailable",
    }
    if baseline_result is not None:
        payload["baseline"] = baseline_result
        if baseline_result.get("version_code") is not None and ccode is not None and ccode <= int(baseline_result["version_code"]):
            payload["status"] = "fail"
            payload["reason"] = "candidate_version_not_greater_than_baseline"
            payload["device_upgrade_status"] = "fail"
            write_decision(payload)
            print("AION_STEP15_DEVICE_GATE_FAIL candidate_version_not_greater_than_baseline")
            return 1

    write_decision(payload)
    print("AION_STEP15_DEVICE_GATE_PASS")
    return 0


def main() -> int:
    ap = argparse.ArgumentParser(description="AION Step 15.6 device install/upgrade gate")
    ap.add_argument("--mode", choices=("probe", "test"), default="probe")
    ap.add_argument("--candidate-apk", type=Path)
    ap.add_argument("--baseline-apk", type=Path)
    args = ap.parse_args()
    if args.mode == "probe":
        return probe()
    if args.candidate_apk is None:
        print("AION_STEP15_DEVICE_GATE_BLOCKED candidate_apk_required")
        return 2
    return test_device(args.candidate_apk, args.baseline_apk)


if __name__ == "__main__":
    raise SystemExit(main())
