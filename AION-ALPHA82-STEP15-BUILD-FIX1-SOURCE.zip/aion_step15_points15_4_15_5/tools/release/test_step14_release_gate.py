#!/usr/bin/env python3
from __future__ import annotations

import importlib.util
import json
import tempfile
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
MODULE = HERE / "aion_step14_release_gate.py"
spec = importlib.util.spec_from_file_location("aion_step14_release_gate", MODULE)
mod = importlib.util.module_from_spec(spec)
assert spec and spec.loader
sys.modules[spec.name] = mod
spec.loader.exec_module(mod)


def assert_true(value: bool, msg: str) -> None:
    if not value:
        raise AssertionError(msg)


def main() -> int:
    lkg = json.loads(mod.LKG_MANIFEST.read_text(encoding="utf-8"))
    with tempfile.TemporaryDirectory() as td:
        historical_build = Path(td) / "build.gradle.kts"
        historical_build.write_text(
            'applicationId = "com.aion.mobile"\nversionCode = 56\nversionName = "2.0.0-alpha8.2-dev1"\n',
            encoding="utf-8",
        )
        meta = mod.read_build_meta(historical_build)
        assert_true(meta.application_id == "com.aion.mobile", "historical app id")
        assert_true(meta.version_code == 56, "historical Step14 code")
        assert_true(meta.version_name == "2.0.0-alpha8.2-dev1", "historical Step14 name")

        aab = Path(td) / "app-release.aab"
        aab.write_bytes(b"signed-aab-test-fixture")
        good = {
            "schema": 1,
            "application_id": "com.aion.mobile",
            "version_name": "2.0.0-alpha8.2-dev2",
            "version_code": 57,
            "gradle_unit_tests_pass": True,
            "lint_pass": True,
            "bundle_release_pass": True,
            "worker_gate_pass": True,
            "release_signing_verified": True,
            "play_console_fgs_declared": True,
            "data_safety_reviewed": True,
            "device_upgrade_status": "unavailable",
            "signed_aab_sha256": mod.sha256(aab),
        }
        fake_current = mod.BuildMeta("com.aion.mobile", "2.0.0-alpha8.2-dev2", 57)
        assert_true(not mod.validate_production_evidence(good, fake_current, lkg, aab), "valid evidence")

        bad = dict(good)
        bad["release_signing_verified"] = False
        errs = mod.validate_production_evidence(bad, fake_current, lkg, aab)
        assert_true("evidence_false_or_missing:release_signing_verified" in errs, "signing fail closed")

        wrong = dict(good)
        wrong["signed_aab_sha256"] = "0" * 64
        errs = mod.validate_production_evidence(wrong, fake_current, lkg, aab)
        assert_true("signed_aab_sha256_mismatch" in errs, "aab hash fail closed")

        old_current = mod.BuildMeta("com.aion.mobile", str(lkg["version_name"]), int(lkg["version_code"]))
        errs = mod.validate_production_evidence(good, old_current, lkg, aab)
        assert_true("version_code_not_bumped_after_lkg" in errs, "version code fail closed")
        assert_true("version_name_not_bumped_after_lkg" in errs, "version name fail closed")

    print("STEP14_14_10_RELEASE_GATE_SELFTEST_PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
