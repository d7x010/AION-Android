#!/usr/bin/env python3
from __future__ import annotations
import importlib.util
import json
import os
import sys
import tempfile
from pathlib import Path
from unittest import mock

SCRIPT = Path(__file__).with_name("aion_step15_device_gate.py")
spec = importlib.util.spec_from_file_location("aion_step15_device_gate", SCRIPT)
mod = importlib.util.module_from_spec(spec)
assert spec and spec.loader
sys.modules[spec.name] = mod
spec.loader.exec_module(mod)

with tempfile.TemporaryDirectory() as td:
    decision = Path(td) / "decision.json"
    with mock.patch.object(mod, "DECISION", decision), mock.patch.object(mod.shutil, "which", return_value=None):
        rc = mod.probe()
        assert rc == 0
        data = json.loads(decision.read_text())
        assert data["status"] == "unavailable"
        assert data["reason"] == "adb_missing"
        assert data["device_upgrade_status"] == "unavailable"

with tempfile.TemporaryDirectory() as td:
    decision = Path(td) / "decision.json"
    with mock.patch.object(mod, "DECISION", decision), mock.patch.object(mod.shutil, "which", return_value="/fake/adb"), mock.patch.object(mod, "online_devices", return_value=[]):
        rc = mod.probe()
        assert rc == 0
        data = json.loads(decision.read_text())
        assert data["reason"] == "no_online_device"

print("STEP15_15_6_DEVICE_GATE_SELFTEST_PASS")
