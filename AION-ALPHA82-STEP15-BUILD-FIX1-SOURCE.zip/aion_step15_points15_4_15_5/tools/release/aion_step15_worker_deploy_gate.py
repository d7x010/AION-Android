#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, os, re, shutil, subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
WORKER = ROOT / "cloudflare" / "aion-core"


def run(cmd, cwd: Path, timeout=300):
    return subprocess.run(cmd, cwd=cwd, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                          timeout=timeout, check=False)


def validate_wrangler_toml(path: Path) -> list[str]:
    text = path.read_text(encoding="utf-8")
    checks = {
        "worker_name": r'(?m)^name\s*=\s*"aion-core"\s*$',
        "worker_main": r'(?m)^main\s*=\s*"src/index\.js"\s*$',
        "ai_binding": r'(?m)^binding\s*=\s*"AI"\s*$',
        "durable_binding": r'(?m)^name\s*=\s*"AION_RUNS"\s*$',
        "durable_class": r'(?m)^class_name\s*=\s*"AionRunDurableObject"\s*$',
        "migration": r'(?m)^tag\s*=\s*"aion-runs-v1"\s*$',
    }
    return [f"wrangler_config_missing:{k}" for k,p in checks.items() if not re.search(p, text)]


def main() -> int:
    ap = argparse.ArgumentParser(description="AION Step 15.5 Worker tests + deploy gate")
    ap.add_argument("--root", type=Path, default=ROOT)
    ap.add_argument("--require-dry-run", action="store_true")
    ap.add_argument("--wrangler-cmd")
    ap.add_argument("--evidence-out", type=Path)
    args = ap.parse_args()
    root = args.root.resolve(); worker = root / "cloudflare" / "aion-core"
    errors = []
    for p in [worker / "src/index.js", worker / "test-worker.mjs", worker / "test-idempotency.mjs", worker / "wrangler.toml"]:
        if not p.is_file(): errors.append(f"missing:{p.relative_to(root)}")
    if errors:
        print("AION_STEP15_WORKER_DEPLOY_GATE_FAIL"); [print("-", e) for e in errors]; return 1
    cfg_errors = validate_wrangler_toml(worker / "wrangler.toml")
    if cfg_errors:
        print("AION_STEP15_WORKER_DEPLOY_GATE_FAIL"); [print("-", e) for e in cfg_errors]; return 1

    commands = [
        (["node", "--check", "src/index.js"], "syntax"),
        (["node", "--test", "test-worker.mjs"], "worker_tests"),
        (["node", "--test", "test-idempotency.mjs"], "idempotency_tests"),
    ]
    for cmd, label in commands:
        p = run(cmd, worker, timeout=600)
        if p.returncode != 0:
            print(p.stdout)
            print(f"AION_STEP15_WORKER_DEPLOY_GATE_FAIL {label}:{p.returncode}")
            return 1
        print(f"{label}=PASS")

    dry_run = "NOT_REQUIRED"
    if args.require_dry_run:
        wrangler = args.wrangler_cmd or shutil.which("wrangler")
        if not wrangler:
            print("AION_STEP15_WORKER_DEPLOY_GATE_BLOCKED")
            print("- wrangler_missing_for_dry_run")
            print("worker_tests=PASS")
            print("deploy_dry_run=NOT_RUN")
            return 2
        p = run([wrangler, "deploy", "--dry-run"], worker, timeout=300)
        if p.returncode != 0:
            print(p.stdout)
            print(f"AION_STEP15_WORKER_DEPLOY_GATE_FAIL dry_run:{p.returncode}")
            return 1
        dry_run = "PASS"

    payload = {
        "schema": 1, "step": "15.5", "worker_syntax": "PASS", "worker_tests": "PASS",
        "idempotency_tests": "PASS", "wrangler_config": "PASS", "deploy_dry_run": dry_run,
        "actual_deploy_performed": False,
    }
    if args.evidence_out:
        out = args.evidence_out.resolve(); out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print("AION_STEP15_WORKER_DEPLOY_GATE_PASS")
    print(f"deploy_dry_run={dry_run}")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
