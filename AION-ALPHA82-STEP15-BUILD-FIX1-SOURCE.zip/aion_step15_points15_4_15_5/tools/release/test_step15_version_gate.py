#!/usr/bin/env python3
from __future__ import annotations

import importlib.util
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
MODULE = HERE / "aion_step15_version_gate.py"
spec = importlib.util.spec_from_file_location("aion_step15_version_gate", MODULE)
mod = importlib.util.module_from_spec(spec)
assert spec and spec.loader
sys.modules[spec.name] = mod
spec.loader.exec_module(mod)


def check(value: bool, msg: str) -> None:
    if not value:
        raise AssertionError(msg)


def main() -> int:
    lkg = {"application_id": "com.aion.mobile", "version_name": "2.0.0-alpha8.2-dev1", "version_code": 56}
    check(not mod.validate("com.aion.mobile", "2.0.0-alpha8.2-dev2", 57, lkg), "valid bump")
    check("version_code_not_monotonic" in mod.validate("com.aion.mobile", "2.0.0-alpha8.2-dev2", 56, lkg), "code monotonic")
    check("version_name_not_bumped" in mod.validate("com.aion.mobile", "2.0.0-alpha8.2-dev1", 57, lkg), "name bump")
    check("application_id_changed" in mod.validate("com.example.bad", "2.0.0-alpha8.2-dev2", 57, lkg), "app id immutable")
    print("STEP15_15_1_VERSION_GATE_SELFTEST_PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
