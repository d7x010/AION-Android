#!/usr/bin/env python3
from __future__ import annotations

import argparse
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def run(label: str, cmd: list[str]) -> None:
    print(f"[RUN] {label}")
    proc = subprocess.run(cmd, cwd=ROOT)
    if proc.returncode != 0:
        print(f"AION_FULL_REGRESSION_GATE_FAIL stage={label} code={proc.returncode}")
        raise SystemExit(proc.returncode)
    print(f"[PASS] {label}")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--lkg-artifact", required=True, type=Path)
    args = ap.parse_args()

    run("security", [sys.executable, "tools/security/aion_security_gate.py"])
    run("supply-chain", [sys.executable, "tools/security/aion_supply_chain_gate.py"])
    run("rollback", [sys.executable, "tools/release/aion_rollback_gate.py", "--artifact", str(args.lkg_artifact)])
    run("worker-syntax", ["node", "--check", "cloudflare/aion-core/src/index.js"])
    run("worker-regression", ["node", "--test", "cloudflare/aion-core/test-worker.mjs"])
    run("worker-idempotency", ["node", "--test", "cloudflare/aion-core/test-idempotency.mjs"])
    run("sandbox-syntax", ["node", "--check", "cloudflare/aion-sandbox/src/index.js"])
    run("sandbox-policy", ["node", "--test", "cloudflare/aion-sandbox/test-policy.mjs"])

    gradle = shutil.which("gradle")
    wrapper = ROOT / "gradlew"
    android_sdk = bool(shutil.which("adb")) or bool(__import__("os").environ.get("ANDROID_HOME") or __import__("os").environ.get("ANDROID_SDK_ROOT"))
    if gradle or wrapper.exists():
        print("android_gradle=AVAILABLE step15_build_gate_required")
    else:
        print("android_gradle=UNAVAILABLE deferred_to_step15")
    print(f"android_sdk_or_adb={'AVAILABLE' if android_sdk else 'UNAVAILABLE'}")
    print("AION_FULL_REGRESSION_GATE_PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
