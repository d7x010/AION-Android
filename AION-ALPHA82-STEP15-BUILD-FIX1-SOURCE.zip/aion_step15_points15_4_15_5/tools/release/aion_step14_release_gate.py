#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
APP_GRADLE = ROOT / "app" / "build.gradle.kts"
LKG_MANIFEST = ROOT / "release" / "LAST_KNOWN_GOOD.json"

VERSION_NAME_RE = re.compile(r'versionName\s*=\s*"([^"]+)"')
VERSION_CODE_RE = re.compile(r'versionCode\s*=\s*(\d+)')
APP_ID_RE = re.compile(r'applicationId\s*=\s*"([^"]+)"')

REQUIRED_STATUS_FILES = (
    "STEP14_BATCH1_14_1_TO_14_5_STATUS_AR.md",
    "STEP14_POINT14_6_STATUS_AR.md",
    "STEP14_POINT14_7_STATUS_AR.md",
    "STEP14_POINT14_8_STATUS_AR.md",
    "STEP14_POINT14_9_STATUS_AR.md",
)

REQUIRED_PRODUCTION_EVIDENCE = (
    "gradle_unit_tests_pass",
    "lint_pass",
    "bundle_release_pass",
    "worker_gate_pass",
    "release_signing_verified",
    "play_console_fgs_declared",
    "data_safety_reviewed",
)


@dataclass(frozen=True)
class BuildMeta:
    application_id: str
    version_name: str
    version_code: int


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def read_build_meta(path: Path = APP_GRADLE) -> BuildMeta:
    text = path.read_text(encoding="utf-8")
    app = APP_ID_RE.search(text)
    name = VERSION_NAME_RE.search(text)
    code = VERSION_CODE_RE.search(text)
    if not (app and name and code):
        raise ValueError("build_metadata_missing")
    return BuildMeta(app.group(1), name.group(1), int(code.group(1)))


def run_checked(label: str, cmd: list[str]) -> None:
    print(f"[RUN] {label}")
    p = subprocess.run(cmd, cwd=ROOT)
    if p.returncode != 0:
        print(f"AION_STEP14_RELEASE_GATE_FAIL stage={label} code={p.returncode}")
        raise SystemExit(p.returncode)
    print(f"[PASS] {label}")


def source_preconditions(lkg_artifact: Path, allow_step15_bump: bool = False) -> tuple[BuildMeta, dict[str, object]]:
    if not lkg_artifact.is_file():
        raise ValueError("lkg_artifact_missing")
    lkg = json.loads(LKG_MANIFEST.read_text(encoding="utf-8"))
    if sha256(lkg_artifact) != str(lkg.get("sha256", "")).lower():
        raise ValueError("lkg_sha256_mismatch")

    missing = [name for name in REQUIRED_STATUS_FILES if not (ROOT / name).is_file()]
    if missing:
        raise ValueError("missing_step14_status:" + ",".join(missing))

    current = read_build_meta()
    if current.application_id != lkg.get("application_id"):
        raise ValueError("application_id_changed_from_lkg")
    if current.version_code < int(lkg.get("version_code", -1)):
        raise ValueError("version_code_regressed")

    # Step 14 source mode preserves the historical pre-Step15 version.
    # Production mode is entered only in Step 15 and requires a monotonic bump.
    if allow_step15_bump:
        if current.version_code <= int(lkg.get("version_code", -1)):
            raise ValueError("step15_version_code_not_bumped_after_lkg")
        if current.version_name == str(lkg.get("version_name", "")):
            raise ValueError("step15_version_name_not_bumped_after_lkg")
    else:
        if current.version_code != int(lkg.get("version_code", -1)):
            raise ValueError("step14_must_not_bump_version_code_before_step15")
        if current.version_name != str(lkg.get("version_name", "")):
            raise ValueError("step14_must_not_bump_version_name_before_step15")

    return current, lkg


def source_blockers() -> list[str]:
    blockers: list[str] = []
    wrapper = ROOT / "gradlew"
    if not (wrapper.is_file() or shutil.which("gradle")):
        blockers.append("android_gradle_build_not_executed")
    if not (os.environ.get("ANDROID_HOME") or os.environ.get("ANDROID_SDK_ROOT")):
        blockers.append("android_sdk_not_available")
    if not shutil.which("adb"):
        blockers.append("device_or_adb_not_available")
    blockers.extend(
        [
            "signed_aab_not_produced",
            "release_signing_not_verified",
            "play_console_fgs_declaration_unverified",
            "play_data_safety_unverified",
        ]
    )
    return blockers


def validate_production_evidence(
    evidence: dict[str, object],
    current: BuildMeta,
    lkg: dict[str, object],
    aab_artifact: Path | None,
) -> list[str]:
    errors: list[str] = []
    if evidence.get("schema") != 1:
        errors.append("evidence_schema_invalid")
    for key in REQUIRED_PRODUCTION_EVIDENCE:
        if evidence.get(key) is not True:
            errors.append(f"evidence_false_or_missing:{key}")

    device_status = evidence.get("device_upgrade_status")
    if device_status not in {"pass", "unavailable"}:
        errors.append("device_upgrade_status_must_be_pass_or_unavailable")

    if current.version_code <= int(lkg.get("version_code", -1)):
        errors.append("version_code_not_bumped_after_lkg")
    if current.version_name == str(lkg.get("version_name", "")):
        errors.append("version_name_not_bumped_after_lkg")
    if evidence.get("application_id") != current.application_id:
        errors.append("evidence_application_id_mismatch")
    if evidence.get("version_name") != current.version_name:
        errors.append("evidence_version_name_mismatch")
    if evidence.get("version_code") != current.version_code:
        errors.append("evidence_version_code_mismatch")

    expected_sha = str(evidence.get("signed_aab_sha256", "")).lower()
    if not aab_artifact or not aab_artifact.is_file():
        errors.append("signed_aab_artifact_missing")
    elif not re.fullmatch(r"[0-9a-f]{64}", expected_sha):
        errors.append("signed_aab_sha256_missing_or_invalid")
    elif sha256(aab_artifact) != expected_sha:
        errors.append("signed_aab_sha256_mismatch")

    return errors


def main() -> int:
    ap = argparse.ArgumentParser(description="Fail-closed AION Step 14 / production release gate")
    ap.add_argument("--mode", choices=("source", "production"), default="source")
    ap.add_argument("--lkg-artifact", required=True, type=Path)
    ap.add_argument("--evidence", type=Path)
    ap.add_argument("--aab-artifact", type=Path)
    args = ap.parse_args()

    try:
        current, lkg = source_preconditions(args.lkg_artifact, allow_step15_bump=(args.mode == "production"))
    except Exception as exc:
        print(f"AION_STEP14_RELEASE_GATE_FAIL {exc}")
        return 1

    run_checked(
        "full-regression",
        [sys.executable, "tools/release/aion_full_regression_gate.py", "--lkg-artifact", str(args.lkg_artifact)],
    )
    run_checked("play-api", [sys.executable, "tools/release/aion_play_api_gate.py"])

    print(f"application_id={current.application_id}")
    print(f"version_name={current.version_name}")
    print(f"version_code={current.version_code}")
    print("AION_STEP14_SOURCE_GATE_PASS")

    if args.mode == "source":
        blockers = source_blockers()
        print("AION_PRODUCTION_RELEASE_GATE_BLOCKED_STEP15")
        for blocker in blockers:
            print(f"- {blocker}")
        return 0

    if not args.evidence or not args.evidence.is_file():
        print("AION_PRODUCTION_RELEASE_GATE_BLOCKED evidence_file_missing")
        return 2

    try:
        evidence = json.loads(args.evidence.read_text(encoding="utf-8"))
    except Exception as exc:
        print(f"AION_PRODUCTION_RELEASE_GATE_BLOCKED evidence_unreadable:{exc}")
        return 2

    errors = validate_production_evidence(evidence, current, lkg, args.aab_artifact)
    if errors:
        print("AION_PRODUCTION_RELEASE_GATE_BLOCKED")
        for error in errors:
            print(f"- {error}")
        return 2

    print("AION_PRODUCTION_RELEASE_GATE_PASS")
    if evidence.get("device_upgrade_status") == "unavailable":
        print("device_upgrade_test=UNAVAILABLE explicitly_recorded")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
