#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
import re
import sys
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
MANIFEST = ROOT / "release/LAST_KNOWN_GOOD.json"

APP_ID_RE = re.compile(r'applicationId\s*=\s*"([^"]+)"')
VERSION_NAME_RE = re.compile(r'versionName\s*=\s*"([^"]+)"')
VERSION_CODE_RE = re.compile(r'versionCode\s*=\s*(\d+)')
SCHEMA_RE = re.compile(
    r'val\s+(\w+)\s*=\s*AionStorageSchemaSpec\("([^"]+)",\s*currentVersion\s*=\s*(\d+),\s*minimumReadableVersion\s*=\s*(\d+)\)'
)


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def parse_build(text: str) -> dict[str, object]:
    app = APP_ID_RE.search(text)
    name = VERSION_NAME_RE.search(text)
    code = VERSION_CODE_RE.search(text)
    if not (app and name and code):
        raise ValueError("build_metadata_missing")
    return {"application_id": app.group(1), "version_name": name.group(1), "version_code": int(code.group(1))}


def parse_schemas(text: str) -> dict[str, dict[str, int]]:
    result: dict[str, dict[str, int]] = {}
    for _, sid, current, minimum in SCHEMA_RE.findall(text):
        result[sid] = {"current": int(current), "minimum_readable": int(minimum)}
    if not result:
        raise ValueError("storage_schema_registry_unparseable")
    return result


def current_metadata() -> tuple[dict[str, object], dict[str, dict[str, int]]]:
    build = parse_build((ROOT / "app/build.gradle.kts").read_text(encoding="utf-8"))
    schemas = parse_schemas((ROOT / "app/src/main/java/com/aion/mobile/core/storage/StorageSchemaRegistry.kt").read_text(encoding="utf-8"))
    return build, schemas


def target_metadata(archive: Path) -> tuple[dict[str, object], dict[str, dict[str, int]]]:
    with zipfile.ZipFile(archive) as zf:
        names = set(zf.namelist())
        build_name = next((n for n in names if n.endswith("app/build.gradle.kts")), None)
        schema_name = next((n for n in names if n.endswith("app/src/main/java/com/aion/mobile/core/storage/StorageSchemaRegistry.kt")), None)
        if not build_name or not schema_name:
            raise ValueError("lkg_archive_missing_build_or_schema_registry")
        build = parse_build(zf.read(build_name).decode("utf-8"))
        schemas = parse_schemas(zf.read(schema_name).decode("utf-8"))
        return build, schemas


def storage_compatible(current: dict[str, dict[str, int]], target: dict[str, dict[str, int]]) -> tuple[bool, list[str]]:
    errors: list[str] = []
    for sid, cur in current.items():
        t = target.get(sid)
        if t is None:
            errors.append(f"target_missing_schema:{sid}")
            continue
        written = cur["current"]
        if not (t["minimum_readable"] <= written <= t["current"]):
            errors.append(
                f"target_cannot_read_current_schema:{sid}:current={written}:target={t['minimum_readable']}..{t['current']}"
            )
    return not errors, errors


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--artifact", required=True, type=Path, help="materialized Last Known Good full-source ZIP")
    args = ap.parse_args()

    errors: list[str] = []
    manifest = json.loads(MANIFEST.read_text(encoding="utf-8"))
    if manifest.get("schema") != 1:
        errors.append("unsupported_lkg_manifest_schema")
    if manifest.get("rollback_delivery") != "rebuild_lkg_source_with_higher_version_code":
        errors.append("unsafe_rollback_delivery_policy")
    if manifest.get("data_policy") != "preserve_in_place_no_schema_downgrade":
        errors.append("unsafe_data_rollback_policy")
    if not args.artifact.is_file():
        errors.append("lkg_artifact_missing")
    else:
        digest = sha256(args.artifact)
        if digest != str(manifest.get("sha256", "")).lower():
            errors.append(f"lkg_sha256_mismatch:{digest}")

    try:
        current_build, current_schemas = current_metadata()
        target_build, target_schemas = target_metadata(args.artifact)
    except Exception as exc:
        errors.append(str(exc))
        current_build = target_build = {}
        current_schemas = target_schemas = {}

    if current_build and target_build:
        if current_build["application_id"] != target_build["application_id"]:
            errors.append("application_id_mismatch")
        for key in ("application_id", "version_name", "version_code"):
            if target_build.get(key) != manifest.get(key):
                errors.append(f"manifest_target_metadata_mismatch:{key}")
        compatible, schema_errors = storage_compatible(current_schemas, target_schemas)
        if not compatible:
            errors.extend(schema_errors)
        next_code = max(int(current_build["version_code"]), int(target_build["version_code"])) + 1
    else:
        next_code = None

    if errors:
        print("AION_ROLLBACK_GATE_FAIL")
        for e in errors:
            print("-", e)
        return 1

    print("AION_ROLLBACK_GATE_PASS")
    print(f"lkg={manifest['artifact_name']}")
    print(f"sha256={manifest['sha256']}")
    print("data=preserve_in_place schema_compatibility=pass")
    print(f"rollback_rebuild_version_code={next_code}")
    print("binary_policy=rebuild_lkg_source_never_self_downgrade")
    return 0


if __name__ == "__main__":
    sys.exit(main())
