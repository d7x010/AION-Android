#!/usr/bin/env python3
from __future__ import annotations

import importlib.util
import os
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
TARGET = HERE / "aion_step15_gradle_lint_gate.py"
spec = importlib.util.spec_from_file_location("aion_step15_gradle_lint_gate", TARGET)
assert spec and spec.loader
mod = importlib.util.module_from_spec(spec)
import sys
sys.modules[spec.name] = mod
spec.loader.exec_module(mod)

assert mod.parse_gradle_version("Gradle 9.6.0") == (9, 6, 0)
assert mod.parse_gradle_version("Gradle 9.6.1") == (9, 6, 1)
assert mod.parse_gradle_version("not gradle") is None

p = mod.read_preflight(mod.ROOT)
assert mod.validate_preflight(p) == []

with tempfile.TemporaryDirectory() as td:
    base = Path(td)
    sdk = base / "sdk"
    (sdk / "platforms" / "android-36").mkdir(parents=True)
    (sdk / "platforms" / "android-36" / "android.jar").write_bytes(b"fake")
    (sdk / "build-tools" / "36.0.0").mkdir(parents=True)
    assert mod.sdk_blockers(sdk) == []

    fake_gradle = base / "gradle"
    fake_gradle.write_text("#!/bin/sh\necho 'Gradle 9.6.0'\n", encoding="utf-8")
    fake_gradle.chmod(0o755)
    blockers, version = mod.gradle_blockers(str(fake_gradle), cwd=mod.ROOT)
    assert blockers == []
    assert version == "9.6.0"

    old_gradle = base / "gradle-old"
    old_gradle.write_text("#!/bin/sh\necho 'Gradle 9.5.0'\n", encoding="utf-8")
    old_gradle.chmod(0o755)
    blockers, _ = mod.gradle_blockers(str(old_gradle), cwd=mod.ROOT)
    assert blockers == ["gradle_too_old:9.5.0"]

assert mod.sdk_blockers(None) == ["android_sdk_missing"]
blockers, _ = mod.gradle_blockers(None)
assert blockers == ["gradle_missing"]

print("STEP15_15_2_15_3_GATE_SELFTEST_PASS")
