#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import os
import re
import shutil
import subprocess
import sys
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
APP_BUILD = ROOT / "app" / "build.gradle.kts"
TOP_BUILD = ROOT / "build.gradle.kts"

EXPECTED_APPLICATION_ID = "com.aion.mobile"
EXPECTED_VERSION_NAME = "2.0.0-alpha8.2-dev2"
EXPECTED_VERSION_CODE = 57
EXPECTED_COMPILE_SDK = 36
EXPECTED_TARGET_SDK = 36
EXPECTED_AGP = "9.4.0"
MIN_GRADLE = (9, 6, 0)
EXPECTED_BUILD_TOOLS = "36.0.0"


@dataclass(frozen=True)
class Preflight:
    application_id: str
    version_name: str
    version_code: int
    compile_sdk: int
    target_sdk: int
    agp: str


def _match(pattern: str, text: str, label: str) -> str:
    m = re.search(pattern, text)
    if not m:
        raise ValueError(f"{label}_missing")
    return m.group(1)


def read_preflight(root: Path = ROOT) -> Preflight:
    app = (root / "app" / "build.gradle.kts").read_text(encoding="utf-8")
    top = (root / "build.gradle.kts").read_text(encoding="utf-8")
    return Preflight(
        application_id=_match(r'applicationId\s*=\s*"([^"]+)"', app, "application_id"),
        version_name=_match(r'versionName\s*=\s*"([^"]+)"', app, "version_name"),
        version_code=int(_match(r'versionCode\s*=\s*(\d+)', app, "version_code")),
        compile_sdk=int(_match(r'compileSdk\s*=\s*(\d+)', app, "compile_sdk")),
        target_sdk=int(_match(r'targetSdk\s*=\s*(\d+)', app, "target_sdk")),
        agp=_match(r'id\("com\.android\.application"\)\s+version\s+"([^"]+)"', top, "agp"),
    )


def validate_preflight(p: Preflight) -> list[str]:
    expected = {
        "application_id": EXPECTED_APPLICATION_ID,
        "version_name": EXPECTED_VERSION_NAME,
        "version_code": EXPECTED_VERSION_CODE,
        "compile_sdk": EXPECTED_COMPILE_SDK,
        "target_sdk": EXPECTED_TARGET_SDK,
        "agp": EXPECTED_AGP,
    }
    actual = p.__dict__
    return [f"{k}_unexpected:{actual[k]}" for k, v in expected.items() if actual[k] != v]


def parse_gradle_version(text: str) -> tuple[int, int, int] | None:
    # Gradle --version prints: "Gradle 9.6.0".
    m = re.search(r"\bGradle\s+(\d+)\.(\d+)(?:\.(\d+))?", text)
    if not m:
        return None
    return int(m.group(1)), int(m.group(2)), int(m.group(3) or 0)


def find_gradle(root: Path, explicit: str | None = None) -> str | None:
    if explicit:
        return explicit
    wrapper = root / "gradlew"
    if wrapper.is_file() and os.access(wrapper, os.X_OK):
        return str(wrapper)
    return shutil.which("gradle")


def find_sdk(explicit: str | None = None) -> Path | None:
    raw = explicit or os.environ.get("ANDROID_SDK_ROOT") or os.environ.get("ANDROID_HOME")
    return Path(raw).expanduser().resolve() if raw else None


def sdk_blockers(sdk: Path | None) -> list[str]:
    if sdk is None:
        return ["android_sdk_missing"]
    blockers: list[str] = []
    if not (sdk / "platforms" / f"android-{EXPECTED_COMPILE_SDK}" / "android.jar").is_file():
        blockers.append(f"android_platform_{EXPECTED_COMPILE_SDK}_missing")
    if not (sdk / "build-tools" / EXPECTED_BUILD_TOOLS).is_dir():
        blockers.append(f"build_tools_{EXPECTED_BUILD_TOOLS}_missing")
    return blockers


def gradle_blockers(gradle: str | None, cwd: Path = ROOT) -> tuple[list[str], str | None]:
    if not gradle:
        return ["gradle_missing"], None
    try:
        p = subprocess.run(
            [gradle, "--version"], cwd=cwd, text=True, stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT, timeout=30, check=False,
        )
    except Exception as exc:
        return [f"gradle_version_unavailable:{type(exc).__name__}"], None
    version = parse_gradle_version(p.stdout or "")
    if p.returncode != 0 or version is None:
        return ["gradle_version_unparseable"], p.stdout
    if version < MIN_GRADLE:
        return [f"gradle_too_old:{'.'.join(map(str, version))}"], p.stdout
    return [], ".".join(map(str, version))


def lint_reports(root: Path) -> list[Path]:
    report_dir = root / "app" / "build" / "reports"
    if not report_dir.exists():
        return []
    return sorted(
        p for p in report_dir.rglob("lint-results-debug*")
        if p.is_file() and p.suffix.lower() in {".html", ".xml", ".txt"}
    )


def run_gradle_lint(
    root: Path,
    gradle: str,
    sdk: Path,
    timeout_seconds: int = 1800,
) -> tuple[int, str, list[Path]]:
    env = os.environ.copy()
    env["ANDROID_SDK_ROOT"] = str(sdk)
    env["ANDROID_HOME"] = str(sdk)
    cmd = [gradle, ":app:testDebugUnitTest", ":app:lintDebug", "--no-daemon", "--stacktrace"]
    p = subprocess.run(
        cmd, cwd=root, env=env, text=True, stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT, timeout=timeout_seconds, check=False,
    )
    return p.returncode, p.stdout or "", lint_reports(root)


def write_evidence(path: Path, preflight: Preflight, gradle_version: str, reports: list[Path]) -> None:
    payload = {
        "schema": 1,
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "application_id": preflight.application_id,
        "version_name": preflight.version_name,
        "version_code": preflight.version_code,
        "compile_sdk": preflight.compile_sdk,
        "target_sdk": preflight.target_sdk,
        "agp": preflight.agp,
        "gradle": gradle_version,
        "gradle_unit_tests_pass": True,
        "lint_pass": True,
        "lint_reports": [str(p.relative_to(ROOT)) if p.is_relative_to(ROOT) else str(p) for p in reports],
    }
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def main() -> int:
    ap = argparse.ArgumentParser(description="Fail-closed AION Step 15.2/15.3 Gradle + Android Lint gate")
    ap.add_argument("--root", type=Path, default=ROOT)
    ap.add_argument("--gradle-cmd")
    ap.add_argument("--sdk-root")
    ap.add_argument("--evidence-out", type=Path)
    ap.add_argument("--timeout-seconds", type=int, default=1800)
    args = ap.parse_args()
    root = args.root.resolve()

    try:
        preflight = read_preflight(root)
        preflight_errors = validate_preflight(preflight)
    except Exception as exc:
        print(f"AION_STEP15_GRADLE_LINT_GATE_FAIL preflight:{exc}")
        return 1
    if preflight_errors:
        print("AION_STEP15_GRADLE_LINT_GATE_FAIL")
        for error in preflight_errors:
            print("-", error)
        return 1

    gradle = find_gradle(root, args.gradle_cmd)
    sdk = find_sdk(args.sdk_root)
    g_blockers, gradle_version = gradle_blockers(gradle, cwd=root)
    blockers = g_blockers + sdk_blockers(sdk)
    if blockers:
        print("AION_STEP15_GRADLE_LINT_GATE_BLOCKED")
        for blocker in blockers:
            print("-", blocker)
        print("gradle_unit_tests=NOT_RUN")
        print("android_lint=NOT_RUN")
        return 2

    assert gradle is not None and sdk is not None and gradle_version is not None
    code, output, reports = run_gradle_lint(root, gradle, sdk, args.timeout_seconds)
    sys.stdout.write(output)
    if code != 0:
        print(f"AION_STEP15_GRADLE_LINT_GATE_FAIL gradle_exit={code}")
        return 1
    if not reports:
        print("AION_STEP15_GRADLE_LINT_GATE_FAIL lint_report_missing")
        return 1

    if args.evidence_out:
        write_evidence(args.evidence_out.resolve(), preflight, gradle_version, reports)
    print("AION_STEP15_GRADLE_LINT_GATE_PASS")
    print(f"gradle={gradle_version}")
    print("gradle_unit_tests=PASS")
    print("android_lint=PASS")
    for report in reports:
        print(f"lint_report={report}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
