#!/usr/bin/env python3
from __future__ import annotations

import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]

TRUSTED_GRADLE_REPOSITORIES = {"google()", "mavenCentral()", "gradlePluginPortal()"}
DYNAMIC_VERSION = re.compile(r'''(?:[:@](?:\+|latest\.[A-Za-z]+|[^"']*SNAPSHOT)|:[\[(][^"']+[\])])''', re.I)
HTTP_REPO = re.compile(r'''(?:url\s*=\s*uri\s*\(\s*["']http://|maven\s*\{[^}]*["']http://)''', re.I | re.S)


def gradle_gate(errors: list[str]) -> None:
    files = [ROOT / "settings.gradle.kts", ROOT / "build.gradle.kts", ROOT / "app/build.gradle.kts"]
    combined = "\n".join(p.read_text(encoding="utf-8") for p in files)
    if "mavenLocal()" in combined:
        errors.append("gradle_mavenLocal_forbidden")
    if "jcenter()" in combined:
        errors.append("gradle_jcenter_forbidden")
    if HTTP_REPO.search(combined):
        errors.append("gradle_insecure_http_repository")
    if DYNAMIC_VERSION.search(combined):
        errors.append("gradle_dynamic_or_snapshot_dependency")

    settings = (ROOT / "settings.gradle.kts").read_text(encoding="utf-8")
    if "RepositoriesMode.FAIL_ON_PROJECT_REPOS" not in settings:
        errors.append("gradle_repositories_must_be_centralized")
    # This project intentionally uses only these central repository functions.
    for token in re.findall(r"\b(?:google|mavenCentral|gradlePluginPortal|mavenLocal|jcenter)\(\)", settings):
        if token not in TRUSTED_GRADLE_REPOSITORIES:
            errors.append(f"untrusted_gradle_repository={token}")


def npm_gate(errors: list[str]) -> None:
    for path in ROOT.glob("cloudflare/**/package.json"):
        data = json.loads(path.read_text(encoding="utf-8"))
        for section in ("dependencies", "devDependencies", "optionalDependencies"):
            for name, version in (data.get(section) or {}).items():
                value = str(version).strip()
                # Exact semver only. No tags, git URLs, ranges, file/tarball URLs, or prerelease wildcards.
                if not re.fullmatch(r"\d+\.\d+\.\d+(?:-[0-9A-Za-z.-]+)?", value):
                    errors.append(f"npm_dependency_not_exact:{path.relative_to(ROOT)}:{name}={value}")


def model_pack_contract_gate(errors: list[str]) -> None:
    models = (ROOT / "app/src/main/java/com/aion/mobile/core/local/LocalResourceModels.kt").read_text(encoding="utf-8")
    verifier = (ROOT / "app/src/main/java/com/aion/mobile/core/local/ModelPackVerifier.kt").read_text(encoding="utf-8")
    registry = (ROOT / "app/src/main/java/com/aion/mobile/core/local/LocalModelRegistryStore.kt").read_text(encoding="utf-8")
    schema = (ROOT / "app/src/main/java/com/aion/mobile/core/storage/StorageSchemaRegistry.kt").read_text(encoding="utf-8")
    policy = (ROOT / "app/src/main/java/com/aion/mobile/core/local/ModelPackSupplyChainPolicy.kt").read_text(encoding="utf-8")
    required = {
        "model_provenance_type": "data class ModelPackProvenance" in models,
        "source_type_recorded": "enum class ModelPackSourceType" in models,
        "remote_https_only": 'scheme != "https"' in models and 'REMOTE_REPOSITORY' in models,
        "provenance_uri_no_credentials": "source_uri_must_not_contain_credentials_query_or_fragment" in models,
        "signature_algorithm_allowlist": "SUPPORTED_SIGNATURE_ALGORITHMS" in models,
        "signing_key_id": "signerKeyId" in models and "signerKeyId" in verifier,
        "manifest_digest_policy": "MANIFEST_DIGEST_MISMATCH" in policy and "manifestDigest" in policy,
        "signature_payload": "fun signaturePayload(" in verifier,
        "default_rejecting_verifier": "RejectingModelPackSignatureVerifier" in verifier,
        "supply_chain_fail_closed": "SUPPLY_CHAIN_INVALID" in verifier,
        "provenance_persisted": "out.writeUTF(provenance.sourceUri)" in registry and "manifestSha256" in registry,
        "local_model_schema_v2": 'local_models", currentVersion = 2' in schema,
    }
    for key, ok in required.items():
        if not ok:
            errors.append(f"model_pack_contract_missing:{key}")


def main() -> int:
    errors: list[str] = []
    gradle_gate(errors)
    npm_gate(errors)
    model_pack_contract_gate(errors)
    if errors:
        print("AION_SUPPLY_CHAIN_GATE_FAIL")
        for item in errors:
            print("-", item)
        return 1
    print("AION_SUPPLY_CHAIN_GATE_PASS")
    print("gradle=repositories-pinned dependencies=exact model_packs=provenance+hash+signature")
    return 0


if __name__ == "__main__":
    sys.exit(main())
