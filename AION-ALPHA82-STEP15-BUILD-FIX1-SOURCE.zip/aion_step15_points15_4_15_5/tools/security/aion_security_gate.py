#!/usr/bin/env python3
from __future__ import annotations

import re
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
ANDROID = '{http://schemas.android.com/apk/res/android}'

ALLOWED_PERMISSIONS = {
    'android.permission.INTERNET',
    'android.permission.ACCESS_NETWORK_STATE',
    'android.permission.RECEIVE_BOOT_COMPLETED',
    'android.permission.RECORD_AUDIO',
    'android.permission.MODIFY_AUDIO_SETTINGS',
    'android.permission.POST_NOTIFICATIONS',
    'android.permission.FOREGROUND_SERVICE',
    'android.permission.FOREGROUND_SERVICE_DATA_SYNC',
}

SCANNED_SUFFIXES = {
    '.kt', '.kts', '.java', '.xml', '.toml', '.json', '.jsonc', '.js', '.mjs', '.ts',
    '.properties', '.gradle', '.sh', '.py', '.yaml', '.yml', '.txt'
}
IGNORED_PARTS = {'.git', '.gradle', 'build', 'node_modules'}

HIGH_CONFIDENCE_SECRET_PATTERNS = [
    ('private_key', re.compile(r'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----')),
    ('openai_like_key', re.compile(r'\bsk-[A-Za-z0-9_-]{20,}\b')),
    ('anthropic_like_key', re.compile(r'\bsk-ant-[A-Za-z0-9_-]{16,}\b')),
    ('google_api_key', re.compile(r'\bAIza[0-9A-Za-z_-]{30,}\b')),
    ('hardcoded_store_password', re.compile(r'\b(?:storePassword|keyPassword)\s*=\s*["\'][^"\']+["\']')),
]


def fail(errors: list[str], message: str) -> None:
    errors.append(message)


def manifest_gate(errors: list[str]) -> None:
    manifest = ROOT / 'app/src/main/AndroidManifest.xml'
    root = ET.parse(manifest).getroot()
    permissions = {node.attrib.get(ANDROID + 'name', '') for node in root.findall('uses-permission')}
    unexpected = sorted(permissions - ALLOWED_PERMISSIONS)
    missing = sorted(ALLOWED_PERMISSIONS - permissions)
    if unexpected:
        fail(errors, f'unexpected_permissions={unexpected}')
    if missing:
        fail(errors, f'missing_expected_permissions={missing}')

    app = root.find('application')
    if app is None:
        fail(errors, 'missing_application')
        return
    if app.attrib.get(ANDROID + 'allowBackup') != 'false':
        fail(errors, 'allowBackup_must_be_false')
    if app.attrib.get(ANDROID + 'usesCleartextTraffic') != 'false':
        fail(errors, 'usesCleartextTraffic_must_be_false')
    if app.attrib.get(ANDROID + 'debuggable') == 'true':
        fail(errors, 'manifest_must_not_force_debuggable')

    exported_true = []
    for tag in ('activity', 'service', 'receiver', 'provider'):
        for node in app.findall(tag):
            if node.attrib.get(ANDROID + 'exported') == 'true':
                exported_true.append((tag, node.attrib.get(ANDROID + 'name', '')))
    if exported_true != [('activity', '.MainActivity')]:
        fail(errors, f'exported_component_whitelist_violation={exported_true}')

    providers = app.findall('provider')
    fp = next((p for p in providers if p.attrib.get(ANDROID + 'name') == 'androidx.core.content.FileProvider'), None)
    if fp is None:
        fail(errors, 'file_provider_missing')
    else:
        if fp.attrib.get(ANDROID + 'exported') != 'false':
            fail(errors, 'file_provider_must_not_be_exported')
        if fp.attrib.get(ANDROID + 'grantUriPermissions') != 'true':
            fail(errors, 'file_provider_must_use_temporary_uri_grants')
        if fp.attrib.get(ANDROID + 'authorities') != '${applicationId}.files':
            fail(errors, 'file_provider_authority_must_be_app_scoped')

    paths = ROOT / 'app/src/main/res/xml/aion_file_paths.xml'
    proot = ET.parse(paths).getroot()
    children = list(proot)
    if len(children) != 1 or children[0].tag != 'files-path' or children[0].attrib.get('path') != 'aion_attachments/':
        fail(errors, 'file_provider_paths_must_be_limited_to_internal_aion_attachments')


def secrets_gate(errors: list[str]) -> None:
    signing_material = list((ROOT / 'app').glob('*.keystore')) + list((ROOT / 'app').glob('*.jks'))
    if signing_material:
        fail(errors, 'signing_material_committed=' + ','.join(str(p.relative_to(ROOT)) for p in signing_material))

    for path in ROOT.rglob('*'):
        if not path.is_file() or any(part in IGNORED_PARTS for part in path.parts):
            continue
        if path.suffix.lower() not in SCANNED_SUFFIXES and path.name not in {'.env', '.dev.vars'}:
            continue
        # Documentation may name secret variables but must not contain concrete high-confidence values.
        try:
            text = path.read_text(encoding='utf-8', errors='ignore')
        except OSError:
            continue
        for name, pattern in HIGH_CONFIDENCE_SECRET_PATTERNS:
            if pattern.search(text):
                fail(errors, f'{name}:{path.relative_to(ROOT)}')


def build_gate(errors: list[str]) -> None:
    build = (ROOT / 'app/build.gradle.kts').read_text(encoding='utf-8')
    if 'storePassword' in build or 'keyPassword' in build or 'aion-debug.keystore' in build:
        fail(errors, 'custom_debug_signing_secret_reference_present')


def main() -> int:
    errors: list[str] = []
    manifest_gate(errors)
    secrets_gate(errors)
    build_gate(errors)
    if errors:
        print('AION_SECURITY_GATE_FAIL')
        for item in errors:
            print('-', item)
        return 1
    print('AION_SECURITY_GATE_PASS')
    print(f'permissions={len(ALLOWED_PERMISSIONS)} exported_whitelist=MainActivity secrets=clean fileprovider=scoped')
    return 0


if __name__ == '__main__':
    sys.exit(main())
