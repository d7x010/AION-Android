# AION α8.2 — Step 12 Batch 3 (12.11 → 12.15)

الحالة: مكتملة كدفعة ثالثة من Step 12. لا تبدأ 12.16 من هذا الملف قبل الاعتماد على هذا الـSnapshot أو Snapshot أحدث محفوظ ومثبت.

## 12.11 — Automatic successful-search indexing
- أضيف `AionKnowledgeSearchIndexer`.
- الفهرسة لا تعمل أثناء partial/error؛ يتم استدعاؤها فقط من `persistSuccessfulResult` في مساري Foreground Service وJob Recovery.
- المصدر يجب أن يحمل URL HTTP/HTTPS، مع dedupe حسب URL وحد أقصى 24 مصدرًا للنتيجة الواحدة.
- الكتابة idempotent عبر stable id + content hash، لذلك إعادة Recovery لا تضاعف المعرفة.

## 12.12 — Project / Conversation scope enforcement
- أضيف `KnowledgeAccessPolicy` و`KnowledgeAccessContext`.
- العزل يسبق scoring: PROJECT لا يظهر إلا داخل نفس projectId، وCONVERSATION لا يظهر إلا لنفس conversationId ونفس project affinity.
- `AionKnowledgeStore.retrieve()` يطبق العزل قبل `hybridRetrieve()`.
- نقل محادثة إلى مشروع آخر يعيد ربط project affinity لمعرفة المحادثة نفسها بدل تسريبها أو فقدها بصمت.

## 12.13 — No automatic promotion to global truth
- `KnowledgeWriteOrigin.AUTOMATIC_SEARCH` يجبر أي نتيجة بحث تلقائية إلى `KnowledgeScope.CONVERSATION` مهما كان scope المطلوب من caller.
- نتائج البحث لا تُرقّى تلقائيًا إلى USER أو PROJECT.
- USER/PROJECT knowledge تبقى مسارات صريحة/مقيدة وليست نتيجة جانبية لمحادثة عادية.

## 12.14 — Temporary Chats never persist Knowledge
- `AionKnowledgeSearchIndexer` يفحص `MemoryPrivacyStore.mode()` ويرفض Temporary Chat قبل الفهرسة.
- `KnowledgeAccessPolicy.prepareWrite()` يرفض أي كتابة عندما `temporary=true` كحاجز ثانٍ fail-closed.
- `filterVisible()` يعيد صفر Knowledge في Temporary Chat، لذلك لا يوجد read/write عبر Knowledge API لذلك السياق.

## 12.15 — Lifecycle cleanup for Project / Conversation deletion
- حذف Conversation يستدعي `AionKnowledgeStore.deleteConversation()` ويحذف Knowledge المحلي الخاص بها.
- حذف Project يحذف PROJECT knowledge الخاص به، بينما Conversation knowledge التابعة لمحادثات باقية تُفصل من projectId بدل حذف سجل المحادثة نفسه.
- نقل Conversation يستدعي `rebindConversationProject()` لضمان استمرار العزل الصحيح بعد النقل.

## ملفات الإنتاج الجديدة/المعدلة
- `app/src/main/java/com/aion/mobile/core/knowledge/KnowledgeAccessPolicy.kt`
- `app/src/main/java/com/aion/mobile/core/knowledge/AionKnowledgeStore.kt`
- `app/src/main/java/com/aion/mobile/core/knowledge/AionKnowledgeSearchIndexer.kt`
- `app/src/main/java/com/aion/mobile/core/run/AionRunService.kt`
- `app/src/main/java/com/aion/mobile/core/run/AionJobRecoveryRunner.kt`
- `app/src/main/java/com/aion/mobile/feature/chat/ChatViewModel.kt`

## اختبارات داخل المشروع
- `app/src/test/java/com/aion/mobile/core/knowledge/KnowledgeAccessPolicyTest.kt`

## نتائج التحقق
- `STEP12_BATCH3_POLICY_SELFTEST_PASS`
- `STEP12_BATCH3_TEST_SOURCE_COMPILE_PASS`
- `STEP12_BATCH3_STORE_PERSISTENCE_CLEANUP_PASS`
- `STEP12_BATCH3_SEARCH_INDEXER_PASS`
- `STEP12_BATCH3_INTEGRATION_SANITY_PASS`
- `STEP12_BATCH3_ANDROID_OWNER_PARSE_SMOKE_PASS`
- Regression: `STEP12_BATCH1_SELFTEST_PASS`
- Regression: `STEP12_BATCH2_SELFTEST_PASS`

## قيود التحقق الحالية
لم يُشغّل Gradle/Android SDK الكامل في هذه البيئة. الاختبارات أعلاه هي Kotlin/JVM policy tests، Android-store/indexer compile/execution مع stubs خارج المشروع، وsource/parser integration checks. بوابة Gradle الكاملة تبقى ضمن الإغلاق النهائي/Step 15 حسب البروتوكول الحاكم.

## الإصدار
لم يُرفع الإصدار عمدًا:
- versionName = `2.0.0-alpha8.2-dev1`
- versionCode = `56`
رفع الإصدار يبقى مؤجلًا إلى Step 15.
