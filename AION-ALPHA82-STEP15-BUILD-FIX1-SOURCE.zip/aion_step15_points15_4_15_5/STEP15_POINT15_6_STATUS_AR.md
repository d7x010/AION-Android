# AION — Step 15.6 Status

التاريخ: 2026-09-12

## الهدف
اختبار تثبيت/ترقية APK على جهاز Android أو Emulator حقيقي عندما تكون الأدوات متاحة، مع عدم ادعاء نجاح وهمي عند غياب الجهاز/ADB.

## التنفيذ
تمت إضافة:
- `tools/release/aion_step15_device_gate.py`
- `tools/release/test_step15_device_gate.py`
- `release/STEP15_DEVICE_DECISION.json`

البوابة تدعم:
- `probe`: اكتشاف ADB والأجهزة المتصلة.
- `test`: تثبيت candidate APK وتشغيل `MainActivity` والتحقق من package version.
- optional baseline APK لاختبار upgrade فعلي عبر `adb install -r` مع اشتراط أن candidate versionCode أعلى.
- FAIL-CLOSED عند فشل التثبيت/التشغيل أو تراجع versionCode.

## النتيجة الحالية
- Self-test: `STEP15_15_6_DEVICE_GATE_SELFTEST_PASS`.
- Runtime probe: `AION_STEP15_DEVICE_GATE_UNAVAILABLE adb_missing`.
- `device_upgrade_status = unavailable`.
- لا APK حالي لأن 15.2–15.4 ما زالت محجوبة خارجيًا.

هذه الحالة **UNAVAILABLE وليست FAIL**، وهي متوافقة مع عقد Release Gate الذي يسمح بتسجيل غياب الجهاز صراحةً بدل اختلاق اختبار.
