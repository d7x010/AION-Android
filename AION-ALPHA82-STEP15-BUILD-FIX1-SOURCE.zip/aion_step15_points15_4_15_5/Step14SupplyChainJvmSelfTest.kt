package com.aion.mobile.core.local

import com.aion.mobile.core.storage.AionStorageSchemaRegistry
import java.io.File
import java.nio.file.Files

fun main() {
    val accepting = object : ModelPackSignatureVerifier {
        override fun verify(file: File, descriptor: LocalModelPackDescriptor, signature: String): Boolean = signature == "sig"
    }
    fun base(file: File, source: String = "https://models.aion.example/nano.pack", signature: String? = "sig") =
        LocalModelPackDescriptor(
            modelId = "nano",
            version = "1.0.0",
            expectedSizeBytes = file.length(),
            sha256 = ModelPackVerifier(accepting).sha256(file),
            signature = signature,
            requireSignature = true,
            provenance = ModelPackProvenance(
                sourceType = ModelPackSourceType.REMOTE_REPOSITORY,
                sourceUri = source,
                publisher = "AION Model Registry",
                acquiredAtEpochMs = 2_000L,
                issuedAtEpochMs = 1_000L,
                manifestSha256 = "0".repeat(64),
                signatureAlgorithm = "Ed25519",
                signerKeyId = "prod-model-key-v1",
            ),
            requirements = LocalModelRequirements("nano", 1L, 1L, 1L, false),
        )

    val root = Files.createTempDirectory("aion-step14-supply").toFile()
    val pack = File(root, "nano.pack").apply { writeText("signed-model") }
    val sealed = ModelPackSupplyChainPolicy.seal(base(pack))
    check(ModelPackVerifier(accepting).verify(pack, sealed) is ModelPackVerificationResult.Verified)

    val insecure = ModelPackSupplyChainPolicy.seal(base(pack, source = "http://models.example/nano.pack"))
    val insecureResult = ModelPackVerifier(accepting).verify(pack, insecure) as ModelPackVerificationResult.Failed
    check(insecureResult.code == ModelPackVerificationResult.Code.SUPPLY_CHAIN_INVALID)
    check(insecureResult.detail.startsWith("INSECURE_REMOTE_SOURCE:"))

    val unsigned = ModelPackSupplyChainPolicy.seal(base(pack, signature = null).copy(requireSignature = false))
    val unsignedResult = ModelPackVerifier(accepting).verify(pack, unsigned) as ModelPackVerificationResult.Failed
    check(unsignedResult.detail.startsWith("SIGNATURE_REQUIRED:"))

    val tokenUrl = sealed.copy(provenance = sealed.provenance!!.copy(sourceUri = "https://models.aion.example/nano.pack?token=secret"))
    val tokenResult = ModelPackVerifier(accepting).verify(pack, tokenUrl) as ModelPackVerificationResult.Failed
    check(tokenResult.detail.startsWith("INVALID_SOURCE_URI:"))

    val tampered = sealed.copy(requirements = sealed.requirements.copy(estimatedResidentBytes = 999L))
    val tamperedResult = ModelPackVerifier(accepting).verify(pack, tampered) as ModelPackVerificationResult.Failed
    check(tamperedResult.detail.startsWith("MANIFEST_DIGEST_MISMATCH:"))

    val defaultReject = ModelPackVerifier().verify(pack, sealed) as ModelPackVerificationResult.Failed
    check(defaultReject.code == ModelPackVerificationResult.Code.SIGNATURE_INVALID)

    val registryFile = File(root, "models.bin")
    val registry = LocalModelRegistryStore(registryFile)
    registry.replace(listOf(LocalModelRecord(sealed, LocalModelState.NOT_INSTALLED)))
    val restored = registry.readAll().getValue("nano")
    check(restored.descriptor.provenance == sealed.provenance)
    check(AionStorageSchemaRegistry.localModels.currentVersion == 2)
    check(AionStorageSchemaRegistry.localModels.canRead(1))

    val originalPayload = ModelPackVerifier(accepting).signaturePayload(sealed).decodeToString()
    val changedPayload = ModelPackVerifier(accepting).signaturePayload(
        sealed.copy(requirements = sealed.requirements.copy(minimumAvailableRamBytes = 2L))
    ).decodeToString()
    check(originalPayload != changedPayload)
    check(originalPayload.contains(sealed.provenance!!.manifestSha256))

    println("STEP14_14_6_SUPPLY_CHAIN_SELFTEST_PASS")
}
