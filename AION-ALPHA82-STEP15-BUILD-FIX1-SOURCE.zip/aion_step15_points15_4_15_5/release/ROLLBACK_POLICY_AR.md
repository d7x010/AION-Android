# سياسة Rollback / Last Known Good في AION

- لا يقوم AION بتخفيض APK ذاتيًا ولا يحذف بيانات المستخدم عند crash-loop.
- بعد فشلين متتاليين أثناء startup يدخل التطبيق Safe Mode ويُسجل أن rollback خارجي مطلوب.
- rollback الثنائي الصحيح يعيد بناء **مصدر Last Known Good** مع `versionCode` جديد أعلى من النسخة المثبتة، بدل محاولة تثبيت `versionCode` أقدم.
- قبل أي rollback يجب أن يثبت الـgate أن نسخة LKG تستطيع قراءة كل schema قد تكون النسخة الحالية كتبتها بالفعل.
- البيانات تبقى في مكانها؛ لا يوجد schema downgrade تلقائي.
- ملف `LAST_KNOWN_GOOD.json` هو مؤشر rollback إلى النسخة السابقة المثبتة والمختبرة، وليس ادعاءً أن النسخة الحالية نفسها صالحة للرجوع إليها.
