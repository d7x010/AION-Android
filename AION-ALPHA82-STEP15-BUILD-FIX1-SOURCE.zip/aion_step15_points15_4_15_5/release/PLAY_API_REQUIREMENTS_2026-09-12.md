# AION — Google Play / Android API verification — 2026-09-12

هذه الوثيقة تسجل تحقق 14.9 من المصدر الحالي فقط، ولا تدعي نشرًا فعليًا على Google Play.

## متطلبات تم التحقق منها من المصدر
- Google Play mobile new apps/updates after 2026-08-31: target API 36+ → AION targetSdk=36.
- Android 16 SDK → compileSdk=36.
- Android Gradle Plugin مناسب لـ API 36 → AGP 9.4.0.
- Android 16 edge-to-edge → `enableEdgeToEdge()` موجود ولا يوجد opt-out قديم.
- Predictive Back → لا يوجد استعمال `KEYCODE_BACK` أو `onBackPressed()` legacy في مصدر Kotlin الحالي.
- dataSync FGS → النوع والإذنان الأساسي والنوعي موجودان في Manifest.
- Android 15 dataSync timeout → `Service.onTimeout(startId, fgsType)` يوقف foreground/service ويحفظ retry state.
- BOOT_COMPLETED → لا يشغّل dataSync FGS؛ يوقظ JobScheduler recovery فقط.
- لا توجد native libraries/CMake/ndk sources في المشروع الحالي؛ لذلك متطلبات 64-bit و16 KB page size لا تحتاج ELF/native remediation الآن.
- Android application plugin موجود، لذا مصدر المشروع يدعم بناء Android App Bundle؛ الـAAB الفعلي مؤجل إلى Step 15.

## متطلبات خارج المصدر لا يمكن إثباتها هنا
- تصريح Foreground Service `dataSync` في Play Console، مع وصف الاستخدام وتأثير التأجيل/القطع وفيديو توضيحي.
- مراجعة Data safety / privacy / store declarations بحيث تطابق السلوك الفعلي للإصدار المنشور.
- إنشاء signed AAB حقيقي ورفعه/اختباره في Play Console؛ هذا ضمن Step 15 وليس 14.9.

## ملاحظة سياسة
استخدام AION الحالي لـ `dataSync` يطابق فئة نقل/جلب البيانات بين الجهاز والسحابة تقنيًا، لكن القبول النهائي لهذا الاستخدام وسياسة Play Console يبقيان قرار مراجعة Google Play، وليس شيئًا يمكن للمصدر وحده إثباته.
