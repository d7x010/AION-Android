# AION α8.2 — Step 11 Batch 1 (11.1 → 11.5)

التاريخ: 2026-09-12
الحالة: مكتمل كدفعة وسيطة، وليس إغلاق Step 11 بالكامل.
القاعدة: مبني فوق AION-ALPHA82-CONSISTENCY-RECOVERED-SOURCE.zip.

## 11.1 Device Resource Profiler
- AndroidDeviceResourceProfiler يقرأ RAM الكلية والمتاحة وlow-memory.
- يقرأ المساحة المتاحة داخل تخزين التطبيق.
- يقرأ نسبة البطارية وحالة الشحن.
- يقرأ Power Saver.
- يقرأ thermal status على Android Q+ ويحوّله إلى ThermalLevel واضح.

## 11.2 Resource Governor
- قرار ALLOW / DEFER / DENY.
- severe thermal يمنع local inference.
- البطارية الحرجة بدون شحن تؤجل local inference.
- سياسة background أكثر تحفظًا مع Power Saver والبطارية والحرارة.
- حدود RAM وstorage.
- max concurrent local models مشتق من موارد الجهاز.
- resident-memory budget منفصل عن عدد النماذج.

## 11.3 Local Model Manager lifecycle
الحالات الفعلية:
NOT_INSTALLED / DOWNLOADING / VERIFYING / READY / LOADED / UNLOADING / FAILED.
- سجل النماذج محفوظ على القرص.
- الكتابة تستخدم temp + fsync + atomic replace قدر الإمكان.
- LOADED/UNLOADING بعد process recreation لا يُفترض أنه ما زال محملاً؛ يرجع إلى READY إذا بقي pack صالحًا.
- تنزيل/تحقق منقطع يصبح FAILED بدل ادعاء READY.
- UnavailableLocalModelRuntime يفشل مغلقًا ولا يدّعي وجود LLM محلي.

## 11.4 Model Pack verification
- حجم الملف.
- SHA-256.
- ModelPackSignatureVerifier interface.
- default verifier يرفض أي توقيع لا يوجد verifier حقيقي للتحقق منه.
- التحقق يتم قبل commit، وبعد commit، ومرة أخرى قبل load لمنع pack معدّل من التحول إلى READY/LOADED.

## 11.5 LRU / memory-pressure eviction
- LRU حسب last-used ثم loaded-at ثم model id لتثبيت السلوك.
- eviction تلقائي قبل load إذا تجاوز العدد/ميزانية resident memory.
- AndroidMemoryPressureMonitor يربط ComponentCallbacks2 بالـmanager.
- CRITICAL pressure يفرغ كل local models المحملة.
- HIGH/MODERATE تقلص المجموعة تدريجيًا.
- AndroidLocalModelEnvironment يسجل monitor فعليًا عند الإنشاء ويلغيه عند close.

## التحقق
PASS: STEP11_BATCH1_SELFTEST_PASS
PASS: STEP11_BATCH1_ANDROID_COMPILE_PASS

Self-test يغطي:
- severe thermal.
- critical battery.
- hash mismatch -> FAILED.
- lifecycle persistence/process recreation.
- LRU eviction.
- critical memory-pressure eviction.
- signature fail-closed.

Android compile check شغّل Kotlin compiler على ملفات Android الجديدة مع stubs مؤقتة خارج شجرة المشروع للتحقق من الترابط النحوي/النوعي.

## قيد صريح
لم يتم تشغيل Gradle/Android SDK build كامل في هذه البيئة، لذلك لا يوجد ادعاء APK أو assembleDebug لهذه الدفعة.

## التالي
11.6 → 11.10 فقط. لا تعتبر Step 11 مغلقًا قبل تنفيذ بقية المتطلبات ثم بوابة الإغلاق النهائية وحفظ AION-ALPHA82-STEP11-COMPLETE-SOURCE.zip.
