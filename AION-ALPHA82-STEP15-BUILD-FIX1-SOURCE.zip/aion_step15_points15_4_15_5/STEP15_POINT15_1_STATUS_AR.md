# AION — Step 15.1 Status

## النطاق
تنفيذ أول بند فقط من Step 15 الحاكم: رفع `versionName/versionCode` بعد استقرار المصدر، دون بدء Gradle build أو APK/AAB.

## التغييرات
- `applicationId` بقي `com.aion.mobile`.
- `versionName`: من `2.0.0-alpha8.2-dev1` إلى `2.0.0-alpha8.2-dev2`.
- `versionCode`: من `56` إلى `57`.
- بقي `release/LAST_KNOWN_GOOD.json` مثبتًا على Snapshot 14.6 (`dev1 / 56`) ولم يُعاد تعريفه إلى المصدر الحالي.
- أضيف `tools/release/aion_step15_version_gate.py` كبوابة fail-closed لرفع الإصدار.
- أضيف `tools/release/test_step15_version_gate.py`.
- أضيف `release/STEP15_VERSION_DECISION.json`.
- تم تحديث `release/STEP15_RELEASE_EVIDENCE.example.json` ليحمل الإصدار الفعلي `dev2 / 57` مع إبقاء أدلة البناء false حتى تنفيذها فعليًا.
- تم تعديل بوابة 14.10 بحيث يحافظ وضع `source` على عقد Step 14 التاريخي، بينما يسمح وضع `production` في Step 15 فقط بإصدار أعلى من LKG. هذا يمنع تعطل Release Gate بعد الرفع ويحافظ على fail-closed.
- تم تحويل اختبار Step 14 التاريخي إلى fixture `dev1 / 56` بدل ربطه بالإصدار الحالي المتغير.

## الاختبارات
- `STEP15_15_1_VERSION_GATE_SELFTEST_PASS`.
- `AION_STEP15_VERSION_GATE_PASS`.
- `STEP14_14_10_RELEASE_GATE_SELFTEST_PASS`.
- Rollback Gate: PASS، وأصبح `rollback_rebuild_version_code=58` للمصدر الحالي 57.
- Security Gate: PASS.
- Supply-chain Gate: PASS.
- Full Regression Gate: PASS.
- Play/API Gate: PASS.
- Production transition check: PASS؛ بوابة production وصلت إلى `evidence_file_missing` وأرجعت code 2 بدل رفض version bump.

## ما لم يُختبر في 15.1
- لم يُشغّل Gradle test/lint/assemble أو bundleRelease؛ هذا يبدأ في 15.2 وفق المرجع الحاكم.
- لم يُنتج APK أو AAB.
- لم يتم توقيع release artifact.
- لا يوجد Android SDK/ADB في هذه البيئة حتى الآن، لذلك لا يوجد اختبار جهاز.
- لم يتم تنفيذ أي إجراء خارجي في Play Console.

## القرار
**Step 15.1 PASS** للمصدر والإصدار فقط. الانتقال التالي هو 15.2، ولا توجد أي مطالبة بأن التطبيق مبني أو جاهز للنشر بعد.
