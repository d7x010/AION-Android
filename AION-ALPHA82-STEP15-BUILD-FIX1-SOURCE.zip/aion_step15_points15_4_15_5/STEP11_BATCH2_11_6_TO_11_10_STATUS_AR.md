# AION α8.2 — Step 11 Batch 2 (11.6 → 11.10)

التاريخ: 2026-09-12
الحالة: مكتمل كدفعة ثانية؛ لا يبدأ Step 12 من هذا الملف قبل إغلاق Step 11 رسميًا.
القاعدة: مبني فوق Snapshot الدفعة 11.1 → 11.5 المحفوظة.

## 11.6 Storage Budget
- LocalStorageBudgetPolicy يحدد سقفًا حقيقيًا لملفات النماذج حسب pool التخزين القابل للاستخدام مع reserve للنظام وabsolute cap.
- LocalModelManager يفرض القرار قبل atomicCopy للـmodel pack.
- تجاوز الميزانية ينتج FAILED مع storage_budget_exceeded ولا يدعي READY.

## 11.7 Offline Capability Matrix
- مصفوفة صريحة للقدرات Offline.
- القدرة المؤكدة محليًا: DETERMINISTIC_ARITHMETIC فقط عبر aion-nano-deterministic-v1.
- GENERAL_CHAT / WEB_SEARCH / REMOTE_FILE_ANALYSIS / CLOUD_TOOLS لا تُعلن كقدرات offline.

## 11.8 Backend Health + Circuit Breaker
- rolling آخر 20 sample: success/failure/latency.
- CLOSED / OPEN / HALF_OPEN.
- threshold افتراضي 3 failures ثم open window.
- HALF_OPEN يسمح probe واحدة عبر durable probe lease، ويمكن التعافي بعد process death.
- التخزين يستخدم atomic replace قدر الإمكان.
- AionRunService وAionJobRecoveryRunner يستشيران صحة AION Cloud قبل التنفيذ السحابي ويسجلان النجاح/الفشل.

## 11.9 AION Local / aion-nano-deterministic-v1
- الحساب الصريح ينفذ داخل APK عبر DeterministicCalculator بلا شبكة.
- يتم قبل server reconciliation إذا لم يعبر الـRun حدود Cloud سابقًا.
- execution metadata: provider=AION Local, model=aion-nano-deterministic-v1, routing=local-deterministic-v1.
- المسار موجود في foreground service وJobScheduler recovery.

## 11.10 Honest routing + date guard + telemetry fail-safe
- المحادثة العامة تبقى Cloud؛ لا يوجد ادعاء LLM محلي.
- forceWebSearch والمرفقات لا يتم اعتراضها بالحساب المحلي.
- ISO date مثل 2026-09-11 و2026 - 09 - 11 لا تُصنف كطرح.
- LocalTelemetry best-effort فقط، واستدعاؤها بعد حفظ الرد؛ فشلها لا يسقط ردًا ناجحًا.
- Backend health metadata persistence أيضًا best-effort.

## التحقق
PASS: STEP11_BATCH2_SELFTEST_PASS
PASS: STEP11_BATCH2_ANDROID_LOCAL_COMPILE_PASS
PASS: STEP11_BATCH2_INTEGRATION_SANITY_PASS

Self-test يغطي:
- storage budget policy + enforcement داخل LocalModelManager.
- Offline Capability Matrix honesty.
- circuit CLOSED→OPEN→HALF_OPEN→CLOSED.
- half-open probe lease recovery بعد process recreation.
- rolling success/failure/average latency persistence.
- explicit Arabic arithmetic executes locally.
- general chat routes to Cloud.
- force web search routes to Cloud.
- ISO-date/date-like text not parsed as arithmetic.
- telemetry I/O failure is contained.

## قيد صريح
لم يتم تشغيل Gradle/Android SDK assembleDebug في هذه البيئة. Android-local compile check استخدم Kotlin compiler وAndroid stubs خارج شجرة المشروع؛ integration sanity تحقق من ترتيب الربط في المصدر الحقيقي. لا يوجد ادعاء APK أو Gradle PASS.

## التالي
أغلق Step 11 ببوابة regression مجمعة على 11.1→11.10 ثم احفظ AION-ALPHA82-STEP11-COMPLETE-SOURCE.zip قبل بدء Step 12.
