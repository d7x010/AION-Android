package com.aion.mobile.core.knowledge

import android.content.Context
import com.aion.mobile.core.storage.DurableFileRecovery
import java.io.File

/** Durable on-device Knowledge Engine store with scope/privacy enforcement at its public read/write API. */
object AionKnowledgeStore {
    private const val FILE_NAME = "knowledge_v1.aion"
    private const val MAX_STORED_ENTRIES = 4_000

    /** Raw durable rows are intentionally internal to maintenance/migration paths. */
    internal fun loadAll(context: Context): List<AionKnowledgeEntry> {
        val result = DurableFileRecovery.readText(file(context), KnowledgeStoreCodec::isReadable)
        val raw = result.bytes?.toString(Charsets.UTF_8) ?: return emptyList()
        return KnowledgeStoreCodec.decodeStrict(raw).orEmpty()
    }

    fun retrieve(
        context: Context,
        query: String,
        access: KnowledgeAccessContext,
        now: Long = System.currentTimeMillis(),
        limit: Int = KnowledgeEnginePolicy.DEFAULT_LIMIT
    ): KnowledgeRetrievalResult {
        val visible = KnowledgeAccessPolicy.filterVisible(loadAll(context), access)
        return KnowledgeEnginePolicy.hybridRetrieve(visible, query, now, limit)
    }

    fun upsert(
        context: Context,
        entry: AionKnowledgeEntry,
        access: KnowledgeAccessContext,
        origin: KnowledgeWriteOrigin
    ): AionKnowledgeEntry? {
        val clean = KnowledgeAccessPolicy.prepareWrite(entry, access, origin) ?: return null
        val rows = loadAll(context).toMutableList()
        val exact = rows.indexOfFirst { it.id == clean.id }
        if (exact >= 0) {
            rows[exact] = clean
        } else {
            val duplicate = rows.indexOfFirst { old ->
                old.scope == clean.scope && old.ownerId == clean.ownerId && old.projectId == clean.projectId &&
                    old.provenance.contentHash == clean.provenance.contentHash &&
                    old.provenance.sourceUrl == clean.provenance.sourceUrl
            }
            if (duplicate >= 0) {
                val old = rows[duplicate]
                rows[duplicate] = clean.copy(id = old.id, createdAt = old.createdAt)
            } else rows += clean
        }
        val bounded = bounded(rows)
        if (!persist(context, bounded)) return null
        return bounded.firstOrNull { it.id == clean.id }
            ?: bounded.firstOrNull {
                it.provenance.contentHash == clean.provenance.contentHash && it.scope == clean.scope &&
                    it.ownerId == clean.ownerId && it.projectId == clean.projectId
            }
    }

    fun deleteConversation(context: Context, conversationId: String): KnowledgeCleanupResult {
        val mutation = KnowledgeAccessPolicy.cleanupConversation(loadAll(context), conversationId)
        return if (mutation.result.removed == 0 || persist(context, bounded(mutation.entries))) {
            mutation.result
        } else KnowledgeCleanupResult()
    }

    fun deleteProject(context: Context, projectId: String): KnowledgeCleanupResult {
        val mutation = KnowledgeAccessPolicy.cleanupProject(loadAll(context), projectId)
        return if ((mutation.result.removed == 0 && mutation.result.detachedFromProject == 0) || persist(context, bounded(mutation.entries))) {
            mutation.result
        } else KnowledgeCleanupResult()
    }

    fun rebindConversationProject(context: Context, conversationId: String, projectId: String?): Boolean {
        val current = loadAll(context)
        val rebound = KnowledgeAccessPolicy.rebindConversationProject(current, conversationId, projectId)
        if (rebound == current) return true
        return persist(context, bounded(rebound))
    }

    /** Reserved for controlled migration/import; normal callers must use upsert() above. */
    internal fun replaceAllForMigration(context: Context, entries: List<AionKnowledgeEntry>): Boolean =
        persist(context, bounded(entries))

    private fun bounded(entries: List<AionKnowledgeEntry>): List<AionKnowledgeEntry> = entries
        .mapNotNull(KnowledgeEnginePolicy::sanitize)
        .sortedWith(compareByDescending<AionKnowledgeEntry> { it.active }.thenByDescending { it.updatedAt })
        .take(MAX_STORED_ENTRIES)

    private fun directory(context: Context): File = File(context.filesDir, "aion_knowledge").also {
        if (!it.exists()) it.mkdirs()
    }

    private fun file(context: Context): File = File(directory(context), FILE_NAME)

    private fun persist(context: Context, entries: List<AionKnowledgeEntry>): Boolean {
        val raw = KnowledgeStoreCodec.encode(entries)
        return DurableFileRecovery.writeText(file(context), raw, KnowledgeStoreCodec::isReadable)
    }
}
