package com.aion.mobile.core.run

data class RuntimeSnapshotStamp(
    val runId: String,
    val revision: Long,
    val terminal: Boolean,
    val isRunning: Boolean,
    val textLength: Int,
)

object RuntimeSnapshotAcceptancePolicy {
    fun shouldAccept(current: RuntimeSnapshotStamp?, next: RuntimeSnapshotStamp): Boolean {
        if (current == null || current.runId != next.runId) return true
        if (current.terminal && !next.terminal) return false
        if (current.revision > 0L && next.revision > 0L && next.revision < current.revision) return false
        if (current.revision > 0L && next.revision == current.revision &&
            current.textLength > next.textLength && !next.terminal) return false
        return current != next
    }
}

object RuntimeModelStatusPolicy {
    fun label(
        isRunning: Boolean,
        executionModelId: String,
        executionProviderLabel: String,
        requestedModelLabel: String,
        phase: RuntimeUiPhase?,
        liveExecution: Boolean,
    ): String? {
        if (!isRunning || phase in setOf(RuntimeUiPhase.COMPLETED, RuntimeUiPhase.FAILED, RuntimeUiPhase.CANCELLED)) return null
        val actualModel = executionModelId.trim()
        val provider = executionProviderLabel.trim()
        if (actualModel.isNotBlank()) return if (provider.isNotBlank()) "$provider · $actualModel" else actualModel
        if (!liveExecution && phase !in setOf(RuntimeUiPhase.WAITING_NETWORK, RuntimeUiPhase.WAITING_TOOL, RuntimeUiPhase.WAITING_USER, RuntimeUiPhase.PAUSED, RuntimeUiPhase.BLOCKED, RuntimeUiPhase.QUEUED)) {
            return "بانتظار استئناف التنفيذ"
        }
        return when (phase) {
            RuntimeUiPhase.WAITING_NETWORK -> "لم يبدأ التنفيذ · بانتظار الشبكة"
            RuntimeUiPhase.WAITING_TOOL -> "تنفيذ الأدوات"
            RuntimeUiPhase.WAITING_USER -> "بانتظار إجراء منك"
            RuntimeUiPhase.PAUSED, RuntimeUiPhase.BLOCKED -> "التنفيذ متوقف"
            RuntimeUiPhase.QUEUED -> "قيد الاستعداد"
            else -> requestedModelLabel.trim().takeIf { label ->
                label.isNotBlank() && !label.contains("auto", ignoreCase = true) && !label.contains("تلقائي")
            }?.let { "مطلوب: $it" } ?: "جار اختيار النموذج"
        }
    }
}
