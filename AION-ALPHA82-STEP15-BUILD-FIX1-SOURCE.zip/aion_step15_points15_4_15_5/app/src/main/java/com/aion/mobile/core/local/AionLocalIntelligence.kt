package com.aion.mobile.core.local

import com.aion.mobile.core.ai.GatewayExecution
import com.aion.mobile.core.ai.GatewayResult
import com.aion.mobile.core.tools.DeterministicCalculator
import com.aion.mobile.model.ChatMessage
import com.aion.mobile.model.MessageRole

sealed interface LocalIntelligenceDecision {
    data class Executed(val result: GatewayResult) : LocalIntelligenceDecision
    data class CloudRequired(val reason: String) : LocalIntelligenceDecision
}

/**
 * Conservative intent classifier: it only intercepts an explicit arithmetic request.
 * Anything ambiguous is left for Cloud rather than pretending a local LLM exists.
 */
object LocalArithmeticIntentClassifier {
    private val isoDate = Regex("^\\s*\\d{4}\\s*[-/]\\s*\\d{1,2}\\s*[-/]\\s*\\d{1,2}\\s*$")
    private val dateWithText = Regex("(?i).*(?:date|تاريخ|اليوم|موعد).*\\d{4}[-/]\\d{1,2}[-/]\\d{1,2}.*")
    private val explicitArabicPrefix = Regex("^\\s*(?:احسب|احسبلي|احسب لي|كم يساوي|ناتج)\\s*[:：]?\\s*(.+?)\\s*[؟?]?\\s*$")
    private val explicitEnglishPrefix = Regex("(?i)^\\s*(?:calculate|compute|what is)\\s+(.+?)\\s*[?]?\\s*$")
    private val mathOnly = Regex("^[\\s0-9٠-٩۰-۹.+\\-−*/×÷%^()]+$")
    private val hasOperator = Regex("[+\\-−*/×÷%^]")

    fun extractExpression(text: String): String? {
        val trimmed = text.trim()
        if (trimmed.isBlank() || isoDate.matches(trimmed) || dateWithText.matches(trimmed)) return null
        val candidate = explicitArabicPrefix.matchEntire(trimmed)?.groupValues?.getOrNull(1)
            ?: explicitEnglishPrefix.matchEntire(trimmed)?.groupValues?.getOrNull(1)
            ?: trimmed.takeIf { mathOnly.matches(it) && hasOperator.containsMatchIn(it) }
            ?: return null
        val clean = candidate.trim().removeSuffix("؟").removeSuffix("?").trim()
        if (isoDate.matches(clean)) return null
        return clean.takeIf { it.isNotBlank() && mathOnly.matches(it) && hasOperator.containsMatchIn(it) }
    }
}

object AionLocalIntelligence {
    fun route(messages: List<ChatMessage>, forceWebSearch: Boolean): LocalIntelligenceDecision {
        if (forceWebSearch) return LocalIntelligenceDecision.CloudRequired("web_search_requested")
        val lastUser = messages.lastOrNull { it.role == MessageRole.USER }
            ?: return LocalIntelligenceDecision.CloudRequired("no_user_message")
        if (lastUser.attachments.isNotEmpty()) return LocalIntelligenceDecision.CloudRequired("attachments_require_cloud")
        val expression = LocalArithmeticIntentClassifier.extractExpression(lastUser.text)
            ?: return LocalIntelligenceDecision.CloudRequired("general_chat_requires_cloud")
        return when (val calculated = DeterministicCalculator.evaluate(expression)) {
            is DeterministicCalculator.Result.Success -> LocalIntelligenceDecision.Executed(
                GatewayResult(
                    text = calculated.text,
                    execution = GatewayExecution(
                        providerKey = OfflineCapabilityMatrix.LOCAL_PROVIDER_KEY,
                        providerLabel = OfflineCapabilityMatrix.LOCAL_PROVIDER_LABEL,
                        modelId = OfflineCapabilityMatrix.NANO_MODEL_ID,
                        routingPolicy = "local-deterministic-v1",
                        fallbackUsed = false,
                        attempts = 1,
                    ),
                )
            )
            is DeterministicCalculator.Result.Failure -> LocalIntelligenceDecision.CloudRequired("arithmetic_not_safely_parseable")
        }
    }
}
