package com.aion.mobile.core.storage

import java.io.File
import java.io.FileOutputStream
import java.nio.file.Files
import java.nio.file.StandardCopyOption

/**
 * Small durable-file primitive used by user-data stores.
 *
 * Guarantees:
 * - primary data is validated before being accepted;
 * - every valid primary seeds/refreshes a Last Known Good sidecar;
 * - a corrupt primary is restored only from a validated LKG copy;
 * - if both primary and LKG are invalid, writes fail closed instead of overwriting evidence/data;
 * - replacement uses fsync + atomic move when available.
 */
object DurableFileRecovery {
    private const val LKG_SUFFIX = ".lkg"

    data class ReadResult(
        val bytes: ByteArray?,
        val recoveredFromLkg: Boolean = false,
        val corruptWithoutRecovery: Boolean = false,
    )

    fun lkgFile(primary: File): File = File(primary.parentFile, primary.name + LKG_SUFFIX)

    fun readText(primary: File, validator: (String) -> Boolean): ReadResult = readBytes(primary) { bytes ->
        runCatching { validator(bytes.toString(Charsets.UTF_8)) }.getOrDefault(false)
    }

    fun writeText(primary: File, text: String, validator: (String) -> Boolean): Boolean {
        if (!runCatching { validator(text) }.getOrDefault(false)) return false
        return writeBytes(primary, text.toByteArray(Charsets.UTF_8)) { bytes ->
            runCatching { validator(bytes.toString(Charsets.UTF_8)) }.getOrDefault(false)
        }
    }

    fun readBytes(primary: File, validator: (ByteArray) -> Boolean): ReadResult {
        if (!primary.isFile) return ReadResult(bytes = null)
        val primaryBytes = runCatching { primary.readBytes() }.getOrNull()
        if (primaryBytes != null && runCatching { validator(primaryBytes) }.getOrDefault(false)) {
            seedLkg(primary, primaryBytes, validator)
            return ReadResult(bytes = primaryBytes)
        }

        val backup = lkgFile(primary)
        val backupBytes = runCatching { backup.takeIf { it.isFile }?.readBytes() }.getOrNull()
        if (backupBytes != null && runCatching { validator(backupBytes) }.getOrDefault(false)) {
            if (atomicReplace(primary, backupBytes)) {
                return ReadResult(bytes = backupBytes, recoveredFromLkg = true)
            }
            // Even when restore cannot replace the primary, callers may safely read the validated LKG.
            return ReadResult(bytes = backupBytes, recoveredFromLkg = true)
        }
        return ReadResult(bytes = null, corruptWithoutRecovery = true)
    }

    fun writeBytes(primary: File, bytes: ByteArray, validator: (ByteArray) -> Boolean): Boolean {
        if (!runCatching { validator(bytes) }.getOrDefault(false)) return false
        primary.parentFile?.mkdirs()

        if (primary.isFile) {
            val current = runCatching { primary.readBytes() }.getOrNull()
            val currentValid = current != null && runCatching { validator(current) }.getOrDefault(false)
            if (!currentValid) {
                val backup = lkgFile(primary)
                val backupBytes = runCatching { backup.takeIf { it.isFile }?.readBytes() }.getOrNull()
                val backupValid = backupBytes != null && runCatching { validator(backupBytes) }.getOrDefault(false)
                if (!backupValid) return false
                if (!atomicReplace(primary, backupBytes!!)) return false
            }
        }

        if (!atomicReplace(primary, bytes)) return false
        // The LKG may be older if the process dies here, but it is always valid. That is intentional.
        return atomicReplace(lkgFile(primary), bytes)
    }

    private fun seedLkg(primary: File, bytes: ByteArray, validator: (ByteArray) -> Boolean) {
        val backup = lkgFile(primary)
        val existing = runCatching { backup.takeIf { it.isFile }?.readBytes() }.getOrNull()
        if (existing != null && runCatching { validator(existing) }.getOrDefault(false)) return
        runCatching { atomicReplace(backup, bytes) }
    }

    private fun atomicReplace(target: File, bytes: ByteArray): Boolean = runCatching {
        target.parentFile?.mkdirs()
        val temp = File(target.parentFile, target.name + ".tmp-" + System.nanoTime())
        FileOutputStream(temp).use { out ->
            out.write(bytes)
            out.fd.sync()
        }
        try {
            Files.move(
                temp.toPath(),
                target.toPath(),
                StandardCopyOption.ATOMIC_MOVE,
                StandardCopyOption.REPLACE_EXISTING,
            )
        } catch (_: Throwable) {
            Files.move(temp.toPath(), target.toPath(), StandardCopyOption.REPLACE_EXISTING)
        }
        true
    }.getOrDefault(false)
}
