package com.aion.mobile.core.local

import java.io.File
import java.io.FileInputStream
import java.security.MessageDigest

interface ModelPackSignatureVerifier {
    /**
     * Returns true only when [signature] authenticates BOTH the pack bytes and the canonical
     * descriptor/provenance manifest. Implementations must verify [ModelPackVerifier.signaturePayload].
     */
    fun verify(file: File, descriptor: LocalModelPackDescriptor, signature: String): Boolean
}

/** Safe default: no external model pack is trusted until a real verifier/keyring is injected. */
object RejectingModelPackSignatureVerifier : ModelPackSignatureVerifier {
    override fun verify(file: File, descriptor: LocalModelPackDescriptor, signature: String): Boolean = false
}

sealed interface ModelPackVerificationResult {
    data object Verified : ModelPackVerificationResult
    data class Failed(val code: Code, val detail: String) : ModelPackVerificationResult

    enum class Code {
        FILE_MISSING,
        SIZE_MISMATCH,
        HASH_MISMATCH,
        SUPPLY_CHAIN_INVALID,
        SIGNATURE_INVALID,
        IO_ERROR,
    }
}

class ModelPackVerifier(
    private val signatureVerifier: ModelPackSignatureVerifier = RejectingModelPackSignatureVerifier,
) {
    fun verify(file: File, descriptor: LocalModelPackDescriptor): ModelPackVerificationResult {
        when (val supplyChain = ModelPackSupplyChainPolicy.validate(descriptor)) {
            ModelPackSupplyChainResult.Trusted -> Unit
            is ModelPackSupplyChainResult.Rejected -> return ModelPackVerificationResult.Failed(
                ModelPackVerificationResult.Code.SUPPLY_CHAIN_INVALID,
                "${supplyChain.code}:${supplyChain.detail}",
            )
        }
        if (!file.isFile) {
            return ModelPackVerificationResult.Failed(ModelPackVerificationResult.Code.FILE_MISSING, file.absolutePath)
        }
        if (file.length() != descriptor.expectedSizeBytes) {
            return ModelPackVerificationResult.Failed(
                ModelPackVerificationResult.Code.SIZE_MISMATCH,
                "actual=${file.length()}, expected=${descriptor.expectedSizeBytes}",
            )
        }
        val actualHash = runCatching { sha256(file) }.getOrElse {
            return ModelPackVerificationResult.Failed(ModelPackVerificationResult.Code.IO_ERROR, it.message.orEmpty())
        }
        if (!actualHash.equals(descriptor.sha256, ignoreCase = true)) {
            return ModelPackVerificationResult.Failed(
                ModelPackVerificationResult.Code.HASH_MISMATCH,
                "actual=$actualHash",
            )
        }
        val signature = requireNotNull(descriptor.signature)
        if (!signatureVerifier.verify(file, descriptor, signature)) {
            return ModelPackVerificationResult.Failed(ModelPackVerificationResult.Code.SIGNATURE_INVALID, "signature rejected")
        }
        return ModelPackVerificationResult.Verified
    }

    fun sha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        FileInputStream(file).use { input ->
            val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
            while (true) {
                val read = input.read(buffer)
                if (read <= 0) break
                digest.update(buffer, 0, read)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }

    /** Stable UTF-8 payload a trusted keyring must authenticate together with the pack bytes. */
    fun signaturePayload(descriptor: LocalModelPackDescriptor): ByteArray {
        val provenance = requireNotNull(descriptor.provenance) { "provenance required" }
        val requirements = descriptor.requirements
        val manifest = listOf(
            "aion-model-pack-signature-v1",
            descriptor.modelId,
            descriptor.version,
            descriptor.expectedSizeBytes.toString(),
            descriptor.sha256.lowercase(),
            descriptor.requireSignature.toString(),
            requirements.modelId,
            requirements.minimumAvailableRamBytes.toString(),
            requirements.estimatedResidentBytes.toString(),
            requirements.minimumFreeStorageBytes.toString(),
            requirements.allowBackground.toString(),
            provenance.sourceType.name,
            provenance.sourceUri.trim(),
            provenance.publisher.trim(),
            provenance.acquiredAtEpochMs.toString(),
            provenance.issuedAtEpochMs.toString(),
            provenance.manifestSha256.lowercase(),
            provenance.signatureAlgorithm,
            provenance.signerKeyId,
        ).joinToString("\n")
        return manifest.toByteArray(Charsets.UTF_8)
    }
}
