package com.aion.mobile.core.local

import android.content.Context
import java.io.File

/**
 * Android-owned wiring for Step 11 local model infrastructure.
 * Creating it registers memory-pressure callbacks; [close] must be called when the owner is disposed.
 */
class AndroidLocalModelEnvironment(
    context: Context,
    signatureVerifier: ModelPackSignatureVerifier = RejectingModelPackSignatureVerifier,
    runtime: LocalModelRuntime = UnavailableLocalModelRuntime,
) : AutoCloseable {
    private val appContext = context.applicationContext
    val profiler: DeviceResourceProfiler = AndroidDeviceResourceProfiler(appContext)
    val governor: ResourceGovernor = ResourceGovernor()

    private val root = File(appContext.filesDir, "aion_local_models")
    val manager: LocalModelManager = LocalModelManager(
        modelDirectory = File(root, "packs"),
        registry = LocalModelRegistryStore(File(root, "registry.bin")),
        verifier = ModelPackVerifier(signatureVerifier),
        resourceGovernor = governor,
        runtime = runtime,
    )

    private val memoryPressureMonitor = AndroidMemoryPressureMonitor(appContext, manager).also { it.register() }

    override fun close() {
        memoryPressureMonitor.unregister()
    }
}
