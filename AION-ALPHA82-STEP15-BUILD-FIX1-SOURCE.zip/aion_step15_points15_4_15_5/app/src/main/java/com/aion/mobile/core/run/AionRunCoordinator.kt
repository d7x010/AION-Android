package com.aion.mobile.core.run

import android.content.Context
import android.content.Intent
import com.aion.mobile.core.ai.GatewayActivity
import com.aion.mobile.core.run.fault.RunCancellationFence
import com.aion.mobile.model.ChatMessage
import com.aion.mobile.model.ChatSource
import com.aion.mobile.core.sovereign.SovereignTask
import com.aion.mobile.core.sovereign.SovereignTaskMachine
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

internal data class AionRunRequest(
    val runId: String,
    val conversationId: String,
    val placeholderId: Long,
    val modelId: String,
    val modelLabel: String,
    val messages: List<ChatMessage>,
    val sessionMessages: List<ChatMessage>,
    val forceWebSearch: Boolean,
    val customInstructions: String,
    val memoryContext: String,
    val contextContext: String
)

data class AionRunSnapshot(
    val runId: String,
    val conversationId: String = "",
    val placeholderId: Long,
    val modelId: String,
    val modelLabel: String,
    val executionProviderKey: String = "",
    val executionProviderLabel: String = "",
    val executionModelId: String = "",
    val routingPolicy: String = "",
    val fallbackUsed: Boolean = false,
    val executionAttempts: Int = 1,
    val orchestratorContract: Int = 0,
    val orchestratorTraceId: String = "",
    val orchestratorSearchReason: String = "",
    val orchestratorMemoryPolicy: String = "",
    val orchestratorToolRoute: String = "",
    val orchestratorResponseProfile: String = "",
    val text: String = "",
    val activity: GatewayActivity = GatewayActivity.THINKING,
    val isRunning: Boolean = true,
    val sources: List<ChatSource> = emptyList(),
    val errorText: String? = null,
    val wasStopped: Boolean = false,
    val runtimeUi: RuntimeUiTruth? = null,
    val runtimeRevision: Long = 0L,
    val runtimeUpdatedAt: String = "",
    val restoredFromDisk: Boolean = false
)

internal object AionRunRegistry {
    private val requests = ConcurrentHashMap<String, AionRunRequest>()

    fun register(request: AionRunRequest) {
        requests[request.runId] = request
    }

    fun get(runId: String): AionRunRequest? = requests[runId]

    fun remove(runId: String) {
        requests.remove(runId)
    }
}

object AionRunBus {
    private val _snapshot = MutableStateFlow<AionRunSnapshot?>(null)
    private val publishLock = Any()
    val snapshot: StateFlow<AionRunSnapshot?> = _snapshot.asStateFlow()

    fun publish(snapshot: AionRunSnapshot?) = synchronized(publishLock) {
        if (snapshot == null) {
            _snapshot.value = null
            return@synchronized
        }
        val current = _snapshot.value
        val currentStamp = current?.let {
            RuntimeSnapshotStamp(
                runId = it.runId,
                revision = it.runtimeRevision,
                terminal = it.runtimeUi?.terminal == true || !it.isRunning,
                isRunning = it.isRunning,
                textLength = it.text.length,
            )
        }
        val nextStamp = RuntimeSnapshotStamp(
            runId = snapshot.runId,
            revision = snapshot.runtimeRevision,
            terminal = snapshot.runtimeUi?.terminal == true || !snapshot.isRunning,
            isRunning = snapshot.isRunning,
            textLength = snapshot.text.length,
        )
        if (!RuntimeSnapshotAcceptancePolicy.shouldAccept(currentStamp, nextStamp)) return@synchronized
        _snapshot.value = snapshot
    }
}

object AionRunCoordinator {
    fun start(
        context: Context,
        conversationId: String,
        placeholderId: Long,
        modelId: String,
        modelLabel: String,
        messages: List<ChatMessage>,
        sessionMessages: List<ChatMessage>,
        forceWebSearch: Boolean,
        customInstructions: String = "",
        memoryContext: String = "",
        contextContext: String = ""
    ): String {
        val runId = UUID.randomUUID().toString()
        val request = AionRunRequest(
            runId = runId,
            conversationId = conversationId,
            placeholderId = placeholderId,
            modelId = modelId,
            modelLabel = modelLabel,
            messages = messages,
            sessionMessages = sessionMessages,
            forceWebSearch = forceWebSearch,
            customInstructions = customInstructions,
            memoryContext = memoryContext,
            contextContext = contextContext
        )
        // Durable source of truth is written before any Service intent. The registry below
        // is only a hot cache and may disappear on process death.
        AionRunRequestStore.save(context.noBackupFilesDir, request)
        SovereignTaskStore.save(
            context.noBackupFilesDir,
            SovereignTask(id = runId, goal = "chat:$conversationId")
        )
        // Persist the wake-up guarantee before touching any in-memory cache or Service.
        // If the process dies after this line, JobScheduler can still recover the run.
        AionRecoveryScheduler.scheduleGeneral(context, 1_000L)
        AionRunRegistry.register(request)
        AionRunUiRestorer.publishDurableTruth(context, runId)

        val intent = Intent(context, AionRunService::class.java).apply {
            action = AionRunService.ACTION_START
            putExtra(AionRunService.EXTRA_RUN_ID, runId)
        }
        context.startForegroundService(intent)
        return runId
    }

    fun stop(context: Context, runId: String?) {
        if (runId.isNullOrBlank()) return
        // Persist cancellation before signalling the Service. If the process dies in
        // between, recovery sees the tombstone and must not resurrect this run.
        RunCancellationFence.mark(context.noBackupFilesDir, runId)
        SovereignTaskStore.load(context.noBackupFilesDir, runId)?.let { task ->
            val requested = SovereignTaskMachine.requestCancel(task)
            SovereignTaskStore.save(context.noBackupFilesDir, SovereignTaskMachine.applyCancellation(requested))
        }
        AionRunUiRestorer.persistCancelledPartial(context, runId)
        AionRunUiRestorer.publishDurableTruth(context, runId)
        context.startService(
            Intent(context, AionRunService::class.java).apply {
                action = AionRunService.ACTION_STOP
                putExtra(AionRunService.EXTRA_RUN_ID, runId)
            }
        )
    }

    fun cancelAll(context: Context) {
        val root = context.noBackupFilesDir
        AionRunRequestStore.listRunIds(root).forEach { runId ->
            RunCancellationFence.mark(root, runId)
            SovereignTaskStore.load(root, runId)?.let { task ->
                val requested = SovereignTaskMachine.requestCancel(task)
                SovereignTaskStore.save(root, SovereignTaskMachine.applyCancellation(requested))
            }
            AionRunUiRestorer.persistCancelledPartial(context, runId)
            AionRunUiRestorer.publishDurableTruth(context, runId)
        }
        context.startService(Intent(context, AionRunService::class.java).apply { action = AionRunService.ACTION_STOP_ALL })
    }

}
