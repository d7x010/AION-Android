package com.aion.mobile.core.knowledge

enum class KnowledgeScope { USER, PROJECT, CONVERSATION }

enum class KnowledgeSourceType {
    NEWS,
    WEB_PAGE,
    DOCUMENT,
    PROJECT_FILE,
    MANUAL
}

data class KnowledgeProvenance(
    val sourceUrl: String = "",
    val sourceTitle: String = "",
    val sourceType: KnowledgeSourceType,
    val contentHash: String = "",
    val observedAt: Long,
    val fetchedAt: Long = observedAt,
    val publishedAt: Long = 0L
)

data class AionKnowledgeEntry(
    val id: String,
    val scope: KnowledgeScope,
    val ownerId: String = "",
    /** Project affinity for conversation knowledge. Empty means a non-project conversation. */
    val projectId: String = "",
    val title: String = "",
    val text: String,
    /** Stable semantic key for a claim when the ingester can identify one. */
    val claimKey: String = "",
    /** Normalized value asserted for claimKey. Different values surface as contradictions. */
    val claimValue: String = "",
    val provenance: KnowledgeProvenance,
    val authority: Float = 0.5f,
    val confidence: Float = 0.5f,
    val createdAt: Long,
    val updatedAt: Long,
    val active: Boolean = true
)

data class KnowledgeHit(
    val entry: AionKnowledgeEntry,
    val score: Double,
    val lexicalScore: Double,
    val vectorScore: Double,
    val freshnessScore: Double,
    val authorityScore: Double,
    val confidenceScore: Double
)

data class KnowledgeConflictVariant(
    val entryId: String,
    val value: String,
    val sourceTitle: String,
    val sourceUrl: String,
    val sourceType: KnowledgeSourceType,
    val observedAt: Long,
    val confidence: Float
)

data class KnowledgeContradiction(
    val claimKey: String,
    val variants: List<KnowledgeConflictVariant>
)

data class KnowledgeRetrievalResult(
    val hits: List<KnowledgeHit> = emptyList(),
    val contradictions: List<KnowledgeContradiction> = emptyList(),
    val candidateCount: Int = 0
)
