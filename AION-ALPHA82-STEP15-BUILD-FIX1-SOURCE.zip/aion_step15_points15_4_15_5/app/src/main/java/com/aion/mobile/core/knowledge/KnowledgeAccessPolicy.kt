package com.aion.mobile.core.knowledge

/** Why a Knowledge entry is being written. Automatic web search is intentionally the most restricted origin. */
enum class KnowledgeWriteOrigin {
    AUTOMATIC_SEARCH,
    USER_EXPLICIT,
    PROJECT_FILE,
    IMPORTED_DOCUMENT,
    MIGRATION
}

data class KnowledgeAccessContext(
    val conversationId: String = "",
    val projectId: String = "",
    val temporary: Boolean = false
)

data class KnowledgeCleanupResult(
    val removed: Int = 0,
    val detachedFromProject: Int = 0
)

data class KnowledgeCleanupMutation(
    val entries: List<AionKnowledgeEntry>,
    val result: KnowledgeCleanupResult
)

/**
 * Scope/privacy contract for Knowledge Engine.
 *
 * Invariants:
 * - Project and conversation isolation is decided before scoring.
 * - Temporary conversations cannot read or write Knowledge.
 * - Automatic search results can never become USER/PROJECT global truth; they are conversation-local.
 */
object KnowledgeAccessPolicy {
    const val CONTRACT = 1
    const val POLICY = "knowledge-scope-privacy-v1"

    fun visibleInContext(entry: AionKnowledgeEntry, access: KnowledgeAccessContext): Boolean {
        if (access.temporary || !entry.active) return false
        val projectId = access.projectId.trim()
        val conversationId = access.conversationId.trim()
        return when (entry.scope) {
            KnowledgeScope.USER -> true
            KnowledgeScope.PROJECT -> projectId.isNotBlank() && entry.ownerId == projectId && entry.projectId == projectId
            KnowledgeScope.CONVERSATION -> {
                if (conversationId.isBlank() || entry.ownerId != conversationId) return false
                if (entry.projectId.isBlank()) projectId.isBlank() else entry.projectId == projectId
            }
        }
    }

    fun filterVisible(entries: List<AionKnowledgeEntry>, access: KnowledgeAccessContext): List<AionKnowledgeEntry> =
        if (access.temporary) emptyList() else entries.filter { visibleInContext(it, access) }

    fun prepareWrite(
        entry: AionKnowledgeEntry,
        access: KnowledgeAccessContext,
        origin: KnowledgeWriteOrigin
    ): AionKnowledgeEntry? {
        if (access.temporary) return null
        val clean = KnowledgeEnginePolicy.sanitize(entry) ?: return null
        val conversationId = access.conversationId.trim().take(160)
        val projectId = access.projectId.trim().take(160)

        val scoped = when (origin) {
            KnowledgeWriteOrigin.AUTOMATIC_SEARCH -> {
                if (conversationId.isBlank()) return null
                clean.copy(
                    scope = KnowledgeScope.CONVERSATION,
                    ownerId = conversationId,
                    projectId = projectId
                )
            }
            KnowledgeWriteOrigin.PROJECT_FILE -> {
                if (projectId.isBlank()) return null
                clean.copy(scope = KnowledgeScope.PROJECT, ownerId = projectId, projectId = projectId)
            }
            KnowledgeWriteOrigin.USER_EXPLICIT,
            KnowledgeWriteOrigin.IMPORTED_DOCUMENT,
            KnowledgeWriteOrigin.MIGRATION -> clean
        }
        val sanitized = KnowledgeEnginePolicy.sanitize(scoped) ?: return null
        // Non-automatic callers still cannot smuggle project/conversation data into another active scope.
        return when (sanitized.scope) {
            KnowledgeScope.USER -> sanitized
            KnowledgeScope.PROJECT -> sanitized.takeIf { projectId.isNotBlank() && it.ownerId == projectId && it.projectId == projectId }
            KnowledgeScope.CONVERSATION -> sanitized.takeIf {
                conversationId.isNotBlank() && it.ownerId == conversationId &&
                    ((it.projectId.isBlank() && projectId.isBlank()) || it.projectId == projectId)
            }
        }
    }

    fun cleanupConversation(entries: List<AionKnowledgeEntry>, conversationId: String): KnowledgeCleanupMutation {
        val id = conversationId.trim()
        if (id.isBlank()) return KnowledgeCleanupMutation(entries, KnowledgeCleanupResult())
        val kept = entries.filterNot { it.scope == KnowledgeScope.CONVERSATION && it.ownerId == id }
        return KnowledgeCleanupMutation(
            entries = kept,
            result = KnowledgeCleanupResult(removed = entries.size - kept.size)
        )
    }

    fun cleanupProject(entries: List<AionKnowledgeEntry>, projectId: String): KnowledgeCleanupMutation {
        val id = projectId.trim()
        if (id.isBlank()) return KnowledgeCleanupMutation(entries, KnowledgeCleanupResult())
        var removed = 0
        var detached = 0
        val next = entries.mapNotNull { entry ->
            when {
                entry.scope == KnowledgeScope.PROJECT && entry.ownerId == id -> {
                    removed += 1
                    null
                }
                entry.scope == KnowledgeScope.CONVERSATION && entry.projectId == id -> {
                    detached += 1
                    entry.copy(projectId = "")
                }
                else -> entry
            }
        }
        return KnowledgeCleanupMutation(next, KnowledgeCleanupResult(removed, detached))
    }

    fun rebindConversationProject(
        entries: List<AionKnowledgeEntry>,
        conversationId: String,
        projectId: String?
    ): List<AionKnowledgeEntry> {
        val conversation = conversationId.trim()
        if (conversation.isBlank()) return entries
        val project = projectId.orEmpty().trim().take(160)
        return entries.map { entry ->
            if (entry.scope == KnowledgeScope.CONVERSATION && entry.ownerId == conversation) {
                entry.copy(projectId = project)
            } else entry
        }
    }
}
