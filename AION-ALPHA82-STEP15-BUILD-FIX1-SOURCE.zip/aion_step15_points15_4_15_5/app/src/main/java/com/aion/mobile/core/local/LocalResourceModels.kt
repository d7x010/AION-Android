package com.aion.mobile.core.local

import java.io.File

/** Snapshot واحد immutable لموارد الجهاز؛ لا يُفترض أن يبقى صالحًا لوقت طويل. */
data class DeviceResourceSnapshot(
    val capturedAtEpochMs: Long,
    val totalRamBytes: Long,
    val availableRamBytes: Long,
    val lowMemory: Boolean,
    val availableStorageBytes: Long,
    val batteryPercent: Int?,
    val charging: Boolean,
    val powerSaver: Boolean,
    val thermalLevel: ThermalLevel,
) {
    init {
        require(capturedAtEpochMs >= 0L)
        require(totalRamBytes >= 0L)
        require(availableRamBytes >= 0L)
        require(availableStorageBytes >= 0L)
        require(batteryPercent == null || batteryPercent in 0..100)
    }
}

enum class ThermalLevel {
    UNKNOWN,
    NONE,
    LIGHT,
    MODERATE,
    SEVERE,
    CRITICAL,
    EMERGENCY,
    SHUTDOWN;

    fun atLeast(other: ThermalLevel): Boolean = rank() >= other.rank()

    private fun rank(): Int = when (this) {
        UNKNOWN -> 0
        NONE -> 0
        LIGHT -> 1
        MODERATE -> 2
        SEVERE -> 3
        CRITICAL -> 4
        EMERGENCY -> 5
        SHUTDOWN -> 6
    }
}

enum class ExecutionEnvironment { FOREGROUND, BACKGROUND }

enum class LocalExecutionDecision { ALLOW, DEFER, DENY }

enum class LocalExecutionReason {
    OK,
    THERMAL_LIMIT,
    BATTERY_CRITICAL,
    POWER_SAVER_BACKGROUND,
    BACKGROUND_NOT_ALLOWED,
    RAM_LOW,
    STORAGE_LOW,
    MODEL_LIMIT,
}

data class LocalModelRequirements(
    val modelId: String,
    val minimumAvailableRamBytes: Long,
    val estimatedResidentBytes: Long,
    val minimumFreeStorageBytes: Long = 0L,
    val allowBackground: Boolean = false,
) {
    init {
        require(modelId.isNotBlank())
        require(minimumAvailableRamBytes >= 0L)
        require(estimatedResidentBytes >= 0L)
        require(minimumFreeStorageBytes >= 0L)
    }
}

data class ResourceGovernorDecision(
    val decision: LocalExecutionDecision,
    val reason: LocalExecutionReason,
    val maxConcurrentLocalModels: Int,
    val maxResidentBytes: Long,
    val detail: String = "",
) {
    val allowed: Boolean get() = decision == LocalExecutionDecision.ALLOW
}

interface DeviceResourceProfiler {
    fun snapshot(): DeviceResourceSnapshot
}

enum class LocalModelState {
    NOT_INSTALLED,
    DOWNLOADING,
    VERIFYING,
    READY,
    LOADED,
    UNLOADING,
    FAILED,
}

enum class ModelPackSourceType {
    REMOTE_REPOSITORY,
    BUNDLED_RELEASE,
    USER_IMPORT,
    LEGACY_UNVERIFIED,
}

data class ModelPackProvenance(
    val sourceType: ModelPackSourceType,
    val sourceUri: String,
    val publisher: String,
    val acquiredAtEpochMs: Long,
    val issuedAtEpochMs: Long,
    val manifestSha256: String,
    val signatureAlgorithm: String,
    val signerKeyId: String,
) {
    fun validationError(): String? {
        val normalizedUri = sourceUri.trim()
        val uri = runCatching { java.net.URI(normalizedUri) }.getOrNull() ?: return "source_uri_invalid"
        val scheme = uri.scheme?.lowercase()
        when (sourceType) {
            ModelPackSourceType.REMOTE_REPOSITORY -> {
                if (scheme != "https" || uri.host.isNullOrBlank()) return "remote_source_must_be_https"
            }
            ModelPackSourceType.BUNDLED_RELEASE -> {
                if (scheme != "bundled") return "bundled_source_scheme_invalid"
            }
            ModelPackSourceType.USER_IMPORT -> {
                if (scheme !in setOf("file", "content")) return "user_import_source_invalid"
            }
            ModelPackSourceType.LEGACY_UNVERIFIED -> return "legacy_unverified"
        }
        if (normalizedUri.length > 2048) return "source_uri_too_long"
        if (uri.userInfo != null || uri.rawQuery != null || uri.rawFragment != null) return "source_uri_must_not_contain_credentials_query_or_fragment"
        if (publisher.isBlank() || publisher.length > 160) return "publisher_invalid"
        if (acquiredAtEpochMs <= 0L) return "acquired_at_invalid"
        if (issuedAtEpochMs <= 0L || issuedAtEpochMs > acquiredAtEpochMs) return "issued_at_invalid"
        if (!manifestSha256.matches(Regex("^[0-9a-fA-F]{64}$"))) return "manifest_sha256_invalid"
        if (signatureAlgorithm !in SUPPORTED_SIGNATURE_ALGORITHMS) return "signature_algorithm_unsupported"
        if (!signerKeyId.matches(Regex("^[A-Za-z0-9._:@/-]{3,160}$"))) return "signing_key_id_invalid"
        return null
    }

    companion object {
        val SUPPORTED_SIGNATURE_ALGORITHMS = setOf("Ed25519", "SHA256withECDSA", "SHA256withRSA")
    }
}

data class LocalModelPackDescriptor(
    val modelId: String,
    val version: String,
    val expectedSizeBytes: Long,
    val sha256: String,
    val signature: String? = null,
    val requireSignature: Boolean = true,
    val provenance: ModelPackProvenance? = null,
    val requirements: LocalModelRequirements,
) {
    init {
        require(modelId.isNotBlank())
        require(version.isNotBlank())
        require(expectedSizeBytes >= 0L)
        require(sha256.matches(Regex("^[0-9a-fA-F]{64}$")))
        require(requirements.modelId == modelId)
    }
}

data class LocalModelRecord(
    val descriptor: LocalModelPackDescriptor,
    val state: LocalModelState,
    val packPath: String? = null,
    val lastUsedAtEpochMs: Long = 0L,
    val loadedAtEpochMs: Long? = null,
    val failureReason: String? = null,
) {
    fun packFileOrNull(): File? = packPath?.let(::File)
}

enum class MemoryPressure {
    NORMAL,
    MODERATE,
    HIGH,
    CRITICAL,
}
