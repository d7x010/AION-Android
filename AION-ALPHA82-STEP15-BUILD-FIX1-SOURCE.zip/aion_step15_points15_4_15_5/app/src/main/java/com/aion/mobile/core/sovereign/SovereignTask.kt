package com.aion.mobile.core.sovereign

import java.time.Instant
import java.util.UUID

enum class SovereignTaskState {
    QUEUED, PLANNING, RUNNING, WAITING_TOOL, WAITING_NETWORK, WAITING_USER,
    VERIFYING, PAUSED, BLOCKED, COMPLETED, FAILED_RECOVERABLE, FAILED_FINAL, CANCELLED
}

data class TaskCheckpoint(
    val savedAt: String,
    val state: SovereignTaskState,
    val stepId: String? = null,
    val payload: Map<String, String> = emptyMap(),
)

data class TaskFailure(
    val type: String,
    val recoverable: Boolean,
    val action: String,
    val message: String = "",
)

data class SovereignTask(
    val contract: Int = 1,
    val id: String = "aion_${UUID.randomUUID()}",
    val goal: String,
    val state: SovereignTaskState = SovereignTaskState.QUEUED,
    val currentStep: String? = null,
    val checkpoint: TaskCheckpoint? = null,
    val dependencies: Set<String> = emptySet(),
    val outputs: List<String> = emptyList(),
    val attempts: Int = 0,
    val maxAttempts: Int = 5,
    val createdAt: String = Instant.now().toString(),
    val updatedAt: String = createdAt,
    val lastHeartbeatAt: String? = null,
    val nextRetryAt: String? = null,
    val blockedReason: String? = null,
    val lastFailure: TaskFailure? = null,
    val revision: Long = 1,
    val cancelRequested: Boolean = false,
)

object SovereignTaskMachine {
    private val terminal = setOf(SovereignTaskState.COMPLETED, SovereignTaskState.FAILED_FINAL, SovereignTaskState.CANCELLED)
    private val transitions = mapOf(
        SovereignTaskState.QUEUED to setOf(SovereignTaskState.PLANNING, SovereignTaskState.PAUSED, SovereignTaskState.CANCELLED, SovereignTaskState.BLOCKED),
        SovereignTaskState.PLANNING to setOf(SovereignTaskState.RUNNING, SovereignTaskState.WAITING_USER, SovereignTaskState.WAITING_NETWORK, SovereignTaskState.FAILED_RECOVERABLE, SovereignTaskState.FAILED_FINAL, SovereignTaskState.PAUSED, SovereignTaskState.CANCELLED, SovereignTaskState.BLOCKED),
        SovereignTaskState.RUNNING to setOf(SovereignTaskState.WAITING_TOOL, SovereignTaskState.WAITING_NETWORK, SovereignTaskState.WAITING_USER, SovereignTaskState.VERIFYING, SovereignTaskState.FAILED_RECOVERABLE, SovereignTaskState.FAILED_FINAL, SovereignTaskState.PAUSED, SovereignTaskState.CANCELLED, SovereignTaskState.BLOCKED),
        SovereignTaskState.WAITING_TOOL to setOf(SovereignTaskState.RUNNING, SovereignTaskState.VERIFYING, SovereignTaskState.FAILED_RECOVERABLE, SovereignTaskState.FAILED_FINAL, SovereignTaskState.PAUSED, SovereignTaskState.CANCELLED, SovereignTaskState.BLOCKED),
        SovereignTaskState.WAITING_NETWORK to setOf(SovereignTaskState.QUEUED, SovereignTaskState.RUNNING, SovereignTaskState.FAILED_RECOVERABLE, SovereignTaskState.PAUSED, SovereignTaskState.CANCELLED, SovereignTaskState.BLOCKED),
        SovereignTaskState.WAITING_USER to setOf(SovereignTaskState.QUEUED, SovereignTaskState.RUNNING, SovereignTaskState.PAUSED, SovereignTaskState.CANCELLED, SovereignTaskState.BLOCKED),
        SovereignTaskState.VERIFYING to setOf(SovereignTaskState.COMPLETED, SovereignTaskState.RUNNING, SovereignTaskState.FAILED_RECOVERABLE, SovereignTaskState.FAILED_FINAL, SovereignTaskState.PAUSED, SovereignTaskState.CANCELLED, SovereignTaskState.BLOCKED),
        SovereignTaskState.PAUSED to setOf(SovereignTaskState.QUEUED, SovereignTaskState.PLANNING, SovereignTaskState.RUNNING, SovereignTaskState.CANCELLED, SovereignTaskState.BLOCKED),
        SovereignTaskState.BLOCKED to setOf(SovereignTaskState.QUEUED, SovereignTaskState.PLANNING, SovereignTaskState.RUNNING, SovereignTaskState.WAITING_USER, SovereignTaskState.WAITING_NETWORK, SovereignTaskState.PAUSED, SovereignTaskState.CANCELLED, SovereignTaskState.FAILED_FINAL),
        SovereignTaskState.FAILED_RECOVERABLE to setOf(SovereignTaskState.QUEUED, SovereignTaskState.PLANNING, SovereignTaskState.RUNNING, SovereignTaskState.WAITING_NETWORK, SovereignTaskState.BLOCKED, SovereignTaskState.FAILED_FINAL, SovereignTaskState.CANCELLED),
        SovereignTaskState.COMPLETED to emptySet(),
        SovereignTaskState.FAILED_FINAL to emptySet(),
        SovereignTaskState.CANCELLED to emptySet(),
    )

    fun canTransition(from: SovereignTaskState, to: SovereignTaskState): Boolean = from == to || transitions[from]?.contains(to) == true

    fun transition(task: SovereignTask, to: SovereignTaskState, now: String = Instant.now().toString()): SovereignTask {
        require(canTransition(task.state, to)) { "invalid_task_transition:${task.state}->$to" }
        val enteringRun = to == SovereignTaskState.RUNNING && task.state != SovereignTaskState.RUNNING
        return task.copy(
            state = to,
            attempts = task.attempts + if (enteringRun) 1 else 0,
            updatedAt = now,
            revision = task.revision + 1,
            nextRetryAt = if (to in terminal) null else task.nextRetryAt,
            blockedReason = if (to in terminal) null else task.blockedReason,
        )
    }

    fun checkpoint(task: SovereignTask, payload: Map<String, String>, now: String = Instant.now().toString()): SovereignTask {
        require(task.state !in terminal) { "cannot_checkpoint_terminal_task" }
        return task.copy(
            checkpoint = TaskCheckpoint(now, task.state, task.currentStep, payload),
            updatedAt = now,
            revision = task.revision + 1,
        )
    }

    fun requestCancel(task: SovereignTask, now: String = Instant.now().toString()): SovereignTask {
        if (task.state in terminal) return task
        return task.copy(cancelRequested = true, updatedAt = now, revision = task.revision + 1)
    }

    fun applyCancellation(task: SovereignTask, now: String = Instant.now().toString()): SovereignTask {
        if (!task.cancelRequested || task.state in terminal) return task
        return transition(task, SovereignTaskState.CANCELLED, now)
    }
}

object SovereignFailureClassifier {
    fun classify(status: Int = 0, code: String = "", message: String = ""): TaskFailure {
        val c = code.lowercase(); val m = message.lowercase()
        return when {
            status == 401 || status == 403 || "auth" in c -> TaskFailure("authentication_required", true, "block_user_auth", message)
            status == 429 || "rate" in c -> TaskFailure("rate_limit", true, "backoff", message)
            status == 408 || status == 504 || "timeout" in c || "timeout" in m -> TaskFailure("timeout", true, "retry", message)
            status >= 500 || "network" in c || "network" in m || "fetch" in m -> TaskFailure("network_or_upstream", true, "wait_network", message)
            "context" in c || "context length" in m || "too large" in m -> TaskFailure("context_overflow", true, "compact_context", message)
            "sandbox" in c -> TaskFailure("sandbox_failure", true, "restart_sandbox", message)
            status in 400..499 -> TaskFailure("invalid_request", false, "replan_or_fail", message)
            else -> TaskFailure("unknown", true, "bounded_retry", message)
        }
    }
}
