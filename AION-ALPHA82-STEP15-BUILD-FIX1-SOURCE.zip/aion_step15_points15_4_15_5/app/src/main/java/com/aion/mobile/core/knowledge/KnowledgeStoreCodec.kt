package com.aion.mobile.core.knowledge

import com.aion.mobile.core.storage.AionStorageSchemaRegistry
import java.util.Base64

/** Stable line codec so persistence can be round-trip tested without Android JSON dependencies. */
object KnowledgeStoreCodec {
    const val HEADER = "AION_KNOWLEDGE_V1"

    fun encode(entries: List<AionKnowledgeEntry>): String = buildString {
        append(HEADER).append('\n')
        entries.mapNotNull(KnowledgeEnginePolicy::sanitize)
            .sortedBy { it.id }
            .forEach { row ->
                val fields = listOf(
                    row.id,
                    row.scope.name,
                    row.ownerId,
                    row.projectId,
                    row.title,
                    row.text,
                    row.claimKey,
                    row.claimValue,
                    row.provenance.sourceUrl,
                    row.provenance.sourceTitle,
                    row.provenance.sourceType.name,
                    row.provenance.contentHash,
                    row.provenance.observedAt.toString(),
                    row.provenance.fetchedAt.toString(),
                    row.provenance.publishedAt.toString(),
                    row.authority.toString(),
                    row.confidence.toString(),
                    row.createdAt.toString(),
                    row.updatedAt.toString(),
                    if (row.active) "1" else "0"
                )
                append(fields.joinToString("\t") { encodeField(it) }).append('\n')
            }
    }

    fun isReadable(raw: String): Boolean = decodeStrict(raw) != null

    fun decode(raw: String): List<AionKnowledgeEntry> = decodeStrict(raw).orEmpty()

    fun decodeStrict(raw: String): List<AionKnowledgeEntry>? {
        val lines = raw.lineSequence().toList()
        val header = lines.firstOrNull()?.trim().orEmpty()
        val version = Regex("^AION_KNOWLEDGE_V(\\d+)$").matchEntire(header)
            ?.groupValues?.getOrNull(1)?.toIntOrNull() ?: return null
        if (!AionStorageSchemaRegistry.knowledge.canRead(version)) return null

        val output = ArrayList<AionKnowledgeEntry>()
        for (line in lines.drop(1)) {
            if (line.isBlank()) continue
            val row = runCatching {
                val f = line.split('\t').map(::decodeField)
                if (f.size != 20) return@runCatching null
                KnowledgeEnginePolicy.sanitize(
                    AionKnowledgeEntry(
                        id = f[0],
                        scope = KnowledgeScope.valueOf(f[1]),
                        ownerId = f[2],
                        projectId = f[3],
                        title = f[4],
                        text = f[5],
                        claimKey = f[6],
                        claimValue = f[7],
                        provenance = KnowledgeProvenance(
                            sourceUrl = f[8],
                            sourceTitle = f[9],
                            sourceType = KnowledgeSourceType.valueOf(f[10]),
                            contentHash = f[11],
                            observedAt = f[12].toLong(),
                            fetchedAt = f[13].toLong(),
                            publishedAt = f[14].toLong()
                        ),
                        authority = f[15].toFloat(),
                        confidence = f[16].toFloat(),
                        createdAt = f[17].toLong(),
                        updatedAt = f[18].toLong(),
                        active = f[19] == "1"
                    )
                )
            }.getOrNull() ?: return null
            output += row
        }
        return output
    }

    private fun encodeField(value: String): String = Base64.getUrlEncoder().withoutPadding()
        .encodeToString(value.toByteArray(Charsets.UTF_8))

    private fun decodeField(value: String): String = if (value.isBlank()) "" else String(
        Base64.getUrlDecoder().decode(value), Charsets.UTF_8
    )
}
