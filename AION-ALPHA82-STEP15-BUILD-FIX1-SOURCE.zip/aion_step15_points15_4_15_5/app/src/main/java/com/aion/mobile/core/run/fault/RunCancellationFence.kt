package com.aion.mobile.core.run.fault

import java.io.File
import java.io.FileOutputStream

/**
 * Durable cancellation tombstone. Cancellation is persisted before a Service/Job is
 * signalled, so process death cannot resurrect a user-cancelled run.
 */
object RunCancellationFence {
    private const val DIRECTORY = "aion_runs/cancelled"

    fun mark(noBackupRoot: File, runId: String, atMs: Long = System.currentTimeMillis()) {
        requireSafe(runId)
        val target = file(noBackupRoot, runId)
        target.parentFile?.mkdirs()
        val tmp = File(target.parentFile, "${target.name}.tmp")
        FileOutputStream(tmp).use { out ->
            out.write("v1\n$runId\n$atMs\n".toByteArray(Charsets.UTF_8))
            out.fd.sync()
        }
        if (!tmp.renameTo(target)) {
            target.writeBytes(tmp.readBytes())
            tmp.delete()
        }
    }

    fun isCancelled(noBackupRoot: File, runId: String): Boolean {
        requireSafe(runId)
        val target = file(noBackupRoot, runId)
        if (!target.isFile) return false
        return runCatching {
            val lines = target.readLines(Charsets.UTF_8)
            lines.size >= 3 && lines[0] == "v1" && lines[1] == runId && lines[2].toLong() >= 0L
        }.getOrElse {
            // Corrupt cancellation markers fail closed: a corrupt tombstone must not
            // silently revive a possibly cancelled side-effecting run.
            true
        }
    }

    fun clear(noBackupRoot: File, runId: String) {
        requireSafe(runId)
        file(noBackupRoot, runId).delete()
    }

    private fun file(root: File, runId: String): File = File(File(root, DIRECTORY), "$runId.cancel")

    private fun requireSafe(runId: String) {
        require(runId.length in 8..128 && runId.all { it.isLetterOrDigit() || it == '-' || it == '_' }) {
            "invalid_run_id"
        }
    }
}
