package com.aion.mobile.core.local

import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.nio.file.Files
import java.nio.file.StandardCopyOption

interface LocalModelRuntime {
    /** Returns true only after the runtime has actually loaded the pack and can accept work. */
    fun load(descriptor: LocalModelPackDescriptor, packFile: File): Boolean
    fun unload(modelId: String)
}

/** No fake LLM runtime: without an injected runtime, load always fails closed. */
object UnavailableLocalModelRuntime : LocalModelRuntime {
    override fun load(descriptor: LocalModelPackDescriptor, packFile: File): Boolean = false
    override fun unload(modelId: String) = Unit
}

sealed interface LocalModelOperationResult {
    data class Success(val record: LocalModelRecord) : LocalModelOperationResult
    data class Rejected(val reason: String, val governor: ResourceGovernorDecision? = null) : LocalModelOperationResult
}

class LocalModelManager(
    private val modelDirectory: File,
    private val registry: LocalModelRegistryStore,
    private val verifier: ModelPackVerifier,
    private val resourceGovernor: ResourceGovernor,
    private val storageBudgetPolicy: LocalStorageBudgetPolicy = LocalStorageBudgetPolicy(),
    private val runtime: LocalModelRuntime = UnavailableLocalModelRuntime,
    private val now: () -> Long = System::currentTimeMillis,
) {
    private val lock = Any()
    private val records = LinkedHashMap<String, LocalModelRecord>()

    init {
        modelDirectory.mkdirs()
        records.putAll(registry.readAll().mapValues { (_, record) -> sanitizeRestored(record) })
        persist()
    }

    fun snapshot(): List<LocalModelRecord> = synchronized(lock) { records.values.toList() }

    fun get(modelId: String): LocalModelRecord? = synchronized(lock) { records[modelId] }

    fun register(descriptor: LocalModelPackDescriptor): LocalModelRecord = synchronized(lock) {
        val existing = records[descriptor.modelId]
        val next = when {
            existing == null -> LocalModelRecord(descriptor, LocalModelState.NOT_INSTALLED)
            existing.descriptor.version == descriptor.version && existing.descriptor.sha256.equals(descriptor.sha256, true) ->
                existing.copy(descriptor = descriptor)
            else -> {
                if (existing.state == LocalModelState.LOADED) runtime.unload(existing.descriptor.modelId)
                existing.packFileOrNull()?.delete()
                LocalModelRecord(descriptor, LocalModelState.NOT_INSTALLED)
            }
        }
        putAndPersist(next)
    }

    fun beginDownload(modelId: String): LocalModelOperationResult = synchronized(lock) {
        val current = records[modelId] ?: return@synchronized LocalModelOperationResult.Rejected("unknown_model")
        if (current.state == LocalModelState.DOWNLOADING) {
            return@synchronized LocalModelOperationResult.Success(current)
        }
        if (current.state !in setOf(LocalModelState.NOT_INSTALLED, LocalModelState.READY, LocalModelState.FAILED)) {
            return@synchronized LocalModelOperationResult.Rejected("invalid_state=${current.state}")
        }
        LocalModelOperationResult.Success(putAndPersist(current.copy(state = LocalModelState.DOWNLOADING, failureReason = null)))
    }

    /**
     * Commits an already downloaded staged pack. Verification happens before it becomes READY.
     * The staged file is never treated as installed just because it exists.
     */
    fun installDownloadedPack(modelId: String, stagedFile: File): LocalModelOperationResult = synchronized(lock) {
        val current = records[modelId] ?: return@synchronized LocalModelOperationResult.Rejected("unknown_model")
        if (current.state != LocalModelState.DOWNLOADING && current.state != LocalModelState.FAILED) {
            return@synchronized LocalModelOperationResult.Rejected("invalid_state=${current.state}")
        }
        putAndPersist(current.copy(state = LocalModelState.VERIFYING, failureReason = null))
        when (val checked = verifier.verify(stagedFile, current.descriptor)) {
            ModelPackVerificationResult.Verified -> {
                val target = packFile(current.descriptor)
                val currentBytes = records.values
                    .asSequence()
                    .filter { it.descriptor.modelId != modelId }
                    .mapNotNull { it.packFileOrNull() }
                    .filter { it.isFile }
                    .sumOf { it.length() }
                val budget = storageBudgetPolicy.decide(
                    currentModelBytes = currentBytes,
                    filesystemUsableBytes = modelDirectory.usableSpace.coerceAtLeast(0L),
                    incomingBytes = current.descriptor.expectedSizeBytes,
                )
                if (!budget.allowed) {
                    return@synchronized LocalModelOperationResult.Success(
                        putAndPersist(current.copy(state = LocalModelState.FAILED, failureReason = "storage_budget_exceeded:${budget.bytesToFree}"))
                    )
                }
                val copied = runCatching { atomicCopy(stagedFile, target) }.isSuccess
                if (!copied) {
                    return@synchronized LocalModelOperationResult.Success(
                        putAndPersist(current.copy(state = LocalModelState.FAILED, failureReason = "pack_commit_failed"))
                    )
                }
                when (val committed = verifier.verify(target, current.descriptor)) {
                    ModelPackVerificationResult.Verified -> Unit
                    is ModelPackVerificationResult.Failed -> {
                        target.delete()
                        return@synchronized LocalModelOperationResult.Success(
                            putAndPersist(current.copy(state = LocalModelState.FAILED, failureReason = committed.code.name))
                        )
                    }
                }
                LocalModelOperationResult.Success(
                    putAndPersist(
                        current.copy(
                            state = LocalModelState.READY,
                            packPath = target.absolutePath,
                            failureReason = null,
                        )
                    )
                )
            }
            is ModelPackVerificationResult.Failed -> LocalModelOperationResult.Success(
                putAndPersist(current.copy(state = LocalModelState.FAILED, failureReason = checked.code.name))
            )
        }
    }

    fun load(
        modelId: String,
        resources: DeviceResourceSnapshot,
        environment: ExecutionEnvironment = ExecutionEnvironment.FOREGROUND,
    ): LocalModelOperationResult = synchronized(lock) {
        val current = records[modelId] ?: return@synchronized LocalModelOperationResult.Rejected("unknown_model")
        if (current.state == LocalModelState.LOADED) {
            return@synchronized LocalModelOperationResult.Success(touchLocked(current))
        }
        if (current.state != LocalModelState.READY) {
            return@synchronized LocalModelOperationResult.Rejected("invalid_state=${current.state}")
        }
        val pack = current.packFileOrNull()
        if (pack == null || !pack.isFile) {
            return@synchronized LocalModelOperationResult.Success(
                putAndPersist(current.copy(state = LocalModelState.FAILED, failureReason = "pack_missing"))
            )
        }
        when (val checked = verifier.verify(pack, current.descriptor)) {
            ModelPackVerificationResult.Verified -> Unit
            is ModelPackVerificationResult.Failed -> {
                return@synchronized LocalModelOperationResult.Success(
                    putAndPersist(current.copy(state = LocalModelState.FAILED, failureReason = checked.code.name))
                )
            }
        }

        val preflight = resourceGovernor.decide(
            snapshot = resources,
            requirements = current.descriptor.requirements,
            environment = environment,
            loadedModelCount = 0,
            loadedResidentBytes = 0L,
        )
        if (!preflight.allowed) {
            return@synchronized LocalModelOperationResult.Rejected(preflight.reason.name, preflight)
        }

        evictUntilLoadCouldFitLocked(current.descriptor.requirements, resources)
        val loaded = records.values.filter { it.state == LocalModelState.LOADED }
        val decision = resourceGovernor.decide(
            snapshot = resources,
            requirements = current.descriptor.requirements,
            environment = environment,
            loadedModelCount = loaded.size,
            loadedResidentBytes = loaded.sumOf { it.descriptor.requirements.estimatedResidentBytes },
        )
        if (!decision.allowed) return@synchronized LocalModelOperationResult.Rejected(decision.reason.name, decision)

        if (!runtime.load(current.descriptor, pack)) {
            return@synchronized LocalModelOperationResult.Success(
                putAndPersist(current.copy(state = LocalModelState.FAILED, failureReason = "runtime_load_failed"))
            )
        }
        val timestamp = now()
        LocalModelOperationResult.Success(
            putAndPersist(current.copy(state = LocalModelState.LOADED, lastUsedAtEpochMs = timestamp, loadedAtEpochMs = timestamp))
        )
    }

    fun unload(modelId: String): LocalModelOperationResult = synchronized(lock) {
        val current = records[modelId] ?: return@synchronized LocalModelOperationResult.Rejected("unknown_model")
        if (current.state != LocalModelState.LOADED) {
            return@synchronized LocalModelOperationResult.Rejected("invalid_state=${current.state}")
        }
        putAndPersist(current.copy(state = LocalModelState.UNLOADING))
        return@synchronized runCatching {
            runtime.unload(modelId)
            LocalModelOperationResult.Success(
                putAndPersist(current.copy(state = LocalModelState.READY, loadedAtEpochMs = null, failureReason = null))
            )
        }.getOrElse {
            LocalModelOperationResult.Success(
                putAndPersist(current.copy(state = LocalModelState.FAILED, loadedAtEpochMs = null, failureReason = "runtime_unload_failed"))
            )
        }
    }

    fun markUsed(modelId: String): LocalModelRecord? = synchronized(lock) {
        val current = records[modelId] ?: return@synchronized null
        if (current.state != LocalModelState.LOADED) return@synchronized current
        touchLocked(current)
    }

    /** LRU eviction is deterministic; oldest last-use is evicted first, then oldest load time, then model id. */
    fun evictForMemoryPressure(pressure: MemoryPressure): List<String> = synchronized(lock) {
        val loaded = loadedLruLocked()
        val target = when (pressure) {
            MemoryPressure.NORMAL -> 0
            MemoryPressure.MODERATE -> if (loaded.size > 1) 1 else 0
            MemoryPressure.HIGH -> maxOf(0, loaded.size - 1)
            MemoryPressure.CRITICAL -> loaded.size
        }
        val evicted = mutableListOf<String>()
        repeat(target) {
            val victim = loadedLruLocked().firstOrNull() ?: return@repeat
            unloadLocked(victim)
            evicted += victim.descriptor.modelId
        }
        evicted
    }

    private fun evictUntilLoadCouldFitLocked(
        incoming: LocalModelRequirements,
        resources: DeviceResourceSnapshot,
    ) {
        while (true) {
            val loaded = records.values.filter { it.state == LocalModelState.LOADED }
            val resident = loaded.sumOf { it.descriptor.requirements.estimatedResidentBytes }
            val maxConcurrent = resourceGovernor.maxConcurrentLocalModels(resources)
            val maxResident = resourceGovernor.maxResidentBytes(resources)
            val countFits = loaded.size < maxConcurrent
            val memoryFits = resident + incoming.estimatedResidentBytes <= maxResident
            if (countFits && memoryFits) return
            val victim = loadedLruLocked().firstOrNull() ?: return
            unloadLocked(victim)
        }
    }

    private fun unloadLocked(record: LocalModelRecord) {
        putAndPersist(record.copy(state = LocalModelState.UNLOADING))
        runCatching { runtime.unload(record.descriptor.modelId) }
            .onSuccess {
                putAndPersist(record.copy(state = LocalModelState.READY, loadedAtEpochMs = null, failureReason = null))
            }
            .onFailure {
                putAndPersist(record.copy(state = LocalModelState.FAILED, loadedAtEpochMs = null, failureReason = "runtime_unload_failed"))
            }
    }

    private fun loadedLruLocked(): List<LocalModelRecord> = records.values
        .filter { it.state == LocalModelState.LOADED }
        .sortedWith(
            compareBy<LocalModelRecord> { it.lastUsedAtEpochMs }
                .thenBy { it.loadedAtEpochMs ?: Long.MAX_VALUE }
                .thenBy { it.descriptor.modelId }
        )

    private fun touchLocked(record: LocalModelRecord): LocalModelRecord =
        putAndPersist(record.copy(lastUsedAtEpochMs = now()))

    private fun sanitizeRestored(record: LocalModelRecord): LocalModelRecord {
        if (record.descriptor.provenance == null || record.descriptor.provenance.sourceType == ModelPackSourceType.LEGACY_UNVERIFIED) {
            return record.copy(
                state = LocalModelState.FAILED,
                loadedAtEpochMs = null,
                failureReason = "provenance_required_after_upgrade",
            )
        }
        return when (record.state) {
            LocalModelState.LOADED,
            LocalModelState.UNLOADING -> record.copy(
                state = if (record.packFileOrNull()?.isFile == true) LocalModelState.READY else LocalModelState.FAILED,
                loadedAtEpochMs = null,
                failureReason = if (record.packFileOrNull()?.isFile == true) null else "pack_missing_after_restart",
            )
            LocalModelState.DOWNLOADING,
            LocalModelState.VERIFYING -> record.copy(state = LocalModelState.FAILED, failureReason = "interrupted_install")
            LocalModelState.READY -> if (record.packFileOrNull()?.isFile == true) record
                else record.copy(state = LocalModelState.FAILED, failureReason = "pack_missing_after_restart")
            else -> record
        }
    }

    private fun putAndPersist(record: LocalModelRecord): LocalModelRecord {
        records[record.descriptor.modelId] = record
        persist()
        return record
    }

    private fun persist() = registry.replace(records.values)

    private fun packFile(descriptor: LocalModelPackDescriptor): File =
        File(modelDirectory, safeName(descriptor.modelId) + "-" + safeName(descriptor.version) + ".pack")

    private fun safeName(value: String): String = value.replace(Regex("[^A-Za-z0-9._-]"), "_").take(96)

    private fun atomicCopy(source: File, target: File) {
        target.parentFile?.mkdirs()
        val temp = File(target.parentFile, target.name + ".tmp")
        FileInputStream(source).use { input ->
            FileOutputStream(temp).use { output ->
                input.copyTo(output)
                output.fd.sync()
            }
        }
        runCatching {
            Files.move(
                temp.toPath(),
                target.toPath(),
                StandardCopyOption.ATOMIC_MOVE,
                StandardCopyOption.REPLACE_EXISTING,
            )
        }.getOrElse {
            Files.move(temp.toPath(), target.toPath(), StandardCopyOption.REPLACE_EXISTING)
        }
    }
}
