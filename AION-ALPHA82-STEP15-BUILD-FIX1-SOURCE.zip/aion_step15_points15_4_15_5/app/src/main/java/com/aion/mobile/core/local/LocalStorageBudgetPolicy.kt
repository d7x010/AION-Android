package com.aion.mobile.core.local

import kotlin.math.max
import kotlin.math.min

/**
 * Hard disk budget for local model packs. The budget is computed from the actual model
 * directory filesystem and never assumes that free device space belongs entirely to AION.
 */
data class LocalStorageBudgetDecision(
    val allowed: Boolean,
    val currentModelBytes: Long,
    val incomingBytes: Long,
    val maxModelBytes: Long,
    val bytesToFree: Long,
)

class LocalStorageBudgetPolicy(
    private val reserveForDeviceBytes: Long = 1L * GIB,
    private val maxFractionOfUsablePool: Double = 0.25,
    private val absoluteModelCapBytes: Long = 8L * GIB,
) {
    init {
        require(reserveForDeviceBytes >= 0L)
        require(maxFractionOfUsablePool in 0.05..0.80)
        require(absoluteModelCapBytes > 0L)
    }

    fun decide(currentModelBytes: Long, filesystemUsableBytes: Long, incomingBytes: Long): LocalStorageBudgetDecision {
        require(currentModelBytes >= 0L)
        require(filesystemUsableBytes >= 0L)
        require(incomingBytes >= 0L)

        // current model files + currently free bytes approximates the pool before AION packs.
        val poolBytes = currentModelBytes + filesystemUsableBytes
        val afterReserve = max(0L, poolBytes - reserveForDeviceBytes)
        val fractionalCap = (afterReserve.toDouble() * maxFractionOfUsablePool).toLong()
        val maxModelBytes = min(absoluteModelCapBytes, fractionalCap)
        val projected = currentModelBytes + incomingBytes
        return LocalStorageBudgetDecision(
            allowed = projected <= maxModelBytes,
            currentModelBytes = currentModelBytes,
            incomingBytes = incomingBytes,
            maxModelBytes = maxModelBytes,
            bytesToFree = max(0L, projected - maxModelBytes),
        )
    }

    companion object {
        const val MIB: Long = 1024L * 1024L
        const val GIB: Long = 1024L * MIB
    }
}
