package com.aion.mobile.core.release

import android.content.Context

/**
 * Minimal crash-loop guard. It never deletes user data. If two launches fail before reaching
 * the stable marker, the next launch enters safe mode so risky startup features can stay off.
 */
object StartupCrashGuard {
    private const val PREFS = "aion_startup_guard"
    private const val KEY_IN_PROGRESS = "launch_in_progress"
    private const val KEY_FAILURES = "consecutive_startup_failures"
    private const val KEY_STARTED_AT = "last_launch_started_at"
    private const val KEY_ROLLBACK_REQUESTED = "rollback_requested"
    private const val KEY_ROLLBACK_REASON = "rollback_reason"
    private const val WINDOW_MS = 60_000L

    fun begin(context: Context, now: Long = System.currentTimeMillis()): Boolean {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val previousInProgress = prefs.getBoolean(KEY_IN_PROGRESS, false)
        val previousStartedAt = prefs.getLong(KEY_STARTED_AT, 0L)
        val previousFailures = prefs.getInt(KEY_FAILURES, 0)
        val previousLooksLikeStartupFailure = previousInProgress &&
            previousStartedAt > 0L &&
            now - previousStartedAt in 0..WINDOW_MS
        val failures = if (previousLooksLikeStartupFailure) previousFailures + 1 else previousFailures

        val decision = AionReleaseRollbackPolicy.evaluateStartup(failures)
        prefs.edit()
            .putBoolean(KEY_IN_PROGRESS, true)
            .putInt(KEY_FAILURES, failures)
            .putLong(KEY_STARTED_AT, now)
            .putBoolean(KEY_ROLLBACK_REQUESTED, decision.requestExternalRollback)
            .putString(KEY_ROLLBACK_REASON, decision.reason)
            .apply()

        return decision.enterSafeMode
    }

    fun markStable(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putBoolean(KEY_IN_PROGRESS, false)
            .putInt(KEY_FAILURES, 0)
            .putBoolean(KEY_ROLLBACK_REQUESTED, false)
            .remove(KEY_ROLLBACK_REASON)
            .apply()
    }

    fun isRollbackRequested(context: Context): Boolean =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getBoolean(KEY_ROLLBACK_REQUESTED, false)

    fun rollbackReason(context: Context): String? =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_ROLLBACK_REASON, null)
}
