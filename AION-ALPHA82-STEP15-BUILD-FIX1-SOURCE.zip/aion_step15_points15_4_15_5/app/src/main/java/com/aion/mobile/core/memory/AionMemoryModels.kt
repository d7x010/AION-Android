package com.aion.mobile.core.memory

enum class MemoryScope { USER, PROJECT, CONVERSATION }
enum class MemoryLayer { WORKING, EPISODIC, SEMANTIC, PROCEDURAL, PROJECT }
enum class MemoryKind { FACT, PREFERENCE, DECISION, INSTRUCTION, NOTE }
enum class MemorySource { USER_SETTINGS, PROJECT_NOTES, EXPLICIT, AUTOMATIC }

data class AionMemoryEntry(
    val id: String,
    val scope: MemoryScope,
    val ownerId: String = "",
    /** Project affinity for conversation-scoped memories. Empty means a non-project conversation. */
    val projectId: String = "",
    val layer: MemoryLayer = MemoryLayer.SEMANTIC,
    val kind: MemoryKind = MemoryKind.NOTE,
    val text: String,
    val slot: String = "",
    val source: MemorySource,
    val contentHash: String = "",
    val observedAt: Long = 0L,
    val confidence: Float = 1f,
    val priority: Int = 0,
    val pinned: Boolean = false,
    val createdAt: Long,
    val updatedAt: Long,
    val expiresAt: Long = 0L,
    val active: Boolean = true,
    /** The previous version replaced by this entry, if this entry won the conflict. */
    val supersedesId: String = "",
    /** The newer winning version that replaced this entry. */
    val supersededById: String = "",
    /** Stronger active memory that caused this weaker candidate to stay inactive. */
    val candidateAgainstId: String = ""
)

data class AionMemoryContext(
    val contract: Int = MemoryEnginePolicy.CONTRACT,
    val retrievalContract: Int = MemoryEnginePolicy.RETRIEVAL_CONTRACT,
    val retrievalPolicy: String = MemoryEnginePolicy.RETRIEVAL_POLICY,
    val text: String = "",
    val entryCount: Int = 0,
    val candidateCount: Int = 0,
    val matchedCount: Int = 0,
    val scopes: Set<MemoryScope> = emptySet(),
    val layers: Set<MemoryLayer> = emptySet(),
    val truncated: Boolean = false
)
