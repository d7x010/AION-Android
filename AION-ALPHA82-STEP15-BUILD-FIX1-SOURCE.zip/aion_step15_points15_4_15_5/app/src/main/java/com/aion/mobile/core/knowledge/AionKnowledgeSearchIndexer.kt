package com.aion.mobile.core.knowledge

import android.content.Context
import com.aion.mobile.core.memory.ConversationMemoryMode
import com.aion.mobile.core.memory.MemoryPrivacyStore
import com.aion.mobile.core.storage.ChatSessionStore
import com.aion.mobile.model.ChatSource

/** Indexes only successful, source-backed web results; failures/partial runs never call this object. */
object AionKnowledgeSearchIndexer {
    fun indexSuccessfulSources(
        context: Context,
        conversationId: String,
        sources: List<ChatSource>,
        now: Long = System.currentTimeMillis()
    ): Int {
        if (conversationId.isBlank() || sources.isEmpty()) return 0
        val temporary = MemoryPrivacyStore.mode(context, conversationId) == ConversationMemoryMode.TEMPORARY
        if (temporary) return 0
        val projectId = ChatSessionStore.loadConversations(context, includeArchived = true)
            .firstOrNull { it.id == conversationId }
            ?.projectId
            .orEmpty()
        val access = KnowledgeAccessContext(
            conversationId = conversationId,
            projectId = projectId,
            temporary = false
        )
        var stored = 0
        sources.asSequence()
            .map { it.copy(title = it.title.trim(), url = it.url.trim(), snippet = it.snippet.trim()) }
            .filter { it.url.startsWith("https://") || it.url.startsWith("http://") }
            .distinctBy { it.url }
            .take(24)
            .forEach { source ->
                val body = source.snippet.ifBlank { source.title }.take(KnowledgeEnginePolicy.MAX_ENTRY_CHARS)
                if (body.isBlank()) return@forEach
                val hash = KnowledgeEnginePolicy.contentHash(body)
                val stableKey = KnowledgeEnginePolicy.contentHash("$conversationId\n${source.url}\n$hash").take(40)
                val entry = AionKnowledgeEntry(
                    id = "web-$stableKey",
                    scope = KnowledgeScope.CONVERSATION,
                    ownerId = conversationId,
                    projectId = projectId,
                    title = source.title,
                    text = body,
                    provenance = KnowledgeProvenance(
                        sourceUrl = source.url,
                        sourceTitle = source.title,
                        sourceType = KnowledgeSourceType.WEB_PAGE,
                        contentHash = hash,
                        observedAt = now,
                        fetchedAt = now
                    ),
                    authority = 0.55f,
                    confidence = 0.55f,
                    createdAt = now,
                    updatedAt = now
                )
                if (AionKnowledgeStore.upsert(context, entry, access, KnowledgeWriteOrigin.AUTOMATIC_SEARCH) != null) {
                    stored += 1
                }
            }
        return stored
    }
}
