package com.aion.mobile.core.knowledge

import java.security.MessageDigest
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.sqrt

/** Pure, deterministic Knowledge Engine policy. No Android or network dependencies. */
object KnowledgeEnginePolicy {
    const val CONTRACT = 1
    const val RETRIEVAL_POLICY = "lexical-hashed-vector-freshness-authority-confidence-v1"
    const val MAX_ENTRY_CHARS = 24_000
    const val MAX_TITLE_CHARS = 320
    const val MAX_URL_CHARS = 2_048
    const val VECTOR_DIMENSIONS = 128
    const val DEFAULT_LIMIT = 12

    fun normalizeText(raw: String): String = raw
        .replace("\u0000", "")
        .replace(Regex("\\s+"), " ")
        .trim()
        .take(MAX_ENTRY_CHARS)

    fun canonical(raw: String): String = normalizeText(raw)
        .lowercase()
        .replace("أ", "ا")
        .replace("إ", "ا")
        .replace("آ", "ا")
        .replace("ى", "ي")
        .replace("ة", "ه")
        .replace(Regex("[^\\p{L}\\p{N}]+"), " ")
        .trim()

    fun contentHash(raw: String): String {
        val bytes = MessageDigest.getInstance("SHA-256")
            .digest(normalizeText(raw).toByteArray(Charsets.UTF_8))
        return bytes.joinToString("") { "%02x".format(it) }
    }

    fun sanitize(entry: AionKnowledgeEntry): AionKnowledgeEntry? {
        val text = normalizeText(entry.text)
        if (text.isBlank()) return null
        val owner = entry.ownerId.trim().take(160)
        val project = entry.projectId.trim().take(160)
        if (entry.scope != KnowledgeScope.USER && owner.isBlank()) return null
        if (entry.scope == KnowledgeScope.PROJECT && project.isNotBlank() && project != owner) return null
        val observedAt = entry.provenance.observedAt.takeIf { it > 0L }
            ?: maxOf(entry.updatedAt, entry.createdAt).coerceAtLeast(1L)
        val provenance = entry.provenance.copy(
            sourceUrl = entry.provenance.sourceUrl.trim().take(MAX_URL_CHARS),
            sourceTitle = entry.provenance.sourceTitle.trim().replace(Regex("\\s+"), " ").take(MAX_TITLE_CHARS),
            contentHash = entry.provenance.contentHash.ifBlank { contentHash(text) },
            observedAt = observedAt,
            fetchedAt = entry.provenance.fetchedAt.takeIf { it > 0L } ?: observedAt,
            publishedAt = entry.provenance.publishedAt.coerceAtLeast(0L)
        )
        return entry.copy(
            id = entry.id.trim().take(160),
            ownerId = owner,
            projectId = if (entry.scope == KnowledgeScope.PROJECT) owner else project,
            title = entry.title.trim().replace(Regex("\\s+"), " ").take(MAX_TITLE_CHARS),
            text = text,
            claimKey = canonical(entry.claimKey).take(200),
            claimValue = canonical(entry.claimValue).take(600),
            provenance = provenance,
            authority = entry.authority.coerceIn(0f, 1f),
            confidence = entry.confidence.coerceIn(0f, 1f)
        ).takeIf { it.id.isNotBlank() }
    }

    fun hybridRetrieve(
        entries: List<AionKnowledgeEntry>,
        query: String,
        now: Long,
        limit: Int = DEFAULT_LIMIT
    ): KnowledgeRetrievalResult {
        val clean = entries.mapNotNull(::sanitize).filter { it.active }
        if (clean.isEmpty()) return KnowledgeRetrievalResult()
        val normalizedQuery = canonical(query)
        val queryTokens = tokens(normalizedQuery)
        val queryVector = hashedVector(queryTokens)

        val ranked = clean.map { entry ->
            val documentText = listOf(entry.title, entry.text, entry.claimKey, entry.claimValue)
                .filter { it.isNotBlank() }.joinToString(" ")
            val documentCanonical = canonical(documentText)
            val documentTokens = tokens(documentCanonical)
            val lexical = lexicalScore(normalizedQuery, queryTokens, documentCanonical, documentTokens, entry.title)
            val vector = cosine(queryVector, hashedVector(documentTokens))
            val freshness = freshnessScore(entry, now)
            val authority = entry.authority.toDouble().coerceIn(0.0, 1.0)
            val confidence = entry.confidence.toDouble().coerceIn(0.0, 1.0)
            val score = if (queryTokens.isEmpty()) {
                freshness * 0.35 + authority * 0.35 + confidence * 0.30
            } else {
                lexical * 0.42 + vector * 0.28 + freshness * 0.12 + authority * 0.10 + confidence * 0.08
            }
            KnowledgeHit(entry, score, lexical, vector, freshness, authority, confidence)
        }.sortedWith(
            compareByDescending<KnowledgeHit> { it.score }
                .thenByDescending { it.entry.provenance.observedAt }
                .thenBy { it.entry.id }
        )

        val selected = ranked.take(limit.coerceIn(1, 100))
        val selectedClaimKeys = selected.mapNotNull { hit -> hit.entry.claimKey.takeIf(String::isNotBlank) }.toSet()
        val contradictions = contradictionGroups(clean.filter { it.claimKey in selectedClaimKeys })
        return KnowledgeRetrievalResult(
            hits = selected,
            contradictions = contradictions,
            candidateCount = clean.size
        )
    }

    fun freshnessScore(entry: AionKnowledgeEntry, now: Long): Double {
        val timestamp = when {
            entry.provenance.publishedAt > 0L -> entry.provenance.publishedAt
            entry.provenance.fetchedAt > 0L -> entry.provenance.fetchedAt
            else -> entry.provenance.observedAt
        }
        if (timestamp <= 0L || now <= timestamp) return 1.0
        val ageDays = (now - timestamp) / 86_400_000.0
        val halfLifeDays = when (entry.provenance.sourceType) {
            KnowledgeSourceType.NEWS -> 2.5
            KnowledgeSourceType.WEB_PAGE -> 30.0
            KnowledgeSourceType.DOCUMENT -> 365.0
            KnowledgeSourceType.PROJECT_FILE -> 365.0
            KnowledgeSourceType.MANUAL -> 730.0
        }
        return exp(-ln(2.0) * ageDays / halfLifeDays).coerceIn(0.0, 1.0)
    }

    fun contradictionGroups(entries: List<AionKnowledgeEntry>): List<KnowledgeContradiction> = entries
        .mapNotNull(::sanitize)
        .filter { it.active && it.claimKey.isNotBlank() }
        .groupBy { it.claimKey }
        .mapNotNull { (claimKey, group) ->
            val byValue = group.groupBy { canonical(it.claimValue.ifBlank { it.text }) }
                .filterKeys { it.isNotBlank() }
            if (byValue.size < 2) return@mapNotNull null
            KnowledgeContradiction(
                claimKey = claimKey,
                variants = group.sortedWith(
                    compareByDescending<AionKnowledgeEntry> { it.confidence }
                        .thenByDescending { it.provenance.observedAt }
                ).map { entry ->
                    KnowledgeConflictVariant(
                        entryId = entry.id,
                        value = entry.claimValue.ifBlank { entry.text },
                        sourceTitle = entry.provenance.sourceTitle,
                        sourceUrl = entry.provenance.sourceUrl,
                        sourceType = entry.provenance.sourceType,
                        observedAt = entry.provenance.observedAt,
                        confidence = entry.confidence
                    )
                }
            )
        }
        .sortedBy { it.claimKey }

    private fun lexicalScore(
        query: String,
        queryTokens: List<String>,
        document: String,
        documentTokens: List<String>,
        title: String
    ): Double {
        if (queryTokens.isEmpty() || documentTokens.isEmpty()) return 0.0
        val qSet = queryTokens.toSet()
        val dSet = documentTokens.toSet()
        val overlap = qSet.intersect(dSet).size.toDouble()
        val queryCoverage = overlap / qSet.size.coerceAtLeast(1)
        val documentCoverage = overlap / dSet.size.coerceAtLeast(1)
        val phraseBoost = when {
            query.length >= 4 && document.contains(query) -> 0.18
            else -> 0.0
        }
        val titleTokens = tokens(canonical(title)).toSet()
        val titleCoverage = qSet.intersect(titleTokens).size.toDouble() / qSet.size.coerceAtLeast(1)
        return (queryCoverage * 0.58 + documentCoverage * 0.14 + titleCoverage * 0.18 + phraseBoost)
            .coerceIn(0.0, 1.0)
    }

    private fun tokens(raw: String): List<String> = canonical(raw)
        .split(Regex("[^\\p{L}\\p{N}_-]+"))
        .filter { it.length >= 2 }

    private fun hashedVector(tokens: List<String>): DoubleArray {
        val vector = DoubleArray(VECTOR_DIMENSIONS)
        if (tokens.isEmpty()) return vector
        tokens.forEach { token ->
            val hash = fnv1a64(token)
            val index = ((hash and Long.MAX_VALUE) % VECTOR_DIMENSIONS).toInt()
            val sign = if ((hash ushr 63) == 0L) 1.0 else -1.0
            vector[index] += sign
        }
        val norm = sqrt(vector.sumOf { it * it })
        if (norm > 0.0) for (i in vector.indices) vector[i] /= norm
        return vector
    }

    private fun cosine(a: DoubleArray, b: DoubleArray): Double {
        if (a.size != b.size) return 0.0
        var dot = 0.0
        for (i in a.indices) dot += a[i] * b[i]
        // Signed feature hashing can be slightly negative; retrieval should not reward anti-similarity.
        return dot.coerceIn(0.0, 1.0)
    }

    private fun fnv1a64(value: String): Long {
        var hash = -3750763034362895579L // unsigned FNV offset basis represented as signed Long
        value.toByteArray(Charsets.UTF_8).forEach { byte ->
            hash = hash xor (byte.toLong() and 0xffL)
            hash *= 1099511628211L
        }
        return hash
    }
}
