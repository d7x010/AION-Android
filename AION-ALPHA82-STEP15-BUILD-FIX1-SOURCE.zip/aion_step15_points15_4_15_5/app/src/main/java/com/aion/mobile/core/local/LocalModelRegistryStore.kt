package com.aion.mobile.core.local

import com.aion.mobile.core.storage.AionStorageSchemaRegistry
import com.aion.mobile.core.storage.DurableFileRecovery
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.File

/**
 * Durable binary registry with schema validation + Last Known Good recovery.
 * No state is inferred from memory after process recreation.
 */
class LocalModelRegistryStore(private val file: File) {
    @Synchronized
    fun readAll(): Map<String, LocalModelRecord> {
        val recovered = DurableFileRecovery.readBytes(file, ::isReadable)
        val bytes = recovered.bytes ?: return emptyMap()
        return decode(bytes) ?: emptyMap()
    }

    @Synchronized
    fun replace(records: Collection<LocalModelRecord>) {
        require(records.size <= MAX_RECORDS)
        val bytes = encode(records)
        check(DurableFileRecovery.writeBytes(file, bytes, ::isReadable)) { "local_model_registry_persist_failed" }
    }

    private fun encode(records: Collection<LocalModelRecord>): ByteArray {
        val raw = ByteArrayOutputStream()
        DataOutputStream(BufferedOutputStream(raw)).use { out ->
            out.writeInt(MAGIC)
            out.writeInt(VERSION)
            out.writeInt(records.size)
            records.sortedBy { it.descriptor.modelId }.forEach { record ->
                val d = record.descriptor
                out.writeUTF(d.modelId)
                out.writeUTF(d.version)
                out.writeLong(d.expectedSizeBytes)
                out.writeUTF(d.sha256.lowercase())
                out.writeNullableUtf(d.signature)
                out.writeBoolean(d.requireSignature)
                val provenance = d.provenance
                out.writeBoolean(provenance != null)
                if (provenance != null) {
                    out.writeUTF(provenance.sourceType.name)
                    out.writeUTF(provenance.sourceUri)
                    out.writeUTF(provenance.publisher)
                    out.writeLong(provenance.acquiredAtEpochMs)
                    out.writeLong(provenance.issuedAtEpochMs)
                    out.writeUTF(provenance.manifestSha256.lowercase())
                    out.writeUTF(provenance.signatureAlgorithm)
                    out.writeUTF(provenance.signerKeyId)
                }
                out.writeUTF(d.requirements.modelId)
                out.writeLong(d.requirements.minimumAvailableRamBytes)
                out.writeLong(d.requirements.estimatedResidentBytes)
                out.writeLong(d.requirements.minimumFreeStorageBytes)
                out.writeBoolean(d.requirements.allowBackground)
                out.writeUTF(record.state.name)
                out.writeNullableUtf(record.packPath)
                out.writeLong(record.lastUsedAtEpochMs)
                out.writeNullableLong(record.loadedAtEpochMs)
                out.writeNullableUtf(record.failureReason)
            }
            out.flush()
        }
        return raw.toByteArray()
    }

    private fun decode(bytes: ByteArray): Map<String, LocalModelRecord>? = runCatching {
        DataInputStream(BufferedInputStream(ByteArrayInputStream(bytes))).use { input ->
            val magic = input.readInt()
            require(magic == MAGIC) { "invalid registry magic" }
            val version = input.readInt()
            require(AionStorageSchemaRegistry.localModels.canRead(version)) { "unsupported registry version=$version" }
            val count = input.readInt()
            require(count in 0..MAX_RECORDS) { "invalid model count=$count" }
            buildMap {
                repeat(count) {
                    val modelId = input.readUTF()
                    val modelVersion = input.readUTF()
                    val expectedSize = input.readLong()
                    val sha256 = input.readUTF()
                    val signature = input.readNullableUtf()
                    val requireSignature = input.readBoolean()
                    val provenance = if (version >= 2 && input.readBoolean()) {
                        ModelPackProvenance(
                            sourceType = ModelPackSourceType.valueOf(input.readUTF()),
                            sourceUri = input.readUTF(),
                            publisher = input.readUTF(),
                            acquiredAtEpochMs = input.readLong(),
                            issuedAtEpochMs = input.readLong(),
                            manifestSha256 = input.readUTF(),
                            signatureAlgorithm = input.readUTF(),
                            signerKeyId = input.readUTF(),
                        )
                    } else null
                    val descriptor = LocalModelPackDescriptor(
                        modelId = modelId,
                        version = modelVersion,
                        expectedSizeBytes = expectedSize,
                        sha256 = sha256,
                        signature = signature,
                        requireSignature = requireSignature,
                        provenance = provenance,
                        requirements = LocalModelRequirements(
                            modelId = input.readUTF(),
                            minimumAvailableRamBytes = input.readLong(),
                            estimatedResidentBytes = input.readLong(),
                            minimumFreeStorageBytes = input.readLong(),
                            allowBackground = input.readBoolean(),
                        ),
                    )
                    val record = LocalModelRecord(
                        descriptor = descriptor,
                        state = LocalModelState.valueOf(input.readUTF()),
                        packPath = input.readNullableUtf(),
                        lastUsedAtEpochMs = input.readLong(),
                        loadedAtEpochMs = input.readNullableLong(),
                        failureReason = input.readNullableUtf(),
                    )
                    put(descriptor.modelId, record)
                }
            }.also {
                // Reject trailing garbage so corruption cannot be silently accepted.
                require(input.read() == -1) { "trailing registry bytes" }
            }
        }
    }.getOrNull()

    private fun isReadable(bytes: ByteArray): Boolean = decode(bytes) != null

    private fun DataOutputStream.writeNullableUtf(value: String?) {
        writeBoolean(value != null)
        if (value != null) writeUTF(value)
    }

    private fun DataInputStream.readNullableUtf(): String? = if (readBoolean()) readUTF() else null

    private fun DataOutputStream.writeNullableLong(value: Long?) {
        writeBoolean(value != null)
        if (value != null) writeLong(value)
    }

    private fun DataInputStream.readNullableLong(): Long? = if (readBoolean()) readLong() else null

    private companion object {
        const val MAGIC = 0x41494F4E // AION
        val VERSION = AionStorageSchemaRegistry.localModels.currentVersion
        const val MAX_RECORDS = 256
    }
}
