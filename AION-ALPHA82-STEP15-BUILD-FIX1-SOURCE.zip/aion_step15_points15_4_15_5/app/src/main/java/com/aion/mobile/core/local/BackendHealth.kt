package com.aion.mobile.core.local

import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.nio.file.Files
import java.nio.file.StandardCopyOption

internal data class BackendHealthSample(val success: Boolean, val latencyMs: Long, val atEpochMs: Long)

enum class CircuitBreakerState { CLOSED, OPEN, HALF_OPEN }

data class BackendHealthSnapshot(
    val backendId: String,
    val state: CircuitBreakerState,
    val recentSuccesses: Int,
    val recentFailures: Int,
    val averageLatencyMs: Long,
    val consecutiveFailures: Int,
    val openUntilEpochMs: Long,
) {
    val healthyEnoughForPrimary: Boolean get() = state != CircuitBreakerState.OPEN
}

internal data class BackendHealthRecord(
    val backendId: String,
    val state: CircuitBreakerState = CircuitBreakerState.CLOSED,
    val openUntilEpochMs: Long = 0L,
    val halfOpenProbeUntilEpochMs: Long = 0L,
    val samples: List<BackendHealthSample> = emptyList(),
)

class BackendHealthStore(private val file: File) {
    @Synchronized
    internal fun read(): Map<String, BackendHealthRecord> {
        if (!file.isFile) return emptyMap()
        return runCatching {
            DataInputStream(BufferedInputStream(FileInputStream(file))).use { input ->
                require(input.readInt() == MAGIC)
                require(input.readInt() == VERSION)
                buildMap {
                    repeat(input.readInt().coerceIn(0, 64)) {
                        val id = input.readUTF()
                        val state = CircuitBreakerState.valueOf(input.readUTF())
                        val openUntil = input.readLong()
                        val probeUntil = input.readLong()
                        val sampleCount = input.readInt().coerceIn(0, MAX_SAMPLES)
                        val samples = ArrayList<BackendHealthSample>(sampleCount)
                        repeat(sampleCount) {
                            samples += BackendHealthSample(input.readBoolean(), input.readLong(), input.readLong())
                        }
                        put(id, BackendHealthRecord(id, state, openUntil, probeUntil, samples))
                    }
                }
            }
        }.getOrDefault(emptyMap())
    }

    @Synchronized
    internal fun replace(records: Collection<BackendHealthRecord>) {
        file.parentFile?.mkdirs()
        val temp = File(file.parentFile, ".${file.name}.tmp-${System.nanoTime()}")
        DataOutputStream(BufferedOutputStream(FileOutputStream(temp))).use { output ->
            output.writeInt(MAGIC)
            output.writeInt(VERSION)
            output.writeInt(records.size)
            records.forEach { record ->
                output.writeUTF(record.backendId)
                output.writeUTF(record.state.name)
                output.writeLong(record.openUntilEpochMs)
                output.writeLong(record.halfOpenProbeUntilEpochMs)
                output.writeInt(record.samples.size.coerceAtMost(MAX_SAMPLES))
                record.samples.takeLast(MAX_SAMPLES).forEach { sample ->
                    output.writeBoolean(sample.success)
                    output.writeLong(sample.latencyMs)
                    output.writeLong(sample.atEpochMs)
                }
            }
            output.flush()
        }
        FileOutputStream(temp, true).fd.sync()
        atomicReplace(temp, file)
    }

    private fun atomicReplace(source: File, target: File) {
        runCatching {
            Files.move(source.toPath(), target.toPath(), StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE)
        }.recoverCatching {
            Files.move(source.toPath(), target.toPath(), StandardCopyOption.REPLACE_EXISTING)
        }.getOrElse {
            source.delete()
            throw it
        }
    }

    private companion object {
        const val MAGIC = 0x41424831 // ABH1
        const val VERSION = 2
        const val MAX_SAMPLES = 20
    }
}

sealed interface BackendCallPermit {
    data class Allowed(val halfOpenProbe: Boolean) : BackendCallPermit
    data class CircuitOpen(val retryAfterMs: Long) : BackendCallPermit
}

class BackendHealthTracker(
    private val store: BackendHealthStore,
    private val failureThreshold: Int = 3,
    private val openDurationMs: Long = 30_000L,
    private val maxSamples: Int = 20,
    private val now: () -> Long = System::currentTimeMillis,
) {
    private val lock = Any()
    private val records = store.read().toMutableMap()

    init {
        require(failureThreshold >= 1)
        require(openDurationMs >= 1_000L)
        require(maxSamples in 5..100)
    }

    fun beforeCall(backendId: String): BackendCallPermit = synchronized(lock) {
        val current = records[backendId] ?: BackendHealthRecord(backendId)
        val timestamp = now()
        val next = when (current.state) {
            CircuitBreakerState.CLOSED -> current
            CircuitBreakerState.OPEN -> {
                if (timestamp < current.openUntilEpochMs) {
                    return@synchronized BackendCallPermit.CircuitOpen(current.openUntilEpochMs - timestamp)
                }
                current.copy(state = CircuitBreakerState.HALF_OPEN, halfOpenProbeUntilEpochMs = 0L)
            }
            CircuitBreakerState.HALF_OPEN -> current
        }
        if (next.state == CircuitBreakerState.HALF_OPEN && next.halfOpenProbeUntilEpochMs > timestamp) {
            return@synchronized BackendCallPermit.CircuitOpen((next.halfOpenProbeUntilEpochMs - timestamp).coerceAtLeast(1L))
        }
        val reserved = if (next.state == CircuitBreakerState.HALF_OPEN) {
            next.copy(halfOpenProbeUntilEpochMs = timestamp + HALF_OPEN_PROBE_LEASE_MS)
        } else next
        records[backendId] = reserved
        persistBestEffort()
        BackendCallPermit.Allowed(halfOpenProbe = reserved.state == CircuitBreakerState.HALF_OPEN)
    }

    fun recordSuccess(backendId: String, latencyMs: Long) = synchronized(lock) {
        val current = records[backendId] ?: BackendHealthRecord(backendId)
        records[backendId] = current.copy(
            state = CircuitBreakerState.CLOSED,
            openUntilEpochMs = 0L,
            halfOpenProbeUntilEpochMs = 0L,
            samples = append(current.samples, BackendHealthSample(true, latencyMs.coerceAtLeast(0L), now())),
        )
        persistBestEffort()
    }

    fun recordFailure(backendId: String, latencyMs: Long) = synchronized(lock) {
        val current = records[backendId] ?: BackendHealthRecord(backendId)
        val samples = append(current.samples, BackendHealthSample(false, latencyMs.coerceAtLeast(0L), now()))
        val consecutiveFailures = samples.asReversed().takeWhile { !it.success }.size
        val shouldOpen = current.state == CircuitBreakerState.HALF_OPEN || consecutiveFailures >= failureThreshold
        records[backendId] = current.copy(
            state = if (shouldOpen) CircuitBreakerState.OPEN else CircuitBreakerState.CLOSED,
            openUntilEpochMs = if (shouldOpen) now() + openDurationMs else 0L,
            halfOpenProbeUntilEpochMs = 0L,
            samples = samples,
        )
        persistBestEffort()
    }

    fun snapshot(backendId: String): BackendHealthSnapshot = synchronized(lock) {
        val current = records[backendId] ?: BackendHealthRecord(backendId)
        val samples = current.samples
        val successes = samples.count { it.success }
        val failures = samples.size - successes
        val average = if (samples.isEmpty()) 0L else samples.sumOf { it.latencyMs } / samples.size
        BackendHealthSnapshot(
            backendId = backendId,
            state = current.state,
            recentSuccesses = successes,
            recentFailures = failures,
            averageLatencyMs = average,
            consecutiveFailures = samples.asReversed().takeWhile { !it.success }.size,
            openUntilEpochMs = current.openUntilEpochMs,
        )
    }

    private fun append(current: List<BackendHealthSample>, sample: BackendHealthSample): List<BackendHealthSample> =
        (current + sample).takeLast(maxSamples)

    /** Health metadata must never turn a valid model answer into a user-visible failure. */
    private fun persistBestEffort() {
        runCatching { store.replace(records.values) }
    }

    private companion object {
        const val HALF_OPEN_PROBE_LEASE_MS = 15_000L
    }
}
