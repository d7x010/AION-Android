package com.aion.mobile.core.local

/** Truthful offline contract. A capability is never advertised just because code could be added later. */
enum class OfflineCapability {
    DETERMINISTIC_ARITHMETIC,
    GENERAL_CHAT,
    WEB_SEARCH,
    REMOTE_FILE_ANALYSIS,
    CLOUD_TOOLS,
}

data class OfflineCapabilityStatus(
    val capability: OfflineCapability,
    val availableOffline: Boolean,
    val engineId: String? = null,
    val reason: String,
)

object OfflineCapabilityMatrix {
    const val LOCAL_PROVIDER_KEY = "aion-local"
    const val LOCAL_PROVIDER_LABEL = "AION Local"
    const val NANO_MODEL_ID = "aion-nano-deterministic-v1"

    fun status(capability: OfflineCapability): OfflineCapabilityStatus = when (capability) {
        OfflineCapability.DETERMINISTIC_ARITHMETIC -> OfflineCapabilityStatus(
            capability = capability,
            availableOffline = true,
            engineId = NANO_MODEL_ID,
            reason = "Deterministic calculator is packaged in the APK and requires no network.",
        )
        OfflineCapability.GENERAL_CHAT -> OfflineCapabilityStatus(
            capability, false, null,
            "No verified local conversational LLM runtime is installed.",
        )
        OfflineCapability.WEB_SEARCH -> OfflineCapabilityStatus(
            capability, false, null,
            "Web search requires network access.",
        )
        OfflineCapability.REMOTE_FILE_ANALYSIS -> OfflineCapabilityStatus(
            capability, false, null,
            "General semantic file analysis still requires the cloud runtime.",
        )
        OfflineCapability.CLOUD_TOOLS -> OfflineCapabilityStatus(
            capability, false, null,
            "Cloud tools are not available offline.",
        )
    }

    fun all(): List<OfflineCapabilityStatus> = OfflineCapability.entries.map(::status)
}
