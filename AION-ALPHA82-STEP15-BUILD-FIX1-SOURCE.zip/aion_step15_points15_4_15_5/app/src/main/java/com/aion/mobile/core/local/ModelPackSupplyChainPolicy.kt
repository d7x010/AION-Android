package com.aion.mobile.core.local

import java.net.URI
import java.security.MessageDigest

sealed interface ModelPackSupplyChainResult {
    data object Trusted : ModelPackSupplyChainResult
    data class Rejected(val code: Code, val detail: String) : ModelPackSupplyChainResult

    enum class Code {
        PROVENANCE_REQUIRED,
        LEGACY_UNVERIFIED,
        INVALID_SOURCE_URI,
        INSECURE_REMOTE_SOURCE,
        MISSING_PUBLISHER,
        INVALID_ACQUIRED_TIME,
        INVALID_ISSUED_TIME,
        INVALID_MANIFEST_DIGEST,
        MANIFEST_DIGEST_MISMATCH,
        SIGNATURE_REQUIRED,
        SIGNATURE_ALGORITHM_UNSUPPORTED,
        SIGNER_ID_REQUIRED,
    }
}

/** Fail-closed provenance contract for every executable local model pack. */
object ModelPackSupplyChainPolicy {
    private val sha256Pattern = Regex("^[0-9a-fA-F]{64}$")
    private val signerPattern = Regex("^[A-Za-z0-9._:@/-]{3,160}$")
    val supportedSignatureAlgorithms = setOf("Ed25519", "SHA256withECDSA", "SHA256withRSA")

    fun validate(descriptor: LocalModelPackDescriptor): ModelPackSupplyChainResult {
        val p = descriptor.provenance
            ?: return ModelPackSupplyChainResult.Rejected(ModelPackSupplyChainResult.Code.PROVENANCE_REQUIRED, "model pack provenance missing")
        if (p.sourceType == ModelPackSourceType.LEGACY_UNVERIFIED) {
            return ModelPackSupplyChainResult.Rejected(ModelPackSupplyChainResult.Code.LEGACY_UNVERIFIED, "legacy model packs are not trusted after Step 14")
        }
        if (p.publisher.isBlank() || p.publisher.length > 160) {
            return ModelPackSupplyChainResult.Rejected(ModelPackSupplyChainResult.Code.MISSING_PUBLISHER, "publisher invalid")
        }
        if (p.acquiredAtEpochMs <= 0L) {
            return ModelPackSupplyChainResult.Rejected(ModelPackSupplyChainResult.Code.INVALID_ACQUIRED_TIME, "acquiredAt must be positive")
        }
        if (p.issuedAtEpochMs <= 0L || p.issuedAtEpochMs > p.acquiredAtEpochMs + CLOCK_SKEW_MS) {
            return ModelPackSupplyChainResult.Rejected(ModelPackSupplyChainResult.Code.INVALID_ISSUED_TIME, "issuedAt invalid")
        }

        val uri = runCatching { URI(p.sourceUri.trim()) }.getOrNull()
            ?: return ModelPackSupplyChainResult.Rejected(ModelPackSupplyChainResult.Code.INVALID_SOURCE_URI, p.sourceUri)
        if (uri.scheme.isNullOrBlank() || uri.userInfo != null || uri.rawQuery != null || uri.rawFragment != null || p.sourceUri.length > 2048) {
            return ModelPackSupplyChainResult.Rejected(ModelPackSupplyChainResult.Code.INVALID_SOURCE_URI, "scheme/userinfo/query/fragment/length invalid")
        }
        when (p.sourceType) {
            ModelPackSourceType.REMOTE_REPOSITORY -> {
                if (!uri.scheme.equals("https", ignoreCase = true) || uri.host.isNullOrBlank()) {
                    return ModelPackSupplyChainResult.Rejected(ModelPackSupplyChainResult.Code.INSECURE_REMOTE_SOURCE, p.sourceUri)
                }
            }
            ModelPackSourceType.BUNDLED_RELEASE -> if (uri.scheme.lowercase() !in setOf("asset", "res", "bundled")) {
                return ModelPackSupplyChainResult.Rejected(ModelPackSupplyChainResult.Code.INVALID_SOURCE_URI, p.sourceUri)
            }
            ModelPackSourceType.USER_IMPORT -> if (uri.scheme.lowercase() !in setOf("file", "content")) {
                return ModelPackSupplyChainResult.Rejected(ModelPackSupplyChainResult.Code.INVALID_SOURCE_URI, p.sourceUri)
            }
            ModelPackSourceType.LEGACY_UNVERIFIED -> error("handled above")
        }

        if (!descriptor.requireSignature || descriptor.signature.isNullOrBlank()) {
            return ModelPackSupplyChainResult.Rejected(ModelPackSupplyChainResult.Code.SIGNATURE_REQUIRED, "signed pack required")
        }
        if (p.signatureAlgorithm !in supportedSignatureAlgorithms) {
            return ModelPackSupplyChainResult.Rejected(ModelPackSupplyChainResult.Code.SIGNATURE_ALGORITHM_UNSUPPORTED, p.signatureAlgorithm)
        }
        if (!p.signerKeyId.matches(signerPattern)) {
            return ModelPackSupplyChainResult.Rejected(ModelPackSupplyChainResult.Code.SIGNER_ID_REQUIRED, "signerKeyId invalid")
        }
        if (!p.manifestSha256.matches(sha256Pattern)) {
            return ModelPackSupplyChainResult.Rejected(ModelPackSupplyChainResult.Code.INVALID_MANIFEST_DIGEST, p.manifestSha256)
        }
        val expected = manifestDigest(descriptor)
        if (!expected.equals(p.manifestSha256, ignoreCase = true)) {
            return ModelPackSupplyChainResult.Rejected(
                ModelPackSupplyChainResult.Code.MANIFEST_DIGEST_MISMATCH,
                "actual=${p.manifestSha256}, expected=$expected",
            )
        }
        return ModelPackSupplyChainResult.Trusted
    }

    fun seal(descriptor: LocalModelPackDescriptor): LocalModelPackDescriptor {
        val p = requireNotNull(descriptor.provenance) { "provenance required" }
        return descriptor.copy(provenance = p.copy(manifestSha256 = manifestDigest(descriptor)))
    }

    fun manifestDigest(descriptor: LocalModelPackDescriptor): String {
        val p = requireNotNull(descriptor.provenance) { "provenance required" }
        val r = descriptor.requirements
        val canonical = listOf(
            "aion-model-pack-manifest-v1",
            descriptor.modelId,
            descriptor.version,
            descriptor.expectedSizeBytes.toString(),
            descriptor.sha256.lowercase(),
            descriptor.requireSignature.toString(),
            r.modelId,
            r.minimumAvailableRamBytes.toString(),
            r.estimatedResidentBytes.toString(),
            r.minimumFreeStorageBytes.toString(),
            r.allowBackground.toString(),
            p.sourceType.name,
            p.sourceUri.trim(),
            p.publisher.trim(),
            p.acquiredAtEpochMs.toString(),
            p.issuedAtEpochMs.toString(),
            p.signatureAlgorithm,
            p.signerKeyId.trim(),
        ).joinToString("\n")
        return MessageDigest.getInstance("SHA-256")
            .digest(canonical.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }
    }

    private const val CLOCK_SKEW_MS = 5L * 60L * 1000L
}
