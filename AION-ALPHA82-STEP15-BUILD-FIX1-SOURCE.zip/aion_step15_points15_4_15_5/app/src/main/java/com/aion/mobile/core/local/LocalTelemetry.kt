package com.aion.mobile.core.local

import java.io.File
import java.nio.file.Files
import java.nio.file.StandardCopyOption

/** Small best-effort local metadata log. Failure is deliberately non-fatal to the user reply. */
object LocalTelemetry {
    private const val MAX_LINES = 100

    fun recordBestEffort(root: File, event: String, fields: Map<String, String> = emptyMap()): Boolean = runCatching {
        val directory = File(root, "aion_local_intelligence").apply { mkdirs() }
        val target = File(directory, "telemetry.tsv")
        val prior = if (target.isFile) target.readLines().takeLast(MAX_LINES - 1) else emptyList()
        val sanitized = fields.entries.sortedBy { it.key }.joinToString("\t") {
            "${sanitize(it.key)}=${sanitize(it.value)}"
        }
        val line = buildString {
            append(System.currentTimeMillis()).append('\t').append(sanitize(event))
            if (sanitized.isNotBlank()) append('\t').append(sanitized)
        }
        val temp = File(directory, ".telemetry.tmp-${System.nanoTime()}")
        temp.writeText((prior + line).joinToString("\n", postfix = "\n"))
        runCatching {
            Files.move(temp.toPath(), target.toPath(), StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE)
        }.recoverCatching {
            Files.move(temp.toPath(), target.toPath(), StandardCopyOption.REPLACE_EXISTING)
        }.getOrThrow()
        true
    }.getOrDefault(false)

    private fun sanitize(value: String): String = value.replace(Regex("[\\r\\n\\t]"), " ").take(160)
}
