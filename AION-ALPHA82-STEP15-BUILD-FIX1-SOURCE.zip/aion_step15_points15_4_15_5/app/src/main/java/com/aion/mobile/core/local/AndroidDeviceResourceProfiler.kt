package com.aion.mobile.core.local

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import android.os.PowerManager
import android.os.StatFs

class AndroidDeviceResourceProfiler(
    context: Context,
    private val now: () -> Long = System::currentTimeMillis,
) : DeviceResourceProfiler {
    private val appContext = context.applicationContext

    override fun snapshot(): DeviceResourceSnapshot {
        val activity = appContext.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val memory = ActivityManager.MemoryInfo().also(activity::getMemoryInfo)
        val storage = StatFs(appContext.filesDir.absolutePath)
        val power = appContext.getSystemService(Context.POWER_SERVICE) as PowerManager
        val batteryManager = appContext.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val batteryIntent = appContext.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))

        val capacity = batteryManager.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
            .takeIf { it in 0..100 }
        val status = batteryIntent?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL

        return DeviceResourceSnapshot(
            capturedAtEpochMs = now(),
            totalRamBytes = memory.totalMem.coerceAtLeast(0L),
            availableRamBytes = memory.availMem.coerceAtLeast(0L),
            lowMemory = memory.lowMemory,
            availableStorageBytes = storage.availableBytes.coerceAtLeast(0L),
            batteryPercent = capacity,
            charging = charging,
            powerSaver = power.isPowerSaveMode,
            thermalLevel = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                mapThermal(power.currentThermalStatus)
            } else {
                ThermalLevel.UNKNOWN
            },
        )
    }

    private fun mapThermal(value: Int): ThermalLevel = when (value) {
        PowerManager.THERMAL_STATUS_NONE -> ThermalLevel.NONE
        PowerManager.THERMAL_STATUS_LIGHT -> ThermalLevel.LIGHT
        PowerManager.THERMAL_STATUS_MODERATE -> ThermalLevel.MODERATE
        PowerManager.THERMAL_STATUS_SEVERE -> ThermalLevel.SEVERE
        PowerManager.THERMAL_STATUS_CRITICAL -> ThermalLevel.CRITICAL
        PowerManager.THERMAL_STATUS_EMERGENCY -> ThermalLevel.EMERGENCY
        PowerManager.THERMAL_STATUS_SHUTDOWN -> ThermalLevel.SHUTDOWN
        else -> ThermalLevel.UNKNOWN
    }
}
