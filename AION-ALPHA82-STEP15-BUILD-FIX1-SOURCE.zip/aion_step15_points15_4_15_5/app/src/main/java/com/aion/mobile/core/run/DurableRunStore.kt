package com.aion.mobile.core.run

import com.aion.mobile.core.sovereign.SovereignTask
import com.aion.mobile.core.sovereign.SovereignTaskState
import com.aion.mobile.core.sovereign.TaskCheckpoint
import com.aion.mobile.core.sovereign.TaskFailure
import com.aion.mobile.core.storage.AionStorageSchemaRegistry
import com.aion.mobile.core.storage.DurableFileRecovery
import com.aion.mobile.model.AttachmentKind
import com.aion.mobile.model.ChatAttachment
import com.aion.mobile.model.ChatMessage
import com.aion.mobile.model.ChatSource
import com.aion.mobile.model.MessageRole
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

internal object AionRunRequestStore {
    private const val BUCKET = "requests"
    private fun file(root: File, runId: String) = File(DurableRunFiles.dir(root, BUCKET), "$runId.json")

    fun save(root: File, request: AionRunRequest) {
        DurableRunFiles.requireRunId(request.runId)
        val raw = encode(request).toString()
        check(DurableFileRecovery.writeText(file(root, request.runId), raw) { value -> requestReadable(value, request.runId) }) {
            "run_request_persist_failed"
        }
    }

    fun load(root: File, runId: String): AionRunRequest? = runCatching {
        DurableRunFiles.requireRunId(runId)
        val result = DurableFileRecovery.readText(file(root, runId)) { raw -> requestReadable(raw, runId) }
        val raw = result.bytes?.toString(Charsets.UTF_8) ?: return null
        decode(JSONObject(raw)).takeIf { it.runId == runId }
    }.getOrNull()

    private fun requestReadable(raw: String, expectedRunId: String): Boolean = runCatching {
        val node = JSONObject(raw)
        val schema = node.optInt("schema", 1)
        AionStorageSchemaRegistry.runRequest.canRead(schema) &&
            node.optString("runId") == expectedRunId && node.has("conversationId") && node.has("placeholderId")
    }.getOrDefault(false)

    fun listRunIds(root: File): List<String> = DurableRunFiles.dir(root, BUCKET).listFiles()
        ?.asSequence()?.filter { it.isFile && it.name.endsWith(".json") }
        ?.map { it.name.removeSuffix(".json") }
        ?.filter { id -> runCatching { DurableRunFiles.requireRunId(id) }.isSuccess }
        ?.sorted()?.toList().orEmpty()

    private fun encode(request: AionRunRequest) = JSONObject().apply {
        put("schema", AionStorageSchemaRegistry.runRequest.currentVersion)
        put("runId", request.runId)
        put("conversationId", request.conversationId)
        put("placeholderId", request.placeholderId)
        put("modelId", request.modelId)
        put("modelLabel", request.modelLabel)
        put("forceWebSearch", request.forceWebSearch)
        put("customInstructions", request.customInstructions)
        put("memoryContext", request.memoryContext)
        put("contextContext", request.contextContext)
        put("messages", encodeMessages(request.messages))
        put("sessionMessages", encodeMessages(request.sessionMessages))
    }

    private fun decode(node: JSONObject) = AionRunRequest(
        runId = node.getString("runId"),
        conversationId = node.getString("conversationId"),
        placeholderId = node.getLong("placeholderId"),
        modelId = node.optString("modelId", "auto"),
        modelLabel = node.optString("modelLabel", "AION"),
        messages = decodeMessages(node.optJSONArray("messages")),
        sessionMessages = decodeMessages(node.optJSONArray("sessionMessages")),
        forceWebSearch = node.optBoolean("forceWebSearch", false),
        customInstructions = node.optString("customInstructions", ""),
        memoryContext = node.optString("memoryContext", ""),
        contextContext = node.optString("contextContext", ""),
    )

    private fun encodeMessages(messages: List<ChatMessage>) = JSONArray().apply { messages.forEach { put(encodeMessage(it)) } }

    private fun encodeMessage(message: ChatMessage) = JSONObject().apply {
        put("id", message.id); put("role", message.role.name); put("text", message.text)
        putOpt("modelId", message.modelId); putOpt("modelLabel", message.modelLabel)
        putOpt("executionProviderKey", message.executionProviderKey); putOpt("executionProviderLabel", message.executionProviderLabel)
        putOpt("executionModelId", message.executionModelId); putOpt("routingPolicy", message.routingPolicy)
        put("fallbackUsed", message.fallbackUsed); put("executionAttempts", message.executionAttempts)
        put("orchestratorContract", message.orchestratorContract); putOpt("orchestratorTraceId", message.orchestratorTraceId)
        putOpt("orchestratorSearchReason", message.orchestratorSearchReason); putOpt("orchestratorMemoryPolicy", message.orchestratorMemoryPolicy)
        putOpt("orchestratorToolRoute", message.orchestratorToolRoute); putOpt("orchestratorResponseProfile", message.orchestratorResponseProfile)
        put("isError", message.isError); put("isStreaming", message.isStreaming); put("wasStopped", message.wasStopped)
        put("attachments", JSONArray().apply { message.attachments.forEach { attachment -> put(JSONObject().apply {
            put("id", attachment.id); put("name", attachment.name); put("mimeType", attachment.mimeType)
            put("base64Data", attachment.base64Data); put("kind", attachment.kind.name); put("sizeBytes", attachment.sizeBytes); put("localPath", attachment.localPath)
        }) } })
        put("sources", JSONArray().apply { message.sources.forEach { source -> put(JSONObject().apply {
            put("title", source.title); put("url", source.url); put("snippet", source.snippet)
        }) } })
    }

    private fun decodeMessages(array: JSONArray?): List<ChatMessage> = buildList {
        if (array == null) return@buildList
        for (i in 0 until array.length()) {
            val n = array.optJSONObject(i) ?: continue
            val attachments = buildList {
                val a = n.optJSONArray("attachments") ?: JSONArray()
                for (j in 0 until a.length()) {
                    val item = a.optJSONObject(j) ?: continue
                    add(ChatAttachment(
                        id = item.optLong("id", 0L), name = item.optString("name"), mimeType = item.optString("mimeType"),
                        base64Data = item.optString("base64Data"), kind = runCatching { AttachmentKind.valueOf(item.optString("kind")) }.getOrDefault(AttachmentKind.FILE),
                        sizeBytes = item.optLong("sizeBytes", 0L), localPath = item.optString("localPath")
                    ))
                }
            }
            val sources = buildList {
                val s = n.optJSONArray("sources") ?: JSONArray()
                for (j in 0 until s.length()) {
                    val item = s.optJSONObject(j) ?: continue
                    add(ChatSource(item.optString("title"), item.optString("url"), item.optString("snippet")))
                }
            }
            add(ChatMessage(
                id = n.getLong("id"), role = runCatching { MessageRole.valueOf(n.getString("role")) }.getOrDefault(MessageRole.USER), text = n.optString("text"),
                modelId = n.optNullableString("modelId"), modelLabel = n.optNullableString("modelLabel"),
                executionProviderKey = n.optNullableString("executionProviderKey"), executionProviderLabel = n.optNullableString("executionProviderLabel"),
                executionModelId = n.optNullableString("executionModelId"), routingPolicy = n.optNullableString("routingPolicy"), fallbackUsed = n.optBoolean("fallbackUsed"),
                executionAttempts = n.optInt("executionAttempts", 1), orchestratorContract = n.optInt("orchestratorContract", 0), orchestratorTraceId = n.optNullableString("orchestratorTraceId"),
                orchestratorSearchReason = n.optNullableString("orchestratorSearchReason"), orchestratorMemoryPolicy = n.optNullableString("orchestratorMemoryPolicy"),
                orchestratorToolRoute = n.optNullableString("orchestratorToolRoute"), orchestratorResponseProfile = n.optNullableString("orchestratorResponseProfile"),
                attachments = attachments, sources = sources, isError = n.optBoolean("isError"), isStreaming = n.optBoolean("isStreaming"), wasStopped = n.optBoolean("wasStopped")
            ))
        }
    }

    private fun JSONObject.optNullableString(key: String): String? = if (has(key) && !isNull(key)) optString(key).takeIf { it.isNotBlank() } else null
}

object SovereignTaskStore {
    private const val BUCKET = "tasks"
    private fun file(root: File, runId: String) = File(DurableRunFiles.dir(root, BUCKET), "$runId.json")

    fun save(root: File, task: SovereignTask) {
        DurableRunFiles.requireRunId(task.id)
        val node = JSONObject().apply {
            put("schema", AionStorageSchemaRegistry.sovereignTask.currentVersion); put("contract", task.contract); put("id", task.id); put("goal", task.goal); put("state", task.state.name)
            putOpt("currentStep", task.currentStep); put("attempts", task.attempts); put("maxAttempts", task.maxAttempts)
            put("createdAt", task.createdAt); put("updatedAt", task.updatedAt); putOpt("lastHeartbeatAt", task.lastHeartbeatAt); putOpt("nextRetryAt", task.nextRetryAt)
            putOpt("blockedReason", task.blockedReason); put("revision", task.revision); put("cancelRequested", task.cancelRequested)
            put("dependencies", JSONArray(task.dependencies.toList())); put("outputs", JSONArray(task.outputs))
            task.checkpoint?.let { cp -> put("checkpoint", JSONObject().apply {
                put("savedAt", cp.savedAt); put("state", cp.state.name); putOpt("stepId", cp.stepId); put("payload", JSONObject(cp.payload))
            }) }
            task.lastFailure?.let { failure -> put("lastFailure", JSONObject().apply {
                put("type", failure.type); put("recoverable", failure.recoverable); put("action", failure.action); put("message", failure.message)
            }) }
        }
        val raw = node.toString()
        check(DurableFileRecovery.writeText(file(root, task.id), raw) { value -> taskReadable(value, task.id) }) {
            "sovereign_task_persist_failed"
        }
    }

    fun load(root: File, runId: String): SovereignTask? = runCatching {
        DurableRunFiles.requireRunId(runId)
        val result = DurableFileRecovery.readText(file(root, runId)) { value -> taskReadable(value, runId) }
        val raw = result.bytes?.toString(Charsets.UTF_8) ?: return null
        val n = JSONObject(raw)
        val cp = n.optJSONObject("checkpoint")?.let { c ->
            val payloadNode = c.optJSONObject("payload") ?: JSONObject()
            val payload = buildMap { payloadNode.keys().forEach { key -> put(key, payloadNode.optString(key)) } }
            TaskCheckpoint(c.optString("savedAt"), SovereignTaskState.valueOf(c.optString("state")), c.optNullableString("stepId"), payload)
        }
        val failure = n.optJSONObject("lastFailure")?.let { f -> TaskFailure(f.optString("type"), f.optBoolean("recoverable"), f.optString("action"), f.optString("message")) }
        SovereignTask(
            contract = n.optInt("contract", 1), id = n.getString("id"), goal = n.optString("goal"), state = SovereignTaskState.valueOf(n.getString("state")),
            currentStep = n.optNullableString("currentStep"), checkpoint = cp, dependencies = n.optStringSet("dependencies"), outputs = n.optStringList("outputs"),
            attempts = n.optInt("attempts"), maxAttempts = n.optInt("maxAttempts", 5), createdAt = n.optString("createdAt"), updatedAt = n.optString("updatedAt"),
            lastHeartbeatAt = n.optNullableString("lastHeartbeatAt"), nextRetryAt = n.optNullableString("nextRetryAt"), blockedReason = n.optNullableString("blockedReason"),
            lastFailure = failure, revision = n.optLong("revision", 1L), cancelRequested = n.optBoolean("cancelRequested", false)
        )
    }.getOrNull()

    private fun taskReadable(raw: String, expectedRunId: String): Boolean = runCatching {
        val node = JSONObject(raw)
        val schema = node.optInt("schema", 1)
        AionStorageSchemaRegistry.sovereignTask.canRead(schema) &&
            node.optString("id") == expectedRunId &&
            runCatching { SovereignTaskState.valueOf(node.getString("state")) }.isSuccess
    }.getOrDefault(false)

    fun pendingRunIds(root: File): List<String> = AionRunRequestStore.listRunIds(root).filter { runId ->
        val task = load(root, runId) ?: return@filter true
        task.state !in setOf(SovereignTaskState.COMPLETED, SovereignTaskState.FAILED_FINAL, SovereignTaskState.CANCELLED)
    }

    private fun JSONObject.optNullableString(key: String): String? = if (has(key) && !isNull(key)) optString(key).takeIf { it.isNotBlank() } else null
    private fun JSONObject.optStringList(key: String): List<String> = buildList {
        val a = optJSONArray(key) ?: return@buildList
        for (i in 0 until a.length()) add(a.optString(i))
    }
    private fun JSONObject.optStringSet(key: String): Set<String> = optStringList(key).toSet()
}
