package com.aion.mobile.core.memory

import android.content.Context
import com.aion.mobile.core.project.AionProject
import com.aion.mobile.core.storage.AionStorageSchemaRegistry
import com.aion.mobile.core.storage.DurableFileRecovery
import java.io.File
import java.util.UUID
import org.json.JSONArray
import org.json.JSONObject

/** Durable local store for Memory OS v2. */
object AionMemoryStore {
    private val FILE_SCHEMA = AionStorageSchemaRegistry.memory.currentVersion
    private val LEGACY_FILE_SCHEMA = AionStorageSchemaRegistry.memory.minimumReadableVersion

    fun load(context: Context): List<AionMemoryEntry> {
        val currentRaw = readRaw(memoryFile(context))
        if (currentRaw != null) return decode(currentRaw)

        val legacyRaw = readRaw(legacyMemoryFile(context)) ?: return emptyList()
        val migrated = decode(legacyRaw)
        if (migrated.isNotEmpty()) persist(context, migrated)
        return migrated
    }

    fun syncLegacy(
        context: Context,
        globalNotes: String,
        projects: List<AionProject>,
        now: Long = System.currentTimeMillis()
    ): List<AionMemoryEntry> {
        val before = load(context)
        var entries = before
        val global = preserveSyncedTimestamps(
            existing = entries,
            incoming = MemoryEnginePolicy.entriesFromNotes(
                raw = globalNotes,
                scope = MemoryScope.USER,
                ownerId = "",
                source = MemorySource.USER_SETTINGS,
                now = now
            )
        )
        entries = MemoryEnginePolicy.replaceSynchronizedSource(
            entries, MemoryScope.USER, "", MemorySource.USER_SETTINGS, global
        )

        val projectIds = projects.mapTo(hashSetOf()) { it.id }
        entries = entries.map { row ->
            if (row.source == MemorySource.PROJECT_NOTES && row.scope == MemoryScope.PROJECT && row.ownerId !in projectIds) {
                row.copy(active = false)
            } else row
        }
        projects.forEach { project ->
            val rows = preserveSyncedTimestamps(
                existing = entries,
                incoming = MemoryEnginePolicy.entriesFromNotes(
                    raw = project.memoryNotes,
                    scope = MemoryScope.PROJECT,
                    ownerId = project.id,
                    source = MemorySource.PROJECT_NOTES,
                    now = now
                )
            )
            entries = MemoryEnginePolicy.replaceSynchronizedSource(
                entries, MemoryScope.PROJECT, project.id, MemorySource.PROJECT_NOTES, rows
            )
        }
        val compacted = MemoryEnginePolicy.compact(entries)
        if (compacted != before) persist(context, compacted)
        return compacted
    }

    fun buildContext(
        context: Context,
        globalNotes: String,
        projects: List<AionProject>,
        activeProjectId: String?,
        activeConversationId: String?,
        projectOnlyMemory: Boolean,
        queryText: String = "",
        allowedScopes: Set<MemoryScope> = MemoryScope.entries.toSet(),
        now: Long = System.currentTimeMillis()
    ): AionMemoryContext {
        val entries = syncLegacy(context, globalNotes, projects, now)
        return MemoryEnginePolicy.selectForContext(
            entries = entries,
            activeProjectId = activeProjectId,
            activeConversationId = activeConversationId,
            projectOnlyMemory = projectOnlyMemory,
            now = now,
            queryText = queryText,
            allowedScopes = allowedScopes
        )
    }

    /** Structured Memory OS v2 upsert. Previous slot values are preserved as history. */
    fun upsert(
        context: Context,
        scope: MemoryScope,
        ownerId: String = "",
        projectId: String = "",
        kind: MemoryKind,
        layer: MemoryLayer = MemoryEnginePolicy.defaultLayer(scope, kind),
        text: String,
        slot: String = "",
        source: MemorySource,
        confidence: Float = 1f,
        priority: Int = MemoryEnginePolicy.defaultPriority(source),
        pinned: Boolean = false,
        expiresAt: Long = 0L,
        now: Long = System.currentTimeMillis()
    ): AionMemoryEntry? {
        val candidate = AionMemoryEntry(
            id = UUID.randomUUID().toString(),
            scope = scope,
            ownerId = ownerId,
            projectId = projectId,
            layer = if (scope == MemoryScope.PROJECT) MemoryLayer.PROJECT else layer,
            kind = kind,
            text = text,
            slot = slot,
            source = source,
            contentHash = MemoryEnginePolicy.contentHash(text),
            observedAt = now,
            confidence = confidence,
            priority = priority,
            pinned = pinned,
            createdAt = now,
            updatedAt = now,
            expiresAt = expiresAt
        )
        val updated = MemoryEnginePolicy.upsert(load(context), candidate)
        if (!persist(context, updated)) return null
        return updated.firstOrNull { it.id == candidate.id }
            ?: updated.firstOrNull {
                it.active && it.scope == candidate.scope && it.ownerId == candidate.ownerId &&
                    it.projectId == candidate.projectId && it.slot.isNotBlank() && it.slot == candidate.slot
            }
            ?: updated.firstOrNull {
                it.active && it.scope == candidate.scope && it.ownerId == candidate.ownerId &&
                    it.projectId == candidate.projectId && MemoryEnginePolicy.canonical(it.text) == MemoryEnginePolicy.canonical(candidate.text)
            }
    }

    fun forget(context: Context, entryId: String) {
        if (entryId.isBlank()) return
        persist(context, load(context).filterNot { it.id == entryId })
    }

    fun clearScope(context: Context, scope: MemoryScope, ownerId: String = "") {
        val cleanOwner = ownerId.trim()
        persist(context, load(context).filterNot { it.scope == scope && it.ownerId == cleanOwner })
    }

    private fun preserveSyncedTimestamps(
        existing: List<AionMemoryEntry>,
        incoming: List<AionMemoryEntry>
    ): List<AionMemoryEntry> {
        val byId = existing.associateBy { it.id }
        return incoming.map { row ->
            val old = byId[row.id]
            if (old != null && MemoryEnginePolicy.canonical(old.text) == MemoryEnginePolicy.canonical(row.text)) {
                row.copy(
                    createdAt = old.createdAt,
                    updatedAt = old.updatedAt,
                    observedAt = old.observedAt,
                    contentHash = old.contentHash.ifBlank { row.contentHash },
                    pinned = old.pinned,
                    priority = maxOf(old.priority, row.priority)
                )
            } else row
        }
    }

    private fun memoryDir(context: Context): File = File(context.filesDir, "aion_memory").also {
        if (!it.exists()) it.mkdirs()
    }

    private fun memoryFile(context: Context): File = File(memoryDir(context), "memory_v2.json")
    private fun legacyMemoryFile(context: Context): File = File(memoryDir(context), "memory_v1.json")

    private fun readRaw(file: File): String? {
        val result = DurableFileRecovery.readText(file, ::isReadableRaw)
        return result.bytes?.toString(Charsets.UTF_8)
    }

    private fun persist(context: Context, entries: List<AionMemoryEntry>): Boolean {
        val raw = encode(entries).toString()
        return DurableFileRecovery.writeText(memoryFile(context), raw, ::isReadableRaw)
    }

    private fun isReadableRaw(raw: String): Boolean = runCatching {
        val root = JSONObject(raw)
        val schema = root.optInt("schema", LEGACY_FILE_SCHEMA)
        if (!AionStorageSchemaRegistry.memory.canRead(schema)) return@runCatching false
        val array = root.optJSONArray("entries") ?: return@runCatching false
        for (i in 0 until array.length()) {
            val row = array.optJSONObject(i) ?: return@runCatching false
            val id = row.optString("id").trim()
            val text = row.optString("text")
            val scope = runCatching { MemoryScope.valueOf(row.optString("scope").uppercase()) }.getOrNull()
            val source = runCatching { MemorySource.valueOf(row.optString("source").uppercase()) }.getOrNull()
            if (id.isBlank() || MemoryEnginePolicy.normalizeText(text).isBlank() || scope == null || source == null) {
                return@runCatching false
            }
        }
        true
    }.getOrDefault(false)

    private fun encode(entries: List<AionMemoryEntry>): JSONObject = JSONObject().apply {
        put("schema", FILE_SCHEMA)
        put("contract", MemoryEnginePolicy.CONTRACT)
        put("entries", JSONArray().apply {
            MemoryEnginePolicy.compact(entries).forEach { entry ->
                put(JSONObject().apply {
                    put("id", entry.id)
                    put("scope", entry.scope.name.lowercase())
                    put("ownerId", entry.ownerId)
                    put("projectId", entry.projectId)
                    put("layer", entry.layer.name.lowercase())
                    put("kind", entry.kind.name.lowercase())
                    put("text", entry.text)
                    put("slot", entry.slot)
                    put("source", entry.source.name.lowercase())
                    put("contentHash", entry.contentHash)
                    put("observedAt", entry.observedAt)
                    put("confidence", entry.confidence.toDouble())
                    put("priority", entry.priority)
                    put("pinned", entry.pinned)
                    put("createdAt", entry.createdAt)
                    put("updatedAt", entry.updatedAt)
                    put("expiresAt", entry.expiresAt)
                    put("active", entry.active)
                    put("supersedesId", entry.supersedesId)
                    put("supersededById", entry.supersededById)
                    put("candidateAgainstId", entry.candidateAgainstId)
                })
            }
        })
    }

    private fun decode(raw: String): List<AionMemoryEntry> = runCatching {
        val root = JSONObject(raw)
        val schema = root.optInt("schema", LEGACY_FILE_SCHEMA)
        if (!AionStorageSchemaRegistry.memory.canRead(schema)) return@runCatching emptyList()
        val array = root.optJSONArray("entries") ?: JSONArray()
        buildList {
            for (i in 0 until array.length()) {
                val row = array.optJSONObject(i) ?: continue
                val scope = runCatching { MemoryScope.valueOf(row.optString("scope").uppercase()) }.getOrNull() ?: continue
                val kind = runCatching { MemoryKind.valueOf(row.optString("kind").uppercase()) }.getOrNull() ?: MemoryKind.NOTE
                val source = runCatching { MemorySource.valueOf(row.optString("source").uppercase()) }.getOrNull() ?: continue
                val id = row.optString("id").trim()
                val text = row.optString("text")
                if (id.isBlank() || MemoryEnginePolicy.normalizeText(text).isBlank()) continue
                val ownerId = row.optString("ownerId")
                val projectId = if (schema >= 2) row.optString("projectId") else if (scope == MemoryScope.PROJECT) ownerId else ""
                val layer = if (schema >= 2) {
                    runCatching { MemoryLayer.valueOf(row.optString("layer").uppercase()) }.getOrNull()
                        ?: MemoryEnginePolicy.defaultLayer(scope, kind)
                } else MemoryEnginePolicy.defaultLayer(scope, kind)
                val createdAt = row.optLong("createdAt")
                val updatedAt = row.optLong("updatedAt")
                add(
                    AionMemoryEntry(
                        id = id,
                        scope = scope,
                        ownerId = ownerId,
                        projectId = projectId,
                        layer = layer,
                        kind = kind,
                        text = text,
                        slot = row.optString("slot"),
                        source = source,
                        contentHash = if (schema >= 2) row.optString("contentHash") else MemoryEnginePolicy.contentHash(text),
                        observedAt = if (schema >= 2) row.optLong("observedAt", updatedAt) else updatedAt,
                        confidence = row.optDouble("confidence", 1.0).toFloat(),
                        priority = if (schema >= 2) row.optInt("priority", MemoryEnginePolicy.defaultPriority(source)) else MemoryEnginePolicy.defaultPriority(source),
                        pinned = schema >= 2 && row.optBoolean("pinned", false),
                        createdAt = createdAt,
                        updatedAt = updatedAt,
                        expiresAt = row.optLong("expiresAt"),
                        active = row.optBoolean("active", true),
                        supersedesId = if (schema >= 2) row.optString("supersedesId") else "",
                        supersededById = if (schema >= 2) row.optString("supersededById") else "",
                        candidateAgainstId = if (schema >= 2) row.optString("candidateAgainstId") else ""
                    )
                )
            }
        }.let(MemoryEnginePolicy::compact)
    }.getOrDefault(emptyList())
}
