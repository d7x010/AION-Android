package com.aion.mobile.core.storage

/**
 * Central schema registry for durable on-device stores.
 * A store may read only versions in [minimumReadableVersion, currentVersion].
 * Future versions fail closed so an older build never rewrites newer data.
 */
data class AionStorageSchemaSpec(
    val id: String,
    val currentVersion: Int,
    val minimumReadableVersion: Int = currentVersion,
) {
    init {
        require(id.isNotBlank())
        require(currentVersion >= 1)
        require(minimumReadableVersion in 1..currentVersion)
    }

    fun canRead(version: Int): Boolean = version in minimumReadableVersion..currentVersion
    fun isFuture(version: Int): Boolean = version > currentVersion
}

object AionStorageSchemaRegistry {
    val chat = AionStorageSchemaSpec("chat", currentVersion = 5, minimumReadableVersion = 1)
    val memory = AionStorageSchemaSpec("memory", currentVersion = 2, minimumReadableVersion = 1)
    val knowledge = AionStorageSchemaSpec("knowledge", currentVersion = 1, minimumReadableVersion = 1)
    val localModels = AionStorageSchemaSpec("local_models", currentVersion = 2, minimumReadableVersion = 1)
    val runRequest = AionStorageSchemaSpec("run_request", currentVersion = 1, minimumReadableVersion = 1)
    val sovereignTask = AionStorageSchemaSpec("sovereign_task", currentVersion = 1, minimumReadableVersion = 1)

    private val all = listOf(chat, memory, knowledge, localModels, runRequest, sovereignTask)

    fun byId(id: String): AionStorageSchemaSpec? = all.firstOrNull { it.id == id.trim() }
    fun snapshot(): Map<String, Int> = all.associate { it.id to it.currentVersion }
}
