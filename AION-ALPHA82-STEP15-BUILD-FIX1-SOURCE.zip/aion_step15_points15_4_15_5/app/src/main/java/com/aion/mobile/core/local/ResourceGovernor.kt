package com.aion.mobile.core.local

import kotlin.math.max
import kotlin.math.min

/**
 * Policy-only governor. It never guesses that a model exists and never performs I/O.
 * It decides whether a *known* local model may be loaded/executed under the latest resource snapshot.
 */
class ResourceGovernor(
    private val criticalBatteryPercent: Int = 10,
    private val backgroundBatteryFloorPercent: Int = 30,
    private val reservedRamBytes: Long = 384L * MIB,
    private val reservedStorageBytes: Long = 512L * MIB,
) {
    init {
        require(criticalBatteryPercent in 1..50)
        require(backgroundBatteryFloorPercent in criticalBatteryPercent..100)
        require(reservedRamBytes >= 0L)
        require(reservedStorageBytes >= 0L)
    }

    fun decide(
        snapshot: DeviceResourceSnapshot,
        requirements: LocalModelRequirements,
        environment: ExecutionEnvironment,
        loadedModelCount: Int,
        loadedResidentBytes: Long,
    ): ResourceGovernorDecision {
        require(loadedModelCount >= 0)
        require(loadedResidentBytes >= 0L)

        val maxConcurrent = maxConcurrentLocalModels(snapshot)
        val maxResident = maxResidentBytes(snapshot)

        if (snapshot.thermalLevel.atLeast(ThermalLevel.SEVERE)) {
            return deny(LocalExecutionReason.THERMAL_LIMIT, maxConcurrent, maxResident, "thermal=${snapshot.thermalLevel}")
        }

        val battery = snapshot.batteryPercent
        if (!snapshot.charging && battery != null && battery <= criticalBatteryPercent) {
            return defer(LocalExecutionReason.BATTERY_CRITICAL, maxConcurrent, maxResident, "battery=$battery")
        }

        if (environment == ExecutionEnvironment.BACKGROUND) {
            if (!requirements.allowBackground) {
                return defer(LocalExecutionReason.BACKGROUND_NOT_ALLOWED, maxConcurrent, maxResident)
            }
            if (snapshot.powerSaver) {
                return defer(LocalExecutionReason.POWER_SAVER_BACKGROUND, maxConcurrent, maxResident)
            }
            if (!snapshot.charging && battery != null && battery < backgroundBatteryFloorPercent) {
                return defer(LocalExecutionReason.BATTERY_CRITICAL, maxConcurrent, maxResident, "backgroundBattery=$battery")
            }
            if (snapshot.thermalLevel.atLeast(ThermalLevel.MODERATE)) {
                return defer(LocalExecutionReason.THERMAL_LIMIT, maxConcurrent, maxResident, "backgroundThermal=${snapshot.thermalLevel}")
            }
        }

        val requiredAvailableRam = max(requirements.minimumAvailableRamBytes, requirements.estimatedResidentBytes + reservedRamBytes)
        if (snapshot.lowMemory || snapshot.availableRamBytes < requiredAvailableRam) {
            return defer(
                LocalExecutionReason.RAM_LOW,
                maxConcurrent,
                maxResident,
                "available=${snapshot.availableRamBytes}, required=$requiredAvailableRam",
            )
        }

        val requiredStorage = requirements.minimumFreeStorageBytes + reservedStorageBytes
        if (snapshot.availableStorageBytes < requiredStorage) {
            return defer(
                LocalExecutionReason.STORAGE_LOW,
                maxConcurrent,
                maxResident,
                "available=${snapshot.availableStorageBytes}, required=$requiredStorage",
            )
        }

        if (loadedModelCount >= maxConcurrent) {
            return defer(LocalExecutionReason.MODEL_LIMIT, maxConcurrent, maxResident, "loaded=$loadedModelCount")
        }

        if (loadedResidentBytes + requirements.estimatedResidentBytes > maxResident) {
            return defer(
                LocalExecutionReason.RAM_LOW,
                maxConcurrent,
                maxResident,
                "resident=${loadedResidentBytes + requirements.estimatedResidentBytes}, budget=$maxResident",
            )
        }

        return ResourceGovernorDecision(
            decision = LocalExecutionDecision.ALLOW,
            reason = LocalExecutionReason.OK,
            maxConcurrentLocalModels = maxConcurrent,
            maxResidentBytes = maxResident,
        )
    }

    fun maxConcurrentLocalModels(snapshot: DeviceResourceSnapshot): Int {
        if (snapshot.thermalLevel.atLeast(ThermalLevel.MODERATE) || snapshot.lowMemory) return 1
        val gib = snapshot.totalRamBytes / GIB
        return when {
            gib >= 12L -> 3
            gib >= 8L -> 2
            else -> 1
        }
    }

    fun maxResidentBytes(snapshot: DeviceResourceSnapshot): Long {
        if (snapshot.availableRamBytes <= reservedRamBytes) return 0L
        val fraction = when {
            snapshot.thermalLevel.atLeast(ThermalLevel.MODERATE) -> 0.30
            snapshot.powerSaver -> 0.35
            else -> 0.50
        }
        val byAvailable = (snapshot.availableRamBytes * fraction).toLong()
        val byTotal = (snapshot.totalRamBytes * 0.30).toLong()
        return max(0L, min(byAvailable, byTotal) - reservedRamBytes / 2)
    }

    private fun deny(
        reason: LocalExecutionReason,
        maxConcurrent: Int,
        maxResident: Long,
        detail: String = "",
    ) = ResourceGovernorDecision(LocalExecutionDecision.DENY, reason, maxConcurrent, maxResident, detail)

    private fun defer(
        reason: LocalExecutionReason,
        maxConcurrent: Int,
        maxResident: Long,
        detail: String = "",
    ) = ResourceGovernorDecision(LocalExecutionDecision.DEFER, reason, maxConcurrent, maxResident, detail)

    companion object {
        const val MIB: Long = 1024L * 1024L
        const val GIB: Long = 1024L * MIB
    }
}
