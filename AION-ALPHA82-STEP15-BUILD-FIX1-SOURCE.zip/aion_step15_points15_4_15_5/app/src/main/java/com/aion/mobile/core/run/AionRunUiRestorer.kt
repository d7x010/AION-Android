package com.aion.mobile.core.run

import android.content.Context
import android.os.Process
import com.aion.mobile.core.ai.GatewayActivity
import com.aion.mobile.core.storage.ChatSessionStore
import com.aion.mobile.core.sovereign.SovereignTaskState
import com.aion.mobile.model.ChatMessage
import com.aion.mobile.model.MessageRole
import java.time.Instant

/** Rebuilds UI state from durable stores; the in-memory bus is only an optimization. */
object AionRunUiRestorer {
    fun restoreRun(context: Context, runId: String, fallbackActivity: GatewayActivity? = null): AionRunSnapshot? {
        val root = context.noBackupFilesDir
        val request = AionRunRequestStore.load(root, runId) ?: return null
        val task = SovereignTaskStore.load(root, runId) ?: return null
        val receipt = DurableToolReceiptStore.latest(root, runId)
        val lease = DurableExecutionLeaseStore.read(root, runId)
        val nowMs = System.currentTimeMillis()
        val observedExecutionLease = lease != null && lease.untilMs > nowMs &&
            leaseOwnedByProcess(lease.owner, Process.myPid())
        val messages = ChatSessionStore.loadMessages(context, request.conversationId)
        val partial = messages.lastOrNull { it.id == request.placeholderId && it.role == MessageRole.AION }
        val fallback = fallbackActivity
            ?: task.checkpoint?.payload?.get("activity")?.let { runCatching { GatewayActivity.valueOf(it) }.getOrNull() }
            ?: if (partial?.text?.isNotBlank() == true) GatewayActivity.WRITING else GatewayActivity.THINKING
        val mappedTruth = RuntimeUiTruthMapper.from(
            task = task,
            fallbackActivity = fallback,
            toolCallId = receipt?.toolCallId,
            toolStatus = receipt?.status,
            toolEffect = receipt?.effect,
        )
        val truth = RuntimeLivenessPolicy.apply(mappedTruth, observedExecutionLease)
        return AionRunSnapshot(
            runId = runId,
            conversationId = request.conversationId,
            placeholderId = request.placeholderId,
            modelId = request.modelId,
            modelLabel = request.modelLabel,
            executionProviderKey = partial?.executionProviderKey.orEmpty(),
            executionProviderLabel = partial?.executionProviderLabel.orEmpty(),
            executionModelId = partial?.executionModelId.orEmpty(),
            routingPolicy = partial?.routingPolicy.orEmpty(),
            fallbackUsed = partial?.fallbackUsed == true,
            executionAttempts = partial?.executionAttempts ?: 1,
            orchestratorContract = partial?.orchestratorContract ?: 0,
            orchestratorTraceId = partial?.orchestratorTraceId.orEmpty(),
            orchestratorSearchReason = partial?.orchestratorSearchReason.orEmpty(),
            orchestratorMemoryPolicy = partial?.orchestratorMemoryPolicy.orEmpty(),
            orchestratorToolRoute = partial?.orchestratorToolRoute.orEmpty(),
            orchestratorResponseProfile = partial?.orchestratorResponseProfile.orEmpty(),
            text = partial?.text.orEmpty(),
            activity = truth.gatewayActivity ?: fallback,
            isRunning = !truth.terminal,
            sources = partial?.sources.orEmpty(),
            errorText = if (task.state == SovereignTaskState.FAILED_FINAL) task.lastFailure?.message?.ifBlank { null } else null,
            wasStopped = task.state == SovereignTaskState.CANCELLED || partial?.wasStopped == true,
            runtimeUi = truth,
            runtimeRevision = task.revision,
            runtimeUpdatedAt = task.updatedAt,
            restoredFromDisk = true,
        )
    }

    fun restoreForConversation(context: Context, conversationId: String): AionRunSnapshot? {
        val root = context.noBackupFilesDir
        return SovereignTaskStore.pendingRunIds(root)
            .asSequence()
            .mapNotNull { runId ->
                val request = AionRunRequestStore.load(root, runId) ?: return@mapNotNull null
                if (request.conversationId != conversationId) return@mapNotNull null
                val task = SovereignTaskStore.load(root, runId) ?: return@mapNotNull null
                Triple(runId, task.updatedAt, task.revision)
            }
            .sortedWith(compareByDescending<Triple<String, String, Long>> { parseInstant(it.second) }.thenByDescending { it.third })
            .mapNotNull { restoreRun(context, it.first) }
            .firstOrNull()
    }

    /**
     * Makes a cancelled checkpoint terminal on disk even if the worker process dies before its catch/finally block runs.
     */
    fun persistCancelledPartial(context: Context, runId: String) {
        val root = context.noBackupFilesDir
        val request = AionRunRequestStore.load(root, runId) ?: return
        val current = ChatSessionStore.loadMessages(context, request.conversationId)
        val index = current.indexOfFirst { it.id == request.placeholderId && it.role == MessageRole.AION }
        if (index < 0) return
        val message = current[index]
        if (!message.isStreaming && message.wasStopped) return
        val updated = current.toMutableList().apply {
            this[index] = message.copy(isStreaming = false, wasStopped = true)
        }
        ChatSessionStore.saveMessages(context, request.conversationId, updated)
    }

    fun publishDurableTruth(context: Context, runId: String, fallbackActivity: GatewayActivity? = null) {
        restoreRun(context, runId, fallbackActivity)?.let(AionRunBus::publish)
    }

    internal fun leaseOwnedByProcess(owner: String, pid: Int): Boolean {
        if (pid <= 0) return false
        return owner.startsWith("android-$pid-") || owner.startsWith("job-$pid-")
    }

    private fun parseInstant(raw: String): Long = runCatching { Instant.parse(raw).toEpochMilli() }.getOrDefault(0L)
}
