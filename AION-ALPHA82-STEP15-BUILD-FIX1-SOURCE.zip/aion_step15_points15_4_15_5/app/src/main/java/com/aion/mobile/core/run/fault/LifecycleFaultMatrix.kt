package com.aion.mobile.core.run.fault

import com.aion.mobile.core.sovereign.SovereignTaskState

enum class WakeTrigger {
    FOREGROUND,
    APP_BACKGROUND,
    PROCESS_RESTART,
    DEVICE_BOOT,
    PACKAGE_REPLACED,
    NETWORK_AVAILABLE,
    RETRY_TIMER,
    JOB_RESTART,
}

enum class LeaseStatus { NONE, OWNED_SELF, OWNED_OTHER_ACTIVE, EXPIRED }
enum class ToolReceiptStatus { NONE, PREPARED, STARTED, UNKNOWN, COMPLETED, FAILED }
enum class ToolEffect { NONE, READ_ONLY, IDEMPOTENT_WRITE, MUTATING }
enum class ServerRunStatus { UNKNOWN, UNAVAILABLE, MISSING, IN_PROGRESS, TOOLS_COMPLETED, COMPLETED, CONFLICT, FAILED }

enum class RecoveryAction {
    CLEANUP_TERMINAL,
    APPLY_CANCEL,
    BLOCK_MISSING_REQUEST,
    HOLD_USER,
    WAIT_NETWORK,
    WAIT_BACKOFF,
    WAIT_LEASE,
    WAIT_SERVER,
    RESTORE_FINAL,
    CONTINUE_MODEL,
    RECONCILE_SERVER,
    RESUME_RUN,
    RESUME_TOOL,
    BLOCK_AMBIGUOUS_SIDE_EFFECT,
    BLOCK_SERVER_CONFLICT,
    SCHEDULE_BACKGROUND_JOB,
}

data class FaultSnapshot(
    val taskState: SovereignTaskState,
    val requestPresent: Boolean = true,
    val networkAvailable: Boolean = true,
    val lease: LeaseStatus = LeaseStatus.NONE,
    val receipt: ToolReceiptStatus = ToolReceiptStatus.NONE,
    val toolEffect: ToolEffect = ToolEffect.NONE,
    val server: ServerRunStatus = ServerRunStatus.UNKNOWN,
    val serverRetryAfterMs: Long = 0L,
    val finalCheckpoint: Boolean = false,
    val cancelRequested: Boolean = false,
    val backoffRemainingMs: Long = 0L,
    val crossedCloudToolBoundary: Boolean = false,
    val trigger: WakeTrigger = WakeTrigger.PROCESS_RESTART,
)

data class RecoveryDecision(
    val action: RecoveryAction,
    val reason: String,
    val mayExecuteTool: Boolean = false,
    val mayExecuteModel: Boolean = false,
    val delayMs: Long = 0L,
)

/**
 * Deterministic recovery kernel used before any coroutine, network request or tool execution.
 * It intentionally fails closed around ambiguous side effects.
 */
object LifecycleFaultMatrix {
    private val terminal = setOf(
        SovereignTaskState.COMPLETED,
        SovereignTaskState.CANCELLED,
        SovereignTaskState.FAILED_FINAL,
    )

    fun decide(s: FaultSnapshot): RecoveryDecision {
        if (s.taskState in terminal) {
            return RecoveryDecision(RecoveryAction.CLEANUP_TERMINAL, "terminal:${s.taskState}")
        }

        // Cancellation wins over every recoverable state. It must be persisted before
        // cancellation of an active coroutine so a dead process cannot resurrect the run.
        if (s.cancelRequested) {
            return RecoveryDecision(RecoveryAction.APPLY_CANCEL, "durable_user_cancel")
        }

        // BOOT_COMPLETED / package replacement must never directly launch dataSync FGS.
        if (s.trigger == WakeTrigger.DEVICE_BOOT || s.trigger == WakeTrigger.PACKAGE_REPLACED) {
            return RecoveryDecision(
                RecoveryAction.SCHEDULE_BACKGROUND_JOB,
                "boot_or_package_wakeup",
                delayMs = s.backoffRemainingMs.coerceAtLeast(0L),
            )
        }

        if (!s.requestPresent) {
            return RecoveryDecision(RecoveryAction.BLOCK_MISSING_REQUEST, "missing_durable_request")
        }

        if (s.taskState == SovereignTaskState.WAITING_USER || s.taskState == SovereignTaskState.BLOCKED) {
            return RecoveryDecision(RecoveryAction.HOLD_USER, "requires_user_or_auth")
        }

        // A final response checkpoint is authoritative: never call model again.
        if (s.taskState == SovereignTaskState.VERIFYING && s.finalCheckpoint) {
            return RecoveryDecision(RecoveryAction.RESTORE_FINAL, "final_checkpoint_present")
        }

        if (s.backoffRemainingMs > 0L) {
            return RecoveryDecision(
                RecoveryAction.WAIT_BACKOFF,
                "not_before",
                delayMs = s.backoffRemainingMs,
            )
        }

        if (!s.networkAvailable) {
            return RecoveryDecision(RecoveryAction.WAIT_NETWORK, "network_unavailable")
        }

        if (s.server == ServerRunStatus.CONFLICT) {
            return RecoveryDecision(RecoveryAction.BLOCK_SERVER_CONFLICT, "idempotency_conflict")
        }
        if (s.server == ServerRunStatus.COMPLETED) {
            return RecoveryDecision(RecoveryAction.RESTORE_FINAL, "server_completed")
        }
        if (s.server == ServerRunStatus.TOOLS_COMPLETED) {
            return RecoveryDecision(
                RecoveryAction.CONTINUE_MODEL,
                "server_tools_completed",
                mayExecuteModel = true,
            )
        }
        if (s.server == ServerRunStatus.IN_PROGRESS) {
            return if (s.serverRetryAfterMs > 0L) {
                RecoveryDecision(
                    RecoveryAction.WAIT_SERVER,
                    "server_execution_in_progress",
                    delayMs = s.serverRetryAfterMs,
                )
            } else {
                RecoveryDecision(
                    RecoveryAction.RESUME_RUN,
                    "server_lease_expired_retry_same_idempotency_key",
                    mayExecuteModel = true,
                )
            }
        }

        // A live lease owned by another runner always wins after authoritative server states.
        if (s.lease == LeaseStatus.OWNED_OTHER_ACTIVE) {
            return RecoveryDecision(RecoveryAction.WAIT_LEASE, "another_runner_owns_lease")
        }

        // Tool boundary policy. Once STARTED is durable, local replay is forbidden unless
        // the tool is proven completed and its result is reusable.
        when (s.receipt) {
            ToolReceiptStatus.STARTED,
            ToolReceiptStatus.UNKNOWN -> {
                if (s.server == ServerRunStatus.MISSING && s.toolEffect == ToolEffect.MUTATING) {
                    return RecoveryDecision(
                        RecoveryAction.BLOCK_AMBIGUOUS_SIDE_EFFECT,
                        "server_missing_but_mutation_was_started",
                    )
                }
                if (s.server == ServerRunStatus.UNAVAILABLE || s.server == ServerRunStatus.UNKNOWN || s.crossedCloudToolBoundary) {
                    return RecoveryDecision(
                        RecoveryAction.RECONCILE_SERVER,
                        "ambiguous_tool_requires_server_reconciliation",
                    )
                }
                return RecoveryDecision(
                    RecoveryAction.BLOCK_AMBIGUOUS_SIDE_EFFECT,
                    "ambiguous_tool_fail_closed",
                )
            }

            ToolReceiptStatus.COMPLETED -> {
                return RecoveryDecision(
                    RecoveryAction.CONTINUE_MODEL,
                    "tool_result_already_completed",
                    mayExecuteModel = true,
                )
            }

            ToolReceiptStatus.PREPARED -> {
                return if (s.toolEffect == ToolEffect.MUTATING && s.crossedCloudToolBoundary) {
                    RecoveryDecision(RecoveryAction.RECONCILE_SERVER, "prepared_mutation_crossed_cloud_boundary")
                } else {
                    RecoveryDecision(
                        RecoveryAction.RESUME_TOOL,
                        "prepared_not_started",
                        mayExecuteTool = true,
                    )
                }
            }

            ToolReceiptStatus.FAILED -> {
                return if (s.toolEffect == ToolEffect.MUTATING) {
                    RecoveryDecision(RecoveryAction.RECONCILE_SERVER, "mutating_tool_failed_requires_proof")
                } else {
                    RecoveryDecision(
                        RecoveryAction.RESUME_TOOL,
                        "safe_tool_retry",
                        mayExecuteTool = true,
                    )
                }
            }

            ToolReceiptStatus.NONE -> Unit
        }

        if (s.crossedCloudToolBoundary && (s.server == ServerRunStatus.UNAVAILABLE || s.server == ServerRunStatus.UNKNOWN)) {
            return RecoveryDecision(RecoveryAction.RECONCILE_SERVER, "cloud_boundary_without_authoritative_status")
        }

        return when (s.taskState) {
            SovereignTaskState.WAITING_TOOL -> RecoveryDecision(
                RecoveryAction.RECONCILE_SERVER,
                "waiting_tool_without_safe_local_replay_proof",
            )
            SovereignTaskState.WAITING_NETWORK,
            SovereignTaskState.QUEUED,
            SovereignTaskState.PLANNING,
            SovereignTaskState.RUNNING,
            SovereignTaskState.PAUSED,
            SovereignTaskState.FAILED_RECOVERABLE,
            SovereignTaskState.VERIFYING -> RecoveryDecision(
                RecoveryAction.RESUME_RUN,
                "recoverable_run_state",
                mayExecuteModel = true,
            )
            SovereignTaskState.WAITING_USER,
            SovereignTaskState.BLOCKED -> RecoveryDecision(RecoveryAction.HOLD_USER, "requires_user")
            SovereignTaskState.COMPLETED,
            SovereignTaskState.FAILED_FINAL,
            SovereignTaskState.CANCELLED -> RecoveryDecision(RecoveryAction.CLEANUP_TERMINAL, "terminal")
        }
    }
}

/** Pure wake-up policy. Boot/package wakeups only schedule a persisted JobScheduler job. */
object LifecycleWakePolicy {
    fun action(trigger: WakeTrigger, hasPendingRuns: Boolean): RecoveryAction? {
        if (!hasPendingRuns) return null
        return when (trigger) {
            WakeTrigger.DEVICE_BOOT,
            WakeTrigger.PACKAGE_REPLACED,
            WakeTrigger.APP_BACKGROUND,
            WakeTrigger.JOB_RESTART -> RecoveryAction.SCHEDULE_BACKGROUND_JOB
            else -> null
        }
    }
}

/** In-memory model used by fault tests to prove at-most-one lease winner. */
class RecoveryLeaseArbiter {
    private data class Lease(val owner: String, val untilMs: Long)
    private val leases = mutableMapOf<String, Lease>()

    @Synchronized
    fun claim(runId: String, owner: String, nowMs: Long, ttlMs: Long): Boolean {
        require(ttlMs > 0)
        val current = leases[runId]
        if (current != null && current.untilMs > nowMs && current.owner != owner) return false
        leases[runId] = Lease(owner, nowMs + ttlMs)
        return true
    }

    @Synchronized
    fun renew(runId: String, owner: String, nowMs: Long, ttlMs: Long): Boolean {
        val current = leases[runId] ?: return false
        if (current.owner != owner || current.untilMs <= nowMs) return false
        leases[runId] = Lease(owner, nowMs + ttlMs)
        return true
    }

    @Synchronized
    fun release(runId: String, owner: String): Boolean {
        val current = leases[runId] ?: return false
        if (current.owner != owner) return false
        leases.remove(runId)
        return true
    }

    @Synchronized
    fun activeOwner(runId: String, nowMs: Long): String? = leases[runId]?.takeIf { it.untilMs > nowMs }?.owner
}
