package com.aion.mobile.core.run

import android.app.job.JobInfo
import android.app.job.JobParameters
import android.app.job.JobScheduler
import android.app.job.JobService
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.NetworkCapabilities
import android.net.ConnectivityManager
import com.aion.mobile.core.ai.AionServerRunState
import com.aion.mobile.core.run.fault.LeaseStatus
import com.aion.mobile.core.run.fault.LifecycleFaultMatrix
import com.aion.mobile.core.run.fault.FaultSnapshot
import com.aion.mobile.core.run.fault.ServerRunStatus
import com.aion.mobile.core.run.fault.ToolEffect
import com.aion.mobile.core.run.fault.ToolReceiptStatus
import com.aion.mobile.core.run.fault.RunCancellationFence
import com.aion.mobile.core.sovereign.SovereignTaskState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.Job
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch
import kotlinx.coroutines.cancel

internal enum class RecoveryDispatch { START_NOW, WAIT_BACKOFF, WAIT_NETWORK, WAIT_LEASE, HOLD, CLEANUP, FAIL_CLOSED }

internal data class RecoveryPlan(val action: RecoveryDispatch, val delayMs: Long = 0L, val reason: String = "")

internal object AionRecoveryEngine {
    fun localPlan(context: Context, runId: String, nowMs: Long = System.currentTimeMillis()): RecoveryPlan {
        val root = context.noBackupFilesDir
        val request = AionRunRequestStore.load(root, runId) ?: return RecoveryPlan(RecoveryDispatch.FAIL_CLOSED, reason = "missing_durable_request")
        val task = SovereignTaskStore.load(root, runId)
            ?: return RecoveryPlan(RecoveryDispatch.START_NOW, reason = "request_exists_task_missing_migration")
        if (RunCancellationFence.isCancelled(root, runId) || task.cancelRequested || task.state == SovereignTaskState.CANCELLED) {
            return RecoveryPlan(RecoveryDispatch.CLEANUP, reason = "durable_cancel")
        }
        if (task.state in setOf(SovereignTaskState.COMPLETED, SovereignTaskState.FAILED_FINAL)) {
            return RecoveryPlan(RecoveryDispatch.CLEANUP, reason = "terminal")
        }
        if (task.state in setOf(SovereignTaskState.WAITING_USER, SovereignTaskState.BLOCKED)) {
            return RecoveryPlan(RecoveryDispatch.HOLD, reason = "requires_user")
        }
        val notBefore = DurableBackoffStore.getNotBefore(root, runId)
        if (notBefore == Long.MAX_VALUE) return RecoveryPlan(RecoveryDispatch.FAIL_CLOSED, reason = "corrupt_backoff")
        if (notBefore > nowMs) return RecoveryPlan(RecoveryDispatch.WAIT_BACKOFF, delayMs = notBefore - nowMs, reason = "durable_not_before")
        val lease = DurableExecutionLeaseStore.read(root, runId)
        if (lease != null && lease.untilMs > nowMs) return RecoveryPlan(RecoveryDispatch.WAIT_LEASE, delayMs = lease.untilMs - nowMs, reason = "live_lease")
        if (task.state == SovereignTaskState.WAITING_NETWORK && !networkAvailable(context)) {
            return RecoveryPlan(RecoveryDispatch.WAIT_NETWORK, reason = "network_unavailable")
        }
        request.runId // prove decoded request is internally consistent
        return RecoveryPlan(RecoveryDispatch.START_NOW, reason = "recoverable")
    }

    fun reconcilePlan(
        localState: SovereignTaskState,
        serverState: AionServerRunState,
        serverRetryAfterMs: Long = 0L,
        hasDurableRequest: Boolean,
        crossedCloudBoundary: Boolean,
        receiptStatus: ToolReceiptStatus = ToolReceiptStatus.NONE,
        toolEffect: ToolEffect = ToolEffect.NONE,
        liveForeignLease: Boolean = false,
        backoffRemainingMs: Long = 0L,
        durableCancel: Boolean = false,
    ) = LifecycleFaultMatrix.decide(
        FaultSnapshot(
            taskState = localState,
            requestPresent = hasDurableRequest,
            cancelRequested = durableCancel,
            lease = if (liveForeignLease) LeaseStatus.OWNED_OTHER_ACTIVE else LeaseStatus.NONE,
            receipt = receiptStatus,
            toolEffect = toolEffect,
            server = when (serverState) {
                AionServerRunState.COMPLETED -> ServerRunStatus.COMPLETED
                AionServerRunState.TOOLS_COMPLETED -> ServerRunStatus.TOOLS_COMPLETED
                AionServerRunState.IN_PROGRESS -> ServerRunStatus.IN_PROGRESS
                AionServerRunState.FAILED -> ServerRunStatus.FAILED
                AionServerRunState.MISSING -> ServerRunStatus.MISSING
                AionServerRunState.UNAVAILABLE -> ServerRunStatus.UNAVAILABLE
            },
            serverRetryAfterMs = serverRetryAfterMs.coerceAtLeast(0L),
            backoffRemainingMs = backoffRemainingMs,
            crossedCloudToolBoundary = crossedCloudBoundary,
        )
    )

    private fun networkAvailable(context: Context): Boolean {
        val cm = context.getSystemService(ConnectivityManager::class.java) ?: return false
        val network = cm.activeNetwork ?: return false
        val capabilities = cm.getNetworkCapabilities(network) ?: return false
        return capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }
}

object AionRecoveryScheduler {
    private const val GENERAL_JOB_ID = 0xA10_01
    private const val NETWORK_JOB_ID = 0xA10_02
    private const val SCHEDULE_BUCKET = "recovery_schedule"

    fun scheduleGeneral(context: Context, minLatencyMs: Long = 0L) = schedule(context, GENERAL_JOB_ID, false, minLatencyMs)
    fun scheduleNetwork(context: Context, minLatencyMs: Long = 0L) = schedule(context, NETWORK_JOB_ID, true, minLatencyMs)

    @Synchronized
    private fun schedule(context: Context, jobId: Int, networkRequired: Boolean, minLatencyMs: Long) {
        val scheduler = context.getSystemService(JobScheduler::class.java) ?: return
        val safeLatencyMs = minLatencyMs.coerceAtLeast(0L)
        val now = System.currentTimeMillis()
        val desiredAt = now + safeLatencyMs
        val marker = markerFile(context, jobId)
        val existingAt = runCatching { marker.takeIf { it.isFile }?.readText()?.trim()?.toLongOrNull() ?: 0L }.getOrDefault(0L)
        val existingJob = scheduler.getPendingJob(jobId)

        // One global general job and one global network job are enough because each job
        // sweeps the full durable queue. Never let a later request replace an earlier one.
        if (existingJob != null && existingAt > 0L && existingAt <= desiredAt) return

        DurableRunFiles.atomicWrite(marker, desiredAt.toString())
        val builder = JobInfo.Builder(jobId, ComponentName(context, AionRecoveryJobService::class.java))
            .setPersisted(true)
            .setMinimumLatency(safeLatencyMs)

        if (networkRequired) {
            // A deadline may run a JobScheduler job after constraints are dropped.
            // Network recovery must never bypass its network constraint.
            builder.setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
        } else {
            builder.setOverrideDeadline((safeLatencyMs + 60_000L).coerceAtMost(24 * 60 * 60_000L))
        }

        if (scheduler.schedule(builder.build()) != JobScheduler.RESULT_SUCCESS) {
            runCatching { if (marker.readText().trim().toLongOrNull() == desiredAt) marker.delete() }
        }
    }

    @Synchronized
    fun markStarted(context: Context, jobId: Int) {
        runCatching { markerFile(context, jobId).delete() }
    }

    private fun markerFile(context: Context, jobId: Int) =
        java.io.File(DurableRunFiles.dir(context.noBackupFilesDir, SCHEDULE_BUCKET), "$jobId.txt")
}

class AionRecoveryJobService : JobService() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val activeLock = Any()
    private val activeJobs = mutableMapOf<Int, Job>()
    private val activeParams = mutableMapOf<Int, JobParameters>()

    override fun onStartJob(params: JobParameters): Boolean {
        val jobId = params.jobId
        AionRecoveryScheduler.markStarted(this, jobId)
        val job = scope.launch(start = CoroutineStart.LAZY) {
            try {
                AionRecoveryCoordinator.recoverOne(this@AionRecoveryJobService)
            } finally {
                val shouldFinish = synchronized(activeLock) {
                    if (activeParams[jobId] === params) {
                        activeParams.remove(jobId)
                        activeJobs.remove(jobId)
                        true
                    } else false
                }
                if (shouldFinish) jobFinished(params, false)
            }
        }
        synchronized(activeLock) {
            activeJobs.remove(jobId)?.cancel(CancellationException("job_replaced"))
            activeParams[jobId] = params
            activeJobs[jobId] = job
        }
        job.start()
        return true
    }

    override fun onStopJob(params: JobParameters): Boolean {
        val jobId = params.jobId
        val job = synchronized(activeLock) {
            if (activeParams[jobId] === params) {
                activeParams.remove(jobId)
                activeJobs.remove(jobId)
            } else null
        }
        job?.cancel(CancellationException("job_stopped_by_system"))
        return true
    }

    override fun onDestroy() {
        synchronized(activeLock) {
            activeJobs.values.forEach { it.cancel(CancellationException("job_service_destroyed")) }
            activeJobs.clear()
            activeParams.clear()
        }
        scope.cancel()
        super.onDestroy()
    }
}

internal object AionRecoveryCoordinator {
    private const val MAX_RUNS_PER_JOB = 3

    suspend fun recoverOne(context: Context) {
        val root = context.noBackupFilesDir
        var executed = 0
        var deferredRunnable = false
        var earliestGeneralDelayMs: Long? = null
        var needsNetworkJob = false

        // Scan the whole pending set instead of letting the first leased/backed-off run
        // starve every run behind it. Execute a bounded batch, then schedule the rest.
        for (runId in SovereignTaskStore.pendingRunIds(root)) {
            val plan = AionRecoveryEngine.localPlan(context, runId)
            when (plan.action) {
                RecoveryDispatch.START_NOW -> {
                    if (executed >= MAX_RUNS_PER_JOB) {
                        deferredRunnable = true
                        continue
                    }
                    // Execute under JobScheduler itself. Do not start a foreground service
                    // from background recovery on Android 12+, where that launch can be rejected.
                    AionJobRecoveryRunner.run(context, runId)
                    executed += 1
                }
                RecoveryDispatch.WAIT_BACKOFF, RecoveryDispatch.WAIT_LEASE -> {
                    val delay = plan.delayMs.coerceAtLeast(1_000L)
                    earliestGeneralDelayMs = minOf(earliestGeneralDelayMs ?: Long.MAX_VALUE, delay)
                }
                RecoveryDispatch.WAIT_NETWORK -> needsNetworkJob = true
                RecoveryDispatch.CLEANUP -> DurableExecutionLeaseStore.clearTerminal(root, runId)
                RecoveryDispatch.HOLD, RecoveryDispatch.FAIL_CLOSED -> Unit
            }
        }

        earliestGeneralDelayMs?.let { AionRecoveryScheduler.scheduleGeneral(context, it) }
        if (needsNetworkJob) AionRecoveryScheduler.scheduleNetwork(context)

        // A runner may have changed task states while this batch was executing. If more
        // immediately recoverable work remains, give it another bounded turn.
        if (deferredRunnable) AionRecoveryScheduler.scheduleGeneral(context, 1_000L)
    }
}

class AionRecoveryReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action == Intent.ACTION_BOOT_COMPLETED || intent?.action == Intent.ACTION_MY_PACKAGE_REPLACED) {
            if (SovereignTaskStore.pendingRunIds(context.noBackupFilesDir).isNotEmpty()) {
                AionRecoveryScheduler.scheduleGeneral(context)
            }
        }
    }
}
