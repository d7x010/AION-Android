package com.aion.mobile.core.local

import android.content.ComponentCallbacks2
import android.content.Context
import android.content.res.Configuration

/** Bridges Android trim callbacks into deterministic LRU eviction. */
class AndroidMemoryPressureMonitor(
    context: Context,
    private val manager: LocalModelManager,
) : ComponentCallbacks2 {
    private val appContext = context.applicationContext
    private var registered = false

    @Synchronized
    fun register() {
        if (registered) return
        appContext.registerComponentCallbacks(this)
        registered = true
    }

    @Synchronized
    fun unregister() {
        if (!registered) return
        appContext.unregisterComponentCallbacks(this)
        registered = false
    }

    override fun onTrimMemory(level: Int) {
        manager.evictForMemoryPressure(
            when {
                level >= ComponentCallbacks2.TRIM_MEMORY_COMPLETE -> MemoryPressure.CRITICAL
                level == ComponentCallbacks2.TRIM_MEMORY_RUNNING_CRITICAL -> MemoryPressure.CRITICAL
                level >= ComponentCallbacks2.TRIM_MEMORY_BACKGROUND -> MemoryPressure.HIGH
                level == ComponentCallbacks2.TRIM_MEMORY_RUNNING_LOW -> MemoryPressure.HIGH
                level >= ComponentCallbacks2.TRIM_MEMORY_UI_HIDDEN -> MemoryPressure.MODERATE
                else -> MemoryPressure.NORMAL
            }
        )
    }

    override fun onLowMemory() {
        manager.evictForMemoryPressure(MemoryPressure.CRITICAL)
    }

    override fun onConfigurationChanged(newConfig: Configuration) = Unit
}
