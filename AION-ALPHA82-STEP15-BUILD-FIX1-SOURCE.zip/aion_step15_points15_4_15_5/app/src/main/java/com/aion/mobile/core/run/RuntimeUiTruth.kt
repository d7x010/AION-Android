package com.aion.mobile.core.run

import com.aion.mobile.core.ai.GatewayActivity
import com.aion.mobile.core.sovereign.SovereignTask
import com.aion.mobile.core.sovereign.SovereignTaskState
import com.aion.mobile.core.run.fault.ToolEffect
import com.aion.mobile.core.run.fault.ToolReceiptStatus
import com.aion.mobile.core.state.AionActivityKind
import com.aion.mobile.core.state.AionActivityState

enum class RuntimeUiPhase {
    QUEUED,
    THINKING,
    SEARCHING_WEB,
    READING_FILE,
    COMPARING,
    WRITING,
    VERIFYING,
    WAITING_NETWORK,
    WAITING_TOOL,
    WAITING_USER,
    PAUSED,
    BLOCKED,
    COMPLETED,
    FAILED,
    CANCELLED,
}

data class RuntimeUiTruth(
    val taskState: SovereignTaskState,
    val phase: RuntimeUiPhase,
    val label: String,
    val detail: String? = null,
    val actionRequired: Boolean = false,
    val terminal: Boolean = false,
    val canStop: Boolean = !terminal,
    val liveExecution: Boolean = false,
    val gatewayActivity: GatewayActivity? = null,
    val toolCallId: String? = null,
) {
    fun asActivityState(): AionActivityState = AionActivityState(
        kind = when (phase) {
            RuntimeUiPhase.SEARCHING_WEB -> AionActivityKind.SEARCHING_WEB
            RuntimeUiPhase.READING_FILE -> AionActivityKind.READING_FILES
            RuntimeUiPhase.COMPARING -> AionActivityKind.COMPARING
            RuntimeUiPhase.WRITING -> AionActivityKind.WRITING
            RuntimeUiPhase.WAITING_NETWORK -> AionActivityKind.RECONNECTING
            RuntimeUiPhase.FAILED -> AionActivityKind.ERROR
            else -> AionActivityKind.THINKING
        },
        detail = label,
    )
}

object RuntimeLivenessPolicy {
    /**
     * A durable RUNNING/VERIFYING checkpoint is not proof that a coroutine is alive.
     * Only an execution lease owned by this process may keep the live indicator enabled.
     */
    fun apply(truth: RuntimeUiTruth, observedExecutionLease: Boolean): RuntimeUiTruth {
        if (truth.terminal || !truth.liveExecution || observedExecutionLease) return truth
        val suspendedLabel = when (truth.phase) {
            RuntimeUiPhase.SEARCHING_WEB -> "بانتظار استئناف البحث"
            RuntimeUiPhase.READING_FILE -> "بانتظار استئناف قراءة الملف"
            RuntimeUiPhase.VERIFYING -> "بانتظار استئناف التحقق"
            else -> "بانتظار استئناف التنفيذ"
        }
        return truth.copy(
            label = suspendedLabel,
            detail = truth.label,
            liveExecution = false,
        )
    }
}

/**
 * Projects durable runtime truth into user-visible state. It exposes observable work only;
 * it never exposes hidden model reasoning or invents tool activity that is absent from runtime metadata.
 */
object RuntimeUiTruthMapper {
    fun from(
        task: SovereignTask,
        fallbackActivity: GatewayActivity? = null,
        toolCallId: String? = null,
        toolStatus: ToolReceiptStatus? = null,
        toolEffect: ToolEffect? = null,
    ): RuntimeUiTruth {
        val payload = task.checkpoint?.payload.orEmpty()
        val activity = payload["activity"]?.let { raw ->
            runCatching { GatewayActivity.valueOf(raw) }.getOrNull()
        } ?: fallbackActivity
        val meaningfulToolId = toolCallId?.takeIf { it.isNotBlank() && it != "server-tool-plan" }
        val reason = task.blockedReason?.trim()?.takeIf { it.isNotBlank() }
            ?: task.lastFailure?.message?.trim()?.takeIf { it.isNotBlank() }

        return when (task.state) {
            SovereignTaskState.QUEUED -> truth(task, RuntimeUiPhase.QUEUED, "قيد الاستعداد", live = false)
            SovereignTaskState.PLANNING -> truth(task, RuntimeUiPhase.THINKING, "جار التفكير", activity = activity, live = true)
            SovereignTaskState.RUNNING -> runningTruth(task, activity)
            SovereignTaskState.WAITING_TOOL -> {
                val toolPhase = classifyTool(meaningfulToolId, activity)
                when (toolPhase) {
                    RuntimeUiPhase.SEARCHING_WEB -> truth(task, toolPhase, "جار البحث", activity = GatewayActivity.SEARCHING_WEB, tool = meaningfulToolId, live = true)
                    RuntimeUiPhase.READING_FILE -> truth(task, toolPhase, "جار قراءة الملف", activity = GatewayActivity.READING_FILES, tool = meaningfulToolId, live = true)
                    else -> {
                        val waitingLabel = when (toolStatus) {
                            ToolReceiptStatus.UNKNOWN -> "جار التحقق من نتيجة الأداة"
                            ToolReceiptStatus.PREPARED, ToolReceiptStatus.STARTED ->
                                if (toolEffect == ToolEffect.MUTATING) "بانتظار إكمال الإجراء" else "بانتظار نتيجة الأداة"
                            ToolReceiptStatus.COMPLETED -> "جار استلام نتيجة الأداة"
                            ToolReceiptStatus.FAILED -> "تعذر تنفيذ الأداة"
                            else -> "بانتظار الأداة"
                        }
                        truth(
                            task,
                            RuntimeUiPhase.WAITING_TOOL,
                            waitingLabel,
                            detail = meaningfulToolId,
                            action = toolStatus == ToolReceiptStatus.FAILED,
                            activity = activity,
                            tool = meaningfulToolId,
                            live = false,
                        )
                    }
                }
            }
            SovereignTaskState.WAITING_NETWORK -> truth(
                task, RuntimeUiPhase.WAITING_NETWORK, "بانتظار الشبكة", detail = reason, activity = activity, live = false,
            )
            SovereignTaskState.WAITING_USER -> truth(
                task, RuntimeUiPhase.WAITING_USER, reason ?: "بانتظار إجراء منك", detail = reason, action = true, activity = activity, live = false,
            )
            SovereignTaskState.VERIFYING -> truth(task, RuntimeUiPhase.VERIFYING, "جار التحقق", activity = activity, live = true)
            SovereignTaskState.PAUSED -> truth(
                task, RuntimeUiPhase.PAUSED, "متوقف مؤقتًا", detail = reason, activity = activity, live = false,
            )
            SovereignTaskState.BLOCKED -> truth(
                task, RuntimeUiPhase.BLOCKED, reason ?: "المهمة محجوبة", detail = reason, action = true, activity = activity, live = false,
            )
            SovereignTaskState.COMPLETED -> truth(task, RuntimeUiPhase.COMPLETED, "اكتمل", terminal = true, activity = activity)
            SovereignTaskState.FAILED_RECOVERABLE -> truth(
                task, RuntimeUiPhase.PAUSED, "تعذر التنفيذ مؤقتًا", detail = reason, activity = activity, live = false,
            )
            SovereignTaskState.FAILED_FINAL -> truth(
                task, RuntimeUiPhase.FAILED, "تعذر إكمال العملية", detail = reason, terminal = true, activity = activity,
            )
            SovereignTaskState.CANCELLED -> truth(task, RuntimeUiPhase.CANCELLED, "تم الإيقاف", terminal = true, activity = activity)
        }
    }

    private fun runningTruth(task: SovereignTask, activity: GatewayActivity?): RuntimeUiTruth = when (activity) {
        GatewayActivity.SEARCHING_WEB -> truth(task, RuntimeUiPhase.SEARCHING_WEB, "جار البحث", activity = activity, live = true)
        GatewayActivity.READING_FILES -> truth(task, RuntimeUiPhase.READING_FILE, "جار قراءة الملف", activity = activity, live = true)
        GatewayActivity.COMPARING -> truth(task, RuntimeUiPhase.COMPARING, "جار مقارنة النتائج", activity = activity, live = true)
        GatewayActivity.WRITING -> truth(task, RuntimeUiPhase.WRITING, "جار كتابة الإجابة", activity = activity, live = true)
        GatewayActivity.THINKING, null -> truth(task, RuntimeUiPhase.THINKING, "جار التفكير", activity = activity, live = true)
    }

    private fun classifyTool(toolCallId: String?, activity: GatewayActivity?): RuntimeUiPhase {
        when (activity) {
            GatewayActivity.SEARCHING_WEB -> return RuntimeUiPhase.SEARCHING_WEB
            GatewayActivity.READING_FILES -> return RuntimeUiPhase.READING_FILE
            else -> Unit
        }
        val id = toolCallId.orEmpty().lowercase()
        return when {
            id.contains("search") || id.contains("web") -> RuntimeUiPhase.SEARCHING_WEB
            id.contains("file") || id.contains("document") -> RuntimeUiPhase.READING_FILE
            else -> RuntimeUiPhase.WAITING_TOOL
        }
    }

    private fun truth(
        task: SovereignTask,
        phase: RuntimeUiPhase,
        label: String,
        detail: String? = null,
        action: Boolean = false,
        terminal: Boolean = false,
        activity: GatewayActivity? = null,
        tool: String? = null,
        live: Boolean = false,
    ) = RuntimeUiTruth(
        taskState = task.state,
        phase = phase,
        label = label,
        detail = detail,
        actionRequired = action,
        terminal = terminal,
        canStop = !terminal,
        liveExecution = live,
        gatewayActivity = activity,
        toolCallId = tool,
    )
}
