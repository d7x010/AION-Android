package com.aion.mobile.core.run

import com.aion.mobile.core.run.fault.ToolEffect
import com.aion.mobile.core.run.fault.ToolReceiptStatus
import java.io.File
import java.io.FileOutputStream
import java.io.RandomAccessFile
import java.security.MessageDigest
import java.util.concurrent.ConcurrentHashMap

internal object DurableRunFiles {
    private const val ROOT = "aion_runs"
    private val monitors = ConcurrentHashMap<String, Any>()

    fun root(noBackupRoot: File): File = File(noBackupRoot, ROOT).apply { mkdirs() }
    fun dir(noBackupRoot: File, name: String): File = File(root(noBackupRoot), name).apply { mkdirs() }

    fun requireRunId(runId: String) {
        require(runId.length in 8..128 && runId.all { it.isLetterOrDigit() || it == '-' || it == '_' }) {
            "invalid_run_id"
        }
    }

    fun atomicWrite(target: File, text: String) {
        target.parentFile?.mkdirs()
        val tmp = File(target.parentFile, "${target.name}.tmp-${System.nanoTime()}")
        FileOutputStream(tmp).use { out ->
            out.write(text.toByteArray(Charsets.UTF_8))
            out.fd.sync()
        }
        if (!tmp.renameTo(target)) {
            FileOutputStream(target).use { out ->
                out.write(tmp.readBytes())
                out.fd.sync()
            }
            tmp.delete()
        }
    }

    fun sha256(value: String): String = MessageDigest.getInstance("SHA-256")
        .digest(value.toByteArray(Charsets.UTF_8))
        .joinToString("") { "%02x".format(it) }

    fun <T> locked(noBackupRoot: File, runId: String, bucket: String, block: () -> T): T {
        requireRunId(runId)
        val monitor = monitors.computeIfAbsent("$bucket:$runId") { Any() }
        return synchronized(monitor) {
            val lockFile = File(dir(noBackupRoot, "locks"), "$bucket-$runId.lck")
            RandomAccessFile(lockFile, "rw").use { raf ->
                val lock = raf.channel.lock()
                try { block() } finally { lock.release() }
            }
        }
    }
}

data class DurableExecutionLease(val owner: String, val untilMs: Long)

enum class LeaseClaimResult { ACQUIRED, RENEWED, HELD_BY_OTHER }

object DurableExecutionLeaseStore {
    private const val BUCKET = "leases"

    private fun file(root: File, runId: String) = File(DurableRunFiles.dir(root, BUCKET), "$runId.lease")

    fun acquire(root: File, runId: String, owner: String, nowMs: Long, ttlMs: Long): LeaseClaimResult {
        require(owner.isNotBlank() && owner.length <= 160) { "invalid_lease_owner" }
        require(ttlMs in 1_000L..30 * 60_000L) { "invalid_lease_ttl" }
        return DurableRunFiles.locked(root, runId, BUCKET) {
            val current = readUnsafe(root, runId)
            if (current != null && current.untilMs > nowMs && current.owner != owner) {
                LeaseClaimResult.HELD_BY_OTHER
            } else {
                val result = if (current?.owner == owner) LeaseClaimResult.RENEWED else LeaseClaimResult.ACQUIRED
                DurableRunFiles.atomicWrite(file(root, runId), "v1\n$owner\n${nowMs + ttlMs}\n")
                result
            }
        }
    }

    fun renew(root: File, runId: String, owner: String, nowMs: Long, ttlMs: Long): Boolean =
        DurableRunFiles.locked(root, runId, BUCKET) {
            val current = readUnsafe(root, runId) ?: return@locked false
            if (current.owner != owner || current.untilMs <= nowMs) return@locked false
            DurableRunFiles.atomicWrite(file(root, runId), "v1\n$owner\n${nowMs + ttlMs}\n")
            true
        }

    fun release(root: File, runId: String, owner: String): Boolean = DurableRunFiles.locked(root, runId, BUCKET) {
        val current = readUnsafe(root, runId) ?: return@locked true
        if (current.owner != owner) return@locked false
        file(root, runId).delete()
    }

    /** Terminal/cancel cleanup. Only call after durable terminal state or cancellation is authoritative. */
    fun clearTerminal(root: File, runId: String): Boolean = DurableRunFiles.locked(root, runId, BUCKET) {
        file(root, runId).delete() || !file(root, runId).exists()
    }

    fun read(root: File, runId: String): DurableExecutionLease? {
        DurableRunFiles.requireRunId(runId)
        return readUnsafe(root, runId)
    }

    private fun readUnsafe(root: File, runId: String): DurableExecutionLease? = runCatching {
        val lines = file(root, runId).takeIf { it.isFile }?.readLines(Charsets.UTF_8) ?: return null
        if (lines.size < 3 || lines[0] != "v1") return null
        DurableExecutionLease(lines[1], lines[2].toLong())
    }.getOrNull()
}

object DurableBackoffStore {
    private const val BUCKET = "backoff"
    private fun file(root: File, runId: String) = File(DurableRunFiles.dir(root, BUCKET), "$runId.backoff")

    fun setNotBefore(root: File, runId: String, notBeforeMs: Long) {
        DurableRunFiles.requireRunId(runId)
        require(notBeforeMs >= 0L)
        DurableRunFiles.atomicWrite(file(root, runId), "v1\n$runId\n$notBeforeMs\n")
    }

    fun getNotBefore(root: File, runId: String): Long = runCatching {
        DurableRunFiles.requireRunId(runId)
        val lines = file(root, runId).takeIf { it.isFile }?.readLines(Charsets.UTF_8) ?: return 0L
        if (lines.size < 3 || lines[0] != "v1" || lines[1] != runId) return 0L
        lines[2].toLong().coerceAtLeast(0L)
    }.getOrElse { Long.MAX_VALUE } // corrupt retry metadata fails closed

    fun clear(root: File, runId: String) {
        DurableRunFiles.requireRunId(runId)
        file(root, runId).delete()
    }
}

data class DurableToolReceipt(
    val runId: String,
    val toolCallId: String,
    val status: ToolReceiptStatus,
    val effect: ToolEffect,
    val inputDigest: String,
    val resultDigest: String = "",
    val updatedAtMs: Long = System.currentTimeMillis(),
)

object DurableToolReceiptStore {
    private const val BUCKET = "tool_receipts"
    private const val SERVER_TOOL_PLAN_ID = "server-tool-plan"

    private fun safeToolCallId(value: String): String {
        require(value.length in 1..128 && value.all { it.isLetterOrDigit() || it in "-_.:" }) { "invalid_tool_call_id" }
        return value
    }

    private fun file(root: File, runId: String, toolCallId: String): File =
        File(File(DurableRunFiles.dir(root, BUCKET), runId).apply { mkdirs() }, "${safeToolCallId(toolCallId)}.receipt")

    fun prepare(root: File, runId: String, toolCallId: String, effect: ToolEffect, canonicalInput: String): DurableToolReceipt {
        val receipt = DurableToolReceipt(
            runId = runId,
            toolCallId = safeToolCallId(toolCallId),
            status = ToolReceiptStatus.PREPARED,
            effect = effect,
            inputDigest = DurableRunFiles.sha256(canonicalInput),
        )
        write(root, receipt)
        return receipt
    }

    fun mark(root: File, receipt: DurableToolReceipt, status: ToolReceiptStatus, result: String = ""): DurableToolReceipt {
        require(status != ToolReceiptStatus.NONE) { "receipt_none_not_persistable" }
        val next = receipt.copy(
            status = status,
            resultDigest = if (result.isBlank()) receipt.resultDigest else DurableRunFiles.sha256(result),
            updatedAtMs = System.currentTimeMillis(),
        )
        write(root, next)
        return next
    }

    fun read(root: File, runId: String, toolCallId: String): DurableToolReceipt? = runCatching {
        DurableRunFiles.requireRunId(runId)
        val lines = file(root, runId, toolCallId).takeIf { it.isFile }?.readLines(Charsets.UTF_8) ?: return null
        if (lines.size < 8 || lines[0] != "v1" || lines[1] != runId || lines[2] != toolCallId) return null
        DurableToolReceipt(
            runId = runId,
            toolCallId = toolCallId,
            status = ToolReceiptStatus.valueOf(lines[3]),
            effect = ToolEffect.valueOf(lines[4]),
            inputDigest = lines[5],
            resultDigest = lines[6],
            updatedAtMs = lines[7].toLong(),
        )
    }.getOrNull()

    fun latest(root: File, runId: String): DurableToolReceipt? {
        DurableRunFiles.requireRunId(runId)
        val dir = File(DurableRunFiles.dir(root, BUCKET), runId)
        return dir.listFiles()?.asSequence()
            ?.filter { it.isFile && it.name.endsWith(".receipt") }
            ?.mapNotNull { candidate ->
                val toolCallId = candidate.name.removeSuffix(".receipt")
                read(root, runId, toolCallId)
            }
            ?.maxByOrNull { it.updatedAtMs }
    }

    /** Mirrors the authoritative server-side tool ledger into Android durable storage. */
    fun mirrorServer(
        root: File,
        runId: String,
        status: String,
        effect: String,
        planDigest: String,
        resultDigest: String,
        updatedAtMs: Long,
    ): DurableToolReceipt? {
        DurableRunFiles.requireRunId(runId)
        val parsedStatus = runCatching { ToolReceiptStatus.valueOf(status.trim().uppercase()) }.getOrNull()
            ?: return null
        if (parsedStatus == ToolReceiptStatus.NONE) return null
        val parsedEffect = runCatching { ToolEffect.valueOf(effect.trim().uppercase()) }.getOrDefault(ToolEffect.NONE)
        val cleanPlanDigest = planDigest.trim().lowercase().takeIf { it.matches(Regex("^[a-f0-9]{64}$")) }
            ?: DurableRunFiles.sha256("server-tool-plan:$runId")
        val cleanResultDigest = resultDigest.trim().lowercase().takeIf { it.matches(Regex("^[a-f0-9]{64}$")) }.orEmpty()
        val effectiveUpdatedAt = updatedAtMs.takeIf { it > 0L } ?: System.currentTimeMillis()
        val existing = read(root, runId, SERVER_TOOL_PLAN_ID)
        if (existing != null && existing.updatedAtMs > effectiveUpdatedAt) return existing
        val receipt = DurableToolReceipt(
            runId = runId,
            toolCallId = SERVER_TOOL_PLAN_ID,
            status = parsedStatus,
            effect = parsedEffect,
            inputDigest = cleanPlanDigest,
            resultDigest = cleanResultDigest,
            updatedAtMs = effectiveUpdatedAt,
        )
        write(root, receipt)
        return receipt
    }

    private fun write(root: File, receipt: DurableToolReceipt) {
        DurableRunFiles.requireRunId(receipt.runId)
        safeToolCallId(receipt.toolCallId)
        val text = buildString {
            append("v1\n")
            append(receipt.runId).append('\n')
            append(receipt.toolCallId).append('\n')
            append(receipt.status.name).append('\n')
            append(receipt.effect.name).append('\n')
            append(receipt.inputDigest).append('\n')
            append(receipt.resultDigest).append('\n')
            append(receipt.updatedAtMs).append('\n')
        }
        DurableRunFiles.atomicWrite(file(root, receipt.runId, receipt.toolCallId), text)
    }
}
