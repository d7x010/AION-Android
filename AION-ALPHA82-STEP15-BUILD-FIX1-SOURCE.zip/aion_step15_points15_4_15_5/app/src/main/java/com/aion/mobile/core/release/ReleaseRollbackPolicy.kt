package com.aion.mobile.core.release

/**
 * Release rollback policy shared by startup crash protection and release tooling tests.
 *
 * AION never attempts to silently downgrade the installed APK or user-data schemas.
 * Runtime protection enters safe mode after a crash loop; binary rollback is performed by
 * rebuilding the previous Last Known Good source with a new, monotonically higher versionCode.
 */
data class RollbackSchemaRange(
    val id: String,
    val currentVersion: Int,
    val minimumReadableVersion: Int,
) {
    init {
        require(id.isNotBlank())
        require(currentVersion >= 1)
        require(minimumReadableVersion in 1..currentVersion)
    }

    fun canRead(version: Int): Boolean = version in minimumReadableVersion..currentVersion
}

data class StartupRollbackDecision(
    val enterSafeMode: Boolean,
    val requestExternalRollback: Boolean,
    val reason: String,
)

object AionReleaseRollbackPolicy {
    const val STARTUP_FAILURE_THRESHOLD = 2

    fun evaluateStartup(consecutiveStartupFailures: Int): StartupRollbackDecision {
        require(consecutiveStartupFailures >= 0)
        return if (consecutiveStartupFailures >= STARTUP_FAILURE_THRESHOLD) {
            StartupRollbackDecision(
                enterSafeMode = true,
                requestExternalRollback = true,
                reason = "startup_crash_loop",
            )
        } else {
            StartupRollbackDecision(
                enterSafeMode = false,
                requestExternalRollback = false,
                reason = "healthy_or_below_threshold",
            )
        }
    }

    /**
     * Rollback is allowed only when the LKG build can read every schema version the current
     * candidate may already have persisted. Data is preserved in place; it is never downgraded.
     */
    fun storageCompatible(
        currentPersistedVersions: Map<String, Int>,
        rollbackTargetSchemas: Collection<RollbackSchemaRange>,
    ): Boolean {
        val target = rollbackTargetSchemas.associateBy { it.id }
        return currentPersistedVersions.all { (id, version) -> target[id]?.canRead(version) == true }
    }

    /** Google Play/update-safe rollback means rebuilding LKG source with a newer code. */
    fun nextRollbackVersionCode(installedVersionCode: Int, lkgVersionCode: Int): Int {
        require(installedVersionCode >= 1)
        require(lkgVersionCode >= 1)
        val base = maxOf(installedVersionCode, lkgVersionCode)
        check(base < Int.MAX_VALUE) { "version_code_exhausted" }
        return base + 1
    }
}
