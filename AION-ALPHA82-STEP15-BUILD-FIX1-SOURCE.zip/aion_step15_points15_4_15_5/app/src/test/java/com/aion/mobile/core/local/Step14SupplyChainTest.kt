package com.aion.mobile.core.local

import com.aion.mobile.core.storage.AionStorageSchemaRegistry
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File
import java.nio.file.Files

class Step14SupplyChainTest {
    @Test
    fun modelPackWithoutProvenanceFailsClosed() {
        val file = tempPack("no-prov")
        val descriptor = rawDescriptor(file, null, "sig")
        val result = ModelPackVerifier(AcceptingVerifier).verify(file, descriptor)
        assertTrue(result is ModelPackVerificationResult.Failed)
        result as ModelPackVerificationResult.Failed
        assertEquals(ModelPackVerificationResult.Code.SUPPLY_CHAIN_INVALID, result.code)
        assertTrue(result.detail.startsWith("PROVENANCE_REQUIRED:"))
    }

    @Test
    fun insecureRemoteSourceFailsClosed() {
        val file = tempPack("http-prov")
        val descriptor = seal(rawDescriptor(file, provenance("http://example.invalid/model.pack"), "sig"))
        val result = ModelPackVerifier(AcceptingVerifier).verify(file, descriptor) as ModelPackVerificationResult.Failed
        assertEquals(ModelPackVerificationResult.Code.SUPPLY_CHAIN_INVALID, result.code)
        assertTrue(result.detail.startsWith("INSECURE_REMOTE_SOURCE:"))
    }

    @Test
    fun unsignedPackFailsEvenWhenLegacyFlagIsFalse() {
        val file = tempPack("unsigned")
        val descriptor = seal(rawDescriptor(file, provenance(), null).copy(requireSignature = false))
        val result = ModelPackVerifier(AcceptingVerifier).verify(file, descriptor) as ModelPackVerificationResult.Failed
        assertTrue(result.detail.startsWith("SIGNATURE_REQUIRED:"))
    }

    @Test
    fun verifiedPackBindsCanonicalManifestAndSigner() {
        val file = tempPack("verified")
        val descriptor = seal(rawDescriptor(file, provenance(), "sig"))
        val verifier = CapturingVerifier()
        assertTrue(ModelPackVerifier(verifier).verify(file, descriptor) is ModelPackVerificationResult.Verified)
        assertTrue(verifier.seen)
        val payload = ModelPackVerifier(verifier).signaturePayload(descriptor).decodeToString()
        assertTrue(payload.contains(descriptor.provenance!!.manifestSha256))
        assertTrue(payload.contains(descriptor.sha256))
        assertTrue(payload.contains("prod-model-key-v1"))
    }

    @Test
    fun localModelRegistryVersionTwoPersistsProvenance() {
        assertEquals(2, AionStorageSchemaRegistry.localModels.currentVersion)
        assertTrue(AionStorageSchemaRegistry.localModels.canRead(1))
        val dir = Files.createTempDirectory("aion-s14-prov-reg").toFile()
        val file = tempPack("registry")
        val descriptor = seal(rawDescriptor(file, provenance(), "sig"))
        val registry = LocalModelRegistryStore(File(dir, "registry.bin"))
        registry.replace(listOf(LocalModelRecord(descriptor, LocalModelState.NOT_INSTALLED)))
        val restored = registry.readAll()[descriptor.modelId]!!.descriptor
        assertEquals(descriptor.provenance, restored.provenance)
        assertEquals(descriptor.signature, restored.signature)
    }

    private fun rawDescriptor(file: File, provenance: ModelPackProvenance?, signature: String?) = LocalModelPackDescriptor(
        modelId = "nano",
        version = "1.0.0",
        expectedSizeBytes = file.length(),
        sha256 = ModelPackVerifier(AcceptingVerifier).sha256(file),
        signature = signature,
        provenance = provenance,
        requirements = LocalModelRequirements("nano", 0L, 0L),
    )

    private fun provenance(source: String = "https://models.aion.example/nano.pack") = ModelPackProvenance(
        sourceType = ModelPackSourceType.REMOTE_REPOSITORY,
        sourceUri = source,
        publisher = "AION Model Registry",
        acquiredAtEpochMs = 1_780_000_000_000L,
        issuedAtEpochMs = 1_779_999_000_000L,
        manifestSha256 = "0".repeat(64),
        signatureAlgorithm = "Ed25519",
        signerKeyId = "prod-model-key-v1",
    )

    private fun seal(descriptor: LocalModelPackDescriptor) = ModelPackSupplyChainPolicy.seal(descriptor)

    private fun tempPack(name: String): File = Files.createTempFile("aion-s14-$name", ".pack").toFile().apply {
        writeBytes("verified-model-pack-$name".toByteArray())
    }

    private object AcceptingVerifier : ModelPackSignatureVerifier {
        override fun verify(file: File, descriptor: LocalModelPackDescriptor, signature: String): Boolean = true
    }

    private class CapturingVerifier : ModelPackSignatureVerifier {
        var seen = false
        override fun verify(file: File, descriptor: LocalModelPackDescriptor, signature: String): Boolean {
            seen = descriptor.provenance?.signerKeyId == "prod-model-key-v1" && signature == "sig"
            return seen
        }
    }
}
