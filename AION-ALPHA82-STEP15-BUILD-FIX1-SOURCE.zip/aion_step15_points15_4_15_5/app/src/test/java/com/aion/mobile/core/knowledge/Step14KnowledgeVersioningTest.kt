package com.aion.mobile.core.knowledge

import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class Step14KnowledgeVersioningTest {
    @Test
    fun knowledgeCodecRejectsFutureAndMalformedSchemas() {
        assertNotNull(KnowledgeStoreCodec.decodeStrict("AION_KNOWLEDGE_V1\n"))
        assertTrue(KnowledgeStoreCodec.isReadable("AION_KNOWLEDGE_V1\n"))
        assertNull(KnowledgeStoreCodec.decodeStrict("AION_KNOWLEDGE_V2\n"))
        assertFalse(KnowledgeStoreCodec.isReadable("AION_KNOWLEDGE_V2\n"))
        assertNull(KnowledgeStoreCodec.decodeStrict("garbage"))
    }
}
