package com.aion.mobile.core.knowledge

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class KnowledgeEnginePolicyTest {
    private val day = 86_400_000L
    private val now = 1_800_000_000_000L

    @Test fun codecRoundTripPreservesProvenanceAndHashes() {
        val original = row(
            id = "doc-1",
            title = "دليل ثابت",
            text = "AION يخزن المعرفة محليًا.",
            type = KnowledgeSourceType.DOCUMENT,
            url = "https://example.test/doc",
            observedAt = now - day
        )
        val decoded = KnowledgeStoreCodec.decode(KnowledgeStoreCodec.encode(listOf(original))).single()
        assertEquals(original.id, decoded.id)
        assertEquals(original.provenance.sourceUrl, decoded.provenance.sourceUrl)
        assertEquals(original.provenance.sourceTitle, decoded.provenance.sourceTitle)
        assertEquals(original.provenance.sourceType, decoded.provenance.sourceType)
        assertTrue(decoded.provenance.contentHash.isNotBlank())
        assertEquals(now - day, decoded.provenance.observedAt)
    }

    @Test fun hybridRetrievalUsesLexicalAndHashedVectorSignal() {
        val relevant = row("r", "Android recovery", "استعادة المهام الدائمة بعد موت العملية", KnowledgeSourceType.DOCUMENT)
        val unrelated = row("u", "طبخ", "طريقة إعداد الأرز والخضروات", KnowledgeSourceType.DOCUMENT)
        val result = KnowledgeEnginePolicy.hybridRetrieve(listOf(unrelated, relevant), "استعادة المهام بعد موت التطبيق", now)
        assertEquals("r", result.hits.first().entry.id)
        assertTrue(result.hits.first().lexicalScore > 0.0)
        assertTrue(result.hits.first().vectorScore > 0.0)
    }

    @Test fun newsDecaysMuchFasterThanStableDocument() {
        val age = 30 * day
        val news = row("news", "خبر", "نفس المعلومة", KnowledgeSourceType.NEWS, observedAt = now - age)
        val doc = row("doc", "مستند", "نفس المعلومة", KnowledgeSourceType.DOCUMENT, observedAt = now - age)
        val newsFresh = KnowledgeEnginePolicy.freshnessScore(news, now)
        val docFresh = KnowledgeEnginePolicy.freshnessScore(doc, now)
        assertTrue(docFresh > newsFresh * 100.0)
    }

    @Test fun contradictionsRemainVisibleAsSeparateVariants() {
        val a = row("a", "Source A", "الحد 10", KnowledgeSourceType.DOCUMENT, claimKey = "limit.max", claimValue = "10")
        val b = row("b", "Source B", "الحد 20", KnowledgeSourceType.WEB_PAGE, claimKey = "limit.max", claimValue = "20")
        val result = KnowledgeEnginePolicy.hybridRetrieve(listOf(a, b), "ما الحد الاقصى", now)
        assertEquals(2, result.hits.size)
        assertEquals(1, result.contradictions.size)
        val conflict = result.contradictions.single()
        assertEquals("limit max", conflict.claimKey)
        assertEquals(setOf("10", "20"), conflict.variants.map { KnowledgeEnginePolicy.canonical(it.value) }.toSet())
    }

    @Test fun authorityAndConfidenceParticipateInRanking() {
        val strong = row("strong", "مرجع رسمي", "سياسة التخزين", KnowledgeSourceType.DOCUMENT, authority = 1f, confidence = 1f)
        val weak = row("weak", "مجهول", "سياسة التخزين", KnowledgeSourceType.DOCUMENT, authority = 0.1f, confidence = 0.1f)
        val result = KnowledgeEnginePolicy.hybridRetrieve(listOf(weak, strong), "سياسة التخزين", now)
        assertEquals("strong", result.hits.first().entry.id)
    }

    private fun row(
        id: String,
        title: String,
        text: String,
        type: KnowledgeSourceType,
        url: String = "https://example.test/$id",
        observedAt: Long = now,
        claimKey: String = "",
        claimValue: String = "",
        authority: Float = 0.8f,
        confidence: Float = 0.9f
    ): AionKnowledgeEntry = AionKnowledgeEntry(
        id = id,
        scope = KnowledgeScope.USER,
        title = title,
        text = text,
        claimKey = claimKey,
        claimValue = claimValue,
        provenance = KnowledgeProvenance(
            sourceUrl = url,
            sourceTitle = title,
            sourceType = type,
            observedAt = observedAt,
            fetchedAt = observedAt
        ),
        authority = authority,
        confidence = confidence,
        createdAt = observedAt,
        updatedAt = observedAt
    )
}
