package com.aion.mobile.core.memory

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class MemoryOsV2PolicyTest {
    private val now = 1_800_000_000_000L

    @Test fun supersessionPreservesOldValueAndLinksBothDirections() {
        val old = row("old", "اليابانية", MemorySource.EXPLICIT, 90, now, slot = "profile.language")
        val incoming = row("new", "الكورية", MemorySource.EXPLICIT, 90, now + 1, slot = "profile.language")
        val result = MemoryEnginePolicy.upsert(listOf(old), incoming)

        assertEquals(2, result.size)
        val oldSaved = result.single { it.id == "old" }
        val newSaved = result.single { it.id == "new" }
        assertFalse(oldSaved.active)
        assertEquals("new", oldSaved.supersededById)
        assertTrue(newSaved.active)
        assertEquals("old", newSaved.supersedesId)
    }

    @Test fun explicitMemoryBeatsWeakAutomaticCandidate() {
        val explicit = row("explicit", "البنفسجي", MemorySource.EXPLICIT, 90, now, slot = "ui.color")
        val weak = row("auto", "الأزرق", MemorySource.AUTOMATIC, 20, now + 10, slot = "ui.color")
        val result = MemoryEnginePolicy.upsert(listOf(explicit), weak)

        assertTrue(result.single { it.id == "explicit" }.active)
        val candidate = result.single { it.id == "auto" }
        assertFalse(candidate.active)
        assertEquals("explicit", candidate.candidateAgainstId)
    }

    @Test fun allRequiredLayersCanBeRepresented() {
        val layers = setOf(
            MemoryLayer.WORKING,
            MemoryLayer.EPISODIC,
            MemoryLayer.SEMANTIC,
            MemoryLayer.PROCEDURAL,
            MemoryLayer.PROJECT
        )
        assertEquals(5, layers.size)
    }

    @Test fun projectAndConversationScopesCannotCrossProjects() {
        val projectA = row("pa", "A-only", MemorySource.EXPLICIT, 90, now, scope = MemoryScope.PROJECT, owner = "A", project = "A")
        val projectB = row("pb", "B-only", MemorySource.EXPLICIT, 90, now, scope = MemoryScope.PROJECT, owner = "B", project = "B")
        val chatA = row("ca", "chat-A", MemorySource.EXPLICIT, 90, now, scope = MemoryScope.CONVERSATION, owner = "chat", project = "A")
        val chatB = row("cb", "chat-B", MemorySource.EXPLICIT, 90, now, scope = MemoryScope.CONVERSATION, owner = "chat", project = "B")

        val ctx = MemoryEnginePolicy.selectForContext(
            entries = listOf(projectA, projectB, chatA, chatB),
            activeProjectId = "A",
            activeConversationId = "chat",
            projectOnlyMemory = true,
            now = now
        )
        assertTrue(ctx.text.contains("A-only"))
        assertTrue(ctx.text.contains("chat-A"))
        assertFalse(ctx.text.contains("B-only"))
        assertFalse(ctx.text.contains("chat-B"))
    }

    @Test fun compactionPreservesPinnedAndHighPriorityHistory() {
        val oldProtected = row("old", "old", MemorySource.EXPLICIT, 95, now - 20, slot = "critical").copy(active = false, pinned = true, supersededById = "new")
        val newProtected = row("new", "new", MemorySource.EXPLICIT, 95, now - 10, slot = "critical").copy(pinned = true, supersedesId = "old")
        val noise = (1..20).map { i -> row("n$i", "noise-$i", MemorySource.AUTOMATIC, 10, now + i) }
        val compacted = MemoryEnginePolicy.compact(listOf(oldProtected, newProtected) + noise, maxStored = 5)

        assertTrue(compacted.any { it.id == "old" })
        assertTrue(compacted.any { it.id == "new" })
        assertTrue(compacted.size <= 5)
    }

    @Test fun provenanceGetsStableContentHashAndObservedTime() {
        val a = MemoryEnginePolicy.upsert(emptyList(), row("a", "نص ثابت", MemorySource.EXPLICIT, 90, now)).single()
        val b = MemoryEnginePolicy.upsert(emptyList(), row("b", "نص ثابت", MemorySource.EXPLICIT, 90, now + 1)).single()
        assertTrue(a.contentHash.isNotBlank())
        assertEquals(a.contentHash, b.contentHash)
        assertNotEquals(0L, a.observedAt)
    }

    private fun row(
        id: String,
        text: String,
        source: MemorySource,
        priority: Int,
        observed: Long,
        slot: String = "",
        scope: MemoryScope = MemoryScope.USER,
        owner: String = "",
        project: String = ""
    ) = AionMemoryEntry(
        id = id,
        scope = scope,
        ownerId = owner,
        projectId = project,
        layer = when (scope) {
            MemoryScope.PROJECT -> MemoryLayer.PROJECT
            MemoryScope.CONVERSATION -> MemoryLayer.EPISODIC
            MemoryScope.USER -> MemoryLayer.SEMANTIC
        },
        kind = MemoryKind.NOTE,
        text = text,
        slot = slot,
        source = source,
        confidence = if (source == MemorySource.AUTOMATIC) 0.4f else 1f,
        priority = priority,
        observedAt = observed,
        createdAt = observed,
        updatedAt = observed
    )
}
