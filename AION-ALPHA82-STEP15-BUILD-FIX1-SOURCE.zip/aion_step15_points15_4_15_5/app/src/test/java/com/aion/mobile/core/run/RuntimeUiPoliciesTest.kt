package com.aion.mobile.core.run

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class RuntimeUiPoliciesTest {
    @Test
    fun terminalSnapshotCannotRegressToOlderActiveSnapshotForSameRun() {
        val terminal = RuntimeSnapshotStamp("run", 9, terminal = true, isRunning = false, textLength = 20)
        val stale = RuntimeSnapshotStamp("run", 8, terminal = false, isRunning = true, textLength = 10)
        assertFalse(RuntimeSnapshotAcceptancePolicy.shouldAccept(terminal, stale))
    }

    @Test
    fun newerRevisionWinsAndExactDuplicateIsDropped() {
        val current = RuntimeSnapshotStamp("run", 4, terminal = false, isRunning = true, textLength = 10)
        assertTrue(RuntimeSnapshotAcceptancePolicy.shouldAccept(current, current.copy(revision = 5, textLength = 11)))
        assertFalse(RuntimeSnapshotAcceptancePolicy.shouldAccept(current, current))
    }

    @Test
    fun runtimeModelLabelNeverClaimsUnknownAutoModel() {
        assertEquals(
            "جار اختيار النموذج",
            RuntimeModelStatusPolicy.label(true, "", "", "AION Auto", RuntimeUiPhase.THINKING, liveExecution = true),
        )
        assertEquals(
            "Cloudflare · glm-4.7-flash",
            RuntimeModelStatusPolicy.label(true, "glm-4.7-flash", "Cloudflare", "AION Auto", RuntimeUiPhase.WRITING, liveExecution = true),
        )
        assertEquals(
            "بانتظار استئناف التنفيذ",
            RuntimeModelStatusPolicy.label(true, "", "", "AION Auto", RuntimeUiPhase.WRITING, liveExecution = false),
        )
        assertNull(RuntimeModelStatusPolicy.label(false, "glm", "Cloud", "AION Auto", RuntimeUiPhase.COMPLETED, liveExecution = false))
    }
}
