package com.aion.mobile.core.knowledge

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class KnowledgeAccessPolicyTest {
    private val now = 1_800_000_000_000L

    @Test fun automaticSearchIsForcedIntoConversationScope() {
        val incoming = row("x", KnowledgeScope.USER, "", "", "بحث حديث")
        val prepared = KnowledgeAccessPolicy.prepareWrite(
            incoming,
            KnowledgeAccessContext(conversationId = "chat-a", projectId = "project-a"),
            KnowledgeWriteOrigin.AUTOMATIC_SEARCH
        )!!
        assertEquals(KnowledgeScope.CONVERSATION, prepared.scope)
        assertEquals("chat-a", prepared.ownerId)
        assertEquals("project-a", prepared.projectId)
    }

    @Test fun temporaryConversationCannotWriteOrReadKnowledge() {
        val access = KnowledgeAccessContext(conversationId = "chat-a", projectId = "project-a", temporary = true)
        assertNull(KnowledgeAccessPolicy.prepareWrite(row("x", KnowledgeScope.USER, "", "", "secret"), access, KnowledgeWriteOrigin.AUTOMATIC_SEARCH))
        assertTrue(KnowledgeAccessPolicy.filterVisible(listOf(row("u", KnowledgeScope.USER, "", "", "global")), access).isEmpty())
    }

    @Test fun projectAndConversationKnowledgeNeverCrossScopeBoundary() {
        val rows = listOf(
            row("pa", KnowledgeScope.PROJECT, "A", "A", "project-a"),
            row("pb", KnowledgeScope.PROJECT, "B", "B", "project-b"),
            row("ca", KnowledgeScope.CONVERSATION, "chat", "A", "chat-a"),
            row("cb", KnowledgeScope.CONVERSATION, "chat", "B", "chat-b"),
            row("global", KnowledgeScope.USER, "", "", "manual-global")
        )
        val visible = KnowledgeAccessPolicy.filterVisible(rows, KnowledgeAccessContext("chat", "A"))
        assertEquals(setOf("pa", "ca", "global"), visible.map { it.id }.toSet())
        assertFalse(visible.any { it.id == "pb" || it.id == "cb" })
    }

    @Test fun deletedProjectRemovesProjectTruthButDetachesSurvivingConversationKnowledge() {
        val mutation = KnowledgeAccessPolicy.cleanupProject(
            listOf(
                row("project", KnowledgeScope.PROJECT, "p", "p", "project-only"),
                row("chat", KnowledgeScope.CONVERSATION, "c", "p", "conversation-survives"),
                row("other", KnowledgeScope.PROJECT, "q", "q", "other")
            ),
            "p"
        )
        assertEquals(1, mutation.result.removed)
        assertEquals(1, mutation.result.detachedFromProject)
        assertFalse(mutation.entries.any { it.id == "project" })
        assertEquals("", mutation.entries.single { it.id == "chat" }.projectId)
        assertTrue(mutation.entries.any { it.id == "other" })
    }

    @Test fun deletedConversationPurgesOnlyItsKnowledge() {
        val mutation = KnowledgeAccessPolicy.cleanupConversation(
            listOf(
                row("a", KnowledgeScope.CONVERSATION, "chat-a", "p", "a"),
                row("b", KnowledgeScope.CONVERSATION, "chat-b", "p", "b"),
                row("p", KnowledgeScope.PROJECT, "p", "p", "project")
            ),
            "chat-a"
        )
        assertEquals(1, mutation.result.removed)
        assertFalse(mutation.entries.any { it.id == "a" })
        assertTrue(mutation.entries.any { it.id == "b" })
        assertTrue(mutation.entries.any { it.id == "p" })
    }

    @Test fun movingConversationRebindsKnowledgeWithoutPromotingIt() {
        val rows = KnowledgeAccessPolicy.rebindConversationProject(
            listOf(row("chat", KnowledgeScope.CONVERSATION, "c", "old", "fact")),
            "c",
            "new"
        )
        val moved = rows.single()
        assertEquals(KnowledgeScope.CONVERSATION, moved.scope)
        assertEquals("c", moved.ownerId)
        assertEquals("new", moved.projectId)
    }

    private fun row(id: String, scope: KnowledgeScope, owner: String, project: String, text: String) = AionKnowledgeEntry(
        id = id,
        scope = scope,
        ownerId = owner,
        projectId = project,
        title = id,
        text = text,
        provenance = KnowledgeProvenance(
            sourceUrl = "https://example.test/$id",
            sourceTitle = id,
            sourceType = KnowledgeSourceType.WEB_PAGE,
            observedAt = now,
            fetchedAt = now
        ),
        createdAt = now,
        updatedAt = now
    )
}
