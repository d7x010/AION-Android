package com.aion.mobile.core.local

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File
import java.security.MessageDigest

class Step11Batch1Test {
    @Test
    fun severeThermalBlocksLocalInference() {
        val decision = ResourceGovernor().decide(
            snapshot = resources(thermal = ThermalLevel.SEVERE),
            requirements = requirements("nano"),
            environment = ExecutionEnvironment.FOREGROUND,
            loadedModelCount = 0,
            loadedResidentBytes = 0,
        )
        assertFalse(decision.allowed)
        assertEquals(LocalExecutionReason.THERMAL_LIMIT, decision.reason)
    }

    @Test
    fun criticalBatteryDefersWhenNotCharging() {
        val decision = ResourceGovernor().decide(
            snapshot = resources(battery = 5, charging = false),
            requirements = requirements("nano"),
            environment = ExecutionEnvironment.FOREGROUND,
            loadedModelCount = 0,
            loadedResidentBytes = 0,
        )
        assertEquals(LocalExecutionDecision.DEFER, decision.decision)
        assertEquals(LocalExecutionReason.BATTERY_CRITICAL, decision.reason)
    }

    @Test
    fun hashMismatchNeverBecomesReady() {
        val root = tempDir("hash")
        val staged = File(root, "download.pack").apply { writeText("wrong") }
        val manager = manager(root)
        val descriptor = descriptor("nano", expected = 5, sha = "0".repeat(64))
        manager.register(descriptor)
        manager.beginDownload("nano")
        val result = manager.installDownloadedPack("nano", staged)
        assertTrue(result is LocalModelOperationResult.Success)
        assertEquals(LocalModelState.FAILED, manager.get("nano")!!.state)
        assertEquals("HASH_MISMATCH", manager.get("nano")!!.failureReason)
    }

    @Test
    fun lifecyclePersistsAndLoadedStateRestoresAsReady() {
        val root = tempDir("persist")
        val bytes = "verified-pack".toByteArray()
        val staged = File(root, "stage.pack").apply { writeBytes(bytes) }
        val runtime = FakeRuntime()
        var clock = 100L
        val manager = manager(root, runtime) { ++clock }
        manager.register(descriptor("nano", bytes.size.toLong(), sha(bytes)))
        manager.beginDownload("nano")
        manager.installDownloadedPack("nano", staged)
        assertEquals(LocalModelState.READY, manager.get("nano")!!.state)
        assertTrue(manager.load("nano", resources()).let { it is LocalModelOperationResult.Success })
        assertEquals(LocalModelState.LOADED, manager.get("nano")!!.state)

        val restored = manager(root, runtime) { ++clock }
        assertEquals(LocalModelState.READY, restored.get("nano")!!.state)
    }

    @Test
    fun lruEvictsOldestWhenConcurrentBudgetIsFull() {
        val root = tempDir("lru")
        val runtime = FakeRuntime()
        var clock = 1L
        val manager = manager(root, runtime) { clock++ }
        val snapshot = resources(totalRam = 8L * ResourceGovernor.GIB, availableRam = 6L * ResourceGovernor.GIB)

        install(manager, root, descriptor("a", 1, sha(byteArrayOf(1))), byteArrayOf(1))
        install(manager, root, descriptor("b", 1, sha(byteArrayOf(2))), byteArrayOf(2))
        install(manager, root, descriptor("c", 1, sha(byteArrayOf(3))), byteArrayOf(3))
        manager.load("a", snapshot)
        manager.load("b", snapshot)
        manager.markUsed("b")
        manager.load("c", snapshot)

        assertEquals(LocalModelState.READY, manager.get("a")!!.state)
        assertEquals(LocalModelState.LOADED, manager.get("b")!!.state)
        assertEquals(LocalModelState.LOADED, manager.get("c")!!.state)
        assertTrue("a" in runtime.unloaded)
    }

    @Test
    fun criticalMemoryPressureEvictsEveryLoadedModel() {
        val root = tempDir("pressure")
        val runtime = FakeRuntime()
        val manager = manager(root, runtime)
        val snapshot = resources(totalRam = 12L * ResourceGovernor.GIB, availableRam = 8L * ResourceGovernor.GIB)
        repeat(2) { index ->
            val id = "m$index"
            val data = byteArrayOf(index.toByte())
            install(manager, root, descriptor(id, 1, sha(data)), data)
            manager.load(id, snapshot)
        }
        assertEquals(2, manager.evictForMemoryPressure(MemoryPressure.CRITICAL).size)
        assertTrue(manager.snapshot().none { it.state == LocalModelState.LOADED })
    }

    private fun manager(root: File, runtime: LocalModelRuntime = FakeRuntime(), now: () -> Long = System::currentTimeMillis): LocalModelManager =
        LocalModelManager(
            modelDirectory = File(root, "models"),
            registry = LocalModelRegistryStore(File(root, "registry.bin")),
            verifier = ModelPackVerifier(AcceptAllSignatures),
            resourceGovernor = ResourceGovernor(),
            runtime = runtime,
            now = now,
        )

    private fun requirements(id: String) = LocalModelRequirements(
        modelId = id,
        minimumAvailableRamBytes = 64L * ResourceGovernor.MIB,
        estimatedResidentBytes = 64L * ResourceGovernor.MIB,
        minimumFreeStorageBytes = 1L,
        allowBackground = true,
    )

    private fun descriptor(id: String, expected: Long, sha: String): LocalModelPackDescriptor {
        val base = LocalModelPackDescriptor(
            modelId = id,
            version = "1",
            expectedSizeBytes = expected,
            sha256 = sha,
            signature = "test-signature",
            provenance = ModelPackProvenance(
                sourceType = ModelPackSourceType.BUNDLED_RELEASE,
                sourceUri = "bundled://tests/$id",
                publisher = "AION Tests",
                acquiredAtEpochMs = 1L,
                issuedAtEpochMs = 1L,
                manifestSha256 = "0".repeat(64),
                signatureAlgorithm = "Ed25519",
                signerKeyId = "test-key-v1",
            ),
            requirements = requirements(id),
        )
        return ModelPackSupplyChainPolicy.seal(base)
    }

    private fun resources(
        totalRam: Long = 8L * ResourceGovernor.GIB,
        availableRam: Long = 6L * ResourceGovernor.GIB,
        battery: Int? = 80,
        charging: Boolean = false,
        thermal: ThermalLevel = ThermalLevel.NONE,
    ) = DeviceResourceSnapshot(
        capturedAtEpochMs = 1,
        totalRamBytes = totalRam,
        availableRamBytes = availableRam,
        lowMemory = false,
        availableStorageBytes = 20L * ResourceGovernor.GIB,
        batteryPercent = battery,
        charging = charging,
        powerSaver = false,
        thermalLevel = thermal,
    )

    private fun install(manager: LocalModelManager, root: File, descriptor: LocalModelPackDescriptor, data: ByteArray) {
        val staged = File(root, descriptor.modelId + ".stage").apply { writeBytes(data) }
        manager.register(descriptor)
        manager.beginDownload(descriptor.modelId)
        manager.installDownloadedPack(descriptor.modelId, staged)
        assertEquals(LocalModelState.READY, manager.get(descriptor.modelId)!!.state)
    }

    private fun sha(data: ByteArray): String = MessageDigest.getInstance("SHA-256")
        .digest(data).joinToString("") { "%02x".format(it) }

    private fun tempDir(name: String): File = createTempDir(prefix = "aion-step11-$name-")

    private fun testProvenance(id: String) = ModelPackSupplyChainPolicy.seal(
        LocalModelPackDescriptor(
            modelId = id,
            version = "1",
            expectedSizeBytes = 0L,
            sha256 = "0".repeat(64),
            signature = "test-signature",
            provenance = ModelPackProvenance(
                sourceType = ModelPackSourceType.BUNDLED_RELEASE,
                sourceUri = "bundled://tests/$id",
                publisher = "AION Tests",
                acquiredAtEpochMs = 1L,
                issuedAtEpochMs = 1L,
                manifestSha256 = "0".repeat(64),
                signatureAlgorithm = "Ed25519",
                signerKeyId = "test-key-v1",
            ),
            requirements = requirements(id),
        )
    ).provenance!!

    private object AcceptAllSignatures : ModelPackSignatureVerifier {
        override fun verify(file: File, descriptor: LocalModelPackDescriptor, signature: String): Boolean = true
    }

    private class FakeRuntime : LocalModelRuntime {
        val loaded = linkedSetOf<String>()
        val unloaded = mutableListOf<String>()
        override fun load(descriptor: LocalModelPackDescriptor, packFile: File): Boolean {
            loaded += descriptor.modelId
            return true
        }
        override fun unload(modelId: String) {
            loaded -= modelId
            unloaded += modelId
        }
    }
}
