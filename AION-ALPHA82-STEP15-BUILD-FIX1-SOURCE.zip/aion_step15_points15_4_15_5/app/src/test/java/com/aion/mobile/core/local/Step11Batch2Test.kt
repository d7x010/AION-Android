package com.aion.mobile.core.local

import com.aion.mobile.model.ChatMessage
import com.aion.mobile.model.MessageRole
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File
import java.nio.file.Files

class Step11Batch2Test {
    @Test
    fun storageBudgetIsEnforcedBeforePackCommit() {
        val dir = Files.createTempDirectory("aion-s11-budget").toFile()
        val modelRoot = File(dir, "models").apply { mkdirs() }
        val registry = LocalModelRegistryStore(File(dir, "registry.bin"))
        val staged = File(dir, "pack.bin").apply { writeBytes(ByteArray(16) { 7 }) }
        val hash = ModelPackVerifier().sha256(staged)
        val descriptor = ModelPackSupplyChainPolicy.seal(
            LocalModelPackDescriptor(
                modelId = "budget-test",
                version = "1",
                expectedSizeBytes = staged.length(),
                sha256 = hash,
                signature = "test-signature",
                provenance = ModelPackProvenance(
                    sourceType = ModelPackSourceType.BUNDLED_RELEASE,
                    sourceUri = "bundled://tests/budget-test",
                    publisher = "AION Tests",
                    acquiredAtEpochMs = 1L,
                    issuedAtEpochMs = 1L,
                    manifestSha256 = "0".repeat(64),
                    signatureAlgorithm = "Ed25519",
                    signerKeyId = "test-key-v1",
                ),
                requirements = LocalModelRequirements("budget-test", 0L, 0L),
            )
        )
        val manager = LocalModelManager(
            modelDirectory = modelRoot,
            registry = registry,
            verifier = ModelPackVerifier(object : ModelPackSignatureVerifier {
                override fun verify(file: File, descriptor: LocalModelPackDescriptor, signature: String): Boolean = true
            }),
            resourceGovernor = ResourceGovernor(),
            storageBudgetPolicy = LocalStorageBudgetPolicy(0L, 0.05, 1L),
        )
        manager.register(descriptor)
        manager.beginDownload("budget-test")
        val install = manager.installDownloadedPack("budget-test", staged)
        assertTrue(install is LocalModelOperationResult.Success)
        assertEquals(LocalModelState.FAILED, manager.get("budget-test")!!.state)
        assertTrue(manager.get("budget-test")!!.failureReason!!.startsWith("storage_budget_exceeded"))
    }

    @Test
    fun offlineCapabilityMatrixDoesNotOverclaim() {
        assertTrue(OfflineCapabilityMatrix.status(OfflineCapability.DETERMINISTIC_ARITHMETIC).availableOffline)
        assertFalse(OfflineCapabilityMatrix.status(OfflineCapability.GENERAL_CHAT).availableOffline)
        assertFalse(OfflineCapabilityMatrix.status(OfflineCapability.WEB_SEARCH).availableOffline)
        assertFalse(OfflineCapabilityMatrix.status(OfflineCapability.REMOTE_FILE_ANALYSIS).availableOffline)
        assertFalse(OfflineCapabilityMatrix.status(OfflineCapability.CLOUD_TOOLS).availableOffline)
    }

    @Test
    fun circuitBreakerTransitionsAndRecoversStaleProbe() {
        val dir = Files.createTempDirectory("aion-s11-health").toFile()
        var now = 10_000L
        val store = BackendHealthStore(File(dir, "health.bin"))
        val health = BackendHealthTracker(store, failureThreshold = 3, openDurationMs = 5_000L, now = { now })
        assertTrue(health.beforeCall("cloud") is BackendCallPermit.Allowed)
        health.recordFailure("cloud", 100)
        health.recordFailure("cloud", 200)
        health.recordFailure("cloud", 300)
        val opened = health.snapshot("cloud")
        assertEquals(CircuitBreakerState.OPEN, opened.state)
        assertEquals(3, opened.recentFailures)
        assertEquals(200L, opened.averageLatencyMs)
        assertTrue(health.beforeCall("cloud") is BackendCallPermit.CircuitOpen)

        now += 5_001L
        val firstProbe = health.beforeCall("cloud")
        assertTrue(firstProbe is BackendCallPermit.Allowed && firstProbe.halfOpenProbe)
        assertTrue(health.beforeCall("cloud") is BackendCallPermit.CircuitOpen)

        now += 15_001L
        val recreated = BackendHealthTracker(BackendHealthStore(File(dir, "health.bin")), now = { now })
        assertTrue(recreated.beforeCall("cloud") is BackendCallPermit.Allowed)
        health.recordSuccess("cloud", 50)
        assertEquals(CircuitBreakerState.CLOSED, health.snapshot("cloud").state)
    }

    @Test
    fun explicitArithmeticExecutesLocallyButGeneralChatDoesNot() {
        val arithmetic = AionLocalIntelligence.route(
            listOf(ChatMessage(1, MessageRole.USER, "احسب 12 × (3 + 2)")),
            forceWebSearch = false,
        )
        assertTrue(arithmetic is LocalIntelligenceDecision.Executed)
        arithmetic as LocalIntelligenceDecision.Executed
        assertEquals("60", arithmetic.result.text)
        assertEquals(OfflineCapabilityMatrix.LOCAL_PROVIDER_KEY, arithmetic.result.execution.providerKey)
        assertEquals(OfflineCapabilityMatrix.NANO_MODEL_ID, arithmetic.result.execution.modelId)

        assertTrue(
            AionLocalIntelligence.route(
                listOf(ChatMessage(2, MessageRole.USER, "اشرح لي الفيزياء")),
                false,
            ) is LocalIntelligenceDecision.CloudRequired
        )
        assertTrue(
            AionLocalIntelligence.route(
                listOf(ChatMessage(3, MessageRole.USER, "2+2")),
                true,
            ) is LocalIntelligenceDecision.CloudRequired
        )
    }

    @Test
    fun dateLikeTextIsNeverTreatedAsArithmetic() {
        assertEquals(null, LocalArithmeticIntentClassifier.extractExpression("2026-09-11"))
        assertEquals(null, LocalArithmeticIntentClassifier.extractExpression("2026 - 09 - 11"))
        assertEquals(null, LocalArithmeticIntentClassifier.extractExpression("ما تاريخ 2026-09-11؟"))
    }

    @Test
    fun telemetryFailureIsContained() {
        val dir = Files.createTempDirectory("aion-s11-telemetry").toFile()
        val unusableRoot = File(dir, "not-a-dir").also { it.writeText("x") }
        assertFalse(LocalTelemetry.recordBestEffort(unusableRoot, "success", mapOf("x" to "y")))
    }
}
