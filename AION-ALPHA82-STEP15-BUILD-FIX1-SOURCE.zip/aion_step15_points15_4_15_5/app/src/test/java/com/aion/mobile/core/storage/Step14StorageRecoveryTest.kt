package com.aion.mobile.core.storage

import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File
import java.nio.file.Files

class Step14StorageRecoveryTest {
    @Test
    fun schemaRegistryRejectsFutureVersionsWithoutRejectingSupportedMigrations() {
        assertTrue(AionStorageSchemaRegistry.chat.canRead(1))
        assertTrue(AionStorageSchemaRegistry.chat.canRead(5))
        assertFalse(AionStorageSchemaRegistry.chat.canRead(6))
        assertTrue(AionStorageSchemaRegistry.memory.canRead(1))
        assertTrue(AionStorageSchemaRegistry.memory.canRead(2))
        assertFalse(AionStorageSchemaRegistry.memory.canRead(3))
        assertEquals(1, AionStorageSchemaRegistry.knowledge.currentVersion)
    }

    @Test
    fun validPrimarySeedsLkgAndCorruptionRecoversExactText() {
        val root = Files.createTempDirectory("aion-recovery").toFile()
        try {
            val file = File(root, "memory.json")
            val validator: (String) -> Boolean = { it.startsWith("v2|") }
            assertTrue(DurableFileRecovery.writeText(file, "v2|good", validator))
            assertTrue(DurableFileRecovery.lkgFile(file).isFile)

            file.writeText("corrupt", Charsets.UTF_8)
            val read = DurableFileRecovery.readText(file, validator)
            assertTrue(read.recoveredFromLkg)
            assertFalse(read.corruptWithoutRecovery)
            assertEquals("v2|good", read.bytes?.toString(Charsets.UTF_8))
            assertEquals("v2|good", file.readText(Charsets.UTF_8))
        } finally {
            root.deleteRecursively()
        }
    }

    @Test
    fun corruptPrimaryAndCorruptLkgFailClosedAndRefuseOverwrite() {
        val root = Files.createTempDirectory("aion-fail-closed").toFile()
        try {
            val file = File(root, "knowledge.aion")
            val validator: (String) -> Boolean = { it.startsWith("AION_KNOWLEDGE_V1") }
            file.writeText("broken-primary", Charsets.UTF_8)
            DurableFileRecovery.lkgFile(file).writeText("broken-backup", Charsets.UTF_8)

            val read = DurableFileRecovery.readText(file, validator)
            assertNull(read.bytes)
            assertTrue(read.corruptWithoutRecovery)
            assertFalse(DurableFileRecovery.writeText(file, "AION_KNOWLEDGE_V1\n", validator))
            assertEquals("broken-primary", file.readText(Charsets.UTF_8))
        } finally {
            root.deleteRecursively()
        }
    }

    @Test
    fun binaryRecoveryUsesSameFailSafeContract() {
        val root = Files.createTempDirectory("aion-binary-recovery").toFile()
        try {
            val file = File(root, "registry.bin")
            val validator: (ByteArray) -> Boolean = { it.size >= 4 && it[0] == 0x41.toByte() }
            val good = byteArrayOf(0x41, 0x49, 0x4f, 0x4e)
            assertTrue(DurableFileRecovery.writeBytes(file, good, validator))
            file.writeBytes(byteArrayOf(0x00, 0x01))
            val read = DurableFileRecovery.readBytes(file, validator)
            assertTrue(read.recoveredFromLkg)
            assertArrayEquals(good, read.bytes)
        } finally {
            root.deleteRecursively()
        }
    }
}
