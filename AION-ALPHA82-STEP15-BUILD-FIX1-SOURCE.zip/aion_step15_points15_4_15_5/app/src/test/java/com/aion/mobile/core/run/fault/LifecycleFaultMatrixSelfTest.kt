package com.aion.mobile.core.run.fault

import com.aion.mobile.core.sovereign.SovereignTaskState
import java.util.Random
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger

private data class Case(val name: String, val snapshot: FaultSnapshot, val expected: RecoveryAction)

fun main() {
    val cases = listOf(
        Case("terminal completed", FaultSnapshot(SovereignTaskState.COMPLETED), RecoveryAction.CLEANUP_TERMINAL),
        Case("terminal cancelled", FaultSnapshot(SovereignTaskState.CANCELLED), RecoveryAction.CLEANUP_TERMINAL),
        Case("terminal failed final", FaultSnapshot(SovereignTaskState.FAILED_FINAL), RecoveryAction.CLEANUP_TERMINAL),
        Case("cancel after process crash", FaultSnapshot(SovereignTaskState.PAUSED, cancelRequested = true), RecoveryAction.APPLY_CANCEL),
        Case("cancel beats backoff", FaultSnapshot(SovereignTaskState.WAITING_NETWORK, cancelRequested = true, backoffRemainingMs = 90_000), RecoveryAction.APPLY_CANCEL),
        Case("boot only schedules job", FaultSnapshot(SovereignTaskState.RUNNING, trigger = WakeTrigger.DEVICE_BOOT), RecoveryAction.SCHEDULE_BACKGROUND_JOB),
        Case("package replace only schedules job", FaultSnapshot(SovereignTaskState.RUNNING, trigger = WakeTrigger.PACKAGE_REPLACED), RecoveryAction.SCHEDULE_BACKGROUND_JOB),
        Case("missing request blocks", FaultSnapshot(SovereignTaskState.RUNNING, requestPresent = false), RecoveryAction.BLOCK_MISSING_REQUEST),
        Case("waiting user holds", FaultSnapshot(SovereignTaskState.WAITING_USER), RecoveryAction.HOLD_USER),
        Case("blocked holds", FaultSnapshot(SovereignTaskState.BLOCKED), RecoveryAction.HOLD_USER),
        Case("final checkpoint during verify restores", FaultSnapshot(SovereignTaskState.VERIFYING, finalCheckpoint = true), RecoveryAction.RESTORE_FINAL),
        Case("persisted backoff respected", FaultSnapshot(SovereignTaskState.FAILED_RECOVERABLE, backoffRemainingMs = 31_337), RecoveryAction.WAIT_BACKOFF),
        Case("offline run waits", FaultSnapshot(SovereignTaskState.RUNNING, networkAvailable = false), RecoveryAction.WAIT_NETWORK),
        Case("offline waiting network waits", FaultSnapshot(SovereignTaskState.WAITING_NETWORK, networkAvailable = false), RecoveryAction.WAIT_NETWORK),
        Case("server conflict blocks", FaultSnapshot(SovereignTaskState.RUNNING, server = ServerRunStatus.CONFLICT), RecoveryAction.BLOCK_SERVER_CONFLICT),
        Case("server complete restores", FaultSnapshot(SovereignTaskState.RUNNING, server = ServerRunStatus.COMPLETED), RecoveryAction.RESTORE_FINAL),
        Case("server tools complete continues model only", FaultSnapshot(SovereignTaskState.WAITING_TOOL, server = ServerRunStatus.TOOLS_COMPLETED), RecoveryAction.CONTINUE_MODEL),
        Case("server in progress waits", FaultSnapshot(SovereignTaskState.RUNNING, server = ServerRunStatus.IN_PROGRESS), RecoveryAction.WAIT_SERVER),
        Case("live other lease waits", FaultSnapshot(SovereignTaskState.RUNNING, lease = LeaseStatus.OWNED_OTHER_ACTIVE), RecoveryAction.WAIT_LEASE),
        Case("expired lease permits recovery", FaultSnapshot(SovereignTaskState.RUNNING, lease = LeaseStatus.EXPIRED), RecoveryAction.RESUME_RUN),
        Case("kill before read tool starts allows tool", FaultSnapshot(SovereignTaskState.WAITING_TOOL, receipt = ToolReceiptStatus.PREPARED, toolEffect = ToolEffect.READ_ONLY), RecoveryAction.RESUME_TOOL),
        Case("kill before mutation starts allows local prepared tool", FaultSnapshot(SovereignTaskState.WAITING_TOOL, receipt = ToolReceiptStatus.PREPARED, toolEffect = ToolEffect.MUTATING), RecoveryAction.RESUME_TOOL),
        Case("prepared mutation after cloud boundary reconciles", FaultSnapshot(SovereignTaskState.WAITING_TOOL, receipt = ToolReceiptStatus.PREPARED, toolEffect = ToolEffect.MUTATING, crossedCloudToolBoundary = true), RecoveryAction.RECONCILE_SERVER),
        Case("kill after tool start reconciles", FaultSnapshot(SovereignTaskState.WAITING_TOOL, receipt = ToolReceiptStatus.STARTED, toolEffect = ToolEffect.MUTATING), RecoveryAction.RECONCILE_SERVER),
        Case("unknown tool reconciles", FaultSnapshot(SovereignTaskState.WAITING_TOOL, receipt = ToolReceiptStatus.UNKNOWN, toolEffect = ToolEffect.MUTATING), RecoveryAction.RECONCILE_SERVER),
        Case("completed tool continues model", FaultSnapshot(SovereignTaskState.WAITING_TOOL, receipt = ToolReceiptStatus.COMPLETED, toolEffect = ToolEffect.MUTATING), RecoveryAction.CONTINUE_MODEL),
        Case("safe failed read can retry", FaultSnapshot(SovereignTaskState.WAITING_TOOL, receipt = ToolReceiptStatus.FAILED, toolEffect = ToolEffect.READ_ONLY), RecoveryAction.RESUME_TOOL),
        Case("failed mutation reconciles", FaultSnapshot(SovereignTaskState.WAITING_TOOL, receipt = ToolReceiptStatus.FAILED, toolEffect = ToolEffect.MUTATING), RecoveryAction.RECONCILE_SERVER),
        Case("crossed boundary no server proof reconciles", FaultSnapshot(SovereignTaskState.RUNNING, crossedCloudToolBoundary = true, server = ServerRunStatus.UNAVAILABLE), RecoveryAction.RECONCILE_SERVER),
        Case("bare waiting tool fail closed", FaultSnapshot(SovereignTaskState.WAITING_TOOL), RecoveryAction.RECONCILE_SERVER),
        Case("paused safe resume", FaultSnapshot(SovereignTaskState.PAUSED), RecoveryAction.RESUME_RUN),
        Case("failed recoverable safe resume", FaultSnapshot(SovereignTaskState.FAILED_RECOVERABLE), RecoveryAction.RESUME_RUN),
        Case("network returned resumes", FaultSnapshot(SovereignTaskState.WAITING_NETWORK, networkAvailable = true), RecoveryAction.RESUME_RUN),
        Case("streaming process death resumes", FaultSnapshot(SovereignTaskState.RUNNING, finalCheckpoint = false), RecoveryAction.RESUME_RUN),
    )

    var passed = 0
    for (case in cases) {
        val decision = LifecycleFaultMatrix.decide(case.snapshot)
        check(decision.action == case.expected) {
            "${case.name}: expected=${case.expected} actual=${decision.action} reason=${decision.reason}"
        }
        passed++
    }

    // Hard safety invariants across a broad cross-product of fault states.
    var invariantChecks = 0L
    for (state in SovereignTaskState.entries) {
        for (receipt in ToolReceiptStatus.entries) {
            for (effect in ToolEffect.entries) {
                for (server in ServerRunStatus.entries) {
                    for (lease in LeaseStatus.entries) {
                        val s = FaultSnapshot(
                            taskState = state,
                            receipt = receipt,
                            toolEffect = effect,
                            server = server,
                            lease = lease,
                            crossedCloudToolBoundary = receipt == ToolReceiptStatus.STARTED || receipt == ToolReceiptStatus.UNKNOWN,
                        )
                        val d = LifecycleFaultMatrix.decide(s)
                        if (state in setOf(SovereignTaskState.COMPLETED, SovereignTaskState.CANCELLED, SovereignTaskState.FAILED_FINAL)) {
                            check(d.action == RecoveryAction.CLEANUP_TERMINAL)
                        }
                        if (server == ServerRunStatus.COMPLETED && state !in setOf(SovereignTaskState.COMPLETED, SovereignTaskState.CANCELLED, SovereignTaskState.FAILED_FINAL)) {
                            check(!d.mayExecuteTool && !d.mayExecuteModel) { "server completed allowed work: $s => $d" }
                        }
                        if ((receipt == ToolReceiptStatus.STARTED || receipt == ToolReceiptStatus.UNKNOWN) && effect == ToolEffect.MUTATING) {
                            check(!d.mayExecuteTool) { "ambiguous mutation replayed: $s => $d" }
                        }
                        if (lease == LeaseStatus.OWNED_OTHER_ACTIVE && server !in setOf(ServerRunStatus.COMPLETED, ServerRunStatus.TOOLS_COMPLETED, ServerRunStatus.CONFLICT, ServerRunStatus.IN_PROGRESS) && state !in setOf(SovereignTaskState.COMPLETED, SovereignTaskState.CANCELLED, SovereignTaskState.FAILED_FINAL, SovereignTaskState.WAITING_USER, SovereignTaskState.BLOCKED)) {
                            check(!d.mayExecuteTool && !d.mayExecuteModel) { "second lease owner executed work: $s => $d" }
                        }
                        invariantChecks++
                    }
                }
            }
        }
    }

    // Concurrent recovery race: exactly one of 32 contenders may acquire an active lease.
    val arbiter = RecoveryLeaseArbiter()
    val winners = AtomicInteger(0)
    val threads = 32
    val ready = CountDownLatch(threads)
    val go = CountDownLatch(1)
    val pool = Executors.newFixedThreadPool(threads)
    repeat(threads) { i ->
        pool.submit {
            ready.countDown(); go.await()
            if (arbiter.claim("run-race", "owner-$i", 1_000L, 60_000L)) winners.incrementAndGet()
        }
    }
    ready.await(); go.countDown(); pool.shutdown()
    while (!pool.isTerminated) Thread.sleep(2)
    check(winners.get() == 1) { "lease race had ${winners.get()} winners" }
    check(arbiter.activeOwner("run-race", 2_000L) != null)
    check(!arbiter.claim("run-race", "intruder", 2_000L, 60_000L))
    check(arbiter.claim("run-race", "after-expiry", 70_001L, 60_000L))

    // Seeded fault fuzz: no unsafe execution after cancel/terminal/ambiguous mutation/live foreign lease.
    val random = Random(0xA10F10L)
    var fuzz = 0
    repeat(50_000) {
        val state = SovereignTaskState.entries[random.nextInt(SovereignTaskState.entries.size)]
        val receipt = ToolReceiptStatus.entries[random.nextInt(ToolReceiptStatus.entries.size)]
        val effect = ToolEffect.entries[random.nextInt(ToolEffect.entries.size)]
        val server = ServerRunStatus.entries[random.nextInt(ServerRunStatus.entries.size)]
        val lease = LeaseStatus.entries[random.nextInt(LeaseStatus.entries.size)]
        val cancel = random.nextInt(20) == 0
        val snap = FaultSnapshot(
            taskState = state,
            requestPresent = random.nextInt(20) != 0,
            networkAvailable = random.nextBoolean(),
            lease = lease,
            receipt = receipt,
            toolEffect = effect,
            server = server,
            finalCheckpoint = random.nextBoolean(),
            cancelRequested = cancel,
            backoffRemainingMs = if (random.nextInt(5) == 0) random.nextInt(300_000).toLong() else 0L,
            crossedCloudToolBoundary = random.nextBoolean(),
            trigger = WakeTrigger.entries[random.nextInt(WakeTrigger.entries.size)],
        )
        val d = LifecycleFaultMatrix.decide(snap)
        val terminal = state in setOf(SovereignTaskState.COMPLETED, SovereignTaskState.CANCELLED, SovereignTaskState.FAILED_FINAL)
        if (terminal) check(!d.mayExecuteModel && !d.mayExecuteTool)
        if (cancel && !terminal && snap.trigger !in setOf(WakeTrigger.DEVICE_BOOT, WakeTrigger.PACKAGE_REPLACED)) {
            check(d.action == RecoveryAction.APPLY_CANCEL) { "cancel resurrected: $snap => $d" }
        }
        if ((receipt == ToolReceiptStatus.STARTED || receipt == ToolReceiptStatus.UNKNOWN) && effect == ToolEffect.MUTATING) {
            check(!d.mayExecuteTool) { "fuzz replayed ambiguous mutation: $snap => $d" }
        }
        fuzz++
    }

    check(LifecycleWakePolicy.action(WakeTrigger.DEVICE_BOOT, true) == RecoveryAction.SCHEDULE_BACKGROUND_JOB)
    check(LifecycleWakePolicy.action(WakeTrigger.PACKAGE_REPLACED, true) == RecoveryAction.SCHEDULE_BACKGROUND_JOB)
    check(LifecycleWakePolicy.action(WakeTrigger.APP_BACKGROUND, true) == RecoveryAction.SCHEDULE_BACKGROUND_JOB)
    check(LifecycleWakePolicy.action(WakeTrigger.DEVICE_BOOT, false) == null)

    println("AION_STEP10_MATRIX_OK cases=$passed invariants=$invariantChecks fuzz=$fuzz leaseRaceWinners=${winners.get()}")
}
