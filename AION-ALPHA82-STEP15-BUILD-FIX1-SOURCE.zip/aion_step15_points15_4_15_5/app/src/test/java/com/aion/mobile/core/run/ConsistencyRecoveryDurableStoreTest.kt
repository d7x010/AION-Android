package com.aion.mobile.core.run

import com.aion.mobile.core.sovereign.SovereignTask
import com.aion.mobile.core.sovereign.SovereignTaskState
import com.aion.mobile.core.sovereign.TaskCheckpoint
import com.aion.mobile.core.sovereign.TaskFailure
import com.aion.mobile.model.AttachmentKind
import com.aion.mobile.model.ChatAttachment
import com.aion.mobile.model.ChatMessage
import com.aion.mobile.model.ChatSource
import com.aion.mobile.model.MessageRole
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test
import java.nio.file.Files

class ConsistencyRecoveryDurableStoreTest {
    @Test
    fun runRequest_roundTripsAcrossDisk() {
        val root = Files.createTempDirectory("aion-request-store").toFile()
        try {
            val attachment = ChatAttachment(
                id = 7L,
                name = "notes.txt",
                mimeType = "text/plain",
                base64Data = "SGVsbG8=",
                kind = AttachmentKind.FILE,
                sizeBytes = 5L,
                localPath = "/tmp/notes.txt",
            )
            val source = ChatSource("Source", "https://example.test/source", "snippet")
            val message = ChatMessage(
                id = 11L,
                role = MessageRole.USER,
                text = "استرجاع دائم",
                modelId = "auto",
                modelLabel = "AION",
                executionProviderKey = "aion-core",
                executionProviderLabel = "AION Core",
                executionModelId = "worker-model",
                routingPolicy = "test-policy",
                fallbackUsed = true,
                executionAttempts = 2,
                orchestratorContract = 3,
                orchestratorTraceId = "trace-1",
                orchestratorSearchReason = "freshness",
                orchestratorMemoryPolicy = "bounded",
                orchestratorToolRoute = "files.read",
                orchestratorResponseProfile = "deep",
                attachments = listOf(attachment),
                sources = listOf(source),
                isStreaming = true,
            )
            val request = AionRunRequest(
                runId = "run-request-roundtrip-0001",
                conversationId = "conversation-1",
                placeholderId = 99L,
                modelId = "auto",
                modelLabel = "AION",
                messages = listOf(message),
                sessionMessages = listOf(message.copy(id = 12L, isStreaming = false)),
                forceWebSearch = true,
                customInstructions = "custom",
                memoryContext = "memory",
                contextContext = "context",
            )

            AionRunRequestStore.save(root, request)

            assertEquals(request, AionRunRequestStore.load(root, request.runId))
            assertEquals(listOf(request.runId), AionRunRequestStore.listRunIds(root))
        } finally {
            root.deleteRecursively()
        }
    }

    @Test
    fun sovereignTask_roundTripsAcrossDisk() {
        val root = Files.createTempDirectory("aion-task-store").toFile()
        try {
            val task = SovereignTask(
                contract = 2,
                id = "run-task-roundtrip-0001",
                goal = "chat:conversation-1",
                state = SovereignTaskState.WAITING_NETWORK,
                currentStep = "reconcile",
                checkpoint = TaskCheckpoint(
                    savedAt = "2026-09-12T01:00:00Z",
                    state = SovereignTaskState.WAITING_NETWORK,
                    stepId = "reconcile",
                    payload = mapOf("cloudBoundary" to "true", "partialChars" to "120"),
                ),
                dependencies = setOf("network", "cloud"),
                outputs = listOf("partial-response"),
                attempts = 2,
                maxAttempts = 7,
                createdAt = "2026-09-12T00:00:00Z",
                updatedAt = "2026-09-12T01:00:00Z",
                lastHeartbeatAt = "2026-09-12T00:59:50Z",
                nextRetryAt = "2026-09-12T01:02:00Z",
                blockedReason = "offline",
                lastFailure = TaskFailure("network_or_upstream", true, "wait_network", "offline"),
                revision = 8L,
                cancelRequested = false,
            )

            SovereignTaskStore.save(root, task)

            assertEquals(task, SovereignTaskStore.load(root, task.id))
        } finally {
            root.deleteRecursively()
        }
    }

    @Test
    fun missingDurableObjectsFailClosedAsMissing() {
        val root = Files.createTempDirectory("aion-missing-store").toFile()
        try {
            assertNull(AionRunRequestStore.load(root, "run-missing-0001"))
            assertNull(SovereignTaskStore.load(root, "run-missing-0001"))
        } finally {
            root.deleteRecursively()
        }
    }
}
