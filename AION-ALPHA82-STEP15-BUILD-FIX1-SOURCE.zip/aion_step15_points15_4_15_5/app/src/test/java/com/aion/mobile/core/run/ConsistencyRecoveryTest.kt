package com.aion.mobile.core.run

import com.aion.mobile.core.run.fault.FaultSnapshot
import com.aion.mobile.core.run.fault.LifecycleFaultMatrix
import com.aion.mobile.core.run.fault.RecoveryAction
import com.aion.mobile.core.run.fault.RunCancellationFence
import com.aion.mobile.core.run.fault.ServerRunStatus
import com.aion.mobile.core.run.fault.ToolEffect
import com.aion.mobile.core.run.fault.ToolReceiptStatus
import com.aion.mobile.core.sovereign.SovereignTaskState
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.nio.file.Files
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger

class ConsistencyRecoveryTest {
    @Test
    fun durablePrimitivesAndFaultMatrixFailClosed() {
        val root = Files.createTempDirectory("aion-consistency-junit").toFile()
        try {
            val runId = "run_test_12345678"
            DurableBackoffStore.setNotBefore(root, runId, 123_456_789L)
            assertEquals(123_456_789L, DurableBackoffStore.getNotBefore(root, runId))

            val prepared = DurableToolReceiptStore.prepare(root, runId, "tool-1", ToolEffect.MUTATING, "{\"x\":1}")
            assertEquals(ToolReceiptStatus.PREPARED, DurableToolReceiptStore.read(root, runId, "tool-1")?.status)
            val started = DurableToolReceiptStore.mark(root, prepared, ToolReceiptStatus.STARTED)
            val completed = DurableToolReceiptStore.mark(root, started, ToolReceiptStatus.COMPLETED, "ok")
            assertTrue(completed.resultDigest.isNotBlank())

            assertEquals(LeaseClaimResult.ACQUIRED, DurableExecutionLeaseStore.acquire(root, runId, "owner-a", 1_000L, 2_000L))
            assertEquals(LeaseClaimResult.HELD_BY_OTHER, DurableExecutionLeaseStore.acquire(root, runId, "owner-b", 2_000L, 2_000L))
            assertEquals(LeaseClaimResult.ACQUIRED, DurableExecutionLeaseStore.acquire(root, runId, "owner-b", 3_001L, 2_000L))

            val raceId = "run_race_12345678"
            val pool = Executors.newFixedThreadPool(32)
            val gate = CountDownLatch(1)
            val done = CountDownLatch(32)
            val winners = AtomicInteger(0)
            repeat(32) { index ->
                pool.submit {
                    try {
                        gate.await()
                        if (DurableExecutionLeaseStore.acquire(root, raceId, "owner-$index", 10_000L, 30_000L) != LeaseClaimResult.HELD_BY_OTHER) {
                            winners.incrementAndGet()
                        }
                    } finally {
                        done.countDown()
                    }
                }
            }
            gate.countDown()
            done.await()
            pool.shutdown()
            assertEquals(1, winners.get())

            RunCancellationFence.mark(root, runId, 999L)
            assertTrue(RunCancellationFence.isCancelled(root, runId))
            assertEquals(
                RecoveryAction.APPLY_CANCEL,
                LifecycleFaultMatrix.decide(FaultSnapshot(SovereignTaskState.RUNNING, cancelRequested = true)).action,
            )

            listOf(SovereignTaskState.COMPLETED, SovereignTaskState.CANCELLED, SovereignTaskState.FAILED_FINAL).forEach { state ->
                assertEquals(RecoveryAction.CLEANUP_TERMINAL, LifecycleFaultMatrix.decide(FaultSnapshot(state)).action)
            }

            val ambiguous = LifecycleFaultMatrix.decide(
                FaultSnapshot(
                    taskState = SovereignTaskState.WAITING_TOOL,
                    receipt = ToolReceiptStatus.STARTED,
                    toolEffect = ToolEffect.MUTATING,
                    server = ServerRunStatus.UNAVAILABLE,
                    crossedCloudToolBoundary = true,
                )
            )
            assertTrue(ambiguous.action in setOf(RecoveryAction.RECONCILE_SERVER, RecoveryAction.BLOCK_AMBIGUOUS_SIDE_EFFECT))
            assertFalse(ambiguous.mayExecuteTool)

            assertEquals(RecoveryAction.RESTORE_FINAL, LifecycleFaultMatrix.decide(FaultSnapshot(SovereignTaskState.RUNNING, server = ServerRunStatus.COMPLETED)).action)
            assertEquals(RecoveryAction.CONTINUE_MODEL, LifecycleFaultMatrix.decide(FaultSnapshot(SovereignTaskState.WAITING_TOOL, server = ServerRunStatus.TOOLS_COMPLETED)).action)

            val activeServerLease = LifecycleFaultMatrix.decide(
                FaultSnapshot(
                    taskState = SovereignTaskState.RUNNING,
                    server = ServerRunStatus.IN_PROGRESS,
                    serverRetryAfterMs = 4_000L,
                )
            )
            assertEquals(RecoveryAction.WAIT_SERVER, activeServerLease.action)
            assertEquals(4_000L, activeServerLease.delayMs)

            val expiredServerLease = LifecycleFaultMatrix.decide(
                FaultSnapshot(
                    taskState = SovereignTaskState.RUNNING,
                    server = ServerRunStatus.IN_PROGRESS,
                    serverRetryAfterMs = 0L,
                )
            )
            assertEquals(RecoveryAction.RESUME_RUN, expiredServerLease.action)
            assertTrue(expiredServerLease.mayExecuteModel)
            assertEquals(RecoveryAction.BLOCK_MISSING_REQUEST, LifecycleFaultMatrix.decide(FaultSnapshot(SovereignTaskState.RUNNING, requestPresent = false)).action)
            assertEquals(
                RecoveryAction.RESUME_RUN,
                LifecycleFaultMatrix.decide(FaultSnapshot(SovereignTaskState.RUNNING, server = ServerRunStatus.MISSING, crossedCloudToolBoundary = true)).action,
            )
            assertEquals(
                RecoveryAction.BLOCK_AMBIGUOUS_SIDE_EFFECT,
                LifecycleFaultMatrix.decide(
                    FaultSnapshot(
                        SovereignTaskState.WAITING_TOOL,
                        receipt = ToolReceiptStatus.STARTED,
                        toolEffect = ToolEffect.MUTATING,
                        server = ServerRunStatus.MISSING,
                        crossedCloudToolBoundary = true,
                    )
                ).action,
            )

            val wait = LifecycleFaultMatrix.decide(FaultSnapshot(SovereignTaskState.FAILED_RECOVERABLE, backoffRemainingMs = 9_999L))
            assertEquals(RecoveryAction.WAIT_BACKOFF, wait.action)
            assertEquals(9_999L, wait.delayMs)
            assertNotNull(DurableExecutionLeaseStore.read(root, runId))
            assertTrue(DurableExecutionLeaseStore.clearTerminal(root, runId))
            assertEquals(null, DurableExecutionLeaseStore.read(root, runId))
        } finally {
            root.deleteRecursively()
        }
    }
}
