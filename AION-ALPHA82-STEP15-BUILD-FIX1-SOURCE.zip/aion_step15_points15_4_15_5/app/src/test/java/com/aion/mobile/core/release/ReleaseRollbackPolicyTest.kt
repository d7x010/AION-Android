package com.aion.mobile.core.release

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ReleaseRollbackPolicyTest {
    @Test fun crashLoopRequiresSafeModeAndExternalRollback() {
        assertFalse(AionReleaseRollbackPolicy.evaluateStartup(1).enterSafeMode)
        val decision = AionReleaseRollbackPolicy.evaluateStartup(2)
        assertTrue(decision.enterSafeMode)
        assertTrue(decision.requestExternalRollback)
        assertEquals("startup_crash_loop", decision.reason)
    }

    @Test fun rollbackNeverTargetsUnreadableSchemas() {
        val target = listOf(RollbackSchemaRange("chat", 4, 1))
        assertFalse(AionReleaseRollbackPolicy.storageCompatible(mapOf("chat" to 5), target))
        assertTrue(AionReleaseRollbackPolicy.storageCompatible(mapOf("chat" to 4), target))
    }

    @Test fun rollbackBuildUsesMonotonicVersionCode() {
        assertEquals(57, AionReleaseRollbackPolicy.nextRollbackVersionCode(56, 56))
        assertEquals(61, AionReleaseRollbackPolicy.nextRollbackVersionCode(60, 56))
    }
}
