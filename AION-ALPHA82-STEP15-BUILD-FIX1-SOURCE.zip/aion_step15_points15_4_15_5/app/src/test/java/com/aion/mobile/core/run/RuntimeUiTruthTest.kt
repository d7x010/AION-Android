package com.aion.mobile.core.run

import com.aion.mobile.core.ai.GatewayActivity
import com.aion.mobile.core.sovereign.SovereignTask
import com.aion.mobile.core.sovereign.SovereignTaskState
import com.aion.mobile.core.sovereign.TaskCheckpoint
import com.aion.mobile.core.run.fault.ToolEffect
import com.aion.mobile.core.run.fault.ToolReceiptStatus
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class RuntimeUiTruthTest {
    private fun task(
        state: SovereignTaskState,
        activity: GatewayActivity? = null,
        reason: String? = null,
    ) = SovereignTask(
        id = "run-test",
        goal = "chat:test",
        state = state,
        checkpoint = activity?.let {
            TaskCheckpoint(
                savedAt = "2026-09-12T00:00:00Z",
                state = state,
                stepId = "test",
                payload = mapOf("activity" to it.name),
            )
        },
        blockedReason = reason,
    )

    @Test
    fun waitingNetworkNeverPretendsToBeThinking() {
        val truth = RuntimeUiTruthMapper.from(task(SovereignTaskState.WAITING_NETWORK, reason = "offline"))
        assertEquals("بانتظار الشبكة", truth.label)
        assertEquals(RuntimeUiPhase.WAITING_NETWORK, truth.phase)
        assertFalse(truth.liveExecution)
        assertFalse(truth.terminal)
    }

    @Test
    fun realGatewayActivityControlsRunningLabel() {
        assertEquals(
            RuntimeUiPhase.SEARCHING_WEB,
            RuntimeUiTruthMapper.from(task(SovereignTaskState.RUNNING, GatewayActivity.SEARCHING_WEB)).phase,
        )
        assertEquals(
            "جار قراءة الملف",
            RuntimeUiTruthMapper.from(task(SovereignTaskState.RUNNING, GatewayActivity.READING_FILES)).label,
        )
    }

    @Test
    fun verifyingAndTerminalStatesMapExactly() {
        assertEquals("جار التحقق", RuntimeUiTruthMapper.from(task(SovereignTaskState.VERIFYING)).label)
        val cancelled = RuntimeUiTruthMapper.from(task(SovereignTaskState.CANCELLED))
        assertTrue(cancelled.terminal)
        assertFalse(cancelled.canStop)
        assertEquals("تم الإيقاف", cancelled.label)
    }

    @Test
    fun waitingToolUsesDurableReceiptTruth() {
        val receiptWaiting = RuntimeUiTruthMapper.from(
            task(SovereignTaskState.WAITING_TOOL),
            toolCallId = "server-tool-plan",
            toolStatus = ToolReceiptStatus.STARTED,
            toolEffect = ToolEffect.READ_ONLY,
        )
        assertEquals("بانتظار نتيجة الأداة", receiptWaiting.label)
        assertFalse(receiptWaiting.liveExecution)

        val ambiguous = RuntimeUiTruthMapper.from(
            task(SovereignTaskState.WAITING_TOOL),
            toolStatus = ToolReceiptStatus.UNKNOWN,
            toolEffect = ToolEffect.MUTATING,
        )
        assertEquals("جار التحقق من نتيجة الأداة", ambiguous.label)
    }

    @Test
    fun persistedRunningWithoutObservedLeaseDoesNotPretendCoroutineIsAlive() {
        val running = RuntimeUiTruthMapper.from(task(SovereignTaskState.RUNNING, GatewayActivity.WRITING))
        val restoredAfterProcessDeath = RuntimeLivenessPolicy.apply(running, observedExecutionLease = false)
        assertFalse(restoredAfterProcessDeath.liveExecution)
        assertEquals("بانتظار استئناف التنفيذ", restoredAfterProcessDeath.label)
    }

    @Test
    fun toolMetadataIsUsedWithoutInventingToolWork() {
        val fileTool = RuntimeUiTruthMapper.from(
            task(SovereignTaskState.WAITING_TOOL),
            toolCallId = "file.reader",
        )
        assertEquals(RuntimeUiPhase.READING_FILE, fileTool.phase)
        assertEquals("جار قراءة الملف", fileTool.label)

        val unknown = RuntimeUiTruthMapper.from(task(SovereignTaskState.WAITING_TOOL))
        assertEquals(RuntimeUiPhase.WAITING_TOOL, unknown.phase)
        assertEquals("بانتظار الأداة", unknown.label)
    }
}
