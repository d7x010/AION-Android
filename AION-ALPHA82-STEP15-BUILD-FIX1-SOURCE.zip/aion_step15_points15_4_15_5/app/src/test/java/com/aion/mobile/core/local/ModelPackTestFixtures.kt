package com.aion.mobile.core.local

import java.io.File

internal object ModelPackTestFixtures {
    val acceptingVerifier = object : ModelPackSignatureVerifier {
        override fun verify(file: File, descriptor: LocalModelPackDescriptor, signature: String): Boolean =
            signature == "test-signature" && descriptor.provenance != null
    }

    fun provenance(id: String): ModelPackProvenance = ModelPackProvenance(
        sourceType = ModelPackSourceType.BUNDLED_RELEASE,
        sourceUri = "bundled://aion-test/$id",
        publisher = "AION Test Publisher",
        acquiredAtEpochMs = 1L,
        issuedAtEpochMs = 1L,
        manifestSha256 = "0".repeat(64),
        signatureAlgorithm = "Ed25519",
        signerKeyId = "test-key-v1",
    )

    fun descriptor(
        id: String,
        expectedSizeBytes: Long,
        sha256: String,
        requirements: LocalModelRequirements = LocalModelRequirements(
            modelId = id,
            minimumAvailableRamBytes = 64L * ResourceGovernor.MIB,
            estimatedResidentBytes = 64L * ResourceGovernor.MIB,
            minimumFreeStorageBytes = 1L,
            allowBackground = true,
        ),
    ): LocalModelPackDescriptor = ModelPackSupplyChainPolicy.seal(
        LocalModelPackDescriptor(
            modelId = id,
            version = "1",
            expectedSizeBytes = expectedSizeBytes,
            sha256 = sha256,
            signature = "test-signature",
            requireSignature = true,
            provenance = provenance(id),
            requirements = requirements,
        )
    )
}
