# AION — Step 14.7 Rollback / Last Known Good

الحالة: مكتملة محليًا كنقطة مستقلة. لم يبدأ 14.8.

## ما تغير

- أضيف `AionReleaseRollbackPolicy` لعقد rollback الصريح:
  - بعد crash-loop (فشلان متتاليان أثناء startup) يدخل AION Safe Mode ويطلب rollback خارجيًا.
  - لا يوجد APK self-downgrade ولا schema downgrade تلقائي.
  - rollback الثنائي الصحيح = إعادة بناء Last Known Good source مع `versionCode` أعلى من النسخة المثبتة.
  - rollback يُرفض إذا كان LKG لا يستطيع قراءة أي schema كتبتها النسخة الحالية.
- تم ربط `StartupCrashGuard` بالعقد الجديد:
  - يسجل `rollback_requested` وسبب الطلب عند crash-loop.
  - `markStable()` يمسح طلب rollback بعد launch مستقر.
  - لا يحذف بيانات المستخدم.
- أضيف `release/LAST_KNOWN_GOOD.json` كمؤشر آلي إلى Snapshot 14.6 المثبت:
  - `AION-ALPHA82-STEP14-POINT14.6-SOURCE.zip`
  - SHA-256: `a8273c023a64cc8eeccd38a45eaf5f86efa6808408d78b06683d731957095b02`
  - applicationId/version/schema ranges مثبتة داخل manifest.
- أضيف `tools/release/aion_rollback_gate.py`:
  - يتحقق من SHA للـLKG الحقيقي.
  - يقرأ build metadata وStorageSchemaRegistry من داخل ZIP نفسه.
  - يفرض نفس applicationId.
  - يرفض target غير القادر على قراءة schemas الحالية.
  - يولد versionCode جديدًا تصاعديًا لخطة rollback بدل downgrade.
- أضيف `release/ROLLBACK_POLICY_AR.md` لتوثيق السياسة.
- أضيف اختبار JVM + JUnit لعقد rollback.

## الاختبارات

- `AION_ROLLBACK_GATE_PASS`
  - LKG SHA الفعلي يطابق manifest.
  - schema compatibility = PASS.
  - rollback rebuild versionCode = 57 للمصدر الحالي code 56.
- `STEP14_14_7_ROLLBACK_POLICY_PASS`
- `STEP14_14_7_STARTUP_CRASH_GUARD_PASS`
- `STEP14_14_7_JUNIT_SOURCE_COMPILE_PASS`
- `STEP14_14_7_TAMPER_FAIL_CLOSED_PASS`
- `STEP14_14_7_NO_DESTRUCTIVE_ROLLBACK_PASS`
- `AION_SECURITY_GATE_PASS`
- `AION_SUPPLY_CHAIN_GATE_PASS`
- Consistency Recovery JVM regression: PASS.
- Worker syntax: PASS.
- Worker idempotency: PASS.
- Sandbox policy: PASS.
- Worker regression: PASS.

## حدود البيئة

- لا يوجد Gradle/Android SDK/ADB كامل في هذه البيئة؛ لذلك لا يوجد ادعاء build APK أو install/upgrade/downgrade على جهاز.
- AION لا يستطيع ولا يجب أن يخفض APK المثبت ذاتيًا. rollback الفعلي في قناة توزيع مثل Play يجب أن يعيد بناء LKG source مع versionCode جديد أعلى؛ Step 15 هو مكان build artifact الحقيقي.
- لم يبدأ Full Regression الخاص بـ14.8 بعد.

## الإصدار

لم يتغير عمدًا:
- `versionName = 2.0.0-alpha8.2-dev1`
- `versionCode = 56`

## نقطة الاستئناف

بعد حفظ هذا Snapshot والتحقق منه، النقطة التالية فقط هي **14.8 — Full Regression**.
