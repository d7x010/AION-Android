import assert from "node:assert/strict";
import worker, { AionRunDurableObject } from "./src/index.js";

class MemoryStorage {
  constructor() { this.map = new Map(); }
  async get(key) { return this.map.get(key); }
  async put(key, value) {
    const storedBytes = new TextEncoder().encode(JSON.stringify(value)).byteLength;
    if (storedBytes >= 1_900_000) throw new Error(`simulated_single_value_limit:${storedBytes}`);
    this.map.set(key, structuredClone(value));
  }
}
class FakeState {
  constructor(storage = new MemoryStorage()) { this.storage = storage; this.pending = []; }
  waitUntil(promise) { this.pending.push(Promise.resolve(promise)); }
  async flush() { await Promise.allSettled(this.pending.splice(0)); }
}
class FakeDurableNamespace {
  constructor(baseEnv) { this.baseEnv = baseEnv; this.instances = new Map(); }
  idFromName(name) { return name; }
  get(id) {
    if (!this.instances.has(id)) {
      const state = new FakeState();
      const instance = new AionRunDurableObject(state, this.baseEnv);
      this.instances.set(id, { state, instance });
    }
    return { fetch: (request) => this.instances.get(id).instance.fetch(request) };
  }
  entry(id) { return this.instances.get(id); }
  async flushAll() { for (const { state } of this.instances.values()) await state.flush(); }
}

async function digest(text) {
  const bytes = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(text));
  return [...new Uint8Array(bytes)].map((b) => b.toString(16).padStart(2, "0")).join("");
}

function chatRequest(body, key, path = "/v1/chat") {
  return new Request(`https://aion.test${path}`, {
    method: "POST",
    headers: { "content-type": "application/json", "Idempotency-Key": key },
    body,
  });
}

let aiCalls = 0;
const baseEnv = {
  AI: {
    run: async () => {
      aiCalls += 1;
      return { response: "نتيجة ثابتة" };
    },
    toMarkdown: async () => ({ data: "" }),
  },
};
const ns = new FakeDurableNamespace(baseEnv);
const env = { ...baseEnv, AION_RUNS: ns };
const body = JSON.stringify({ mode: "fast", messages: [{ role: "user", content: "اختبار idempotency" }] });
const key = "run-idempotency-0001";

const first = await worker.fetch(chatRequest(body, key), env);
assert.equal(first.status, 200);
const firstText = await first.text();
assert.match(firstText, /نتيجة ثابتة/);
assert.equal(aiCalls, 1);

const second = await worker.fetch(chatRequest(body, key), env);
assert.equal(second.status, 200);
assert.equal(await second.text(), firstText);
assert.equal(second.headers.get("x-aion-idempotent-replay"), "1");
assert.equal(aiCalls, 1, "same key+payload must not reexecute model");

const conflict = await worker.fetch(chatRequest(JSON.stringify({ mode: "fast", messages: [{ role: "user", content: "طلب مختلف" }] }), key), env);
assert.equal(conflict.status, 409);
assert.equal(aiCalls, 1);

const status = await worker.fetch(new Request("https://aion.test/v1/run/status", { headers: { "Idempotency-Key": key } }), env);
assert.equal(status.status, 200);
assert.equal((await status.json()).state, "COMPLETED");

const missingKey = "run-idempotency-missing";
const missing = await worker.fetch(new Request("https://aion.test/v1/run/status", { headers: { "Idempotency-Key": missingKey } }), env);
assert.equal(missing.status, 404);
assert.equal((await missing.json()).state, "MISSING");

const busyKey = "run-idempotency-busy01";
const busyNsEntry = ns.get(busyKey); // create instance
const busyEntry = ns.entry(busyKey);
await busyEntry.state.storage.put("run", {
  schema: 1, key: busyKey, digest: await digest(body), state: "IN_PROGRESS", phase: "STARTED",
  leaseOwner: "other", leaseUntil: Date.now() + 30_000, updatedAt: Date.now(), responseStatus: 0,
  responseBody: "", contentType: "", resultDigest: "", error: "", toolSnapshot: null,
});
const busy = await worker.fetch(chatRequest(body, busyKey), env);
assert.equal(busy.status, 425);
assert.ok(Number(busy.headers.get("Retry-After")) >= 1);
assert.equal(aiCalls, 1);

// Recovery from durable TOOLS_COMPLETED must reuse the persisted tool snapshot and execute model only.
const toolsKey = "run-idempotency-tools01";
ns.get(toolsKey);
const toolsEntry = ns.entry(toolsKey);
await toolsEntry.state.storage.put("run", {
  schema: 1, key: toolsKey, digest: await digest(body), state: "TOOLS_COMPLETED", phase: "TOOLS_COMPLETED",
  leaseOwner: "", leaseUntil: 0, updatedAt: Date.now() - 10_000, responseStatus: 0,
  responseBody: "", contentType: "", resultDigest: "", error: "",
  toolSnapshot: { sources: [], context: "persisted-tool-context", metadata: { route: "sentinel-cached-tool", status: "succeeded" } },
});
const callsBeforeToolsResume = aiCalls;
const toolsResume = await worker.fetch(chatRequest(body, toolsKey), env);
assert.equal(toolsResume.status, 200);
const toolsResumeJson = await toolsResume.json();
assert.equal(toolsResumeJson.toolExecution.route, "sentinel-cached-tool");
assert.equal(aiCalls, callsBeforeToolsResume + 1, "TOOLS_COMPLETED must continue model exactly once");
const toolsStatus = await worker.fetch(new Request("https://aion.test/v1/run/status", { headers: { "Idempotency-Key": toolsKey } }), env);
assert.equal((await toolsStatus.json()).state, "COMPLETED");

// A completed read-only tool run must persist its tool receipt and snapshot before the model finishes.
const toolReceiptKey = "run-idempotency-receipt01";
const calculatorBody = JSON.stringify({ mode: "fast", messages: [{ role: "user", content: "احسب 2+2" }] });
const receiptCallsBefore = aiCalls;
const receiptResponse = await worker.fetch(chatRequest(calculatorBody, toolReceiptKey), env);
assert.equal(receiptResponse.status, 200);
await receiptResponse.text();
assert.equal(aiCalls, receiptCallsBefore + 1);
const receiptRecord = await ns.entry(toolReceiptKey).state.storage.get("run");
assert.equal(receiptRecord.toolReceipt?.status, "COMPLETED");
assert.equal(receiptRecord.toolReceipt?.effect, "READ_ONLY");
assert.match(String(receiptRecord.toolReceipt?.planDigest || ""), /^[a-f0-9]{64}$/);
assert.match(String(receiptRecord.toolReceipt?.resultDigest || ""), /^[a-f0-9]{64}$/);
assert.ok(receiptRecord.toolSnapshot, "tool snapshot must be durable before final response");
const receiptStatusResponse = await worker.fetch(new Request("https://aion.test/v1/run/status", { headers: { "Idempotency-Key": toolReceiptKey } }), env);
const receiptStatusJson = await receiptStatusResponse.json();
assert.equal(receiptStatusJson.toolReceipt?.status, "COMPLETED");
assert.equal(receiptStatusJson.toolReceipt?.effect, "READ_ONLY");
assert.equal(receiptStatusJson.toolReceipt?.planDigest, receiptRecord.toolReceipt.planDigest);
assert.equal(receiptStatusJson.toolReceipt?.resultDigest, receiptRecord.toolReceipt.resultDigest);

// An expired mutating STARTED/UNKNOWN receipt is ambiguous: fail closed and never replay it.
const ambiguousKey = "run-idempotency-ambiguous01";
ns.get(ambiguousKey);
const ambiguousEntry = ns.entry(ambiguousKey);
await ambiguousEntry.state.storage.put("run", {
  schema: 1, key: ambiguousKey, digest: await digest(body), state: "IN_PROGRESS", phase: "TOOLS_STARTED",
  leaseOwner: "dead-owner", leaseUntil: Date.now() - 1_000, updatedAt: Date.now() - 5_000,
  responseStatus: 0, responseBody: "", contentType: "", resultDigest: "", error: "", toolSnapshot: null,
  toolReceipt: { status: "STARTED", effect: "MUTATING", planDigest: "sentinel", resultDigest: "", updatedAt: Date.now() - 5_000 },
});
const callsBeforeAmbiguous = aiCalls;
const ambiguous = await worker.fetch(chatRequest(body, ambiguousKey), env);
assert.equal(ambiguous.status, 409);
assert.match(await ambiguous.text(), /ambiguous_mutating_tool/);
assert.equal(aiCalls, callsBeforeAmbiguous, "ambiguous mutating tool must never be replayed");
const ambiguousRecord = await ambiguousEntry.state.storage.get("run");
assert.equal(ambiguousRecord.state, "FAILED");
assert.equal(ambiguousRecord.toolReceipt.status, "UNKNOWN");
const ambiguousReplay = await worker.fetch(chatRequest(body, ambiguousKey), env);
assert.equal(ambiguousReplay.status, 409);
assert.equal(aiCalls, callsBeforeAmbiguous, "blocked ambiguous run must remain terminal");

// Exact streaming replay: the second call must return byte-identical SSE without a second model invocation.
let streamCalls = 0;
const encoder = new TextEncoder();
const streamEnvBase = {
  AI: {
    run: async () => {
      streamCalls += 1;
      return new ReadableStream({
        start(controller) {
          controller.enqueue(encoder.encode('data: {"response":"abc"}\n\ndata: [DONE]\n\n'));
          controller.close();
        },
      });
    },
    toMarkdown: async () => ({ data: "" }),
  },
};
const streamNs = new FakeDurableNamespace(streamEnvBase);
const streamEnv = { ...streamEnvBase, AION_RUNS: streamNs };
const streamKey = "run-idempotency-stream1";
const s1 = await worker.fetch(chatRequest(body, streamKey, "/v1/chat/stream"), streamEnv);
const s1Text = await s1.text();
await streamNs.flushAll();
const s2 = await worker.fetch(chatRequest(body, streamKey, "/v1/chat/stream"), streamEnv);
const s2Text = await s2.text();
assert.equal(s2Text, s1Text);
assert.equal(streamCalls, 1);
assert.equal(s2.headers.get("x-aion-idempotent-replay"), "1");

// A completed SSE run must be replayable through /v1/chat as canonical JSON,
// without invoking the model a second time.
const streamToSync = await worker.fetch(chatRequest(body, streamKey, "/v1/chat"), streamEnv);
assert.equal(streamToSync.status, 200);
assert.match(String(streamToSync.headers.get("content-type") || ""), /application\/json/);
const streamToSyncJson = await streamToSync.json();
assert.equal(streamToSyncJson.response, "abc");
assert.equal(streamCalls, 1, "SSE -> sync fallback must replay, not reexecute");

// Retryable failures must retain their original execution status through /run/status
// and remain resumable with the same idempotency key.
let transientAvailable = false;
let transientCalls = 0;
const transientBase = {
  AI: {
    run: async () => {
      transientCalls += 1;
      if (!transientAvailable) throw new Error("temporary model outage");
      return { response: "تعافى التنفيذ" };
    },
    toMarkdown: async () => ({ data: "" }),
  },
};
const transientNs = new FakeDurableNamespace(transientBase);
const transientEnv = { ...transientBase, AION_RUNS: transientNs };
const transientKey = "run-idempotency-transient01";
const transientFirst = await worker.fetch(chatRequest(body, transientKey), transientEnv);
assert.equal(transientFirst.status, 502);
const transientRecord = await transientNs.entry(transientKey).state.storage.get("run");
assert.equal(transientRecord.state, "FAILED_RECOVERABLE");
assert.equal(transientRecord.responseStatus, 502);
const transientStatus = await worker.fetch(new Request("https://aion.test/v1/run/status", { headers: { "Idempotency-Key": transientKey } }), transientEnv);
const transientStatusJson = await transientStatus.json();
assert.equal(transientStatusJson.state, "FAILED_RECOVERABLE");
assert.equal(transientStatusJson.responseStatus, 502, "status endpoint must not turn a 5xx into 200");
transientAvailable = true;
const transientRecovered = await worker.fetch(chatRequest(body, transientKey), transientEnv);
assert.equal(transientRecovered.status, 200);
assert.equal((await transientRecovered.json()).response, "تعافى التنفيذ");
assert.ok(transientCalls > 1, "same key should resume after a retryable failure");

// A final response larger than one Durable Object value must spill into bounded chunks
// and replay byte-for-byte without a second model invocation.
let largeCalls = 0;
const largeText = "AION-كبير-" + "x".repeat(2_350_000);
const largeBase = {
  AI: {
    run: async () => {
      largeCalls += 1;
      return { response: largeText };
    },
    toMarkdown: async () => ({ data: "" }),
  },
};
const largeNs = new FakeDurableNamespace(largeBase);
const largeEnv = { ...largeBase, AION_RUNS: largeNs };
const largeKey = "run-idempotency-large01";
const largeFirst = await worker.fetch(chatRequest(body, largeKey), largeEnv);
assert.equal(largeFirst.status, 200);
const largeFirstJson = await largeFirst.json();
assert.equal(largeFirstJson.response, largeText);
assert.equal(largeCalls, 1);
const largeRecord = await largeNs.entry(largeKey).state.storage.get("run");
assert.equal(largeRecord.responseBody, "");
assert.ok(largeRecord.responseBodyRef?.chunks >= 2, "large response must be chunked");
for (let index = 0; index < largeRecord.responseBodyRef.chunks; index += 1) {
  const chunk = await largeNs.entry(largeKey).state.storage.get(`${largeRecord.responseBodyRef.prefix}${index}`);
  assert.ok(typeof chunk === "string" && chunk.length > 0);
}
const largeReplay = await worker.fetch(chatRequest(body, largeKey), largeEnv);
assert.equal(largeReplay.status, 200);
assert.equal((await largeReplay.json()).response, largeText);
assert.equal(largeCalls, 1, "chunked replay must not reexecute model");

console.log("AION worker idempotency tests: PASS");
