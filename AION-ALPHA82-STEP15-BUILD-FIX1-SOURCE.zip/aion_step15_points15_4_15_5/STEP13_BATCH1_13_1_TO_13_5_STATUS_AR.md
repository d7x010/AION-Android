# AION — Step 13 / Batch 1 (13.1 → 13.5)

التاريخ: 2026-09-12
الحالة: GREEN ضمن بوابات البيئة المحلية الحالية.
المرجع السابق: `AION-ALPHA82-STEP12-COMPLETE-SOURCE.zip`.

## النطاق المنفذ

### 13.1 — Runtime Truth → UI Projection
- إضافة `RuntimeUiTruth` و`RuntimeUiTruthMapper` كمصدر واحد لتحويل `SovereignTask` إلى حالة واجهة عربية.
- الحالات المدعومة تشمل: planning/running/search/files/comparing/writing/verifying/waiting-network/waiting-tool/waiting-user/paused/blocked/completed/failed/cancelled.
- لا يتم كشف chain-of-thought؛ المعروض هو نشاط runtime المرصود فقط.
- `WAITING_NETWORK` لا يمكن أن يظهر كـ«جار التفكير».

### 13.2 — Process Recreation من التخزين الدائم
- إضافة `AionRunUiRestorer`.
- إعادة بناء run من `AionRunRequestStore` + `SovereignTaskStore` + `DurableToolReceiptStore` + `ChatSessionStore`.
- `ChatViewModel` لا يعتمد على `AionRunBus/StateFlow` وحده عند الإقلاع؛ يبحث عن run قابل للاسترجاع للمحادثة النشطة.
- فتح محادثة أخرى يعيد فحص runtime الدائم قبل اعتبار streaming القديم متوقفًا.

### 13.3 — Tool/Search Activity من metadata الحقيقي
- `GatewayActivity` الموجود في checkpoint هو مصدر نشاط البحث/قراءة الملفات/المقارنة/الكتابة.
- Job recovery أصبح يحفظ activity checkpoint وينشر الحقيقة الدائمة أثناء recovery.
- Tool label يستخدم toolCallId فقط إذا كان موجودًا فعليًا؛ عند غيابه لا تُخترع أداة وهمية.

### 13.4 — Partial Answer Restore
- `AionRunUiRestorer` يقرأ رسالة placeholder من `ChatSessionStore.loadMessages`، والذي يدمج streaming sidecar الذري.
- partial text يبقى ظاهرًا بعد process death/recovery.
- `liveExecution` منفصل عن كون المهمة غير terminal؛ لذلك WAITING_NETWORK/PAUSED لا يدّعيان أن coroutine ما زالت تكتب.

### 13.5 — Durable Stop / Cancellation Fence
- Stop يكتب `RunCancellationFence` أولًا.
- ثم يحول `SovereignTask` إلى CANCELLED في التخزين الدائم.
- ثم يحول آخر partial checkpoint إلى رسالة `wasStopped=true / isStreaming=false` قبل إرسال إشارة Service.
- Job recovery يفعل الشيء نفسه عند اكتشاف durable cancel.
- هذا يغطي cancel بعد process death حتى لو لم توجد Service حية لتنفذ catch/finally.

## ربط الواجهة
- `ChatViewModel.runtimeUiTruth` أصبح مرتبطًا بالـruntime الدائم.
- الحالات غير الحية مثل WAITING_NETWORK/PAUSED/BLOCKED تظهر كسطر حالة مستقل بدل bubble يوحي بكتابة حية.
- مؤشر الرد الحي يستخدم `runtimeUiTruth.asActivityState()` عند توفره.
- بداية run جديد تمسح terminal truth القديم لمنع flicker لحالة سابقة.

## الاختبارات المنفذة
- `STEP13_BATCH1_RUNTIME_MAPPING_PASS`
- `STEP13_BATCH1_RESTORE_CANCEL_PASS`
- `STEP13_BATCH1_JUNIT_SOURCE_COMPILE_PASS`
- `STEP13_BATCH1_COORDINATOR_COMPILE_PASS`
- `STEP13_BATCH1_INTEGRATION_SANITY_PASS`

تم اختبار mapping للحالات المطلوبة، process recreation، partial restore، cancel terminalization، وترتيب cancellation fence قبل Service signal.

## قيود البيئة
- لا يوجد Gradle/Android SDK/ADB كامل في البيئة الحالية؛ لذلك لا يُدعى APK build أو device test.
- compile checks الحالية مركزة باستخدام Kotlin compiler + stubs خارج المشروع ولا تغير كود الإنتاج.

## نقطة الاستئناف التالية
ابدأ من 13.6 وما بعدها فقط بعد التحقق من Snapshot هذه الدفعة.
