import com.aion.mobile.core.run.*
import com.aion.mobile.core.run.fault.*
import com.aion.mobile.core.sovereign.*
import java.io.File
import java.nio.file.Files
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger

fun main() {
    val root = Files.createTempDirectory("aion-consistency-test").toFile()
    val runId = "run_test_12345678"

    // persistence round-trip: backoff + durable tool receipt
    DurableBackoffStore.setNotBefore(root, runId, 123456789L)
    check(DurableBackoffStore.getNotBefore(root, runId) == 123456789L)
    val prepared = DurableToolReceiptStore.prepare(root, runId, "tool-1", ToolEffect.MUTATING, "{\"x\":1}")
    check(DurableToolReceiptStore.read(root, runId, "tool-1") == prepared)
    val started = DurableToolReceiptStore.mark(root, prepared, ToolReceiptStatus.STARTED)
    check(DurableToolReceiptStore.read(root, runId, "tool-1")?.status == ToolReceiptStatus.STARTED)
    val completed = DurableToolReceiptStore.mark(root, started, ToolReceiptStatus.COMPLETED, "ok")
    check(completed.resultDigest.isNotBlank())

    // Authoritative server receipt is mirrored into Android durable storage and wins by timestamp.
    val serverPlanDigest = "a".repeat(64)
    val serverResultDigest = "b".repeat(64)
    val mirrored = DurableToolReceiptStore.mirrorServer(
        root = root,
        runId = runId,
        status = "STARTED",
        effect = "MUTATING",
        planDigest = serverPlanDigest,
        resultDigest = "",
        updatedAtMs = 10_000L,
    )
    check(mirrored?.status == ToolReceiptStatus.STARTED)
    check(mirrored?.effect == ToolEffect.MUTATING)
    check(mirrored?.inputDigest == serverPlanDigest)
    val mirroredCompleted = DurableToolReceiptStore.mirrorServer(
        root = root,
        runId = runId,
        status = "COMPLETED",
        effect = "MUTATING",
        planDigest = serverPlanDigest,
        resultDigest = serverResultDigest,
        updatedAtMs = 20_000L,
    )
    check(mirroredCompleted?.status == ToolReceiptStatus.COMPLETED)
    check(mirroredCompleted?.resultDigest == serverResultDigest)

    // lease takeover after expiry
    check(DurableExecutionLeaseStore.acquire(root, runId, "owner-a", 1_000L, 2_000L) == LeaseClaimResult.ACQUIRED)
    check(DurableExecutionLeaseStore.acquire(root, runId, "owner-b", 2_000L, 2_000L) == LeaseClaimResult.HELD_BY_OTHER)
    check(DurableExecutionLeaseStore.acquire(root, runId, "owner-b", 3_001L, 2_000L) == LeaseClaimResult.ACQUIRED)

    // 32-way race -> exactly one winner
    val raceId = "run_race_12345678"
    val pool = Executors.newFixedThreadPool(32)
    val gate = CountDownLatch(1)
    val done = CountDownLatch(32)
    val winners = AtomicInteger(0)
    repeat(32) { index ->
        pool.submit {
            try {
                gate.await()
                if (DurableExecutionLeaseStore.acquire(root, raceId, "owner-$index", 10_000L, 30_000L) != LeaseClaimResult.HELD_BY_OTHER) {
                    winners.incrementAndGet()
                }
            } finally {
                done.countDown()
            }
        }
    }
    gate.countDown(); done.await(); pool.shutdown()
    check(winners.get() == 1) { "lease winners=${winners.get()}" }

    // durable cancellation vs restart
    RunCancellationFence.mark(root, runId, 999L)
    check(RunCancellationFence.isCancelled(root, runId))
    check(LifecycleFaultMatrix.decide(FaultSnapshot(SovereignTaskState.RUNNING, cancelRequested = true)).action == RecoveryAction.APPLY_CANCEL)

    // terminal never resumes
    for (state in listOf(SovereignTaskState.COMPLETED, SovereignTaskState.CANCELLED, SovereignTaskState.FAILED_FINAL)) {
        check(LifecycleFaultMatrix.decide(FaultSnapshot(state)).action == RecoveryAction.CLEANUP_TERMINAL)
    }

    // ambiguous mutation never locally replays
    val ambiguous = LifecycleFaultMatrix.decide(FaultSnapshot(
        taskState = SovereignTaskState.WAITING_TOOL,
        receipt = ToolReceiptStatus.STARTED,
        toolEffect = ToolEffect.MUTATING,
        server = ServerRunStatus.UNAVAILABLE,
        crossedCloudToolBoundary = true,
    ))
    check(ambiguous.action in setOf(RecoveryAction.RECONCILE_SERVER, RecoveryAction.BLOCK_AMBIGUOUS_SIDE_EFFECT))
    check(!ambiguous.mayExecuteTool)

    // authoritative server states
    check(LifecycleFaultMatrix.decide(FaultSnapshot(SovereignTaskState.RUNNING, server = ServerRunStatus.COMPLETED)).action == RecoveryAction.RESTORE_FINAL)
    check(LifecycleFaultMatrix.decide(FaultSnapshot(SovereignTaskState.WAITING_TOOL, server = ServerRunStatus.TOOLS_COMPLETED)).action == RecoveryAction.CONTINUE_MODEL)
    check(LifecycleFaultMatrix.decide(FaultSnapshot(SovereignTaskState.RUNNING, requestPresent = false)).action == RecoveryAction.BLOCK_MISSING_REQUEST)

    // Server MISSING is authoritative and does not create endless reconciliation for a normal run.
    check(LifecycleFaultMatrix.decide(FaultSnapshot(
        SovereignTaskState.RUNNING,
        server = ServerRunStatus.MISSING,
        crossedCloudToolBoundary = true,
    )).action == RecoveryAction.RESUME_RUN)

    // But server MISSING after a started mutating tool fails closed.
    check(LifecycleFaultMatrix.decide(FaultSnapshot(
        SovereignTaskState.WAITING_TOOL,
        receipt = ToolReceiptStatus.STARTED,
        toolEffect = ToolEffect.MUTATING,
        server = ServerRunStatus.MISSING,
        crossedCloudToolBoundary = true,
    )).action == RecoveryAction.BLOCK_AMBIGUOUS_SIDE_EFFECT)

    // durable not-before survives restart decision
    val wait = LifecycleFaultMatrix.decide(FaultSnapshot(SovereignTaskState.FAILED_RECOVERABLE, backoffRemainingMs = 9_999L))
    check(wait.action == RecoveryAction.WAIT_BACKOFF && wait.delayMs == 9_999L)

    root.deleteRecursively()
    println("AION Consistency Recovery JVM self-test: PASS")
}
