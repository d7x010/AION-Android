# AION α8.3 — نقطة 21: Home shell

- بقيت Home شاشة ترحيب هادئة وليست Dashboard.
- صغرت Core إلى 40dp، وخُفضت الاقتراحات الظاهرة إلى 3 فقط عبر `HomePolicy`.
- لم أضف New Work مزيفًا؛ مدخل New Work الحقيقي سيُنفذ في نقطته المخصصة بعد وجود flow goal-first فعلي.
- `HomePolicyTest.kt`: test authored, execution pending CI.
- Gradle/Android tests: execution pending CI.
