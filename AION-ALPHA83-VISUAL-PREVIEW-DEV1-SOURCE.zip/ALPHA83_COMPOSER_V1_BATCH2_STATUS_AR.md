# AION α8.3 — Composer V1 / الدفعة الثانية

التاريخ: 2026-09-13

## التغيير

- أضيفت `ComposerLayoutPolicy` لاختيار 12dp عند عرض أقل من 360dp و16dp في العرض الطبيعي/الأوسع.
- أضيف `AionComposerFrame` لاحتواء Insets النظام والـIME واستخدام سياسة الهوامش نفسها.
- بقيت أزرار الإرفاق والإرسال والإملاء وAION Live متصلة بالـcallbacks السابقة نفسها.

## التحقق

- أضيفت حالة الاختبار إلى `ComposerPolicyTest.kt` قبل تنفيذ السياسة.
- لا يتوفر Gradle أو Android SDK محليًا؛ كل اختبارات Gradle وAndroid: `execution pending CI`.
- Snapshot السابقة لا تتضمن هذه النقطة؛ هذه الحالة يجب حفظها كـcheckpoint مستقلة بعد structural checks.
