# AION α8.3 — نقطة 22: Recent-first

- تعرض Home أحدث 3 محادثات فقط وبترتيب `updatedAt` تنازليًا عندما تكون المحادثة الحالية فارغة.
- فتح عنصر حديث يستخدم `switchConversation` نفسه ويحترم قفل AION Live؛ لم تُمس المحادثات المخزنة أو الاستمرارية.
- `HomePolicyTest.kt`: test authored, execution pending CI.
- Gradle/Android tests: execution pending CI.
