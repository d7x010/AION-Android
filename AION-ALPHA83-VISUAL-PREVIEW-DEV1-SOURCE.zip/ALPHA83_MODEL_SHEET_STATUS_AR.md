# AION α8.3 — Model Sheet Checkpoint

- توجد `AionSheetStack` واحدة منشأة في `AionApp` وتُمرر إلى `AionChatScreen` ثم `ChatComposer`.
- Add وModels تُرسمان عبر `AionSheetHost` واحد.
- نُقلت واجهة Model الأصلية و`ModelGlyph` إلى `ui/components/AionModelSheet.kt`.
- اختيار النموذج يستخدم `chatViewModel::selectModel` الأصلية ثم يغلق الـstack.
- أزيلت `showModelPicker` وواجهة Model القديمة من `AionApp.kt`.
- مسارا `imagePicker` و`filePicker` لم يتغيرا.
- فحوصات call sites البنيوية نجحت محليًا؛ لا توجد Model modal قديمة أو stack محلية ثانية.
- Back داخل stack يستخدم `back()`، بينما إغلاق الجذر يستخدم `dismiss()`.
- اختبارات Gradle: execution pending CI.
- Library upload pending بسبب: "Codex Library manage upload requires the top-level file bridge parameter."
- هذه checkpoint محلية وليست نسخة دائمة في Library حتى ينجح الرفع.
