# AION α8.3 — Sheet System + Design Tokens Checkpoint

## Sheet System
- مصدر الحقيقة الوحيد هو `AionSheetStack` المنشأ في `AionApp`.
- Add وControl وPower وEffort وModels وResearch وPermissions وContext تمر عبر `AionSheetHost` واحد.
- نُقلت Add وModel وContext خارج `AionApp.kt` مع الحفاظ على callbacks القديمة.
- أُعيدت اختصارات البحث والتحليل القديمة إلى Add بعد اكتشاف إسقاطها في النقل المبسط.
- `showModelPicker` و`showContext` والواجهات القديمة المقابلة أزيلت.
- Evidence/Sources وSettings تبقيان مسارين سياقيين قديمين؛ لم يُدّعَ نقلهما ضمن هذا checkpoint.

## Design System
- ثُبتت لوحة α8.3 المعتمدة، بما فيها Violet/Blue والفروق الدلالية.
- ثُبت Text Tertiary القابل للقراءة `#858692` مع Text Muted منفصل `#6F707C`.
- اكتملت spacing/radii/sizes/motion tokens الأساسية وفق المواصفة.
- حُدثت typography العربية مع letter spacing صفر وخطوط/ارتفاعات معتمدة.

## Verification
- structural checks المحلية نجحت.
- اختبارات Kotlin/Compose وGradle/lint/build: `execution pending CI`.
- GitHub branch creation blocker: HTTP 403 `Resource not accessible by integration`.
