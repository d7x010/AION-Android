# AION α8.3 — دفعة بوابة الإصدار 51–60

## ما نُفّذ

- رُفع `versionCode` إلى `58` و`versionName` إلى `2.0.0-alpha8.3-dev1` داخل `app/build.gradle.kts`.
- أضيفت محليًا Workflow مستقلة: `.github/workflows/aion-alpha83-visual-preview.yml`، ولا تغيّر أي Workflow α8.2.
- تضبط Workflow: Java 17، Gradle 9.6.0 عبر `gradle/actions/setup-gradle@v4`، Android API 36 وBuild Tools 36.0.0، ثم تشغّل `gradle` مباشرةً لا Gradle Wrapper.
- تشمل Workflow: unit tests، `lintDebug`، `assembleDebug`، `bundleRelease`، إعادة تسمية APK/AAB، `apksigner verify`، SHA-256 ورفع artifacts.
- فحوصات المصدر البنيوية أكدت بوابة النسخة، غياب `showModelPicker`، ووجود إنشاء runtime وحيد لـ`AionSheetStack` في `AionApp`؛ التطابقات الأخرى هي تعريف الصنف و`dismiss()` فقط.

## الحقيقة الحالية

- لا يوجد Gradle أو Android SDK محليان؛ لذلك Gradle tests وlint وAPK/AAB/signature كلها **execution pending CI**.
- لم تُنتج APK باسم `AION-alpha83-visual-preview-dev1.apk` بعد، ولا AAB. لا توجد نتيجة جهاز حقيقي.
- جرت محاولة فعلية لرفع Workflow إلى `d7x010/AION-Android`، وفشلت حرفيًا بهذا الخطأ:

`GitHub API error 403: {"message":"Resource not accessible by integration","documentation_url":"https://docs.github.com/rest/repos/contents#create-or-update-file-contents","status":"403"}`

## محاولة بعد إعادة الربط

ظهر للمستودع قراءة صحيحة، لكنه لم يحصل على كتابة فعلية: محاولة إنشاء الفرع `aion/alpha83-visual-preview-dev1` أعادت حرفيًا:

`GitHub API error 403: {"message":"Resource not accessible by integration","documentation_url":"https://docs.github.com/rest/git/refs#create-a-reference","status":"403"}`

## الخطوة المحجوبة فقط

منح تكامل GitHub صلاحية كتابة محتوى المستودع أو دفع هذه الملفات من حساب يملك الصلاحية. بعد ذلك يمكن رفع Workflow وتشغيلها للحصول على الأدلة وAPK/AAB الحقيقية؛ لا يلزم Gradle Wrapper.
