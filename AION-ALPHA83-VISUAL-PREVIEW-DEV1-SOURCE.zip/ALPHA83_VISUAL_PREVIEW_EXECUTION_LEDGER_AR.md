# AION α8.3 — دفتر التنفيذ الذاتي

المقسوم أدناه هو **Visual Preview فقط**: 60 نقطة ذرية، ضمن 6 دفعات من 10. بعد إصدار APK المرئي نفتح دفترًا ثانيًا لبقية FULL MASTER؛ لا أخلطهما لأن نطاقه أوسع من أن يُحسب بصدق كعدد ثابت الآن.

## الدفعة 1 — Sheet System (1–10)

1. سياسة Add القائمة على المسارات الحقيقية — منفذ، CI pending.
2. فصل AionAddSheet — منفذ، CI pending.
3. AionSheetStack وHost لـAdd — منفذ، CI pending.
4. توحيد ملكية Stack — منفذ، CI pending.
5. فصل ModelPicker وModelGlyph — منفذ، CI pending.
6. ربط Models بالـHost نفسه — منفذ، CI pending.
7. Control Sheet — منفذ، CI pending.
8. Power Sheet الصادق تشغيليًا — منفذ، CI pending.
9. Effort/Research/Permissions — منفذ، CI pending.
10. Context destination وإغلاق تحققات Sheet System — منفذ جزئيًا؛ بقيت Sheets قديمة مستقلة يجب نقلها أو تبرير بقائها قبل بوابة الإصدار.

## الدفعة 2 — Foundations + Composer (11–20)

11. تجميد ألوان التصميم — منفذ، CI pending.
12. spacing/radii/touch/motion — منفذ، CI pending.
13. Core state mapping — منفذ، CI pending.
14. Top Bar الهادئ — منفذ، CI pending.
15. Adaptive shell — منفذ، CI pending.
16. Composer context priority — منفذ، CI pending.
17. Context Strip + overflow — منفذ، CI pending.
18. Attachment Shelf — منفذ، CI pending.
19. Composer Dock RTL physical actions — منفذ، CI pending.
20. Composer responsive margins + primary action verification — منفذ، CI pending.

## الدفعة 3 — Home + Drawer (21–30)

21. Home shell — منفذ، CI pending.
22. Recent-first — منفذ، CI pending.
23. Pinned conditional — منفذ، CI pending.
24. 2–3 suggestions only — منفذ، CI pending.
25. New Chat entry — منفذ، CI pending.
26. New Work entry — منفذ، CI pending.
27. Drawer ordering — منفذ، CI pending.
28. Projects/Works and files/artifacts truth — منفذ، CI pending.
29. More / Account row — منفذ، CI pending.
30. Home/Drawer structural and accessibility checks — منفذ بنيويًا؛ Gradle pending CI.

## الدفعة 4 — New Work + Auth + Peak foundation (31–40)

31. New Chat continuity — منفذ/مراجع بنيويًا، CI pending.
32. New Work goal-first — منفذ، CI pending.
33. Pre-message context/files — منفذ عبر المحادثة الفارغة + Add الحقيقي، CI pending.
34. Auth entry preview — منفذ، CI pending.
35. Sign-in semantics — Preview صريح بلا backend، CI pending.
36. Create-account semantics — Preview صريح بلا backend، CI pending.
37. Profile/account route — منفذ، CI pending.
38. Peak mode model — منفذ، CI pending.
39. Peak visual lifecycle — foundation منفذة؛ لا يتم ادعاء trigger runtime غير موجود.
40. Reduce Motion / capability separation — منفذ في Policy، CI pending.

## الدفعة 5 — Hardening (41–50)

41. RTL + mixed text — منفذ بنيويًا، CI pending.
42. IME/insets — منفذ بنيويًا، CI pending.
43. Large text — منفذ في adaptive policy، CI pending.
44. Landscape — منفذ في adaptive policy، CI pending.
45. Foldable/hinge — baseline بالأبعاد فقط؛ hinge integration لم تنفذ لغياب المصدر/المكتبة الحالية.
46. Predictive Back — manifest + BackHandler منفذان، CI pending.
47. TalkBack semantics — baseline منفذ؛ اختبار قارئ الشاشة الحقيقي pending device.
48. Contrast / touch targets — tokens منفذة؛ lint pending CI.
49. Motion/performance isolation — أزيلت activity loops المزيفة، CI pending.
50. Screenshot/state coverage — state coverage موسعة؛ screenshot/device pending.

## الدفعة 6 — Release gate (51–60)

51. Version gate — منفذ في المصدر: `2.0.0-alpha8.3-dev1` / `58`.
52. α8.3 CI workflow — أنشئ محليًا؛ رفعه إلى GitHub محجوب حاليًا بصلاحية التكامل (HTTP 403 موثق في evidence).
53. Unit tests — execution pending CI؛ لا يوجد Gradle محلي.
54. Lint — execution pending CI؛ لا يوجد Android SDK محلي.
55. Debug APK build — execution pending CI؛ لم تُنتج APK محليًا.
56. Release AAB build — execution pending CI؛ لم تُنتج AAB محليًا.
57. APK signature/artifact checks — execution pending CI لعدم وجود APK؛ الخطوات موجودة في Workflow الجديدة.
58. Source ZIP + SHA — منفذ في checkpoint المرشح للإصدار.
59. Evidence/handoff — منفذ، مع توثيق حدود CI/GitHub بدقة.
60. Real-device handoff — pending؛ لا يُسجل PASS إلا بعد تجربة المستخدم للـAPK الناتجة من CI.
