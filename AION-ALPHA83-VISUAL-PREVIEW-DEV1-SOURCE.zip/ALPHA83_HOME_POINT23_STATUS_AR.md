# AION α8.3 — نقطة 23: Pinned conditional

- تعرض Home قسم «المثبتة» فقط عند وجود محادثات مثبتة فعلًا، بحد أقصى عنصرين وترتيب أحدث نشاطًا.
- لا توجد بيانات مصطنعة ولا تغيير في pin storage أو في سلوك فتح المحادثة.
- `HomePolicyTest.kt`: test authored, execution pending CI.
- Gradle/Android tests: execution pending CI.
