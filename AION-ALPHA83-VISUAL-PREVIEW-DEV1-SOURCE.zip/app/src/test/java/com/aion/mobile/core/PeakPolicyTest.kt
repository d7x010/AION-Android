package com.aion.mobile.core

import com.aion.mobile.core.state.AionPeakMode
import com.aion.mobile.core.state.AionPeakVisualProfile
import com.aion.mobile.core.state.PeakPolicy
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Test

class PeakPolicyTest {
    @Test fun peakNeverGrantsPermissionsOrAutonomy() {
        AionPeakMode.entries.forEach { mode ->
            assertFalse(PeakPolicy.grantsPermissions(mode))
            assertFalse(PeakPolicy.grantsAutonomy(mode))
        }
    }

    @Test fun accessibilityProfileKeepsCapabilityWhileReducingMotionOnly() {
        assertEquals(AionPeakMode.PEAK, PeakPolicy.capabilityFor(AionPeakMode.PEAK, AionPeakVisualProfile.ACCESSIBLE))
        assertEquals(280, PeakPolicy.introDurationMs(AionPeakVisualProfile.ACCESSIBLE))
    }

    @Test fun peakModesDescribeTheirVisualIntentWithoutClaimingExtraRuntimeAccess() {
        assertEquals("هادئ", PeakPolicy.labelFor(AionPeakMode.CALM))
        assertEquals("أقصى طاقة", PeakPolicy.labelFor(AionPeakMode.PEAK))
        assertFalse(PeakPolicy.grantsPermissions(AionPeakMode.PEAK))
        assertFalse(PeakPolicy.grantsAutonomy(AionPeakMode.PEAK))
    }
}
