package com.aion.mobile.core.state

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class AuthPreviewPolicyTest {
    @Test
    fun localPreviewDoesNotRequireAuthenticationToUseAion() {
        assertFalse(AuthPreviewPolicy.requiresAuthenticationToUseAion(hasBackend = false))
    }

    @Test
    fun accountSubmissionIsUnavailableWithoutABackend() {
        assertFalse(AuthPreviewPolicy.canSubmitCredentials(hasBackend = false))
        assertTrue(AuthPreviewPolicy.canSubmitCredentials(hasBackend = true))
    }
}
