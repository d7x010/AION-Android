package com.aion.mobile.ui.components

import com.aion.mobile.core.state.AionActivityKind
import com.aion.mobile.core.state.AionActivityState
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class AionCorePresentationTest {
    @Test
    fun externalBlueIsReservedForNetworkAndUploadWork() {
        assertEquals(AionCoreTone.External, AionCorePresentation.from(AionActivityState(AionActivityKind.SEARCHING_WEB)).tone)
        assertEquals(AionCoreTone.External, AionCorePresentation.from(AionActivityState(AionActivityKind.UPLOADING)).tone)
        assertEquals(AionCoreTone.Internal, AionCorePresentation.from(AionActivityState(AionActivityKind.THINKING)).tone)
    }

    @Test
    fun idleCoreIsDormantAndActiveTruthIsAlive() {
        assertFalse(AionCorePresentation.from(null).active)
        assertTrue(AionCorePresentation.from(AionActivityState(AionActivityKind.WRITING)).active)
    }
}
