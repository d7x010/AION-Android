package com.aion.mobile.core

import com.aion.mobile.core.state.AionTopBarPolicy
import org.junit.Assert.assertEquals
import org.junit.Test

class AionTopBarPolicyTest {
    @Test fun contextLineRemovesTheRepeatedAionWordmark() {
        assertEquals("Auto · مشروع AION", AionTopBarPolicy.contextLine("AION Auto · مشروع AION"))
    }

    @Test fun emptyContextFallsBackToAion() {
        assertEquals("AION", AionTopBarPolicy.contextLine("   "))
    }
}
