package com.aion.mobile.ui.components

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class AionAdaptiveFramePolicyTest {
    @Test fun compactPhoneUsesSinglePane() {
        val result = AionAdaptiveFramePolicy.resolve(393, 852)
        assertFalse(result.persistentNavigation)
        assertFalse(result.supportingPane)
    }

    @Test fun compactHeightPreventsForcedTwoPane() {
        val result = AionAdaptiveFramePolicy.resolve(700, 430)
        assertFalse(result.supportingPane)
    }

    @Test fun expandedWindowSupportsPersistentNavigationAndPane() {
        val result = AionAdaptiveFramePolicy.resolve(900, 900)
        assertTrue(result.persistentNavigation)
        assertTrue(result.supportingPane)
    }

    @Test fun largeTextKeepsExpandedWindowReadableInOnePane() {
        val result = AionAdaptiveFramePolicy.resolve(900, 900, fontScale = 1.3f)
        assertFalse(result.persistentNavigation)
        assertFalse(result.supportingPane)
    }
}
