package com.aion.mobile.ui.state

import org.junit.Assert.assertEquals
import org.junit.Test

class AionSheetStateTest {
    @Test
    fun addSheetBackReturnsToNone() {
        val stack = AionSheetStack().push(AionSheetDestination.Add)
        assertEquals(AionSheetDestination.Add, stack.current)
        assertEquals(AionSheetDestination.None, stack.back().current)
    }

    @Test
    fun dismissClearsNestedSheetStack() {
        val stack = AionSheetStack()
            .push(AionSheetDestination.Control)
            .push(AionSheetDestination.Models)
        assertEquals(AionSheetDestination.None, stack.dismiss().current)
    }

    @Test
    fun focusedControlDestinationsRemainInOneStack() {
        val roots = listOf(
            AionSheetDestination.Power,
            AionSheetDestination.Effort,
            AionSheetDestination.Research,
            AionSheetDestination.Permissions,
            AionSheetDestination.Context,
        )
        roots.forEach { destination ->
            val stack = AionSheetStack()
                .push(AionSheetDestination.Control)
                .push(destination)
            assertEquals(destination, stack.current)
            assertEquals(AionSheetDestination.Control, stack.back().current)
        }
    }

    @Test
    fun newWorkUsesTheSameSingleSheetStack() {
        val stack = AionSheetStack().push(AionSheetDestination.NewWork)
        assertEquals(AionSheetDestination.NewWork, stack.current)
        assertEquals(AionSheetDestination.None, stack.dismiss().current)
    }

    @Test
    fun authUsesTheSameSingleSheetStack() {
        val stack = AionSheetStack().push(AionSheetDestination.Auth)
        assertEquals(AionSheetDestination.Auth, stack.current)
        assertEquals(AionSheetDestination.None, stack.dismiss().current)
    }

    @Test
    fun systemBackReturnsToPreviousDestinationBeforeDismiss() {
        val stack = AionSheetStack()
            .push(AionSheetDestination.Control)
            .push(AionSheetDestination.Auth)
        assertEquals(AionSheetDestination.Control, stack.back().current)
        assertEquals(AionSheetDestination.None, stack.back().dismiss().current)
    }
}
