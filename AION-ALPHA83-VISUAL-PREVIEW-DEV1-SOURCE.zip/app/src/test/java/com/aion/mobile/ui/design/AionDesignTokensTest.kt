package com.aion.mobile.ui.design

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import org.junit.Assert.assertEquals
import org.junit.Test

class AionDesignTokensTest {
    @Test
    fun visualPreviewPaletteMatchesFrozenSpec() {
        assertEquals(Color(0xFF0D0D12), AionColors.Background)
        assertEquals(Color(0xFF14141C), AionColors.Surface)
        assertEquals(Color(0xFF1B1B26), AionColors.SurfaceHigh)
        assertEquals(Color(0xFF7C3AED), AionColors.VioletMain)
        assertEquals(Color(0xFF4D8DFF), AionColors.AionBlue)
        assertEquals(Color(0xFF858692), AionColors.TextTertiary)
    }

    @Test
    fun layoutAndMotionTokensMatchFrozenSpec() {
        assertEquals(48.dp, AionSizes.TouchTarget)
        assertEquals(56.dp, AionSizes.TopBarHeight)
        assertEquals(60.dp, AionSizes.ComposerMinHeight)
        assertEquals(52.dp, AionSizes.PrimaryAction)
        assertEquals(90, AionMotion.PressMs)
        assertEquals(260, AionMotion.SheetMs)
    }
}
