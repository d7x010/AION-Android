package com.aion.mobile.core

import com.aion.mobile.core.state.DrawerPolicy
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class DrawerPolicyTest {
    @Test fun secondaryCapabilitiesAreCollapsedWhenDrawerOpens() {
        assertFalse(DrawerPolicy.showSecondaryCapabilities(expanded = false))
    }

    @Test fun secondaryCapabilitiesAppearOnlyAfterMoreIsChosen() {
        assertTrue(DrawerPolicy.showSecondaryCapabilities(expanded = true))
    }
}
