package com.aion.mobile.core

import com.aion.mobile.core.state.HomePolicy
import com.aion.mobile.core.storage.ConversationSummary
import org.junit.Assert.assertEquals
import org.junit.Test

class HomePolicyTest {
    @Test fun homeLimitsSuggestionsToThreeUsefulEntries() {
        assertEquals(listOf("search", "analyze", "write"), HomePolicy.visibleSuggestionKeys(
            listOf("search", "analyze", "write", "work")
        ))
    }

    @Test fun recentConversationsAreNewestFirstAndBounded() {
        val items = listOf(
            ConversationSummary("old", "قديم", updatedAt = 1L, messageCount = 1),
            ConversationSummary("new", "حديث", updatedAt = 4L, messageCount = 1),
            ConversationSummary("middle", "وسط", updatedAt = 2L, messageCount = 1),
            ConversationSummary("latest", "الأحدث", updatedAt = 5L, messageCount = 1),
        )

        assertEquals(listOf("latest", "new", "middle"), HomePolicy.recentConversations(items).map { it.id })
    }

    @Test fun pinnedOnlyAppearsWhenPinnedItemsExist() {
        val items = listOf(
            ConversationSummary("one", "واحد", updatedAt = 1L, messageCount = 1),
            ConversationSummary("two", "اثنان", updatedAt = 3L, messageCount = 1, pinned = true),
        )

        assertEquals(listOf("two"), HomePolicy.pinnedConversations(items).map { it.id })
        assertEquals(emptyList<String>(), HomePolicy.pinnedConversations(items.filterNot { it.pinned }).map { it.id })
    }
}
