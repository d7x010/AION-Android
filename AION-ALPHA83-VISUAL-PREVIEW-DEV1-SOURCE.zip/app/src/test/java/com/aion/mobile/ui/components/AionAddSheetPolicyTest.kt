package com.aion.mobile.ui.components

import org.junit.Assert.assertEquals
import org.junit.Test

class AionAddSheetPolicyTest {
    @Test
    fun exposesOnlyActionsBackedByAvailableIntegrations() {
        assertEquals(
            listOf(AionAddAction.Photos, AionAddAction.File),
            AionAddSheetPolicy.availableActions(cameraAvailable = false, connectedSourceAvailable = false)
        )
    }
}
