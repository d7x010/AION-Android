package com.aion.mobile.core

import com.aion.mobile.core.state.ComposerPolicy
import com.aion.mobile.core.state.ComposerLayoutPolicy
import com.aion.mobile.core.state.ComposerPrimaryAction
import org.junit.Assert.assertEquals
import org.junit.Test

class ComposerPolicyTest {
    @Test fun emptyComposerShowsLiveAndDictation() {
        assertEquals(
            ComposerPrimaryAction.LIVE_AND_DICTATION,
            ComposerPolicy.primaryAction(isSending = false, draftHasText = false, hasAttachments = false)
        )
    }

    @Test fun textOrAttachmentTurnsSlotIntoSend() {
        assertEquals(
            ComposerPrimaryAction.SEND,
            ComposerPolicy.primaryAction(isSending = false, draftHasText = true, hasAttachments = false)
        )
        assertEquals(
            ComposerPrimaryAction.SEND,
            ComposerPolicy.primaryAction(isSending = false, draftHasText = false, hasAttachments = true)
        )
    }

    @Test fun streamingAlwaysOwnsTheSlot() {
        assertEquals(
            ComposerPrimaryAction.STOP,
            ComposerPolicy.primaryAction(isSending = true, draftHasText = true, hasAttachments = true)
        )
    }

    @Test fun composerUsesTwelveDpOnlyOnNarrowPhones() {
        assertEquals(12, ComposerLayoutPolicy.horizontalMarginDp(359))
        assertEquals(16, ComposerLayoutPolicy.horizontalMarginDp(360))
        assertEquals(16, ComposerLayoutPolicy.horizontalMarginDp(700))
    }
}
