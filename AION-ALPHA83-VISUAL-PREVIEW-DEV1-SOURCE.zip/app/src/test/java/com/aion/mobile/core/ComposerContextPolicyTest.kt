package com.aion.mobile.core

import com.aion.mobile.core.state.ComposerContextItem
import com.aion.mobile.core.state.ComposerContextPolicy
import org.junit.Assert.assertEquals
import org.junit.Test

class ComposerContextPolicyTest {
    @Test fun urgentRuntimeTruthPrecedesSelectionContext() {
        assertEquals(
            listOf(
                ComposerContextItem.SAFE_MODE,
                ComposerContextItem.CLOUD_UNCONFIGURED,
                ComposerContextItem.ATTACHMENTS,
            ),
            ComposerContextPolicy.visibleItems(
                safeMode = true,
                isConfigured = false,
                hasAttachments = true,
                hasExplicitModel = true,
                hasProject = true,
            )
        )
    }

    @Test fun contextStripNeverExceedsThreeItems() {
        assertEquals(
            3,
            ComposerContextPolicy.visibleItems(
                safeMode = true,
                isConfigured = false,
                hasAttachments = true,
                hasExplicitModel = true,
                hasProject = true,
            ).size
        )
    }

    @Test fun attachmentContextWinsBeforeModelAndProject() {
        assertEquals(
            listOf(
                ComposerContextItem.ATTACHMENTS,
                ComposerContextItem.MODEL,
                ComposerContextItem.PROJECT,
            ),
            ComposerContextPolicy.visibleItems(
                safeMode = false,
                isConfigured = true,
                hasAttachments = true,
                hasExplicitModel = true,
                hasProject = true,
            )
        )
    }
}
