package com.aion.mobile.ui.components

import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.Menu
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import com.aion.mobile.core.state.AionActivityState
import com.aion.mobile.ui.design.AionRadii
import com.aion.mobile.ui.design.AionSizes
import com.aion.mobile.ui.design.AionSpacing

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AionTopBar(
    activityState: AionActivityState?,
    contextLabel: String,
    onMenu: () -> Unit,
    onControl: () -> Unit,
    onNewChat: () -> Unit,
    newChatEnabled: Boolean,
) {
    CenterAlignedTopAppBar(
        modifier = Modifier.height(AionSizes.TopBarHeight),
        colors = TopAppBarDefaults.centerAlignedTopAppBarColors(containerColor = MaterialTheme.colorScheme.background),
        navigationIcon = {
            IconButton(onClick = onMenu, modifier = Modifier.size(AionSizes.TouchTarget)) {
                Icon(Icons.Outlined.Menu, contentDescription = "القائمة")
            }
        },
        title = {
            Surface(onClick = onControl, shape = androidx.compose.foundation.shape.RoundedCornerShape(AionRadii.Chip), color = Color.Transparent) {
                Row(Modifier.padding(horizontal = AionSpacing.Sm, vertical = AionSpacing.Xs), verticalAlignment = Alignment.CenterVertically) {
                    AionCore(activityState)
                    Spacer(Modifier.width(AionSpacing.Sm))
                    Text(
                        // The compact bar is an identity/control affordance, not a model dashboard.
                        // The full runtime context remains in the control sheet opened by this row.
                        "AION",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        style = MaterialTheme.typography.labelLarge,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
            }
        },
        actions = {
            IconButton(onClick = onNewChat, enabled = newChatEnabled, modifier = Modifier.size(AionSizes.TouchTarget)) {
                Icon(Icons.Outlined.Edit, contentDescription = "محادثة جديدة", modifier = Modifier.size(AionSizes.Icon))
            }
        },
    )
}
