package com.aion.mobile.ui.state

sealed interface AionSheetDestination {
    data object None : AionSheetDestination
    data object Add : AionSheetDestination
    data object Control : AionSheetDestination
    data object Power : AionSheetDestination
    data object Effort : AionSheetDestination
    data object Models : AionSheetDestination
    data object Research : AionSheetDestination
    data object Permissions : AionSheetDestination
    data object Context : AionSheetDestination
    data object NewWork : AionSheetDestination
    data object Auth : AionSheetDestination
}

data class AionSheetStack(
    val entries: List<AionSheetDestination> = emptyList(),
) {
    val current: AionSheetDestination
        get() = entries.lastOrNull() ?: AionSheetDestination.None

    fun push(destination: AionSheetDestination): AionSheetStack =
        copy(entries = entries + destination)

    fun back(): AionSheetStack =
        if (entries.isEmpty()) this else copy(entries = entries.dropLast(1))

    fun dismiss(): AionSheetStack = AionSheetStack()
}
