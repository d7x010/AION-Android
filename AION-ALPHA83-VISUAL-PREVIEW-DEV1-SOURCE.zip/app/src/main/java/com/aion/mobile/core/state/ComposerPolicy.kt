package com.aion.mobile.core.state

/**
 * Single source of truth for the action slot at the edge of the AION composer.
 * Keeping this logic outside Compose prevents visual/state drift between text,
 * attachments, dictation and streaming.
 */
enum class ComposerPrimaryAction {
    LIVE_AND_DICTATION,
    SEND,
    STOP
}

enum class ComposerContextItem {
    SAFE_MODE,
    CLOUD_UNCONFIGURED,
    ATTACHMENTS,
    MODEL,
    PROJECT,
}

object ComposerContextPolicy {
    private const val MAX_VISIBLE_ITEMS = 3

    fun visibleItems(
        safeMode: Boolean,
        isConfigured: Boolean,
        hasAttachments: Boolean,
        hasExplicitModel: Boolean,
        hasProject: Boolean,
    ): List<ComposerContextItem> = buildList {
        if (safeMode) add(ComposerContextItem.SAFE_MODE)
        if (!isConfigured) add(ComposerContextItem.CLOUD_UNCONFIGURED)
        if (hasAttachments) add(ComposerContextItem.ATTACHMENTS)
        if (hasExplicitModel) add(ComposerContextItem.MODEL)
        if (hasProject) add(ComposerContextItem.PROJECT)
    }.take(MAX_VISIBLE_ITEMS)
}

object ComposerPolicy {
    fun primaryAction(
        isSending: Boolean,
        draftHasText: Boolean,
        hasAttachments: Boolean
    ): ComposerPrimaryAction = when {
        isSending -> ComposerPrimaryAction.STOP
        draftHasText || hasAttachments -> ComposerPrimaryAction.SEND
        else -> ComposerPrimaryAction.LIVE_AND_DICTATION
    }
}

object ComposerLayoutPolicy {
    fun horizontalMarginDp(availableWidthDp: Int): Int = if (availableWidthDp < 360) 12 else 16
}
