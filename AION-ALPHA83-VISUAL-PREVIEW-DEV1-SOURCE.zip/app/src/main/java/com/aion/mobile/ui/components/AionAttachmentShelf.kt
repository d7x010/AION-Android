package com.aion.mobile.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.aion.mobile.model.ChatAttachment

@Composable
fun AionAttachmentShelf(
    attachments: List<ChatAttachment>,
    modifier: Modifier = Modifier,
    attachmentContent: @Composable (ChatAttachment) -> Unit,
) {
    if (attachments.isEmpty()) return

    LazyRow(
        modifier = modifier,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        contentPadding = PaddingValues(horizontal = 3.dp, vertical = 2.dp),
    ) {
        items(attachments, key = { it.id }) { attachment ->
            attachmentContent(attachment)
        }
    }
}
