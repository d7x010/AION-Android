package com.aion.mobile.ui.components

import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.runtime.Composable
import com.aion.mobile.ui.design.AionColors
import com.aion.mobile.ui.state.AionSheetDestination
import com.aion.mobile.ui.state.AionSheetStack

/** The only modal-sheet renderer for the compact shell. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AionSheetHost(
    stack: AionSheetStack,
    onDismiss: () -> Unit,
    onBack: () -> Unit,
    addSheet: @Composable () -> Unit,
    controlSheet: @Composable () -> Unit,
    powerSheet: @Composable () -> Unit,
    effortSheet: @Composable () -> Unit,
    modelSheet: @Composable () -> Unit,
    researchSheet: @Composable () -> Unit,
    permissionsSheet: @Composable () -> Unit,
    contextSheet: @Composable () -> Unit,
    newWorkSheet: @Composable () -> Unit,
    authSheet: @Composable () -> Unit,
    settingsSheet: @Composable () -> Unit,
) {
    val dismissOrBack = if (stack.entries.size > 1) onBack else onDismiss
    when (stack.current) {
        AionSheetDestination.None -> Unit
        AionSheetDestination.Add -> ModalBottomSheet(
            onDismissRequest = dismissOrBack,
            containerColor = AionColors.Surface
        ) { addSheet() }
        AionSheetDestination.Control -> ModalBottomSheet(
            onDismissRequest = dismissOrBack,
            containerColor = AionColors.Surface
        ) { controlSheet() }
        AionSheetDestination.Power -> ModalBottomSheet(
            onDismissRequest = dismissOrBack,
            containerColor = AionColors.Surface
        ) { powerSheet() }
        AionSheetDestination.Effort -> ModalBottomSheet(
            onDismissRequest = dismissOrBack,
            containerColor = AionColors.Surface
        ) { effortSheet() }
        AionSheetDestination.Models -> ModalBottomSheet(
            onDismissRequest = dismissOrBack,
            containerColor = AionColors.Surface
        ) { modelSheet() }
        AionSheetDestination.Research -> ModalBottomSheet(
            onDismissRequest = dismissOrBack,
            containerColor = AionColors.Surface
        ) { researchSheet() }
        AionSheetDestination.Permissions -> ModalBottomSheet(
            onDismissRequest = dismissOrBack,
            containerColor = AionColors.Surface
        ) { permissionsSheet() }
        AionSheetDestination.Context -> ModalBottomSheet(
            onDismissRequest = dismissOrBack,
            containerColor = AionColors.Surface
        ) { contextSheet() }
        AionSheetDestination.NewWork -> ModalBottomSheet(
            onDismissRequest = dismissOrBack,
            containerColor = AionColors.Surface
        ) { newWorkSheet() }
        AionSheetDestination.Auth -> ModalBottomSheet(
            onDismissRequest = dismissOrBack,
            containerColor = AionColors.Surface
        ) { authSheet() }
        AionSheetDestination.Settings -> ModalBottomSheet(
            onDismissRequest = dismissOrBack,
            containerColor = AionColors.Surface
        ) { settingsSheet() }
        else -> Unit
    }
}
