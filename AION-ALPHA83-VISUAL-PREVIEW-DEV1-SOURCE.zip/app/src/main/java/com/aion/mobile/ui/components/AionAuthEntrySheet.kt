package com.aion.mobile.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import com.aion.mobile.core.state.AuthPreviewPolicy
import com.aion.mobile.ui.design.AionColors
import com.aion.mobile.ui.design.AionSpacing

private enum class AionAuthScreen { ENTRY, SIGN_IN, CREATE_ACCOUNT, PROFILE }

/** Preview-only auth foundation. It never claims a backend login, OAuth provider, or persisted account. */
@Composable
fun AionAuthEntrySheet(onDismiss: () -> Unit) {
    val hasBackend = false
    var screen by remember { mutableStateOf(AionAuthScreen.ENTRY) }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }

    Column(
        modifier = Modifier.fillMaxWidth().padding(horizontal = AionSpacing.Lg, vertical = AionSpacing.Md),
        verticalArrangement = Arrangement.spacedBy(AionSpacing.Sm),
    ) {
        when (screen) {
            AionAuthScreen.ENTRY -> {
                Text("الحساب", style = MaterialTheme.typography.titleLarge, color = AionColors.TextPrimary)
                Text("AION يعمل محليًا في المعاينة. لا توجد خدمة حسابات مهيأة، لذلك لن ندّعي تسجيل دخول أو أزرار مزودين.", color = AionColors.TextSecondary)
                Text("يمكنك الاستمرار في استخدام AION من دون تسجيل دخول.", color = AionColors.TextSecondary)
                TextButton(onClick = { screen = AionAuthScreen.SIGN_IN }, modifier = Modifier.fillMaxWidth()) { Text("تسجيل الدخول") }
                TextButton(onClick = { screen = AionAuthScreen.CREATE_ACCOUNT }, modifier = Modifier.fillMaxWidth()) { Text("إنشاء حساب") }
                TextButton(onClick = { screen = AionAuthScreen.PROFILE }, modifier = Modifier.fillMaxWidth()) { Text("الملف الشخصي المحلي") }
            }
            AionAuthScreen.SIGN_IN, AionAuthScreen.CREATE_ACCOUNT -> {
                val creating = screen == AionAuthScreen.CREATE_ACCOUNT
                Text(if (creating) "إنشاء حساب" else "تسجيل الدخول", style = MaterialTheme.typography.titleLarge)
                Text("هذه واجهة Preview فقط. الحقول تملك دلالات البريد وكلمة المرور، لكن الإرسال غير متاح قبل ربط backend حقيقي.", color = AionColors.TextSecondary)
                OutlinedTextField(
                    value = email,
                    onValueChange = { email = it },
                    label = { Text("البريد الإلكتروني") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email, imeAction = ImeAction.Next),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                if (!AuthPreviewPolicy.canSubmitCredentials(hasBackend)) {
                    Text("لن تُرسل هذه البيانات أو تُحفظ في هذه المعاينة.", color = AionColors.TextSecondary)
                }
                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it },
                    label = { Text("كلمة المرور") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password, imeAction = ImeAction.Done),
                    visualTransformation = PasswordVisualTransformation(),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                TextButton(onClick = { screen = AionAuthScreen.ENTRY }, modifier = Modifier.fillMaxWidth()) { Text("رجوع") }
            }
            AionAuthScreen.PROFILE -> {
                Text("الملف الشخصي", style = MaterialTheme.typography.titleLarge)
                Text("أنت في وضع المعاينة المحلية. لن تمنعك هذه الحالة من استخدام المحادثة أو المشاريع.", color = AionColors.TextSecondary)
                TextButton(onClick = { screen = AionAuthScreen.ENTRY }, modifier = Modifier.fillMaxWidth()) { Text("رجوع") }
            }
        }
        TextButton(onClick = onDismiss, modifier = Modifier.fillMaxWidth()) { Text("إغلاق") }
    }
}
