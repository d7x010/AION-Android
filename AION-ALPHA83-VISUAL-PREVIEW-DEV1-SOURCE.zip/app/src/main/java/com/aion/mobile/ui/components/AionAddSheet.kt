package com.aion.mobile.ui.components

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material.icons.outlined.Image
import androidx.compose.material.icons.outlined.Psychology
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aion.mobile.ui.design.AionColors
import com.aion.mobile.ui.design.AionSpacing
import com.aion.mobile.ui.theme.AionBlueSoft

@Composable
fun AionAddSheet(
    cameraAvailable: Boolean = false,
    connectedSourceAvailable: Boolean = false,
    onPhotos: () -> Unit,
    onFile: () -> Unit,
    onResearch: () -> Unit,
    onDeepAnalysis: () -> Unit,
) {
    val actions = AionAddSheetPolicy.availableActions(cameraAvailable, connectedSourceAvailable)
    Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 8.dp)) {
        Text("أضف إلى المحادثة", fontSize = 19.sp, fontWeight = FontWeight.Bold)
        Text(
            "يمكنك إرسال حتى 4 عناصر وبحجم إجمالي 5 MB حاليًا.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(Modifier.height(12.dp))
        if (AionAddAction.Photos in actions) {
            AddSheetRow(Icons.Outlined.Image, "صورة", "PNG وJPEG وWEBP وGIF", AionColors.External, onPhotos)
        }
        if (AionAddAction.File in actions) {
            AddSheetRow(Icons.Outlined.Description, "ملف", "PDF وWord وExcel ونصوص وكود", AionBlueSoft, onFile)
        }
        Spacer(Modifier.height(AionSpacing.Md))
        Text(
            "أدوات AION",
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = AionSpacing.Xs, vertical = AionSpacing.Xs),
        )
        AddSheetRow(
            Icons.Outlined.Search,
            "بحث في الويب",
            "فعّل وضع البحث الحي مع المصادر لهذه المحادثة",
            AionColors.External,
            onResearch,
        )
        AddSheetRow(
            Icons.Outlined.Psychology,
            "تحليل عميق",
            "استخدم وضع الاستدلال الأعمق لهذه المحادثة",
            AionColors.Intelligence,
            onDeepAnalysis,
        )
        Spacer(Modifier.height(AionSpacing.Xxl))
    }
}

@Composable
private fun AddSheetRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
    accent: Color,
    onClick: () -> Unit,
) {
    Surface(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        shape = RoundedCornerShape(17.dp),
        color = AionColors.SurfaceRaised,
    ) {
        Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Surface(shape = CircleShape, color = accent.copy(alpha = 0.13f), modifier = Modifier.size(38.dp)) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(icon, contentDescription = null, tint = accent, modifier = Modifier.size(19.dp))
                }
            }
            Spacer(Modifier.width(11.dp))
            Column {
                Text(title, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold)
                Text(subtitle, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}
