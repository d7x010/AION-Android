package com.aion.mobile.ui.components

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.widthIn
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp

data class AionAdaptiveFrameResult(
    val persistentNavigation: Boolean,
    val supportingPane: Boolean,
)

object AionAdaptiveFramePolicy {
    fun resolve(widthDp: Int, heightDp: Int, fontScale: Float = 1f): AionAdaptiveFrameResult {
        val compactHeight = heightDp < 480
        val largeText = fontScale >= 1.3f
        return AionAdaptiveFrameResult(
            persistentNavigation = widthDp >= 840 && !compactHeight && !largeText,
            supportingPane = widthDp >= 840 && !compactHeight && !largeText,
        )
    }
}

@Composable
fun AionAdaptiveFrame(modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    BoxWithConstraints(modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
        val policy = AionAdaptiveFramePolicy.resolve(
            maxWidth.value.toInt(),
            maxHeight.value.toInt(),
            LocalDensity.current.fontScale,
        )
        val contentMaxWidth = if (policy.supportingPane) 900.dp else 760.dp
        Box(
            modifier = Modifier.widthIn(max = contentMaxWidth).fillMaxHeight(),
            contentAlignment = Alignment.TopCenter,
        ) { content() }
    }
}
