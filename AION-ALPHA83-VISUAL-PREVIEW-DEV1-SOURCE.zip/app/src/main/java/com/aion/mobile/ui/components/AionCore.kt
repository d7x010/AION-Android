package com.aion.mobile.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.aion.mobile.core.state.AionActivityKind
import com.aion.mobile.core.state.AionActivityState
import com.aion.mobile.ui.design.AionColors

enum class AionCoreTone { Dormant, Internal, External, Success, Warning, Error, Offline }

data class AionCorePresentation(val tone: AionCoreTone, val active: Boolean) {
    companion object {
        fun from(state: AionActivityState?): AionCorePresentation = when (state?.kind) {
            null, AionActivityKind.IDLE -> AionCorePresentation(AionCoreTone.Dormant, false)
            AionActivityKind.SEARCHING_WEB, AionActivityKind.UPLOADING -> AionCorePresentation(AionCoreTone.External, true)
            AionActivityKind.ERROR -> AionCorePresentation(AionCoreTone.Error, false)
            else -> AionCorePresentation(AionCoreTone.Internal, true)
        }
    }
}

@Composable
fun AionCore(state: AionActivityState?, size: Dp = 30.dp, modifier: Modifier = Modifier) {
    val presentation = AionCorePresentation.from(state)
    val color = when (presentation.tone) {
        AionCoreTone.Dormant -> AionColors.TextTertiary
        AionCoreTone.Internal -> AionColors.VioletElectric
        AionCoreTone.External -> AionColors.AionBlue
        AionCoreTone.Success -> AionColors.Success
        AionCoreTone.Warning -> AionColors.Warning
        AionCoreTone.Error -> AionColors.Error
        AionCoreTone.Offline -> AionColors.TextMuted
    }
    Canvas(modifier.size(size)) {
        val stroke = (this.size.minDimension * 0.105f).coerceAtLeast(1.5f)
        val inset = stroke
        drawArc(
            color = color.copy(alpha = if (presentation.active) 0.98f else 0.76f),
            startAngle = 345f,
            sweepAngle = 300f,
            useCenter = false,
            topLeft = Offset(inset, inset),
            size = Size(this.size.width - inset * 2, this.size.height - inset * 2),
            style = Stroke(stroke, cap = StrokeCap.Round),
        )
        drawCircle(
            color = color.copy(alpha = if (presentation.active) 0.24f else 0.10f),
            radius = this.size.minDimension * 0.19f,
            center = center,
        )
    }
}
