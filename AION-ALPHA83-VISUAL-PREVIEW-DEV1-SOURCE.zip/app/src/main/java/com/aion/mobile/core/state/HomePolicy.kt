package com.aion.mobile.core.state

import com.aion.mobile.core.storage.ConversationSummary

object HomePolicy {
    private const val MAX_HOME_SUGGESTIONS = 3

    fun visibleSuggestionKeys(keys: List<String>): List<String> = keys.take(MAX_HOME_SUGGESTIONS)

    fun recentConversations(items: List<ConversationSummary>): List<ConversationSummary> =
        items.sortedByDescending { it.updatedAt }.take(3)

    fun pinnedConversations(items: List<ConversationSummary>): List<ConversationSummary> =
        items.filter { it.pinned }.sortedByDescending { it.updatedAt }.take(2)
}
