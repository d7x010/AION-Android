package com.aion.mobile.core.state

/** Keeps the preview account surface honest until a real session backend is configured. */
object AuthPreviewPolicy {
    fun requiresAuthenticationToUseAion(hasBackend: Boolean): Boolean = hasBackend

    fun canSubmitCredentials(hasBackend: Boolean): Boolean = hasBackend
}
