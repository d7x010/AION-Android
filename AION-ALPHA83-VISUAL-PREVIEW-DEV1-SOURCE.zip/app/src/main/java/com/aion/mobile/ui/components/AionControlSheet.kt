package com.aion.mobile.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.KeyboardArrowLeft
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.aion.mobile.ui.design.AionColors

@Composable
fun AionControlSheet(
    modelLabel: String,
    researchRelevant: Boolean,
    onPower: () -> Unit,
    onEffort: () -> Unit,
    onModels: () -> Unit,
    onResearch: () -> Unit,
) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 8.dp)) {
        Text("التحكم في AION", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Text(
            "إعدادات هذه المحادثة",
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            style = MaterialTheme.typography.bodySmall,
        )
        ControlRow("القوة", "يديرها AION تلقائيًا", onPower)
        ControlRow("الجهد", "تلقائي", onEffort)
        ControlRow("النموذج", modelLabel, onModels)
        if (researchRelevant) ControlRow("البحث", "عند الحاجة", onResearch)
    }
}

@Composable
private fun ControlRow(title: String, value: String, onClick: () -> Unit) {
    Surface(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        shape = RoundedCornerShape(17.dp),
        color = AionColors.SurfaceRaised,
        border = BorderStroke(1.dp, AionColors.Border),
    ) {
        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.SemiBold)
                Text(value, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
            }
            Icon(Icons.Outlined.KeyboardArrowLeft, contentDescription = "فتح $title", tint = AionColors.TextTertiary)
        }
    }
}
