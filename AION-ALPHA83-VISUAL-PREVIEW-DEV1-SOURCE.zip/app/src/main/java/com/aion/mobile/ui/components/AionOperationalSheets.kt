package com.aion.mobile.ui.components

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.aion.mobile.core.state.AionPeakMode
import com.aion.mobile.core.state.PeakPolicy

@Composable
fun AionPowerSheet(
    selected: AionPeakMode,
    onSelect: (AionPeakMode) -> Unit,
    onBack: () -> Unit,
) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Outlined.ArrowBack, contentDescription = "رجوع") }
            Text("وضع الأداء", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        }
        Text(
            "يغيّر هذا الاختيار طابع الواجهة والحركة فقط في المعاينة؛ لا يمنح صلاحيات ولا استقلالية ولا يبدّل النموذج.",
            modifier = Modifier.padding(12.dp),
            style = MaterialTheme.typography.bodyMedium,
        )
        AionPeakMode.entries.forEach { mode ->
            val selectedMark = if (mode == selected) " — مُختار" else ""
            Button(
                onClick = { onSelect(mode) },
                modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp),
            ) { Text(PeakPolicy.labelFor(mode) + selectedMark) }
        }
    }
}

@Composable
fun AionEffortSheet(onBack: () -> Unit) = OperationalSheet(
    title = "الجهد",
    body = "يحدد AION عمق المعالجة تلقائيًا حسب المهمة. لا توجد قيمة يدوية مربوطة بالـruntime حاليًا.",
    onBack = onBack,
)

@Composable
fun AionResearchSheet(enabled: Boolean, onEnable: () -> Unit, onBack: () -> Unit) {
    OperationalSheet(
        title = "البحث",
        body = if (enabled) "البحث الحي مفعّل لهذه المحادثة." else "البحث يعمل عند الحاجة، ويمكن تفعيل وضع البحث الحي الحالي.",
        onBack = onBack,
        action = if (enabled) null else "تفعيل البحث الحي" to onEnable,
    )
}

@Composable
fun AionPermissionsSheet(onBack: () -> Unit) = OperationalSheet(
    title = "الصلاحيات",
    body = "لا تغيّر أوضاع القوة والجهد صلاحيات النظام. يطلب AION الإذن عند الحاجة إلى إجراء حقيقي.",
    onBack = onBack,
)

@Composable
private fun OperationalSheet(
    title: String,
    body: String,
    onBack: () -> Unit,
    action: Pair<String, () -> Unit>? = null,
) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Outlined.ArrowBack, contentDescription = "رجوع") }
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        }
        Text(body, modifier = Modifier.padding(12.dp), style = MaterialTheme.typography.bodyMedium)
        action?.let { (label, callback) -> Button(onClick = callback) { Text(label) } }
    }
}
