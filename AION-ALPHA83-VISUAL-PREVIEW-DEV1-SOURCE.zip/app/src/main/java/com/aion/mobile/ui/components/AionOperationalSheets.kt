package com.aion.mobile.ui.components

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

@Composable
fun AionPowerSheet(onBack: () -> Unit) = OperationalSheet(
    title = "القوة",
    body = "يدير AION موارد التنفيذ تلقائيًا في هذا الإصدار. القوة لا تمنح أي صلاحية إضافية.",
    onBack = onBack,
)

@Composable
fun AionEffortSheet(onBack: () -> Unit) = OperationalSheet(
    title = "الجهد",
    body = "يحدد AION عمق المعالجة تلقائيًا حسب المهمة. لا توجد قيمة يدوية مربوطة بالـruntime حاليًا.",
    onBack = onBack,
)

@Composable
fun AionResearchSheet(enabled: Boolean, onEnable: () -> Unit, onBack: () -> Unit) {
    OperationalSheet(
        title = "البحث",
        body = if (enabled) "البحث الحي مفعّل لهذه المحادثة." else "البحث يعمل عند الحاجة، ويمكن تفعيل وضع البحث الحي الحالي.",
        onBack = onBack,
        action = if (enabled) null else "تفعيل البحث الحي" to onEnable,
    )
}

@Composable
fun AionPermissionsSheet(onBack: () -> Unit) = OperationalSheet(
    title = "الصلاحيات",
    body = "لا تغيّر أوضاع القوة والجهد صلاحيات النظام. يطلب AION الإذن عند الحاجة إلى إجراء حقيقي.",
    onBack = onBack,
)

@Composable
private fun OperationalSheet(
    title: String,
    body: String,
    onBack: () -> Unit,
    action: Pair<String, () -> Unit>? = null,
) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Outlined.ArrowBack, contentDescription = "رجوع") }
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        }
        Text(body, modifier = Modifier.padding(12.dp), style = MaterialTheme.typography.bodyMedium)
        action?.let { (label, callback) -> Button(onClick = callback) { Text(label) } }
    }
}
