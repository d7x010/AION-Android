package com.aion.mobile.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.aion.mobile.feature.chat.AiModelOption
import com.aion.mobile.ui.design.AionColors
import com.aion.mobile.ui.theme.AionBlueSoft
import com.aion.mobile.ui.theme.AionPurple
import com.aion.mobile.ui.theme.AionPurpleSoft

@Composable
fun AionContextSheet(
    messageCount: Int,
    selectedModel: AiModelOption,
    isConfigured: Boolean,
    cloudHealthLabel: String,
    cloudHealthOk: Boolean?,
    pendingAttachments: Int,
    memoryEnabled: Boolean,
    temporaryMemory: Boolean,
    projectName: String?,
    onTemporaryMemoryChange: (Boolean) -> Unit,
) {
    Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 8.dp)) {
        Text("سياق المحادثة", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(5.dp))
        Text(
            "هذه اللوحة تظهر عند الطلب فقط حتى تبقى الدردشة نظيفة.",
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            style = MaterialTheme.typography.bodySmall
        )
        Spacer(Modifier.height(15.dp))
        ContextRow("النموذج الحالي", selectedModel.label, AionPurple)
        ContextRow("الرسائل", messageCount.toString(), AionPurpleSoft)
        ContextRow("المشروع", projectName ?: "بدون مشروع", if (projectName != null) AionPurple else AionColors.TextTertiary)
        ContextRow("البحث في الويب", "تلقائي عند الحاجة", AionBlueSoft)
        ContextRow("المرفقات الجاهزة", pendingAttachments.toString(), AionPurpleSoft)
        ContextRow(
            "اتصال AION Cloud",
            when {
                !isConfigured -> "غير مضبوط"
                cloudHealthOk == true -> cloudHealthLabel
                cloudHealthOk == false -> "تعذر التحقق"
                else -> "العنوان مضبوط"
            },
            when {
                cloudHealthOk == true -> AionPurple
                cloudHealthOk == false -> MaterialTheme.colorScheme.error
                else -> AionColors.TextTertiary
            }
        )
        ContextRow(
            "الذاكرة المحلية",
            when {
                temporaryMemory -> "موقوفة لهذه المحادثة"
                memoryEnabled -> "مفعلة"
                else -> "معطلة من الإعدادات"
            },
            if (memoryEnabled && !temporaryMemory) AionPurple else AionColors.TextTertiary
        )
        Surface(
            modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
            shape = RoundedCornerShape(15.dp),
            color = AionColors.SurfaceRaised
        ) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 13.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text("محادثة مؤقتة", fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.labelLarge)
                    Text(
                        "عند تفعيلها لا تُقرأ الذاكرة ولا يُسمح بالحفظ منها لهذه المحادثة.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
                Switch(checked = temporaryMemory, onCheckedChange = onTemporaryMemoryChange)
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun ContextRow(label: String, value: String, accent: Color) {
    Surface(
        modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp),
        shape = RoundedCornerShape(15.dp),
        color = AionColors.SurfaceRaised
    ) {
        Row(modifier = Modifier.fillMaxWidth().padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(7.dp).clip(CircleShape).background(accent))
            Spacer(Modifier.width(9.dp))
            Text(label, modifier = Modifier.weight(1f), color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
            Text(value, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.labelMedium)
        }
    }
}
