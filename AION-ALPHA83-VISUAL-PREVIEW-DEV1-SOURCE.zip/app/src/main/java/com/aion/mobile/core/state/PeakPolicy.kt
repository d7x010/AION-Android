package com.aion.mobile.core.state

enum class AionPeakMode { CALM, BALANCED, PERFORMANCE, PEAK }

enum class AionPeakVisualProfile { FULL, QUICK, SILENT, ACCESSIBLE }

object PeakPolicy {
    fun labelFor(mode: AionPeakMode): String = when (mode) {
        AionPeakMode.CALM -> "هادئ"
        AionPeakMode.BALANCED -> "متوازن"
        AionPeakMode.PERFORMANCE -> "أداء"
        AionPeakMode.PEAK -> "أقصى طاقة"
    }

    fun capabilityFor(mode: AionPeakMode, profile: AionPeakVisualProfile): AionPeakMode = mode
    fun grantsPermissions(mode: AionPeakMode): Boolean = false
    fun grantsAutonomy(mode: AionPeakMode): Boolean = false
    fun introDurationMs(profile: AionPeakVisualProfile): Int = when (profile) {
        AionPeakVisualProfile.FULL -> 1_150
        AionPeakVisualProfile.QUICK -> 420
        AionPeakVisualProfile.SILENT -> 0
        AionPeakVisualProfile.ACCESSIBLE -> 280
    }
}
