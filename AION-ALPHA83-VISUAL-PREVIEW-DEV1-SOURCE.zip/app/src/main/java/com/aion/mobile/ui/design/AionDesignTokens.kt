package com.aion.mobile.ui.design

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * AION α8.3 frozen visual-preview tokens. UI code consumes these semantic values instead of inventing
 * one-off colors, radii or touch sizes in individual screens.
 */
object AionColors {
    val Background = Color(0xFF0D0D12)
    val Surface = Color(0xFF14141C)
    val SurfaceHigh = Color(0xFF1B1B26)
    val SurfaceRaised = SurfaceHigh
    val SurfaceInteractive = Color(0xFF1E1E25)
    val SurfaceMuted = Color(0xFF15151A)
    val SurfaceSelected = Color(0xFF171221)
    val Border = Color(0xFF292932)
    val BorderStrong = Color(0xFF353540)
    val BorderFocused = Color(0xFF4B3D78)

    val TextPrimary = Color(0xFFF5F5F7)
    val TextSecondary = Color(0xFFA7A7B2)
    val TextMuted = Color(0xFF6F707C)
    val TextTertiary = Color(0xFF858692)
    val TextDisabled = TextMuted

    val VioletDeep = Color(0xFF4C1D95)
    val VioletMain = Color(0xFF7C3AED)
    val VioletElectric = Color(0xFF9D5CFF)
    val VioletGlow = Color(0xFFB48CFF)
    val Intelligence = VioletMain
    val IntelligenceStrong = VioletElectric
    val IntelligenceSoft = VioletGlow

    val AionBlue = Color(0xFF4D8DFF)
    val IceBlue = Color(0xFF78B7FF)
    val External = AionBlue
    val ExternalSoft = IceBlue

    val Success = Color(0xFF3DDC97)
    val Warning = Color(0xFFF6B94A)
    val Error = Color(0xFFFF6B6B)
}

object AionSpacing {
    val Zero: Dp = 0.dp
    val Xs: Dp = 4.dp
    val Sm: Dp = 8.dp
    val Md: Dp = 12.dp
    val Lg: Dp = 16.dp
    val Xl: Dp = 20.dp
    val Xxl: Dp = 24.dp
    val Xxxl: Dp = 32.dp
    val Huge: Dp = 40.dp
    val Max: Dp = 48.dp
}

object AionRadii {
    val Small: Dp = 8.dp
    val Medium: Dp = 12.dp
    val Large: Dp = 16.dp
    val Card: Dp = 20.dp
    val Expanded: Dp = 24.dp
    val Composer: Dp = 28.dp
    val Chip: Dp = Medium
    val Attachment: Dp = Large
    val UserBubble: Dp = Expanded
}

object AionSizes {
    val Icon: Dp = 24.dp
    val SmallIcon: Dp = 18.dp
    val TouchTarget: Dp = 48.dp
    val TopBarHeight: Dp = 56.dp
    val ComposerMinHeight: Dp = 60.dp
    val PrimaryAction: Dp = 52.dp
    val LiveButton: Dp = 48.dp
    val ActivityMark: Dp = 18.dp
    val AttachmentThumb: Dp = 56.dp
    val AttachmentIconBox: Dp = 38.dp
    val AttachmentCardMinWidth: Dp = 184.dp
    val AttachmentCardMaxWidth: Dp = 286.dp
    val AttachmentImageHeight: Dp = 168.dp
    val ContentMaxWidth: Dp = 760.dp
    val DrawerMaxWidth: Dp = 372.dp
    val MiniLiveOrb: Dp = 56.dp
}

object AionLayout {
    /** Maximum width of a user bubble relative to the readable content column. */
    const val UserBubbleMaxFraction: Float = 0.78f

    val ChatHorizontalPadding: Dp = 16.dp
    val ChatVerticalPadding: Dp = 12.dp
    val MessageSpacing: Dp = 20.dp

    val ComposerOuterHorizontal: Dp = 10.dp
    val ComposerOuterTop: Dp = 5.dp
    val ComposerOuterBottom: Dp = 5.dp

    val UserBubbleHorizontalPadding: Dp = 14.dp
    val UserBubbleVerticalPadding: Dp = 10.dp
    val AssistantTextEdgePadding: Dp = 2.dp

    val ScrollReturnBottomGap: Dp = 12.dp
}

object AionMotion {
    const val PressMs = 90
    const val FastMs = 140
    const val MorphMs = 190
    const val StandardMs = MorphMs
    const val PageMs = 220
    const val SheetMs = 260
    const val HeroMs = 360
    const val PeakFullMs = 1_150
    const val PeakQuickMs = 420
    const val PeakAccessibleMs = 280
}
