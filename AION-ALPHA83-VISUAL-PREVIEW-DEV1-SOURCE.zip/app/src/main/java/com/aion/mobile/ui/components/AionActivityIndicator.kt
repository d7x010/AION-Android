package com.aion.mobile.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import com.aion.mobile.core.state.AionActivityKind
import com.aion.mobile.core.state.AionActivityState
import com.aion.mobile.ui.design.AionColors
import com.aion.mobile.ui.design.AionSizes

@Composable
fun AionActivityIndicator(
    state: AionActivityState,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier,
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Start
    ) {
        AionActivityMark(state = state)
        Spacer(Modifier.width(8.dp))
        Text(
            text = activityLabel(state),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun AionActivityMark(state: AionActivityState) {
    val color = activityColor(state.kind)
    Canvas(Modifier.size(AionSizes.ActivityMark)) {
        val w = size.width
        val h = size.height
        val center = Offset(w / 2f, h / 2f)
        val stroke = (w * 0.10f).coerceAtLeast(1.4f)

        when (state.kind) {
            AionActivityKind.SEARCHING_WEB -> {
                drawCircle(color.copy(alpha = 0.18f), radius = w * 0.18f, center = center)
                drawArc(
                    color = color,
                    startAngle = -75f,
                    sweepAngle = 215f,
                    useCenter = false,
                    topLeft = Offset(stroke, stroke),
                    size = androidx.compose.ui.geometry.Size(w - stroke * 2f, h - stroke * 2f),
                    style = Stroke(width = stroke, cap = StrokeCap.Round),
                )
            }

            AionActivityKind.READING_FILES -> {
                val inset = w * 0.19f
                drawRoundRect(
                    color = color.copy(alpha = 0.72f),
                    topLeft = Offset(inset, inset * 0.65f),
                    size = androidx.compose.ui.geometry.Size(w - inset * 2f, h - inset * 1.3f),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(w * 0.08f),
                    style = Stroke(width = stroke)
                )
                val y = h * 0.50f
                drawLine(
                    color = color,
                    start = Offset(w * 0.29f, y),
                    end = Offset(w * 0.71f, y),
                    strokeWidth = stroke,
                    cap = StrokeCap.Round
                )
            }

            AionActivityKind.WRITING -> {
                val x = w * 0.50f
                drawLine(
                    color = color.copy(alpha = 0.82f),
                    start = Offset(x, h * 0.20f),
                    end = Offset(x, h * 0.80f),
                    strokeWidth = stroke * 1.25f,
                    cap = StrokeCap.Round
                )
                drawCircle(color, radius = w * 0.08f, center = Offset(w * 0.30f, h * 0.72f))
            }

            AionActivityKind.RECONNECTING -> {
                drawArc(
                    color = color,
                    startAngle = 20f,
                    sweepAngle = 285f,
                    useCenter = false,
                    topLeft = Offset(stroke, stroke),
                    size = androidx.compose.ui.geometry.Size(w - stroke * 2f, h - stroke * 2f),
                    style = Stroke(width = stroke, cap = StrokeCap.Round),
                )
            }

            AionActivityKind.LISTENING,
            AionActivityKind.SPEAKING -> {
                val heights = floatArrayOf(0.34f, 0.70f, 0.48f, 0.82f)
                heights.forEachIndexed { index, base ->
                    val x = w * (0.26f + index * 0.16f)
                    val half = h * base * 0.38f
                    drawLine(
                        color = color,
                        start = Offset(x, center.y - half),
                        end = Offset(x, center.y + half),
                        strokeWidth = stroke,
                        cap = StrokeCap.Round
                    )
                }
            }

            AionActivityKind.ERROR -> {
                drawCircle(color.copy(alpha = 0.15f), radius = w * 0.42f, center = center)
                drawLine(color, Offset(center.x, h * 0.27f), Offset(center.x, h * 0.60f), strokeWidth = stroke, cap = StrokeCap.Round)
                drawCircle(color, radius = stroke * 0.68f, center = Offset(center.x, h * 0.75f))
            }

            else -> {
                // Internal work: quiet three-point mark instead of a generic spinner.
                val xs = floatArrayOf(0.27f, 0.50f, 0.73f)
                xs.forEachIndexed { index, xFactor ->
                    val alpha = if (index == 1) 1f else 0.58f
                    drawCircle(
                        color = color.copy(alpha = alpha),
                        radius = w * 0.09f,
                        center = Offset(w * xFactor, center.y)
                    )
                }
            }
        }
    }
}

private fun activityColor(kind: AionActivityKind): Color = when (kind) {
    AionActivityKind.SEARCHING_WEB,
    AionActivityKind.UPLOADING -> AionColors.External
    AionActivityKind.ERROR -> AionColors.Error
    else -> AionColors.Intelligence
}

private fun activityLabel(state: AionActivityState): String {
    state.detail?.trim()?.takeIf { it.isNotEmpty() }?.let { return it }
    return when (state.kind) {
        AionActivityKind.IDLE -> ""
        AionActivityKind.THINKING -> "جارٍ التفكير…"
        AionActivityKind.READING_FILES -> "أقرأ المرفقات…"
        AionActivityKind.SEARCHING_WEB -> "أبحث في الويب…"
        AionActivityKind.COMPARING -> "أقارن النتائج…"
        AionActivityKind.WRITING -> "أصيغ الإجابة…"
        AionActivityKind.UPLOADING -> "أرفع الملفات…"
        AionActivityKind.RECONNECTING -> "أعيد الاتصال…"
        AionActivityKind.LISTENING -> "أستمع إليك…"
        AionActivityKind.SPEAKING -> "AION يتحدث…"
        AionActivityKind.ERROR -> "تعذر إكمال العملية"
    }
}
