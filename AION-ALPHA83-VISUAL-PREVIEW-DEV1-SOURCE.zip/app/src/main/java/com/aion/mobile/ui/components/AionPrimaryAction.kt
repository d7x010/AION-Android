package com.aion.mobile.ui.components

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ArrowUpward
import androidx.compose.material.icons.outlined.Mic
import androidx.compose.material.icons.outlined.Stop
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import com.aion.mobile.core.state.ComposerPrimaryAction
import com.aion.mobile.ui.design.AionColors
import com.aion.mobile.ui.design.AionSizes

@Composable
fun AionPrimaryAction(
    action: ComposerPrimaryAction,
    isConfigured: Boolean,
    isListening: Boolean,
    amplitude: Float,
    onStop: () -> Unit,
    onSend: () -> Unit,
    onDictation: () -> Unit,
) {
    when (action) {
        ComposerPrimaryAction.STOP -> AionRoundAction(
            onClick = onStop,
            background = AionColors.TextPrimary,
        ) {
            Icon(
                Icons.Outlined.Stop,
                contentDescription = "إيقاف",
                tint = AionColors.Background,
                modifier = Modifier.size(AionSizes.SmallIcon),
            )
        }

        ComposerPrimaryAction.SEND -> AionRoundAction(
            onClick = onSend,
            background = if (isConfigured) AionColors.TextPrimary else AionColors.BorderStrong,
        ) {
            Icon(
                Icons.Outlined.ArrowUpward,
                contentDescription = "إرسال",
                tint = if (isConfigured) AionColors.Background else AionColors.TextSecondary,
                modifier = Modifier.size(AionSizes.Icon),
            )
        }

        ComposerPrimaryAction.DICTATION -> {
            val scale = if (isListening) (1f + amplitude / 60f).coerceAtMost(1.18f) else 1f
            Surface(
                onClick = onDictation,
                shape = CircleShape,
                color = if (isListening) AionColors.VioletMain.copy(alpha = 0.18f) else Color.Transparent,
                modifier = Modifier.size(AionSizes.TouchTarget).scale(scale),
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        Icons.Outlined.Mic,
                        contentDescription = if (isListening) "إيقاف الإملاء الصوتي" else "إملاء صوتي",
                        tint = if (isListening) AionColors.VioletGlow else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(AionSizes.Icon),
                    )
                }
            }
        }
    }
}

@Composable
private fun AionRoundAction(
    onClick: () -> Unit,
    background: Color,
    content: @Composable () -> Unit,
) {
    Surface(
        onClick = onClick,
        shape = CircleShape,
        color = background,
        modifier = Modifier.size(AionSizes.TouchTarget),
    ) {
        Box(contentAlignment = Alignment.Center) { content() }
    }
}
