package com.aion.mobile.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ArrowUpward
import androidx.compose.material.icons.outlined.Mic
import androidx.compose.material.icons.outlined.Stop
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import com.aion.mobile.core.state.ComposerPrimaryAction
import com.aion.mobile.ui.design.AionColors
import com.aion.mobile.ui.design.AionSizes

@Composable
fun AionPrimaryAction(
    action: ComposerPrimaryAction,
    isConfigured: Boolean,
    isListening: Boolean,
    amplitude: Float,
    onStop: () -> Unit,
    onSend: () -> Unit,
    onDictation: () -> Unit,
    onLive: () -> Unit,
) {
    when (action) {
        ComposerPrimaryAction.STOP -> AionRoundAction(
            onClick = onStop,
            background = AionColors.TextPrimary,
        ) {
            Icon(
                Icons.Outlined.Stop,
                contentDescription = "إيقاف",
                tint = AionColors.Background,
                modifier = Modifier.size(AionSizes.SmallIcon),
            )
        }

        ComposerPrimaryAction.SEND -> AionRoundAction(
            onClick = onSend,
            background = if (isConfigured) AionColors.TextPrimary else AionColors.BorderStrong,
        ) {
            Icon(
                Icons.Outlined.ArrowUpward,
                contentDescription = "إرسال",
                tint = if (isConfigured) AionColors.Background else AionColors.TextSecondary,
                modifier = Modifier.size(AionSizes.Icon),
            )
        }

        ComposerPrimaryAction.LIVE_AND_DICTATION -> {
            val scale = if (isListening) (1f + amplitude / 60f).coerceAtMost(1.18f) else 1f
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(
                    onClick = onDictation,
                    shape = CircleShape,
                    color = if (isListening) AionColors.VioletMain.copy(alpha = 0.18f) else Color.Transparent,
                    modifier = Modifier.size(AionSizes.TouchTarget).scale(scale),
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            Icons.Outlined.Mic,
                            contentDescription = if (isListening) "إيقاف الإملاء الصوتي" else "إملاء صوتي",
                            tint = if (isListening) AionColors.VioletGlow else MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(AionSizes.Icon),
                        )
                    }
                }
                if (!isListening) {
                    AionLiveEntryButton(onClick = onLive)
                }
            }
        }
    }
}

@Composable
private fun AionRoundAction(
    onClick: () -> Unit,
    background: Color,
    content: @Composable () -> Unit,
) {
    Surface(
        onClick = onClick,
        shape = CircleShape,
        color = background,
        modifier = Modifier.size(AionSizes.TouchTarget),
    ) {
        Box(contentAlignment = Alignment.Center) { content() }
    }
}

@Composable
private fun AionLiveEntryButton(onClick: () -> Unit) {
    Surface(
        onClick = onClick,
        shape = CircleShape,
        color = AionColors.TextPrimary,
        modifier = Modifier
            .size(AionSizes.TouchTarget)
            .semantics { contentDescription = "AION Live" },
    ) {
        Box(contentAlignment = Alignment.Center) {
            Row(
                horizontalArrangement = Arrangement.spacedBy(2.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                listOf(10.dp, 17.dp, 13.dp, 19.dp, 11.dp).forEachIndexed { index, height ->
                    Box(
                        Modifier
                            .width(2.dp)
                            .height(height)
                            .clip(CircleShape)
                            .background(if (index == 2) AionColors.VioletElectric else AionColors.Background)
                    )
                }
            }
        }
    }
}
