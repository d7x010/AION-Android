package com.aion.mobile.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Check
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aion.mobile.feature.chat.AiModelOption
import com.aion.mobile.ui.design.AionColors
import com.aion.mobile.ui.theme.AionBlueSoft
import com.aion.mobile.ui.theme.AionPurple
import com.aion.mobile.ui.theme.AionPurpleSoft

@Composable
fun AionModelSheet(
    options: List<AiModelOption>,
    selectedKey: String,
    onSelect: (String) -> Unit,
    onDismiss: () -> Unit
) {
    Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 8.dp)) {
        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(modifier = Modifier.weight(1f)) {
                Text("وضع AION لهذه المحادثة", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text(
                    "يُحفظ الاختيار لهذه المحادثة ويمكن تغييره في أي وقت.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    style = MaterialTheme.typography.bodySmall
                )
            }
            IconButton(onClick = onDismiss) { Icon(Icons.Outlined.Close, contentDescription = "إغلاق") }
        }
        Spacer(Modifier.height(12.dp))
        options.forEach { option ->
            val selected = option.key == selectedKey
            Surface(
                modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp).clickable(enabled = option.enabled) {
                    onSelect(option.key)
                },
                shape = RoundedCornerShape(17.dp),
                color = if (selected) AionColors.Intelligence.copy(alpha = 0.12f) else AionColors.SurfaceRaised,
                border = BorderStroke(1.dp, if (selected) AionColors.Intelligence.copy(alpha = 0.55f) else AionColors.Border)
            ) {
                Row(modifier = Modifier.fillMaxWidth().padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
                    ModelGlyph(option)
                    Spacer(Modifier.width(11.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            option.label,
                            fontWeight = FontWeight.SemiBold,
                            color = if (option.enabled) MaterialTheme.colorScheme.onSurface else AionColors.TextDisabled
                        )
                        Text(option.provider, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                    }
                    option.badge?.let {
                        Text(it, color = if (option.enabled) AionColors.IntelligenceSoft else AionColors.TextTertiary, style = MaterialTheme.typography.labelMedium)
                        Spacer(Modifier.width(7.dp))
                    }
                    if (selected) Icon(Icons.Outlined.Check, contentDescription = null, tint = AionPurple)
                }
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun ModelGlyph(option: AiModelOption) {
    val color = when {
        option.key == "auto" -> AionPurple
        option.provider == "OpenAI" -> Color(0xFFE8E8EC)
        option.key == "claude" -> Color(0xFFE07B49)
        option.key == "gemini" -> AionBlueSoft
        option.key == "grok" -> Color(0xFFD7D7DA)
        option.key == "deepseek" -> Color(0xFF658CFF)
        else -> AionPurpleSoft
    }
    Surface(shape = CircleShape, color = color.copy(alpha = 0.14f), modifier = Modifier.size(36.dp)) {
        Box(contentAlignment = Alignment.Center) {
            Text(
                when (option.key) {
                    "auto" -> "A"
                    "fast" -> "↗"
                    "deep" -> "◈"
                    "research" -> "⌕"
                    "claude" -> "C"
                    "gemini" -> "✦"
                    "grok" -> "X"
                    else -> "AI"
                },
                color = color,
                fontWeight = FontWeight.ExtraBold,
                fontSize = 12.sp
            )
        }
    }
}
