package com.aion.mobile.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.aion.mobile.ui.design.AionColors

// Backward-compatible aliases while α7.3 components migrate to semantic design tokens.
val AionPurple = AionColors.Intelligence
val AionPurpleStrong = AionColors.IntelligenceStrong
val AionPurpleSoft = AionColors.IntelligenceSoft
val AionBlueSoft = AionColors.ExternalSoft
val AionBlack = AionColors.Background
val AionSurface = AionColors.Surface
val AionSurfaceRaised = AionColors.SurfaceRaised

private val AionDarkColors = darkColorScheme(
    primary = AionColors.Intelligence,
    onPrimary = Color.White,
    primaryContainer = Color(0xFF261A45),
    onPrimaryContainer = Color(0xFFECE4FF),
    secondary = AionColors.External,
    onSecondary = Color(0xFF06142B),
    background = AionColors.Background,
    onBackground = AionColors.TextPrimary,
    surface = AionColors.Surface,
    onSurface = AionColors.TextPrimary,
    surfaceVariant = AionColors.SurfaceRaised,
    onSurfaceVariant = AionColors.TextSecondary,
    outline = AionColors.Border,
    error = AionColors.Error,
    onError = Color(0xFF2B050A)
)

/**
 * Arabic-first reading scale. The main response text intentionally gets a little more
 * line-height than α7.2 for long-form comfort.
 */
private val AionTypography = Typography(
    displaySmall = TextStyle(
        fontSize = 28.sp,
        lineHeight = 38.sp,
        fontWeight = FontWeight.SemiBold,
        letterSpacing = 0.sp
    ),
    bodyLarge = TextStyle(
        fontSize = 16.sp,
        lineHeight = 26.sp,
        fontWeight = FontWeight.Normal,
        letterSpacing = 0.sp
    ),
    bodyMedium = TextStyle(
        fontSize = 14.sp,
        lineHeight = 22.sp,
        fontWeight = FontWeight.Normal,
        letterSpacing = 0.sp
    ),
    bodySmall = TextStyle(
        fontSize = 12.sp,
        lineHeight = 18.sp,
        fontWeight = FontWeight.Normal,
        letterSpacing = 0.sp
    ),
    titleLarge = TextStyle(
        fontSize = 22.sp,
        lineHeight = 30.sp,
        fontWeight = FontWeight.Bold,
        letterSpacing = 0.sp
    ),
    titleMedium = TextStyle(
        fontSize = 18.sp,
        lineHeight = 26.sp,
        fontWeight = FontWeight.SemiBold,
        letterSpacing = 0.sp
    ),
    titleSmall = TextStyle(
        fontSize = 15.sp,
        lineHeight = 22.sp,
        fontWeight = FontWeight.SemiBold,
        letterSpacing = 0.sp
    ),
    labelLarge = TextStyle(
        fontSize = 14.sp,
        lineHeight = 20.sp,
        fontWeight = FontWeight.SemiBold,
        letterSpacing = 0.sp
    ),
    labelMedium = TextStyle(
        fontSize = 12.sp,
        lineHeight = 18.sp,
        fontWeight = FontWeight.Medium,
        letterSpacing = 0.sp
    )
)

@Composable
fun AionTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = AionDarkColors,
        typography = AionTypography,
        content = content
    )
}
