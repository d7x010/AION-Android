package com.aion.mobile.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.aion.mobile.ui.design.AionRadii

data class AionContextChip(
    val key: String,
    val label: String,
    val accent: Color,
)

@Composable
fun AionContextStrip(
    items: List<AionContextChip>,
    hiddenCount: Int,
    modifier: Modifier = Modifier,
) {
    if (items.isEmpty() && hiddenCount == 0) return

    LazyRow(
        modifier = modifier,
        horizontalArrangement = Arrangement.spacedBy(7.dp),
        contentPadding = PaddingValues(horizontal = 3.dp, vertical = 2.dp),
    ) {
        items(items, key = { it.key }) { item ->
            AionContextChipView(item)
        }
        if (hiddenCount > 0) {
            item(key = "overflow") {
                AionContextChipView(
                    AionContextChip(
                        key = "overflow",
                        label = "+$hiddenCount",
                        accent = items.lastOrNull()?.accent ?: Color.Gray,
                    )
                )
            }
        }
    }
}

@Composable
private fun AionContextChipView(item: AionContextChip) {
    Surface(
        shape = RoundedCornerShape(AionRadii.Chip),
        color = item.accent.copy(alpha = 0.10f),
        border = BorderStroke(1.dp, item.accent.copy(alpha = 0.28f)),
    ) {
        Text(
            text = item.label,
            modifier = Modifier.padding(horizontal = 9.dp, vertical = 6.dp),
            color = item.accent,
            style = androidx.compose.material3.MaterialTheme.typography.labelMedium,
        )
    }
}
