package com.aion.mobile.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.aion.mobile.ui.design.AionColors
import com.aion.mobile.ui.design.AionSpacing

/** Creates a real Project-backed work context; it does not claim a separate Work engine. */
@Composable
fun AionNewWorkSheet(
    onCreate: (name: String, instructions: String) -> Unit,
    onDismiss: () -> Unit,
) {
    var goal by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("") }

    Column(
        modifier = Modifier.fillMaxWidth().padding(horizontal = AionSpacing.Lg, vertical = AionSpacing.Md),
        verticalArrangement = Arrangement.spacedBy(AionSpacing.Sm),
    ) {
        Text("عمل جديد", style = MaterialTheme.typography.titleLarge, color = AionColors.TextPrimary)
        Text(
            "ابدأ بالهدف. سينشئ AION مشروعًا ومحادثة مرتبطة فارغة؛ بعدها تستطيع إضافة ملفات أو سياق من زر + قبل أول رسالة. لا يدّعي محرك عمل مستقلًا غير موجود.",
            style = MaterialTheme.typography.bodyMedium,
            color = AionColors.TextSecondary,
        )
        OutlinedTextField(
            value = goal,
            onValueChange = { goal = it.take(6_000) },
            label = { Text("ما الهدف الذي تريد إنجازه؟") },
            minLines = 3,
            maxLines = 6,
            modifier = Modifier.fillMaxWidth(),
        )
        OutlinedTextField(
            value = name,
            onValueChange = { name = it.take(60) },
            label = { Text("اسم اختياري للعمل") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
        )
        Spacer(Modifier.height(2.dp))
        TextButton(
            onClick = {
                val cleanGoal = goal.trim()
                if (cleanGoal.isNotBlank()) {
                    onCreate(
                        name.trim().ifBlank { cleanGoal.take(60) },
                        "الهدف:\n$cleanGoal",
                    )
                }
            },
            enabled = goal.isNotBlank(),
            modifier = Modifier.fillMaxWidth(),
        ) { Text("إنشاء العمل") }
        TextButton(onClick = onDismiss, modifier = Modifier.fillMaxWidth()) { Text("إلغاء") }
    }
}
