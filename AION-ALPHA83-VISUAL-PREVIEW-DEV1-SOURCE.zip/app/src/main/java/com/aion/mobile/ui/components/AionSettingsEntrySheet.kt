package com.aion.mobile.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.aion.mobile.ui.design.AionColors
import com.aion.mobile.ui.design.AionSpacing

/** A truthful settings landing surface; advanced controls remain wired to the existing settings flow. */
@Composable
fun AionSettingsEntrySheet(onOpenAdvanced: () -> Unit, onDismiss: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxWidth().padding(horizontal = AionSpacing.Lg, vertical = AionSpacing.Md),
        verticalArrangement = Arrangement.spacedBy(AionSpacing.Sm),
    ) {
        Text("الإعدادات", style = MaterialTheme.typography.titleLarge, color = AionColors.TextPrimary)
        Text("الاتصال والسحابة والذاكرة والصوت تُدار من مكان واحد.", color = AionColors.TextSecondary)
        TextButton(onClick = onOpenAdvanced, modifier = Modifier.fillMaxWidth()) { Text("فتح الإعدادات") }
        TextButton(onClick = onDismiss, modifier = Modifier.fillMaxWidth()) { Text("إغلاق") }
    }
}
