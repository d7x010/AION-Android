package com.aion.mobile.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.aion.mobile.ui.design.AionColors
import com.aion.mobile.ui.design.AionSpacing

/**
 * The dedicated settings landing surface.  It deliberately exposes only one real destination:
 * the existing settings editor, which owns Cloud, memory and voice persistence.
 */
@Composable
fun AionSettingsEntrySheet(onOpenAdvanced: () -> Unit, onDismiss: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxWidth().padding(horizontal = AionSpacing.Lg, vertical = AionSpacing.Md),
        verticalArrangement = Arrangement.spacedBy(AionSpacing.Sm),
    ) {
        Text("الإعدادات", style = MaterialTheme.typography.titleLarge, color = AionColors.TextPrimary)
        Text(
            "إعدادات التطبيق الفعلية في مكان مستقل عن قائمة المحادثات.",
            color = AionColors.TextSecondary,
        )
        HorizontalDivider()
        Text("AION Cloud", style = MaterialTheme.typography.titleMedium, color = AionColors.TextPrimary)
        Text("الاتصال، حالة الخدمة، وتعليمات AION.", color = AionColors.TextSecondary)
        Text("الذاكرة والخصوصية", style = MaterialTheme.typography.titleMedium, color = AionColors.TextPrimary)
        Text("الذاكرة المحلية وخيارات الخصوصية المتاحة.", color = AionColors.TextSecondary)
        Text("الصوت", style = MaterialTheme.typography.titleMedium, color = AionColors.TextPrimary)
        Text("اختيار الصوت ومعاينته عند توفره فعليًا.", color = AionColors.TextSecondary)
        TextButton(onClick = onOpenAdvanced, modifier = Modifier.fillMaxWidth()) { Text("إدارة هذه الإعدادات") }
        TextButton(onClick = onDismiss, modifier = Modifier.fillMaxWidth()) { Text("إغلاق") }
    }
}
