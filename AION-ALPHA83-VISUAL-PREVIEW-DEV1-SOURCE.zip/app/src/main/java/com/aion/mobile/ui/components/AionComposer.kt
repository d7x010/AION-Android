package com.aion.mobile.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import com.aion.mobile.ui.design.AionColors
import com.aion.mobile.ui.design.AionRadii
import com.aion.mobile.ui.design.AionSizes
import com.aion.mobile.core.state.ComposerLayoutPolicy

@Composable
fun AionComposerFrame(
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit,
) {
    BoxWithConstraints(
        modifier = modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .imePadding(),
    ) {
        val horizontal = ComposerLayoutPolicy.horizontalMarginDp(maxWidth.value.toInt()).dp
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = horizontal, vertical = 5.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            content()
        }
    }
}

@Composable
fun AionComposerDock(
    value: String,
    onValueChange: (String) -> Unit,
    isListening: Boolean,
    isFocused: Boolean,
    onFocusChanged: (Boolean) -> Unit,
    startSlot: @Composable () -> Unit,
    endSlot: @Composable () -> Unit,
    modifier: Modifier = Modifier,
) {
    val contentDirection = LocalLayoutDirection.current
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(AionRadii.Composer),
        color = AionColors.SurfaceRaised,
        border = BorderStroke(
            1.dp,
            when {
                isListening -> AionColors.VioletMain.copy(alpha = 0.85f)
                isFocused -> AionColors.BorderFocused
                else -> AionColors.Border
            },
        ),
    ) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .defaultMinSize(minHeight = AionSizes.ComposerMinHeight)
                    .padding(horizontal = 5.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                startSlot()
                CompositionLocalProvider(LocalLayoutDirection provides contentDirection) {
                    BasicTextField(
                        value = value,
                        onValueChange = onValueChange,
                        modifier = Modifier
                            .weight(1f)
                            .onFocusChanged { onFocusChanged(it.isFocused) }
                            .padding(horizontal = 5.dp, vertical = 10.dp),
                        textStyle = MaterialTheme.typography.bodyLarge.copy(
                            color = MaterialTheme.colorScheme.onSurface,
                            textAlign = TextAlign.Start,
                        ),
                        cursorBrush = SolidColor(AionColors.VioletMain),
                        minLines = 1,
                        maxLines = 6,
                        decorationBox = { inner ->
                            Box {
                                if (value.isBlank()) {
                                    Text(
                                        "اكتب رسالة إلى AION…",
                                        color = if (isListening) AionColors.VioletGlow else MaterialTheme.colorScheme.onSurfaceVariant,
                                        style = MaterialTheme.typography.bodyMedium,
                                    )
                                }
                                inner()
                            }
                        },
                    )
                }
                endSlot()
            }
        }
    }
}
