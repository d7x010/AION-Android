package com.aion.mobile.core.state

/** Keeps compact navigation focused on chats before exposing infrequent capabilities. */
object DrawerPolicy {
    fun showSecondaryCapabilities(expanded: Boolean): Boolean = expanded
}
