package com.aion.mobile.ui.components

/** Lists only entry points that have a real integration behind them. */
enum class AionAddAction { Photos, Camera, File, ConnectedSource }

object AionAddSheetPolicy {
    fun availableActions(
        cameraAvailable: Boolean,
        connectedSourceAvailable: Boolean
    ): List<AionAddAction> = buildList {
        add(AionAddAction.Photos)
        if (cameraAvailable) add(AionAddAction.Camera)
        add(AionAddAction.File)
        if (connectedSourceAvailable) add(AionAddAction.ConnectedSource)
    }
}
