package com.aion.mobile.ui

import androidx.compose.foundation.layout.Column
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.remember
import androidx.compose.ui.test.assertExists
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithContentDescription
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.aion.mobile.ui.components.AionSheetHost
import com.aion.mobile.ui.state.AionSheetDestination
import com.aion.mobile.ui.state.AionSheetStack
import com.aion.mobile.ui.theme.AionTheme
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class AionSheetHostTest {
    @get:Rule val composeRule = createComposeRule()

    @Test
    fun modelBackReturnsToControlBeforeDismiss() {
        composeRule.setContent {
            var stack by remember {
                mutableStateOf(
                    AionSheetStack()
                        .push(AionSheetDestination.Control)
                        .push(AionSheetDestination.Models)
                )
            }
            AionTheme {
                AionSheetHost(
                    stack = stack,
                    onDismiss = { stack = stack.dismiss() },
                    onBack = { stack = stack.back() },
                    addSheet = { Text("إضافة") },
                    controlSheet = { Text("القوة") },
                    powerSheet = { Text("القوة") },
                    effortSheet = { Text("الجهد") },
                    modelSheet = {
                        Column {
                            Text("النماذج")
                            TextButton(onClick = { stack = stack.back() }) { Text("رجوع") }
                        }
                    },
                    researchSheet = { Text("البحث") },
                    permissionsSheet = { Text("الصلاحيات") },
                )
            }
        }
        composeRule.onNodeWithText("النماذج").assertExists()
        composeRule.onNodeWithText("رجوع").performClick()
        composeRule.onNodeWithText("القوة").assertExists()
    }
}
