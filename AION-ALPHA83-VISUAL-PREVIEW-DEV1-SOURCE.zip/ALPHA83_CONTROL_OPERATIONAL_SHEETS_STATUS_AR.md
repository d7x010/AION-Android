# AION α8.3 — Control and Operational Sheets Checkpoint

- أضيفت `AionControlSheet` بصفوف القوة والجهد والنموذج والبحث دون telemetry استعراضية.
- أضيفت وجهات Power وEffort وResearch وPermissions إلى `AionSheetStack`.
- كل الوجهات تُرسم من `AionSheetHost` نفسه، مع back إلى الوجهة السابقة وdismiss للجذر.
- Model يستخدم `chatViewModel::selectModel` الأصلية، والبحث الحي يستخدم shortcut الموجود مسبقًا فقط.
- Power/Effort لا تدّعيان إعداد runtime يدويًا غير موجود؛ تعرضان الإدارة التلقائية الحالية بوضوح.
- Add flow وimage/file pickers لم تتغير.
- أضيف اختبار UI للتنقل Models → Control، لكنه `execution pending CI`.
- Gradle/lint/build: `execution pending CI`.
- GitHub write blocker: إنشاء فرع α8.3 أعاد HTTP 403 `Resource not accessible by integration`.
