# AION α8.3 — الدفعة 4 / النقاط 31–40

## المنفذ فعليًا

31. New Chat: راجعت مسار `newConversation`؛ ينشئ سجلًا جديدًا ثم ينتقل إليه ولا يحذف السجل السابق.
32. New Work: الهدف أولًا، ثم Project ومحادثة فارغة فعلية عبر `createProject`.
33. السياق والملفات قبل أول رسالة: بعد إنشاء العمل تكون المحادثة الجديدة فارغة ويظل مسار `+` الحقيقي متاحًا قبل الإرسال.
34–37. Auth foundation: `Auth` destination داخل SheetHost الموحد، Entry/Sign In/Create Account/Profile واضحة كـPreview محلي، دون backend أو OAuth أو جلسة مزيفة. حقلا البريد وكلمة المرور يحملان دلالات لوحة مفاتيح مناسبة.
38. Peak model: أوضاع Calm/Balanced/Performance/Peak وملفات Full/Quick/Silent/Accessible.
39. Peak lifecycle foundation: مدد intro معتمدة (Full 1150ms، Quick 420ms، Silent 0، Accessible 280ms). لم أربطها بزر يغيّر runtime لأن runtime لا يملك حتى الآن Power profile قابلًا للتنفيذ؛ لا توجد حركة ادعائية.
40. فصل القدرة عن الصلاحيات/autonomy: `PeakPolicy` يثبت أن Peak لا يمنح أي إذن أو autonomy، وأن Accessible لا يقلل القدرة.

## التحقق

- اختبارات `PeakPolicyTest.kt` وامتداد `AionSheetStateTest.kt` كُتبت قبل/مع التنفيذ: execution pending CI.
- فحوصات بنيوية محلية: SheetStack واحدة، Host واحدة، Auth/NewWork داخل المضيف نفسه، ومسارات المرفقات/model selection باقية.
- Gradle/Android/lint: execution pending CI.
