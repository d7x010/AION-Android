# AION α8.3 — تصحيح ما بعد معاينة الجهاز / الدفعة 2: Home

## التغيير

- سطح Home لا يعرض محادثة فارغة تحمل الاسم الافتراضي «محادثة جديدة» ضمن Recent.
- لا تحذف السياسة المحادثة ولا تغيّر التخزين أو الانتقال أو جلسة AION Live؛ تغيّر فقط ما يستحق أن يظهر في سطح البداية.

## اختبار أولًا

- أضيف `recentHomeDoesNotSurfaceEmptyNewConversationPlaceholders` إلى `HomePolicyTest` قبل تغيير `HomePolicy`.
- التنفيذ المحلي: `pending CI` لغياب Gradle محليًا.
- CI للدفعة السابقة (Composer/Top Bar) نجحت في run `34808008274`؛ نجاحها لا يغطي هذا التغيير حتى snapshot التالية.
