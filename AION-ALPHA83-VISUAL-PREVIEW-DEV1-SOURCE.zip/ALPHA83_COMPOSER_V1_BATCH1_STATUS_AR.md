# AION α8.3 — Composer V1 / الدفعة الأولى

التاريخ: 2026-09-13

## المنفذ فعليًا

- أضيفت `ComposerContextPolicy` بأولوية ثابتة للحقيقة التشغيلية ثم المرفقات ثم سياق النموذج والمشروع، مع حد أقصى 3 عناصر ظاهرة.
- فُصل `AionContextStrip` عن صف المرفقات، ويعرض `+N` عند وجود سياقات إضافية.
- أضيف `AionAttachmentShelf` مستقل مع إبقاء معاينات المرفقات وإزالتها على callbacks الحالية.
- استُخرج هيكل المحرر إلى `AionComposerDock` بارتفاع أدنى 60dp، وبحد 6 أسطر قبل التمرير الداخلي.
- ثُبت موضع `+` في الجانب الفيزيائي الأيسر وPrimary Action في الجانب الفيزيائي الأيمن، مع إبقاء اتجاه النص الفعلي RTL/LTR داخل المحرر.
- استُخرج `AionPrimaryAction` مع حالات الإملاء/AION Live والإرسال والإيقاف دون إنشاء Queue وهمية.
- بقي الإملاء متصلًا بـ`SpeechRecognizer` الحالي، ويستخدم مؤشره قيمة RMS الحقيقية.
- بقي AION Live منفصلًا عن زر الإملاء وبنفس callback السابقة.
- لم تتغير pickers أو تحميل/تخزين المرفقات أو runtime أو Worker أو Cloud routing.

## التحقق المحلي

- فحصت call sites للمكوّنات الجديدة وعدم بقاء `InfoChip` أو `AionLiveEntryButton` القديمتين داخل `AionApp.kt`.
- يوجد إنشاء واحد فقط لـ`AionSheetStack` في المسار الفعلي، وAdd/Models ما زالت تمر عبر `AionSheetHost` الواحدة.
- استدعاءات `imagePicker.launch` و`filePicker.launch` و`selectModel(key)` الأصلية باقية.
- لا يتوفر Gradle أو Android SDK محليًا في هذه البيئة؛ لذلك لا توجد ادعاءات compile/PASS محلية.

## الاختبارات

- `ComposerContextPolicyTest.kt`: test authored, execution pending CI.
- `ComposerPolicyTest.kt`: execution pending CI.
- بقية اختبارات Gradle/Android: execution pending CI.

## بوابة CI

- تعذر إنشاء branch عبر GitHub connector برسالة: `HTTP 403 Resource not accessible by integration`.
- العمل البرمجي مستمر، والـworkflow المبكرة والبناء الكامل ينتظران صلاحية كتابة فعلية على GitHub.

## التالي

- Composer V1 / الدفعة الثانية: فحوصات RTL/حالة Primary Action، ثم Home + Drawer حسب الترتيب الحاكم.
