# AION α8.3 — تصحيح ما بعد معاينة الجهاز / الدفعة 1

## ما تغيّر فعليًا

- استبدلت حالة Composer الفارغة من `LIVE_AND_DICTATION` إلى `DICTATION`.
- صار زر الإجراء الأساسي عند المسودة الفارغة زر إملاء واحدًا فقط.
- أزيل زر AION Live الأبيض الكبير من داخل موضع الإجراء الأساسي.
- صار AION Live اختصارًا مستقلًا يظهر فقط عندما يكون الاتصال الحقيقي متاحًا ولا يكون Safe Mode فعالًا.
- أزيلت هوية AION النصية المكررة في أعلى الشاشة؛ أصبح Core هو الهوية، والسطر يعرض السياق المختصر فقط حتى لا يُقصّ على الهاتف.

## ما لم يتغير

- لا تعديل على runtime أو Worker أو Cloud routing أو التخزين أو المرفقات أو اختيار النموذج.
- لا تسجيل دخول/مزود/OAuth مزيف.
- لا queue أو waveform أو progress مزيف.

## الاختبارات والتحقق

- `ComposerPolicyTest.emptyComposerShowsOnlyDictationAsThePrimaryAction`: كتب قبل التغيير. التنفيذ `pending CI` لأن Gradle غير متاح محليًا.
- `AionTopBarPolicyTest`: كتب قبل التغيير. التنفيذ `pending CI` للسبب نفسه.
- فحص بنيوي محلي: لا يبقى `LIVE_AND_DICTATION` أو `AionLiveEntryButton` أو `onLive =` في مسار Composer؛ وAION Live يستدعي نفس `onStartVoiceCall()` السابقة.

## التالي

تصحيح Home والـDrawer والأسطح المستقلة للحساب والإعدادات وفق سجل تدقيق الجهاز، ثم تشغيل CI قبل أي APK جديدة.
