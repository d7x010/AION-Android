# AION α8.3 — الدفعة 3 / النقاط 21–30

التاريخ: 2026-09-13

## المنفذ فعليًا

21. Home shell هادئة وCore صغير.
22. Recent-first: أحدث 3 محادثات فقط، وبنفس `switchConversation` المحمي بجلسة AION Live.
23. Pinned conditional: لا يظهر القسم من دون بيانات مثبتة حقيقية.
24. اقتراحات Home: ثلاثة فقط.
25. New Chat: نفس `newConversation` الحقيقي ولا حذف للسجل.
26. New Work: Sheet هدف-first تنشئ Project حقيقيًا ثم محادثة مرتبطة عبر `ChatViewModel.createProject`؛ لا تدّعي Work Engine مستقلًا.
27. ترتيب Drawer: Search → New Chat → New Work → المحادثات (مثبتة/حديثة) → الأعمال والمشاريع → الملفات والمخرجات → المزيد.
28. Files/Artifacts: المسار صريح؛ يعرض حقيقة عدم وجود فهرس موحد بدل اختراع عناصر أو تقدم.
29. Account row: معاينة محلية صريحة تؤدي إلى Settings، بلا login وهمي؛ Auth foundation تبقى في دفعتها القادمة.
30. فحوصات بنيوية: stack واحدة، Host واحدة، والمسارات الأساسية للمرفقات/model selection موجودة.

## الاختبارات

- `HomePolicyTest.kt` و`AionSheetStateTest.kt`: test authored, execution pending CI.
- جميع اختبارات Gradle وAndroid: `execution pending CI`.

## حدود صريحة

- فهرس ملفات/Artifacts الحقيقي لم يُبن بعد، لذلك لا يدّعي التطبيق وجوده.
- تسجيل الدخول الحقيقي لم يُبن بعد، لذلك صف الحساب لا يتظاهر بجلسة أو مزود OAuth.
