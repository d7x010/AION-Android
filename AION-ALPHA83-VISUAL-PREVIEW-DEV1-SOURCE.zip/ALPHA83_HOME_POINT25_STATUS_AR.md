# AION α8.3 — نقطة 25: New Chat entry

- أضيف مدخل «محادثة جديدة» في Home باستخدام callback `onNewChat` الأصلية.
- لا يمس السجل السابق؛ يستدعي نفس `newConversation` المحمي بقفل AION Live الموجود أصلًا.
- Gradle/Android tests: execution pending CI.
