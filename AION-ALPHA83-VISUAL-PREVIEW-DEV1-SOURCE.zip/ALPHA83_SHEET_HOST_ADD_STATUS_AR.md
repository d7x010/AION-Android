# AION α8.3 — Sheet Host + Add Checkpoint

- Add Sheet انتقلت إلى `ui/components/AionAddSheet.kt`.
- `AionSheetHost` يرسم وجهة Add الوحيدة من `AionSheetStack`.
- Add تستخدم `AionAddSheetPolicy` ولا تعرض قدرات غير موصولة.
- بقية Sheets القديمة ما زالت مستقلة داخل `AionApp.kt` ولم تُنقل بعد.
- اختبارات Gradle: execution pending CI.
- Library upload pending بسبب: "Codex Library manage upload requires the top-level file bridge parameter."
- هذه checkpoint آمنة وليست إغلاقًا لـSheet System.
