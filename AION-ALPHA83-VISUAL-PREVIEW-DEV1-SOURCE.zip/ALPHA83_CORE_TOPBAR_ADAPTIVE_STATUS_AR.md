# AION α8.3 — Core / Top Bar / Adaptive Frame Checkpoint

- أضيف `AionCore` بهوية O داكنة وnotch أعلى اليمين.
- البنفسجي للنشاط الداخلي، والأزرق محصور في البحث/الرفع الخارجي الحقيقي.
- استُبدلت كل استدعاءات `AionMark` القديمة وحُذف تنفيذها المركزي.
- أضيف `AionTopBar`: Menu + Core/Context + إجراء محادثة جديدة واحد.
- الضغط على Core يفتح `AionSheetDestination.Control` في الـHost الموحد.
- أضيف `AionAdaptiveFramePolicy` لاختبارات Compact/compact-height/Expanded.
- أضيفت اختبارات pure policy، وحالتها `execution pending CI`.
- structural checks المحلية نجحت؛ Gradle/lint/build ما زالت pending CI.
- تعذر إنشاء فرع GitHub بسبب HTTP 403 `Resource not accessible by integration`؛ التطوير والحفظ في Library مستمران.
