# AION α8.3 — الدفعة 5 / النقاط 41–50

41. RTL/mixed direction: Composer يثبت + يسارًا وPrimary Action يمينًا فيزيائيًا بينما يبقي النص باتجاهه العربي/اللاتيني، و`supportsRtl=true` موجود.
42. IME/insets: `adjustResize` + `imePadding` + `navigationBarsPadding` مستخدمة في Composer.
43. Large Text: عند fontScale >= 1.3 تمنع سياسة الإطار التحول إلى عمودين ضيقين.
44. Landscape: ارتفاع أقل من 480dp يمنع فرض supporting pane.
45. Foldable: لا توجد WindowManager/hinge integration في المصدر الحالي؛ تعتمد المعاينة حاليًا على العرض/الارتفاع فقط ولا تدّعي hinge awareness مكتملة.
46. Back: `enableOnBackInvokedCallback=true` و`BackHandler` يعيدان وجهة Sheet السابقة ثم dismiss.
47. TalkBack: ضوابط Top Bar/Composer/Sheets تستعمل أوصافًا واضحة؛ لم يُعلن اختبار قارئ شاشة فعلي.
48. Contrast/touch: Design Tokens تحمل 48dp target؛ فحص Gradle accessibility لم يُشغّل بعد.
49. Motion/performance isolation: أزيلت infinite activity loops وwaveform المزيف من ActivityIndicator؛ الرمز ثابت ويتغير فقط مع Runtime truth.
50. State coverage: اختبارات Stack وAdaptive policy امتدت؛ screenshot/device tests execution pending CI/device.

## التحقق

- اختبارات جديدة/موسعة: `AionAdaptiveFramePolicyTest`, `AionSheetStateTest` — execution pending CI.
- Gradle/lint/APK/device: execution pending CI.
