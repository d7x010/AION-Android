# سجل AION Mobile V2

## 2.0.0-alpha1

- تأسيس مشروع Android أصلي.
- إنشاء واجهة RTL عربية داكنة.
- إضافة شاشة دردشة أساسية وشريط كتابة ورسائل.
- إضافة درج جانبي لقدرات AION.
- تأسيس طبقات مستقلة للذكاء الاصطناعي والوكيل والذاكرة والملفات والصوت والبحث والأدوات.
- إضافة اختبار وحدة لسجل القدرات.
- إضافة GitHub Actions للاختبار والفحص وبناء APK والتحقق من توقيعه.
- عدم تضمين أي مفتاح API سري داخل التطبيق.


## إصلاح البناء 2026-09-07
- إزالة `org.jetbrains.kotlin.android` لأن AGP 9.4 يستخدم Kotlin المدمجة تلقائيًا.
- الاعتماد على `compileOptions.targetCompatibility = JavaVersion.VERSION_17` لضبط هدف Kotlin تلقائيًا وفق Kotlin المدمجة.
- الإبقاء على `org.jetbrains.kotlin.plugin.compose` لأنه مطلوب لمترجم Compose مع Kotlin 2.x.

## إصلاح توافق Compose مع Android API 37
- رفع `compileSdk` من 36 إلى 37 لأن Compose 1.12.0 يتطلب Android API 37 أو أحدث وقت الترجمة.
- الإبقاء على `targetSdk = 36` و`minSdk = 26` دون تغيير سلوك التشغيل أو الحد الأدنى للأجهزة.
