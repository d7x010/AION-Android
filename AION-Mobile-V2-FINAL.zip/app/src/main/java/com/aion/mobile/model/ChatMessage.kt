package com.aion.mobile.model

enum class MessageRole {
    USER,
    AION
}

data class ChatMessage(
    val id: Long,
    val role: MessageRole,
    val text: String
)
