package com.aion.mobile.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.ArrowUpward
import androidx.compose.material.icons.outlined.AttachFile
import androidx.compose.material.icons.outlined.Build
import androidx.compose.material.icons.outlined.Check
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.ContentCopy
import androidx.compose.material.icons.outlined.Folder
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.KeyboardArrowDown
import androidx.compose.material.icons.outlined.Memory
import androidx.compose.material.icons.outlined.Menu
import androidx.compose.material.icons.outlined.Mic
import androidx.compose.material.icons.outlined.Psychology
import androidx.compose.material.icons.outlined.Public
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.SmartToy
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.aion.mobile.core.AionCapability
import com.aion.mobile.core.CapabilityState
import com.aion.mobile.core.FeatureRegistry
import com.aion.mobile.feature.chat.AiModelOption
import com.aion.mobile.feature.chat.ChatViewModel
import com.aion.mobile.model.ChatMessage
import com.aion.mobile.model.MessageRole
import com.aion.mobile.ui.theme.AionBlueSoft
import com.aion.mobile.ui.theme.AionPurple
import com.aion.mobile.ui.theme.AionPurpleSoft
import com.aion.mobile.ui.theme.AionPurpleStrong
import kotlinx.coroutines.launch

@Composable
fun AionApp(chatViewModel: ChatViewModel = viewModel()) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
        val scope = rememberCoroutineScope()
        var selectedCapability by remember { mutableStateOf<AionCapability?>(null) }
        var showSettings by remember { mutableStateOf(false) }
        var showModelPicker by remember { mutableStateOf(false) }
        var showContext by remember { mutableStateOf(false) }

        ModalNavigationDrawer(
            drawerState = drawerState,
            drawerContent = {
                AionDrawer(
                    onCapabilityClick = {
                        selectedCapability = it
                        scope.launch { drawerState.close() }
                    },
                    onNewChat = {
                        chatViewModel.newConversation()
                        scope.launch { drawerState.close() }
                    },
                    onSettings = {
                        showSettings = true
                        scope.launch { drawerState.close() }
                    }
                )
            }
        ) {
            AionChatScreen(
                messages = chatViewModel.messages,
                onSend = chatViewModel::send,
                onMenu = { scope.launch { drawerState.open() } },
                onNewChat = chatViewModel::newConversation,
                onModelPicker = { showModelPicker = true },
                onContext = { showContext = true },
                selectedModel = chatViewModel.selectedModel,
                isConfigured = chatViewModel.isConfigured,
                isSending = chatViewModel.isSending
            )
        }

        selectedCapability?.let { capability ->
            CapabilityDialog(capability = capability, onDismiss = { selectedCapability = null })
        }

        if (showSettings) {
            SettingsDialog(
                initialApiKey = chatViewModel.apiKey,
                initialModel = chatViewModel.model,
                onSave = { key, model ->
                    chatViewModel.saveSettings(key, model)
                    showSettings = false
                },
                onDismiss = { showSettings = false }
            )
        }

        if (showModelPicker) {
            ModelPickerSheet(
                options = chatViewModel.modelOptions,
                selectedKey = chatViewModel.selectedModelKey,
                onSelect = {
                    chatViewModel.selectModel(it)
                    showModelPicker = false
                },
                onDismiss = { showModelPicker = false }
            )
        }

        if (showContext) {
            ContextSheet(
                messageCount = chatViewModel.messages.size,
                selectedModel = chatViewModel.selectedModel,
                isConfigured = chatViewModel.isConfigured,
                onDismiss = { showContext = false }
            )
        }
    }
}

@Composable
private fun AionDrawer(
    onCapabilityClick: (AionCapability) -> Unit,
    onNewChat: () -> Unit,
    onSettings: () -> Unit
) {
    ModalDrawerSheet(
        modifier = Modifier.fillMaxHeight().width(310.dp),
        drawerContainerColor = Color(0xFF0D0E13)
    ) {
        Spacer(Modifier.height(22.dp))
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            AionMark(size = 42.dp)
            Spacer(Modifier.width(12.dp))
            Column {
                Text("AION", fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
                Text("Intelligence OS", color = AionPurpleSoft, fontSize = 11.sp)
            }
        }

        Spacer(Modifier.height(18.dp))
        Surface(
            onClick = onNewChat,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp),
            shape = RoundedCornerShape(18.dp),
            color = AionPurpleStrong
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 13.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Outlined.Add, contentDescription = null)
                Spacer(Modifier.width(10.dp))
                Text("محادثة جديدة", fontWeight = FontWeight.Bold)
            }
        }

        Spacer(Modifier.height(10.dp))
        DrawerEntry(Icons.Outlined.Search, "البحث", "البحث داخل المحادثات", onClick = {})
        DrawerEntry(Icons.Outlined.Folder, "المشاريع", "مساحات عمل مستقلة", onClick = {
            FeatureRegistry.capabilities.firstOrNull { it.key == "files" }?.let(onCapabilityClick)
        })
        DrawerEntry(Icons.Outlined.SmartToy, "الوكلاء", "مهام متعددة الخطوات", onClick = {
            FeatureRegistry.capabilities.firstOrNull { it.key == "agent" }?.let(onCapabilityClick)
        })
        DrawerEntry(Icons.Outlined.Memory, "الذاكرة", "سياق وتفضيلات", onClick = {
            FeatureRegistry.capabilities.firstOrNull { it.key == "memory" }?.let(onCapabilityClick)
        })
        DrawerEntry(Icons.Outlined.Build, "الأدوات", "أدوات واتصالات", onClick = {
            FeatureRegistry.capabilities.firstOrNull { it.key == "tools" }?.let(onCapabilityClick)
        })

        Spacer(Modifier.weight(1f))
        HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.55f))
        NavigationDrawerItem(
            label = { Text("الإعدادات") },
            selected = false,
            onClick = onSettings,
            icon = { Icon(Icons.Outlined.Settings, contentDescription = null) },
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
        )
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 14.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("AION Mobile", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 11.sp)
            Text("α4", color = AionPurpleSoft, fontSize = 11.sp)
        }
    }
}

@Composable
private fun DrawerEntry(icon: ImageVector, title: String, subtitle: String, onClick: () -> Unit) {
    NavigationDrawerItem(
        label = {
            Column {
                Text(title)
                Text(subtitle, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        },
        selected = false,
        onClick = onClick,
        icon = { Icon(icon, contentDescription = null) },
        modifier = Modifier.padding(horizontal = 10.dp)
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AionChatScreen(
    messages: List<ChatMessage>,
    onSend: (String) -> Unit,
    onMenu: () -> Unit,
    onNewChat: () -> Unit,
    onModelPicker: () -> Unit,
    onContext: () -> Unit,
    selectedModel: AiModelOption,
    isConfigured: Boolean,
    isSending: Boolean
) {
    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background),
                navigationIcon = {
                    IconButton(onClick = onMenu) {
                        Icon(Icons.Outlined.Menu, contentDescription = "القائمة")
                    }
                },
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        AionMark(size = 28.dp)
                        Spacer(Modifier.width(9.dp))
                        Column {
                            Text("AION", fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
                            Text("Intelligence OS", color = AionPurpleSoft, fontSize = 9.sp)
                        }
                    }
                },
                actions = {
                    IconButton(onClick = onContext) {
                        Icon(Icons.Outlined.Info, contentDescription = "سياق المحادثة", tint = AionPurpleSoft)
                    }
                    IconButton(onClick = onNewChat) {
                        Icon(Icons.Outlined.Add, contentDescription = "محادثة جديدة")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .imePadding()
                .navigationBarsPadding()
        ) {
            Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
                if (messages.isEmpty()) {
                    WelcomeContent()
                } else {
                    MessagesList(messages)
                }
            }
            ChatComposer(
                onSend = onSend,
                onModelPicker = onModelPicker,
                selectedModel = selectedModel,
                isConfigured = isConfigured,
                isSending = isSending
            )
        }
    }
}

@Composable
private fun WelcomeContent() {
    Column(
        modifier = Modifier.fillMaxSize().padding(horizontal = 22.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        AionMark(size = 74.dp)
        Spacer(Modifier.height(20.dp))
        Text(
            "بماذا يمكنني مساعدتك؟",
            fontSize = 27.sp,
            fontWeight = FontWeight.ExtraBold,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(8.dp))
        Text(
            "اسأل، فكّر، أنشئ، نفّذ.",
            color = AionPurpleSoft,
            textAlign = TextAlign.Center,
            fontSize = 14.sp
        )
        Spacer(Modifier.height(26.dp))
        LazyRow(
            contentPadding = PaddingValues(horizontal = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(listOf("ابحث في الويب", "حلّل فكرة", "اكتب نصًا", "راجع مشروعًا")) { text ->
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    contentColor = MaterialTheme.colorScheme.onSurfaceVariant
                ) {
                    Text(text, modifier = Modifier.padding(horizontal = 13.dp, vertical = 9.dp), fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
private fun MessagesList(messages: List<ChatMessage>) {
    val state = rememberLazyListState()
    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) state.animateScrollToItem(messages.lastIndex)
    }

    LazyColumn(
        state = state,
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        itemsIndexed(messages, key = { _, message -> message.id }) { _, message ->
            MessageBubble(message)
        }
    }
}

@Composable
private fun MessageBubble(message: ChatMessage) {
    val isUser = message.role == MessageRole.USER
    val clipboard = LocalClipboardManager.current

    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = if (isUser) Arrangement.Start else Arrangement.End,
            verticalAlignment = Alignment.Top
        ) {
            if (!isUser) {
                AionMark(size = 28.dp)
                Spacer(Modifier.width(9.dp))
            }

            Column(modifier = Modifier.fillMaxWidth(if (isUser) 0.88f else 0.93f)) {
                if (!isUser) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier.size(6.dp).clip(CircleShape).background(
                                if (message.isError) MaterialTheme.colorScheme.error else AionPurple
                            )
                        )
                        Spacer(Modifier.width(6.dp))
                        Text(
                            message.modelLabel ?: "AION",
                            color = if (message.isError) MaterialTheme.colorScheme.error else AionPurpleSoft,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                    Spacer(Modifier.height(6.dp))
                }

                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = when {
                        isUser -> Color(0xFF211A2F)
                        message.isError -> Color(0xFF231116)
                        else -> Color.Transparent
                    }
                ) {
                    Text(
                        message.text,
                        modifier = Modifier.padding(
                            horizontal = if (isUser || message.isError) 15.dp else 2.dp,
                            vertical = if (isUser || message.isError) 12.dp else 2.dp
                        ),
                        lineHeight = 23.sp,
                        color = if (message.isError) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface
                    )
                }

                if (!isUser && !message.text.startsWith("جارٍ التفكير")) {
                    Row(modifier = Modifier.padding(top = 5.dp)) {
                        IconButton(onClick = { clipboard.setText(AnnotatedString(message.text)) }, modifier = Modifier.size(32.dp)) {
                            Icon(
                                Icons.Outlined.ContentCopy,
                                contentDescription = "نسخ",
                                modifier = Modifier.size(17.dp),
                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ChatComposer(
    onSend: (String) -> Unit,
    onModelPicker: () -> Unit,
    selectedModel: AiModelOption,
    isConfigured: Boolean,
    isSending: Boolean
) {
    var input by remember { mutableStateOf("") }

    Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp)) {
        Surface(
            shape = RoundedCornerShape(26.dp),
            color = Color(0xFF15161D),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF292433))
        ) {
            Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp)) {
                Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        onClick = onModelPicker,
                        shape = RoundedCornerShape(14.dp),
                        color = Color(0xFF261A3A),
                        contentColor = AionPurpleSoft
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 11.dp, vertical = 7.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(Modifier.size(7.dp).clip(CircleShape).background(AionPurple))
                            Spacer(Modifier.width(7.dp))
                            Text(selectedModel.label, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                            Spacer(Modifier.width(3.dp))
                            Icon(Icons.Outlined.KeyboardArrowDown, contentDescription = null, modifier = Modifier.size(16.dp))
                        }
                    }
                    Spacer(Modifier.weight(1f))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Outlined.Public, contentDescription = null, tint = AionBlueSoft, modifier = Modifier.size(15.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("ويب", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 10.sp)
                    }
                }

                BasicTextField(
                    value = input,
                    onValueChange = { input = it },
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 12.dp),
                    textStyle = MaterialTheme.typography.bodyLarge.copy(
                        color = MaterialTheme.colorScheme.onSurface,
                        textAlign = TextAlign.Start
                    ),
                    maxLines = 7,
                    decorationBox = { inner ->
                        Box {
                            if (input.isBlank()) {
                                Text("اكتب رسالتك…", color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            inner()
                        }
                    }
                )

                Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { }) {
                        Icon(Icons.Outlined.Add, contentDescription = "إضافة")
                    }
                    IconButton(onClick = { }) {
                        Icon(Icons.Outlined.AttachFile, contentDescription = "إرفاق ملف")
                    }
                    IconButton(onClick = { }) {
                        Icon(Icons.Outlined.Mic, contentDescription = "الصوت")
                    }
                    Spacer(Modifier.weight(1f))
                    Surface(
                        onClick = {
                            if (input.isNotBlank() && !isSending) {
                                onSend(input)
                                input = ""
                            }
                        },
                        shape = CircleShape,
                        color = if (input.isBlank() || isSending) Color(0xFF3A3445) else AionPurpleStrong,
                        modifier = Modifier.size(42.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                Icons.Outlined.ArrowUpward,
                                contentDescription = "إرسال",
                                tint = if (input.isBlank() || isSending) Color(0xFF8D8796) else Color.White
                            )
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(6.dp))
        Text(
            when {
                !isConfigured -> "أضف مفتاح API من الإعدادات"
                isSending -> "AION يعمل على الرد…"
                else -> "AION α4 • يمكن تغيير النموذج لكل رسالة داخل نفس الدردشة"
            },
            modifier = Modifier.fillMaxWidth(),
            textAlign = TextAlign.Center,
            fontSize = 9.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ModelPickerSheet(
    options: List<AiModelOption>,
    selectedKey: String,
    onSelect: (String) -> Unit,
    onDismiss: () -> Unit
) {
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF111218)
    ) {
        Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 8.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("اختر النموذج لهذه الرسالة", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text(
                        "يمكنك تبديل النموذج في أي رسالة مع بقاء نفس المحادثة والسياق.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 12.sp
                    )
                }
                IconButton(onClick = onDismiss) { Icon(Icons.Outlined.Close, contentDescription = "إغلاق") }
            }

            Spacer(Modifier.height(14.dp))
            options.forEach { option ->
                val selected = option.key == selectedKey
                Surface(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp).clickable(enabled = option.enabled) {
                        onSelect(option.key)
                    },
                    shape = RoundedCornerShape(18.dp),
                    color = if (selected) Color(0xFF281B3E) else Color(0xFF181920),
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp,
                        if (selected) AionPurple else Color(0xFF2E2A36)
                    )
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(15.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        ModelGlyph(option)
                        Spacer(Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                option.label,
                                fontWeight = FontWeight.SemiBold,
                                color = if (option.enabled) MaterialTheme.colorScheme.onSurface else Color(0xFF77727D)
                            )
                            Text(option.provider, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 11.sp)
                        }
                        option.badge?.let {
                            Text(it, color = if (option.enabled) AionPurpleSoft else Color(0xFF77727D), fontSize = 10.sp)
                            Spacer(Modifier.width(8.dp))
                        }
                        if (selected) Icon(Icons.Outlined.Check, contentDescription = null, tint = AionPurple)
                    }
                }
            }
            Spacer(Modifier.height(28.dp))
        }
    }
}

@Composable
private fun ModelGlyph(option: AiModelOption) {
    val color = when {
        option.key == "auto" -> AionPurple
        option.provider == "OpenAI" -> Color(0xFFE8E8EC)
        option.key == "claude" -> Color(0xFFE07B49)
        option.key == "gemini" -> AionBlueSoft
        option.key == "grok" -> Color(0xFFD7D7DA)
        option.key == "deepseek" -> Color(0xFF658CFF)
        else -> AionPurpleSoft
    }
    Surface(shape = CircleShape, color = color.copy(alpha = 0.15f), modifier = Modifier.size(38.dp)) {
        Box(contentAlignment = Alignment.Center) {
            Text(
                when (option.key) {
                    "auto" -> "A"
                    "gpt-luna", "gpt-sol" -> "G"
                    "claude" -> "C"
                    "gemini" -> "✦"
                    "grok" -> "X"
                    "deepseek" -> "D"
                    else -> "AI"
                },
                color = color,
                fontWeight = FontWeight.ExtraBold,
                fontSize = 13.sp
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ContextSheet(
    messageCount: Int,
    selectedModel: AiModelOption,
    isConfigured: Boolean,
    onDismiss: () -> Unit
) {
    ModalBottomSheet(onDismissRequest = onDismiss, containerColor = Color(0xFF111218)) {
        Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 8.dp)) {
            Text("سياق المحادثة", fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            Text(
                "هذه اللوحة لا تبقى مفتوحة أثناء الدردشة. افتحها فقط عندما تريد رؤية ما يستخدمه AION.",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = 12.sp
            )
            Spacer(Modifier.height(18.dp))
            ContextRow("النموذج الحالي", selectedModel.label, AionPurple)
            ContextRow("الرسائل في المحادثة", messageCount.toString(), AionBlueSoft)
            ContextRow("البحث في الويب", "متاح", AionBlueSoft)
            ContextRow("اتصال API", if (isConfigured) "جاهز" else "غير مضبوط", if (isConfigured) AionPurple else MaterialTheme.colorScheme.error)
            ContextRow("الملفات", "ستُضاف في المرحلة التالية", Color(0xFF8C8794))
            ContextRow("ذاكرة المشروع", "ستُضاف في المرحلة التالية", Color(0xFF8C8794))
            Spacer(Modifier.height(28.dp))
        }
    }
}

@Composable
private fun ContextRow(label: String, value: String, accent: Color) {
    Surface(
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        shape = RoundedCornerShape(16.dp),
        color = Color(0xFF181920)
    ) {
        Row(modifier = Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(8.dp).clip(CircleShape).background(accent))
            Spacer(Modifier.width(10.dp))
            Text(label, modifier = Modifier.weight(1f), color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(value, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
        }
    }
}

@Composable
private fun AionMark(size: androidx.compose.ui.unit.Dp) {
    Surface(shape = RoundedCornerShape(size * 0.28f), color = Color(0xFF1A1029), modifier = Modifier.size(size)) {
        Box(contentAlignment = Alignment.Center) {
            Text(
                "A",
                color = AionPurpleSoft,
                fontSize = (size.value * 0.48f).sp,
                fontWeight = FontWeight.Black
            )
            Box(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = size * 0.18f)
                    .size(size * 0.13f)
                    .clip(CircleShape)
                    .background(AionPurple)
            )
        }
    }
}

@Composable
private fun SettingsDialog(
    initialApiKey: String,
    initialModel: String,
    onSave: (String, String) -> Unit,
    onDismiss: () -> Unit
) {
    var key by remember(initialApiKey) { mutableStateOf(initialApiKey) }
    var model by remember(initialModel) { mutableStateOf(initialModel) }

    AlertDialog(
        onDismissRequest = onDismiss,
        icon = { Icon(Icons.Outlined.Settings, contentDescription = null, tint = AionPurple) },
        title = { Text("إعدادات AION") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    "مفتاح OpenAI يبقى على هذا الجهاز. في النسخ القادمة سننقل المفاتيح إلى خادم AION آمن.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                OutlinedTextField(
                    value = key,
                    onValueChange = { key = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("OpenAI API Key") },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation()
                )
                OutlinedTextField(
                    value = model,
                    onValueChange = { model = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("نموذج AION Auto الافتراضي") },
                    supportingText = { Text("الافتراضي: gpt-5.6-luna") },
                    singleLine = true
                )
                Text(
                    "يمكن تغيير النموذج لكل رسالة من داخل صندوق الدردشة. هذا الحقل يحدد فقط نموذج Auto الافتراضي.",
                    fontSize = 11.sp,
                    color = AionPurpleSoft
                )
            }
        },
        confirmButton = { TextButton(onClick = { onSave(key, model) }) { Text("حفظ") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}

@Composable
private fun CapabilityDialog(capability: AionCapability, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        icon = { Icon(capability.icon(), contentDescription = null, tint = AionPurple) },
        title = { Text(capability.title) },
        text = {
            Column {
                Text(capability.description)
                Spacer(Modifier.height(12.dp))
                Text("الحالة: ${capability.state.label()}", color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (capability.state != CapabilityState.READY) {
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "الواجهة والبنية الأساسية موجودة، وسيتم توصيل التنفيذ الفعلي على مراحل.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("حسنًا") } }
    )
}

private fun CapabilityState.label(): String = when (this) {
    CapabilityState.READY -> "جاهز"
    CapabilityState.FOUNDATION -> "البنية جاهزة — الربط لاحقًا"
    CapabilityState.PLANNED -> "مخطط له"
}

private fun AionCapability.icon(): ImageVector = when (key) {
    "agent" -> Icons.Outlined.SmartToy
    "memory" -> Icons.Outlined.Memory
    "files" -> Icons.Outlined.Folder
    "voice" -> Icons.Outlined.Mic
    "search" -> Icons.Outlined.Search
    "tools" -> Icons.Outlined.Build
    else -> Icons.Outlined.Psychology
}
