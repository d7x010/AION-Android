package com.aion.mobile.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.ArrowUpward
import androidx.compose.material.icons.outlined.AttachFile
import androidx.compose.material.icons.outlined.Build
import androidx.compose.material.icons.outlined.Folder
import androidx.compose.material.icons.outlined.Memory
import androidx.compose.material.icons.outlined.Menu
import androidx.compose.material.icons.outlined.Mic
import androidx.compose.material.icons.outlined.Psychology
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.SmartToy
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.aion.mobile.core.AionCapability
import com.aion.mobile.core.CapabilityState
import com.aion.mobile.core.FeatureRegistry
import com.aion.mobile.feature.chat.ChatViewModel
import com.aion.mobile.model.ChatMessage
import com.aion.mobile.model.MessageRole
import kotlinx.coroutines.launch

@Composable
fun AionApp(chatViewModel: ChatViewModel = viewModel()) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
        val scope = rememberCoroutineScope()
        var selectedCapability by remember { mutableStateOf<AionCapability?>(null) }

        ModalNavigationDrawer(
            drawerState = drawerState,
            drawerContent = {
                AionDrawer(
                    onCapabilityClick = {
                        selectedCapability = it
                        scope.launch { drawerState.close() }
                    },
                    onNewChat = {
                        chatViewModel.newConversation()
                        scope.launch { drawerState.close() }
                    }
                )
            }
        ) {
            AionChatScreen(
                messages = chatViewModel.messages,
                onSend = chatViewModel::send,
                onMenu = { scope.launch { drawerState.open() } },
                onNewChat = chatViewModel::newConversation,
                onCapabilityClick = { selectedCapability = it }
            )
        }

        selectedCapability?.let { capability ->
            CapabilityDialog(
                capability = capability,
                onDismiss = { selectedCapability = null }
            )
        }
    }
}

@Composable
private fun AionDrawer(
    onCapabilityClick: (AionCapability) -> Unit,
    onNewChat: () -> Unit
) {
    ModalDrawerSheet(
        modifier = Modifier.fillMaxHeight().width(320.dp),
        drawerContainerColor = Color(0xFF111318)
    ) {
        Spacer(Modifier.height(24.dp))
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                shape = CircleShape,
                color = Color(0xFFE8EAED),
                modifier = Modifier.size(38.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Text("A", color = Color(0xFF111318), fontWeight = FontWeight.Black)
                }
            }
            Spacer(Modifier.width(12.dp))
            Column {
                Text("AION", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text("Mobile V2", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
            }
        }

        Spacer(Modifier.height(20.dp))
        NavigationDrawerItem(
            label = { Text("محادثة جديدة") },
            selected = false,
            onClick = onNewChat,
            icon = { Icon(Icons.Outlined.Add, contentDescription = null) },
            modifier = Modifier.padding(horizontal = 12.dp)
        )

        HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp))
        Text(
            "القدرات",
            modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp),
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            fontSize = 13.sp
        )

        FeatureRegistry.capabilities.filter { it.key != "chat" }.forEach { capability ->
            NavigationDrawerItem(
                label = {
                    Column {
                        Text(capability.title)
                        Text(
                            capability.state.label(),
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 11.sp
                        )
                    }
                },
                selected = false,
                onClick = { onCapabilityClick(capability) },
                icon = { Icon(capability.icon(), contentDescription = null) },
                modifier = Modifier.padding(horizontal = 12.dp)
            )
        }

        Spacer(Modifier.weight(1f))
        HorizontalDivider()
        Row(
            modifier = Modifier.fillMaxWidth().padding(20.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Outlined.Settings, contentDescription = null)
                Spacer(Modifier.width(10.dp))
                Text("الإعدادات")
            }
            Text("α1", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AionChatScreen(
    messages: List<ChatMessage>,
    onSend: (String) -> Unit,
    onMenu: () -> Unit,
    onNewChat: () -> Unit,
    onCapabilityClick: (AionCapability) -> Unit
) {
    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                ),
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("AION", fontWeight = FontWeight.Bold)
                        Spacer(Modifier.width(8.dp))
                        Box(
                            modifier = Modifier
                                .size(7.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF66D17A))
                        )
                        Spacer(Modifier.width(8.dp))
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant
                        ) {
                            Text(
                                "V2 α",
                                modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp),
                                fontSize = 10.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onMenu) {
                        Icon(Icons.Outlined.Menu, contentDescription = "القائمة")
                    }
                },
                actions = {
                    IconButton(onClick = onNewChat) {
                        Icon(Icons.Outlined.Add, contentDescription = "محادثة جديدة")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .imePadding()
                .navigationBarsPadding()
        ) {
            Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
                if (messages.isEmpty()) {
                    WelcomeContent(onCapabilityClick)
                } else {
                    MessagesList(messages)
                }
            }
            ChatComposer(onSend)
        }
    }
}

@Composable
private fun WelcomeContent(onCapabilityClick: (AionCapability) -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize().padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Surface(
            shape = CircleShape,
            color = Color(0xFFE8EAED),
            modifier = Modifier.size(58.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Text("A", color = Color(0xFF111318), fontSize = 28.sp, fontWeight = FontWeight.Black)
            }
        }
        Spacer(Modifier.height(20.dp))
        Text(
            "مرحبًا، أنا AION",
            fontSize = 28.sp,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(10.dp))
        Text(
            "مساعدك الشخصي على أندرويد. هذه هي قاعدة النسخة الثانية، ومصممة لتتوسع إلى وكيل ذكي بذاكرة وملفات وصوت وبحث وأدوات.",
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
            lineHeight = 22.sp
        )
        Spacer(Modifier.height(28.dp))

        LazyRow(
            contentPadding = PaddingValues(horizontal = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            reverseLayout = true
        ) {
            items(FeatureRegistry.capabilities.filter { it.key != "chat" }) { capability ->
                CapabilityChip(capability) { onCapabilityClick(capability) }
            }
        }
    }
}

@Composable
private fun CapabilityChip(capability: AionCapability, onClick: () -> Unit) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(18.dp),
        color = MaterialTheme.colorScheme.surfaceVariant,
        contentColor = MaterialTheme.colorScheme.onSurface
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(capability.icon(), contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
            Text(capability.title, fontSize = 13.sp)
        }
    }
}

@Composable
private fun MessagesList(messages: List<ChatMessage>) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp),
        reverseLayout = false
    ) {
        itemsIndexed(messages, key = { _, message -> message.id }) { _, message ->
            MessageBubble(message)
        }
    }
}

@Composable
private fun MessageBubble(message: ChatMessage) {
    val isUser = message.role == MessageRole.USER
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (isUser) Arrangement.Start else Arrangement.End
    ) {
        if (!isUser) {
            Surface(
                shape = CircleShape,
                color = Color(0xFFE8EAED),
                modifier = Modifier.size(30.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Text("A", color = Color(0xFF111318), fontWeight = FontWeight.Black, fontSize = 12.sp)
                }
            }
            Spacer(Modifier.width(10.dp))
        }

        Surface(
            shape = RoundedCornerShape(20.dp),
            color = if (isUser) Color(0xFF2A2E35) else Color.Transparent,
            modifier = Modifier.fillMaxWidth(if (isUser) 0.86f else 0.92f)
        ) {
            Text(
                message.text,
                modifier = Modifier.padding(
                    horizontal = if (isUser) 16.dp else 4.dp,
                    vertical = if (isUser) 12.dp else 4.dp
                ),
                lineHeight = 22.sp,
                color = MaterialTheme.colorScheme.onSurface
            )
        }
    }
}

@Composable
private fun ChatComposer(onSend: (String) -> Unit) {
    var input by remember { mutableStateOf("") }

    Column(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp)
    ) {
        Surface(
            shape = RoundedCornerShape(28.dp),
            color = Color(0xFF1B1E23),
            tonalElevation = 0.dp
        ) {
            Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp)) {
                BasicTextField(
                    value = input,
                    onValueChange = { input = it },
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 10.dp),
                    textStyle = MaterialTheme.typography.bodyLarge.copy(
                        color = MaterialTheme.colorScheme.onSurface,
                        textAlign = TextAlign.Start
                    ),
                    maxLines = 6,
                    decorationBox = { inner ->
                        Box {
                            if (input.isBlank()) {
                                Text(
                                    "اكتب رسالتك إلى AION…",
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            inner()
                        }
                    }
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { }) {
                        Icon(Icons.Outlined.AttachFile, contentDescription = "إرفاق ملف")
                    }
                    IconButton(onClick = { }) {
                        Icon(Icons.Outlined.Mic, contentDescription = "الصوت")
                    }
                    Spacer(Modifier.weight(1f))
                    Surface(
                        onClick = {
                            if (input.isNotBlank()) {
                                onSend(input)
                                input = ""
                            }
                        },
                        shape = CircleShape,
                        color = if (input.isBlank()) Color(0xFF454A52) else Color(0xFFE8EAED),
                        modifier = Modifier.size(40.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                Icons.Outlined.ArrowUpward,
                                contentDescription = "إرسال",
                                tint = if (input.isBlank()) Color(0xFF9AA0A6) else Color(0xFF111318)
                            )
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(7.dp))
        Text(
            "AION V2 α1 — النسخة الحالية لا تتصل بأي API بعد",
            modifier = Modifier.fillMaxWidth(),
            textAlign = TextAlign.Center,
            fontSize = 10.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun CapabilityDialog(capability: AionCapability, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        icon = { Icon(capability.icon(), contentDescription = null) },
        title = { Text(capability.title) },
        text = {
            Column {
                Text(capability.description)
                Spacer(Modifier.height(12.dp))
                Text(
                    "الحالة: ${capability.state.label()}",
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                if (capability.state != CapabilityState.READY) {
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "تم وضع البنية البرمجية لهذه القدرة، وسيتم توصيل التنفيذ الفعلي بعد نجاح أول بناء رسمي للتطبيق.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("حسنًا") }
        }
    )
}

private fun CapabilityState.label(): String = when (this) {
    CapabilityState.READY -> "جاهز"
    CapabilityState.FOUNDATION -> "البنية جاهزة — الربط لاحقًا"
    CapabilityState.PLANNED -> "مخطط له"
}

private fun AionCapability.icon(): ImageVector = when (key) {
    "agent" -> Icons.Outlined.SmartToy
    "memory" -> Icons.Outlined.Memory
    "files" -> Icons.Outlined.Folder
    "voice" -> Icons.Outlined.Mic
    "search" -> Icons.Outlined.Search
    "tools" -> Icons.Outlined.Build
    else -> Icons.Outlined.Psychology
}
