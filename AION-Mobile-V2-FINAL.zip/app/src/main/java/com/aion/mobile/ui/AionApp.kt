package com.aion.mobile.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.ArrowUpward
import androidx.compose.material.icons.outlined.Build
import androidx.compose.material.icons.outlined.Check
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.ContentCopy
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material.icons.outlined.Folder
import androidx.compose.material.icons.outlined.Image
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.KeyboardArrowDown
import androidx.compose.material.icons.outlined.Memory
import androidx.compose.material.icons.outlined.Menu
import androidx.compose.material.icons.outlined.Mic
import androidx.compose.material.icons.outlined.MoreHoriz
import androidx.compose.material.icons.outlined.Psychology
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.SmartToy
import androidx.compose.material.icons.outlined.Stop
import androidx.compose.material.icons.outlined.VolumeUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import com.aion.mobile.core.AionCapability
import com.aion.mobile.core.CapabilityState
import com.aion.mobile.core.FeatureRegistry
import com.aion.mobile.core.ai.GatewayActivity
import com.aion.mobile.core.files.AttachmentLoader
import com.aion.mobile.feature.chat.AiModelOption
import com.aion.mobile.feature.chat.ChatViewModel
import com.aion.mobile.model.AttachmentKind
import com.aion.mobile.model.ChatAttachment
import com.aion.mobile.model.ChatMessage
import com.aion.mobile.model.ChatSource
import com.aion.mobile.model.MessageRole
import com.aion.mobile.ui.theme.AionBlueSoft
import com.aion.mobile.ui.theme.AionPurple
import com.aion.mobile.ui.theme.AionPurpleSoft
import com.aion.mobile.ui.theme.AionPurpleStrong
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

@Composable
fun AionApp(chatViewModel: ChatViewModel = viewModel()) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
        val scope = rememberCoroutineScope()
        var selectedCapability by remember { mutableStateOf<AionCapability?>(null) }
        var showSettings by remember { mutableStateOf(false) }
        var showModelPicker by remember { mutableStateOf(false) }
        var showContext by remember { mutableStateOf(false) }

        ModalNavigationDrawer(
            drawerState = drawerState,
            drawerContent = {
                AionDrawer(
                    onCapabilityClick = {
                        selectedCapability = it
                        scope.launch { drawerState.close() }
                    },
                    onNewChat = {
                        chatViewModel.newConversation()
                        scope.launch { drawerState.close() }
                    },
                    onContext = {
                        showContext = true
                        scope.launch { drawerState.close() }
                    },
                    onSettings = {
                        showSettings = true
                        scope.launch { drawerState.close() }
                    }
                )
            }
        ) {
            AionChatScreen(
                messages = chatViewModel.messages,
                pendingAttachments = chatViewModel.pendingAttachments,
                onSend = chatViewModel::send,
                onStop = chatViewModel::stopGeneration,
                onRetry = chatViewModel::retryLastResponse,
                onAddAttachments = chatViewModel::addAttachments,
                onRemoveAttachment = chatViewModel::removeAttachment,
                onMenu = { scope.launch { drawerState.open() } },
                onNewChat = chatViewModel::newConversation,
                onModelPicker = { showModelPicker = true },
                selectedModel = chatViewModel.selectedModel,
                isConfigured = chatViewModel.isConfigured,
                isSending = chatViewModel.isSending,
                activity = chatViewModel.activity,
                draft = chatViewModel.draft,
                onDraftChange = chatViewModel::updateDraft
            )
        }

        selectedCapability?.let { capability ->
            CapabilityDialog(capability = capability, onDismiss = { selectedCapability = null })
        }

        if (showSettings) {
            SettingsDialog(
                initialApiKey = chatViewModel.apiKey,
                initialModel = chatViewModel.model,
                onSave = { key, model ->
                    chatViewModel.saveSettings(key, model)
                    showSettings = false
                },
                onDismiss = { showSettings = false }
            )
        }

        if (showModelPicker) {
            ModelPickerSheet(
                options = chatViewModel.modelOptions,
                selectedKey = chatViewModel.selectedModelKey,
                onSelect = {
                    chatViewModel.selectModel(it)
                    showModelPicker = false
                },
                onDismiss = { showModelPicker = false }
            )
        }

        if (showContext) {
            ContextSheet(
                messageCount = chatViewModel.messages.size,
                selectedModel = chatViewModel.selectedModel,
                isConfigured = chatViewModel.isConfigured,
                pendingAttachments = chatViewModel.pendingAttachments.size,
                onDismiss = { showContext = false }
            )
        }
    }
}

@Composable
private fun AionDrawer(
    onCapabilityClick: (AionCapability) -> Unit,
    onNewChat: () -> Unit,
    onContext: () -> Unit,
    onSettings: () -> Unit
) {
    ModalDrawerSheet(
        modifier = Modifier.fillMaxHeight().width(304.dp),
        drawerContainerColor = Color(0xFF0C0C11)
    ) {
        Spacer(Modifier.height(12.dp))
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            AionMark(size = 32.dp)
            Spacer(Modifier.width(10.dp))
            Column {
                Text("AION", fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
                Text("Intelligence OS", color = AionPurpleSoft, fontSize = 10.sp)
            }
        }

        Spacer(Modifier.height(8.dp))
        DrawerEntry(Icons.Outlined.Add, "محادثة جديدة", null, onNewChat)
        DrawerEntry(Icons.Outlined.Search, "البحث", "المحادثات والمشاريع", onClick = {})

        HorizontalDivider(
            color = MaterialTheme.colorScheme.outline.copy(alpha = 0.45f),
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
        )

        DrawerEntry(Icons.Outlined.Folder, "المشاريع", "سياق وملفات مستقلة", onClick = {
            FeatureRegistry.capabilities.firstOrNull { it.key == "files" }?.let(onCapabilityClick)
        })
        DrawerEntry(Icons.Outlined.SmartToy, "الوكلاء", "تنفيذ مهام متعددة الخطوات", onClick = {
            FeatureRegistry.capabilities.firstOrNull { it.key == "agent" }?.let(onCapabilityClick)
        })
        DrawerEntry(Icons.Outlined.Memory, "الذاكرة", "سياق وتفضيلات وقرارات", onClick = {
            FeatureRegistry.capabilities.firstOrNull { it.key == "memory" }?.let(onCapabilityClick)
        })
        DrawerEntry(Icons.Outlined.Build, "الأدوات", "اتصالات وقدرات إضافية", onClick = {
            FeatureRegistry.capabilities.firstOrNull { it.key == "tools" }?.let(onCapabilityClick)
        })
        DrawerEntry(Icons.Outlined.Info, "سياق المحادثة", "ما الذي يستخدمه AION الآن", onContext)

        Spacer(Modifier.weight(1f))
        HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.45f))
        DrawerEntry(Icons.Outlined.Settings, "الإعدادات", null, onSettings)
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("AION Mobile", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 10.sp)
            Text("α5", color = AionPurpleSoft, fontSize = 10.sp)
        }
    }
}

@Composable
private fun DrawerEntry(icon: ImageVector, title: String, subtitle: String?, onClick: () -> Unit) {
    NavigationDrawerItem(
        label = {
            Column {
                Text(title, fontSize = 14.sp)
                if (!subtitle.isNullOrBlank()) {
                    Text(subtitle, fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        },
        selected = false,
        onClick = onClick,
        icon = { Icon(icon, contentDescription = null, modifier = Modifier.size(21.dp)) },
        modifier = Modifier.padding(horizontal = 8.dp, vertical = 1.dp)
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AionChatScreen(
    messages: List<ChatMessage>,
    pendingAttachments: List<ChatAttachment>,
    onSend: (String) -> Unit,
    onStop: () -> Unit,
    onRetry: () -> Unit,
    onAddAttachments: (List<ChatAttachment>) -> Unit,
    onRemoveAttachment: (Long) -> Unit,
    onMenu: () -> Unit,
    onNewChat: () -> Unit,
    onModelPicker: () -> Unit,
    selectedModel: AiModelOption,
    isConfigured: Boolean,
    isSending: Boolean,
    activity: GatewayActivity?,
    draft: String,
    onDraftChange: (String) -> Unit
) {
    val context = LocalContext.current
    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }

    LaunchedEffect(isSending) {
        if (
            isSending &&
            Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    var ttsEngine by remember { mutableStateOf<TextToSpeech?>(null) }

    DisposableEffect(context) {
        lateinit var engine: TextToSpeech
        engine = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                engine.language = Locale.getDefault()
                ttsEngine = engine
            }
        }
        onDispose {
            engine.stop()
            engine.shutdown()
            ttsEngine = null
        }
    }

    val speak: (String) -> Unit = { text ->
        if (text.isNotBlank()) {
            val engine = ttsEngine
            if (engine == null) {
                Toast.makeText(context, "خدمة قراءة النص ما زالت تتهيأ أو غير متاحة على الجهاز.", Toast.LENGTH_SHORT).show()
            } else {
                engine.speak(text, TextToSpeech.QUEUE_FLUSH, null, "aion-${System.currentTimeMillis()}")
            }
        }
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            CenterAlignedTopAppBar(
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                ),
                navigationIcon = {
                    IconButton(onClick = onMenu) {
                        Icon(Icons.Outlined.Menu, contentDescription = "القائمة")
                    }
                },
                title = {
                    Text("AION", fontWeight = FontWeight.ExtraBold, fontSize = 17.sp)
                },
                actions = {
                    IconButton(onClick = onNewChat, enabled = !isSending) {
                        Icon(Icons.Outlined.Add, contentDescription = "محادثة جديدة")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
                if (messages.isEmpty()) {
                    WelcomeContent(onSuggestion = onSend)
                } else {
                    MessagesList(
                        messages = messages,
                        activity = activity,
                        onSpeak = speak,
                        onRetry = onRetry
                    )
                }
            }
            ChatComposer(
                onSend = onSend,
                onStop = onStop,
                onModelPicker = onModelPicker,
                onAddAttachments = onAddAttachments,
                onRemoveAttachment = onRemoveAttachment,
                pendingAttachments = pendingAttachments,
                selectedModel = selectedModel,
                isConfigured = isConfigured,
                isSending = isSending,
                draft = draft,
                onDraftChange = onDraftChange
            )
        }
    }
}

@Composable
private fun WelcomeContent(onSuggestion: (String) -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize().padding(horizontal = 22.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        AionMark(size = 54.dp)
        Spacer(Modifier.height(18.dp))
        Text(
            "بماذا نبدأ؟",
            fontSize = 26.sp,
            fontWeight = FontWeight.ExtraBold,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(7.dp))
        Text(
            "اسأل، ابحث، حلّل، أو أنشئ.",
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
            fontSize = 13.sp
        )
        Spacer(Modifier.height(22.dp))
        LazyRow(
            contentPadding = PaddingValues(horizontal = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(
                listOf(
                    "ابحث في الويب عن أهم الأخبار التقنية اليوم",
                    "حلّل هذه الفكرة معي",
                    "ساعدني في كتابة نص",
                    "راجع مشروعًا خطوة بخطوة"
                )
            ) { text ->
                Surface(
                    onClick = { onSuggestion(text) },
                    shape = RoundedCornerShape(15.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    contentColor = MaterialTheme.colorScheme.onSurfaceVariant
                ) {
                    Text(text, modifier = Modifier.padding(horizontal = 13.dp, vertical = 9.dp), fontSize = 11.sp)
                }
            }
        }
    }
}

@Composable
private fun MessagesList(
    messages: List<ChatMessage>,
    activity: GatewayActivity?,
    onSpeak: (String) -> Unit,
    onRetry: () -> Unit
) {
    val state = rememberLazyListState()
    val scope = rememberCoroutineScope()
    val lastText = messages.lastOrNull()?.text.orEmpty()
    val isNearBottom by remember {
        derivedStateOf {
            if (messages.isEmpty()) true
            else {
                val lastVisible = state.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: 0
                lastVisible >= (messages.lastIndex - 1).coerceAtLeast(0)
            }
        }
    }

    LaunchedEffect(messages.size, lastText.length) {
        if (messages.isNotEmpty() && isNearBottom) {
            state.scrollToItem(messages.lastIndex)
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        LazyColumn(
            state = state,
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            itemsIndexed(messages, key = { _, message -> message.id }) { _, message ->
                MessageBubble(
                    message = message,
                    activity = activity,
                    onSpeak = onSpeak,
                    onRetry = onRetry
                )
            }
        }

        if (!isNearBottom && messages.isNotEmpty()) {
            Surface(
                onClick = {
                    scope.launch { state.animateScrollToItem(messages.lastIndex) }
                },
                shape = CircleShape,
                color = Color(0xFF21172F),
                border = BorderStroke(1.dp, Color(0xFF3A2851)),
                modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 8.dp)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Outlined.KeyboardArrowDown, contentDescription = null, modifier = Modifier.size(16.dp), tint = AionPurpleSoft)
                    Spacer(Modifier.width(4.dp))
                    Text("آخر رد", fontSize = 10.sp, color = AionPurpleSoft)
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun MessageBubble(
    message: ChatMessage,
    activity: GatewayActivity?,
    onSpeak: (String) -> Unit,
    onRetry: () -> Unit
) {
    val isUser = message.role == MessageRole.USER
    val clipboard = LocalClipboardManager.current
    val context = LocalContext.current
    var actionsVisible by remember(message.id) { mutableStateOf(false) }
    var showSources by remember(message.id) { mutableStateOf(false) }

    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = if (isUser) Arrangement.Start else Arrangement.End,
            verticalAlignment = Alignment.Top
        ) {
            Column(modifier = Modifier.fillMaxWidth(if (isUser) 0.88f else 0.96f)) {
                if (message.attachments.isNotEmpty()) {
                    MessageAttachmentRow(message.attachments, isUser)
                    if (message.text.isNotBlank()) Spacer(Modifier.height(6.dp))
                }

                val showLiveIndicator = !isUser && message.isStreaming && message.text.isBlank()
                if (showLiveIndicator) {
                    LiveThinkingIndicator(
                        modelLabel = message.modelLabel ?: "AION",
                        activity = activity ?: GatewayActivity.THINKING
                    )
                } else Surface(
                    onClick = { if (!message.isStreaming) actionsVisible = !actionsVisible },
                    shape = RoundedCornerShape(if (isUser) 19.dp else 12.dp),
                    color = when {
                        isUser -> Color(0xFF21182F)
                        message.isError -> Color(0xFF251116)
                        else -> Color.Transparent
                    }
                ) {
                    Column {
                        if (message.text.isNotBlank()) {
                            Text(
                                message.text,
                                modifier = Modifier.padding(
                                    horizontal = if (isUser || message.isError) 14.dp else 2.dp,
                                    vertical = if (isUser || message.isError) 10.dp else 2.dp
                                ),
                                lineHeight = 24.sp,
                                fontSize = 15.sp,
                                color = if (message.isError) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }

                if (!isUser && message.sources.isNotEmpty() && !message.isStreaming) {
                    Spacer(Modifier.height(7.dp))
                    Surface(
                        onClick = { showSources = true },
                        shape = RoundedCornerShape(13.dp),
                        color = Color(0xFF15131D),
                        border = BorderStroke(1.dp, Color(0xFF30283E))
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(Modifier.size(6.dp).clip(CircleShape).background(AionBlueSoft))
                            Spacer(Modifier.width(6.dp))
                            Text("المصادر ${message.sources.size}", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }

                if (!isUser && message.wasStopped) {
                    Text(
                        "تم إيقاف الرد",
                        modifier = Modifier.padding(top = 5.dp, start = 2.dp),
                        fontSize = 9.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                if (!isUser && actionsVisible && !message.isStreaming) {
                    ResponseActions(
                        isError = message.isError,
                        onCopy = { clipboard.setText(AnnotatedString(message.text)) },
                        onSpeak = { onSpeak(message.text) },
                        onRetry = onRetry,
                        onMore = {
                            Toast.makeText(context, "المزيد من تفاعلات الرد ستتوسع في α6", Toast.LENGTH_SHORT).show()
                        }
                    )
                }
            }
        }
    }

    if (showSources) {
        SourcesSheet(
            sources = message.sources,
            onOpen = { source ->
                runCatching {
                    context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(source.url)))
                }
            },
            onDismiss = { showSources = false }
        )
    }
}

@Composable
private fun MessageAttachmentRow(attachments: List<ChatAttachment>, isUser: Boolean) {
    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        items(attachments, key = { it.id }) { attachment ->
            Surface(
                shape = RoundedCornerShape(13.dp),
                color = if (isUser) Color(0xFF302141) else Color(0xFF17151E),
                border = BorderStroke(1.dp, Color(0xFF3A3047))
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 9.dp, vertical = 7.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        if (attachment.kind == AttachmentKind.IMAGE) Icons.Outlined.Image else Icons.Outlined.Description,
                        contentDescription = null,
                        modifier = Modifier.size(15.dp),
                        tint = if (attachment.kind == AttachmentKind.IMAGE) AionPurpleSoft else AionBlueSoft
                    )
                    Spacer(Modifier.width(5.dp))
                    Text(attachment.name, fontSize = 10.sp, maxLines = 1)
                }
            }
        }
    }
}

@Composable
private fun ResponseActions(
    isError: Boolean,
    onCopy: () -> Unit,
    onSpeak: () -> Unit,
    onRetry: () -> Unit,
    onMore: () -> Unit
) {
    Row(
        modifier = Modifier.padding(top = 5.dp),
        horizontalArrangement = Arrangement.spacedBy(2.dp)
    ) {
        SmallAction(Icons.Outlined.ContentCopy, "نسخ", onCopy)
        if (!isError) SmallAction(Icons.Outlined.VolumeUp, "استماع", onSpeak)
        SmallAction(Icons.Outlined.Refresh, "إعادة", onRetry)
        SmallAction(Icons.Outlined.MoreHoriz, "المزيد", onMore)
    }
}

@Composable
private fun SmallAction(icon: ImageVector, description: String, onClick: () -> Unit) {
    IconButton(onClick = onClick, modifier = Modifier.size(32.dp)) {
        Icon(
            icon,
            contentDescription = description,
            modifier = Modifier.size(16.dp),
            tint = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun LiveThinkingIndicator(modelLabel: String, activity: GatewayActivity) {
    val transition = rememberInfiniteTransition(label = "aion-thinking")
    val pulse by transition.animateFloat(
        initialValue = 0.82f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(animation = tween(760), repeatMode = RepeatMode.Reverse),
        label = "pulse"
    )
    val fade by transition.animateFloat(
        initialValue = 0.45f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(animation = tween(980), repeatMode = RepeatMode.Reverse),
        label = "fade"
    )

    val activityText = when (activity) {
        GatewayActivity.SEARCHING_WEB -> "يبحث في الويب"
        GatewayActivity.WRITING -> "يصيغ الرد"
        GatewayActivity.THINKING -> "يفهم طلبك"
    }

    Row(
        modifier = Modifier.padding(horizontal = 2.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(22.dp)
                .scale(pulse)
                .clip(CircleShape)
                .background(AionPurple.copy(alpha = 0.16f)),
            contentAlignment = Alignment.Center
        ) {
            Box(Modifier.size(8.dp).clip(CircleShape).background(AionPurple))
        }
        Spacer(Modifier.width(9.dp))
        Text(
            "AION • $activityText",
            fontSize = 11.sp,
            color = AionPurpleSoft,
            modifier = Modifier.alpha(fade)
        )
        Spacer(Modifier.width(7.dp))
        ThinkingDots()
    }
}

@Composable
private fun ThinkingDots() {
    val transition = rememberInfiniteTransition(label = "thinking-dots")
    val p1 by transition.animateFloat(0.3f, 1f, infiniteRepeatable(tween(600), RepeatMode.Reverse), label = "p1")
    val p2 by transition.animateFloat(1f, 0.3f, infiniteRepeatable(tween(750), RepeatMode.Reverse), label = "p2")
    val p3 by transition.animateFloat(0.45f, 1f, infiniteRepeatable(tween(900), RepeatMode.Reverse), label = "p3")
    Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
        listOf(p1, p2, p3).forEach { alpha ->
            Box(Modifier.size(4.dp).alpha(alpha).clip(CircleShape).background(AionPurpleSoft))
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ChatComposer(
    onSend: (String) -> Unit,
    onStop: () -> Unit,
    onModelPicker: () -> Unit,
    onAddAttachments: (List<ChatAttachment>) -> Unit,
    onRemoveAttachment: (Long) -> Unit,
    pendingAttachments: List<ChatAttachment>,
    selectedModel: AiModelOption,
    isConfigured: Boolean,
    isSending: Boolean,
    draft: String,
    onDraftChange: (String) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var showAttachSheet by remember { mutableStateOf(false) }
    var isListening by remember { mutableStateOf(false) }
    var rms by remember { mutableFloatStateOf(0f) }
    var voiceBase by remember { mutableStateOf("") }

    val speechRecognizer = remember(context) {
        if (SpeechRecognizer.isRecognitionAvailable(context)) SpeechRecognizer.createSpeechRecognizer(context) else null
    }

    fun mergeVoiceText(base: String, spoken: String): String {
        return listOf(base.trim(), spoken.trim()).filter { it.isNotBlank() }.joinToString(" ")
    }

    DisposableEffect(speechRecognizer) {
        speechRecognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                isListening = true
            }

            override fun onBeginningOfSpeech() {
                isListening = true
            }

            override fun onRmsChanged(rmsdB: Float) {
                rms = rmsdB.coerceIn(0f, 12f)
            }

            override fun onBufferReceived(buffer: ByteArray?) = Unit
            override fun onEndOfSpeech() = Unit

            override fun onError(error: Int) {
                isListening = false
                rms = 0f
                if (error != SpeechRecognizer.ERROR_NO_MATCH && error != SpeechRecognizer.ERROR_SPEECH_TIMEOUT) {
                    Toast.makeText(context, "تعذر التقاط الصوت. حاول مرة أخرى.", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onResults(results: Bundle?) {
                val spoken = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                if (spoken.isNotBlank()) onDraftChange(mergeVoiceText(voiceBase, spoken))
                isListening = false
                rms = 0f
            }

            override fun onPartialResults(partialResults: Bundle?) {
                val spoken = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                if (spoken.isNotBlank()) onDraftChange(mergeVoiceText(voiceBase, spoken))
            }

            override fun onEvent(eventType: Int, params: Bundle?) = Unit
        })
        onDispose {
            speechRecognizer?.cancel()
            speechRecognizer?.destroy()
        }
    }

    fun startListeningNow() {
        val recognizer = speechRecognizer
        if (recognizer == null) {
            Toast.makeText(context, "خدمة التعرف على الصوت غير متاحة على هذا الجهاز.", Toast.LENGTH_SHORT).show()
            return
        }
        voiceBase = draft
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag())
        }
        runCatching { recognizer.startListening(intent) }
            .onFailure { Toast.makeText(context, "تعذر تشغيل الميكروفون.", Toast.LENGTH_SHORT).show() }
    }

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) startListeningNow()
        else Toast.makeText(context, "يحتاج AION إذن الميكروفون لتحويل كلامك إلى نص.", Toast.LENGTH_SHORT).show()
    }

    fun toggleListening() {
        if (isListening) {
            speechRecognizer?.stopListening()
            return
        }
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            startListeningNow()
        } else {
            permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    fun loadUris(uris: List<Uri>) {
        if (uris.isEmpty()) return
        if (pendingAttachments.size + uris.size > 6) {
            Toast.makeText(context, "يمكن إرفاق حتى 6 عناصر في الرسالة الواحدة حاليًا.", Toast.LENGTH_SHORT).show()
            return
        }
        scope.launch {
            val loaded = withContext(Dispatchers.IO) { uris.map { AttachmentLoader.load(context, it) } }
            val attachments = loaded.mapNotNull { result ->
                result.exceptionOrNull()?.message?.let { message ->
                    withContext(Dispatchers.Main.immediate) {
                        Toast.makeText(context, message, Toast.LENGTH_LONG).show()
                    }
                }
                result.getOrNull()
            }
            if (attachments.isNotEmpty()) onAddAttachments(attachments)
        }
    }

    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        loadUris(uris)
    }
    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        loadUris(uris)
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .padding(horizontal = 10.dp, vertical = 7.dp)
    ) {
        LazyRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            contentPadding = PaddingValues(horizontal = 2.dp)
        ) {
            item {
                ModelChip(selectedModel = selectedModel, onClick = onModelPicker)
            }
            if (!isConfigured) {
                item {
                    InfoChip("API غير مضبوط", MaterialTheme.colorScheme.error)
                }
            }
            items(pendingAttachments, key = { it.id }) { attachment ->
                AttachmentChip(attachment = attachment, onRemove = { onRemoveAttachment(attachment.id) })
            }
        }

        Spacer(Modifier.height(6.dp))

        Surface(
            shape = RoundedCornerShape(25.dp),
            color = Color(0xFF15151B),
            border = BorderStroke(
                1.dp,
                if (isListening) AionPurple.copy(alpha = 0.95f) else Color(0xFF2A2632)
            )
        ) {
            Row(
                modifier = Modifier.fillMaxWidth().defaultMinSize(minHeight = 58.dp).padding(horizontal = 5.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { showAttachSheet = true }, enabled = !isSending) {
                    Icon(
                        Icons.Outlined.Add,
                        contentDescription = "إضافة",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                BasicTextField(
                    value = draft,
                    onValueChange = onDraftChange,
                    modifier = Modifier.weight(1f).padding(horizontal = 5.dp, vertical = 10.dp),
                    textStyle = MaterialTheme.typography.bodyLarge.copy(
                        color = MaterialTheme.colorScheme.onSurface,
                        textAlign = TextAlign.Start,
                        lineHeight = 22.sp
                    ),
                    maxLines = 6,
                    decorationBox = { inner ->
                        Box {
                            if (draft.isBlank()) {
                                Text(
                                    if (isListening) "أستمع إليك…" else "اكتب رسالة إلى AION…",
                                    color = if (isListening) AionPurpleSoft else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            inner()
                        }
                    }
                )

                when {
                    isSending -> {
                        Surface(
                            onClick = onStop,
                            shape = CircleShape,
                            color = Color(0xFF2C2435),
                            modifier = Modifier.size(40.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(Icons.Outlined.Stop, contentDescription = "إيقاف", tint = AionPurpleSoft, modifier = Modifier.size(19.dp))
                            }
                        }
                    }

                    draft.isNotBlank() || pendingAttachments.isNotEmpty() -> {
                        Surface(
                            onClick = {
                                val outgoing = draft
                                onSend(outgoing)
                                onDraftChange("")
                            },
                            shape = CircleShape,
                            color = AionPurpleStrong,
                            modifier = Modifier.size(40.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(Icons.Outlined.ArrowUpward, contentDescription = "إرسال", tint = Color.White, modifier = Modifier.size(20.dp))
                            }
                        }
                    }

                    else -> {
                        val scale = if (isListening) (1f + (rms / 60f)).coerceAtMost(1.18f) else 1f
                        Surface(
                            onClick = { toggleListening() },
                            shape = CircleShape,
                            color = if (isListening) Color(0xFF2B1A42) else Color.Transparent,
                            modifier = Modifier.size(40.dp).scale(scale)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    Icons.Outlined.Mic,
                                    contentDescription = if (isListening) "إيقاف الاستماع" else "الصوت",
                                    tint = if (isListening) AionPurpleSoft else MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(21.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAttachSheet) {
        ModalBottomSheet(
            onDismissRequest = { showAttachSheet = false },
            containerColor = Color(0xFF111218)
        ) {
            Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 8.dp)) {
                Text("أضف إلى المحادثة", fontSize = 19.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(12.dp))
                AttachmentSheetRow(
                    icon = Icons.Outlined.Image,
                    title = "صورة",
                    subtitle = "PNG وJPEG وWEBP وGIF",
                    accent = AionPurple,
                    onClick = {
                        showAttachSheet = false
                        imagePicker.launch(arrayOf("image/*"))
                    }
                )
                AttachmentSheetRow(
                    icon = Icons.Outlined.Description,
                    title = "ملف",
                    subtitle = "PDF وWord وExcel ونصوص وكود",
                    accent = AionBlueSoft,
                    onClick = {
                        showAttachSheet = false
                        filePicker.launch(
                            arrayOf(
                                "application/pdf",
                                "text/*",
                                "application/json",
                                "application/xml",
                                "application/msword",
                                "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                                "application/vnd.ms-powerpoint",
                                "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                                "application/vnd.ms-excel",
                                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                            )
                        )
                    }
                )
                Spacer(Modifier.height(22.dp))
            }
        }
    }
}

@Composable
private fun ModelChip(selectedModel: AiModelOption, onClick: () -> Unit) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(13.dp),
        color = Color(0xFF21172F),
        border = BorderStroke(1.dp, Color(0xFF3A2851)),
        contentColor = AionPurpleSoft
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 9.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(Modifier.size(6.dp).clip(CircleShape).background(AionPurple))
            Spacer(Modifier.width(6.dp))
            Text(selectedModel.label, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.width(2.dp))
            Icon(Icons.Outlined.KeyboardArrowDown, contentDescription = null, modifier = Modifier.size(14.dp))
        }
    }
}

@Composable
private fun InfoChip(text: String, accent: Color) {
    Surface(
        shape = RoundedCornerShape(13.dp),
        color = accent.copy(alpha = 0.10f),
        border = BorderStroke(1.dp, accent.copy(alpha = 0.28f))
    ) {
        Text(text, modifier = Modifier.padding(horizontal = 9.dp, vertical = 6.dp), color = accent, fontSize = 10.sp)
    }
}

@Composable
private fun AttachmentChip(attachment: ChatAttachment, onRemove: () -> Unit) {
    Surface(
        shape = RoundedCornerShape(13.dp),
        color = Color(0xFF18171E),
        border = BorderStroke(1.dp, Color(0xFF312B39))
    ) {
        Row(
            modifier = Modifier.padding(start = 8.dp, end = 3.dp, top = 4.dp, bottom = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                if (attachment.kind == AttachmentKind.IMAGE) Icons.Outlined.Image else Icons.Outlined.Description,
                contentDescription = null,
                modifier = Modifier.size(14.dp),
                tint = if (attachment.kind == AttachmentKind.IMAGE) AionPurpleSoft else AionBlueSoft
            )
            Spacer(Modifier.width(5.dp))
            Column {
                Text(attachment.name, fontSize = 9.sp, maxLines = 1)
                Text(formatSize(attachment.sizeBytes), fontSize = 8.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            IconButton(onClick = onRemove, modifier = Modifier.size(28.dp)) {
                Icon(Icons.Outlined.Close, contentDescription = "إزالة", modifier = Modifier.size(13.dp))
            }
        }
    }
}

@Composable
private fun AttachmentSheetRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    accent: Color,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        shape = RoundedCornerShape(17.dp),
        color = Color(0xFF181920)
    ) {
        Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Surface(shape = CircleShape, color = accent.copy(alpha = 0.13f), modifier = Modifier.size(38.dp)) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(icon, contentDescription = null, tint = accent, modifier = Modifier.size(19.dp))
                }
            }
            Spacer(Modifier.width(11.dp))
            Column {
                Text(title, fontWeight = FontWeight.SemiBold)
                Text(subtitle, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 10.sp)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SourcesSheet(sources: List<ChatSource>, onOpen: (ChatSource) -> Unit, onDismiss: () -> Unit) {
    ModalBottomSheet(onDismissRequest = onDismiss, containerColor = Color(0xFF111218)) {
        Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 8.dp)) {
            Text("المصادر", fontSize = 19.sp, fontWeight = FontWeight.Bold)
            Text("المصادر التي استخدمها الرد عند البحث في الويب.", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 11.sp)
            Spacer(Modifier.height(12.dp))
            sources.forEachIndexed { index, source ->
                Surface(
                    onClick = { onOpen(source) },
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    shape = RoundedCornerShape(15.dp),
                    color = Color(0xFF181920)
                ) {
                    Row(modifier = Modifier.padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
                        Surface(shape = CircleShape, color = AionBlueSoft.copy(alpha = 0.12f), modifier = Modifier.size(28.dp)) {
                            Box(contentAlignment = Alignment.Center) {
                                Text("${index + 1}", color = AionBlueSoft, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                        Spacer(Modifier.width(9.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(source.title, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, maxLines = 2)
                            Text(source.url, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 8.sp, maxLines = 1)
                        }
                    }
                }
            }
            Spacer(Modifier.height(22.dp))
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ModelPickerSheet(
    options: List<AiModelOption>,
    selectedKey: String,
    onSelect: (String) -> Unit,
    onDismiss: () -> Unit
) {
    ModalBottomSheet(onDismissRequest = onDismiss, containerColor = Color(0xFF111218)) {
        Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 8.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("النموذج للرسالة التالية", fontSize = 19.sp, fontWeight = FontWeight.Bold)
                    Text(
                        "بدّل النموذج داخل نفس المحادثة من دون فقد السياق.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 11.sp
                    )
                }
                IconButton(onClick = onDismiss) { Icon(Icons.Outlined.Close, contentDescription = "إغلاق") }
            }

            Spacer(Modifier.height(12.dp))
            options.forEach { option ->
                val selected = option.key == selectedKey
                Surface(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp).clickable(enabled = option.enabled) {
                        onSelect(option.key)
                    },
                    shape = RoundedCornerShape(17.dp),
                    color = if (selected) Color(0xFF26193A) else Color(0xFF181920),
                    border = BorderStroke(1.dp, if (selected) AionPurple else Color(0xFF2E2A36))
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(13.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        ModelGlyph(option)
                        Spacer(Modifier.width(11.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                option.label,
                                fontWeight = FontWeight.SemiBold,
                                color = if (option.enabled) MaterialTheme.colorScheme.onSurface else Color(0xFF77727D)
                            )
                            Text(option.provider, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 10.sp)
                        }
                        option.badge?.let {
                            Text(it, color = if (option.enabled) AionPurpleSoft else Color(0xFF77727D), fontSize = 9.sp)
                            Spacer(Modifier.width(7.dp))
                        }
                        if (selected) Icon(Icons.Outlined.Check, contentDescription = null, tint = AionPurple)
                    }
                }
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun ModelGlyph(option: AiModelOption) {
    val color = when {
        option.key == "auto" -> AionPurple
        option.provider == "OpenAI" -> Color(0xFFE8E8EC)
        option.key == "claude" -> Color(0xFFE07B49)
        option.key == "gemini" -> AionBlueSoft
        option.key == "grok" -> Color(0xFFD7D7DA)
        option.key == "deepseek" -> Color(0xFF658CFF)
        else -> AionPurpleSoft
    }
    Surface(shape = CircleShape, color = color.copy(alpha = 0.14f), modifier = Modifier.size(36.dp)) {
        Box(contentAlignment = Alignment.Center) {
            Text(
                when (option.key) {
                    "auto" -> "A"
                    "gpt-luna", "gpt-sol" -> "G"
                    "claude" -> "C"
                    "gemini" -> "✦"
                    "grok" -> "X"
                    "deepseek" -> "D"
                    else -> "AI"
                },
                color = color,
                fontWeight = FontWeight.ExtraBold,
                fontSize = 12.sp
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ContextSheet(
    messageCount: Int,
    selectedModel: AiModelOption,
    isConfigured: Boolean,
    pendingAttachments: Int,
    onDismiss: () -> Unit
) {
    ModalBottomSheet(onDismissRequest = onDismiss, containerColor = Color(0xFF111218)) {
        Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 8.dp)) {
            Text("سياق المحادثة", fontSize = 19.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(5.dp))
            Text(
                "هذه اللوحة تظهر عند الطلب فقط حتى تبقى الدردشة نظيفة.",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = 11.sp
            )
            Spacer(Modifier.height(15.dp))
            ContextRow("النموذج الحالي", selectedModel.label, AionPurple)
            ContextRow("الرسائل", messageCount.toString(), AionPurpleSoft)
            ContextRow("البحث في الويب", "تلقائي عند الحاجة", AionBlueSoft)
            ContextRow("المرفقات الجاهزة", pendingAttachments.toString(), AionPurpleSoft)
            ContextRow("اتصال API", if (isConfigured) "جاهز" else "غير مضبوط", if (isConfigured) AionPurple else MaterialTheme.colorScheme.error)
            ContextRow("ذاكرة المشروع", "قيد البناء", Color(0xFF8C8794))
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun ContextRow(label: String, value: String, accent: Color) {
    Surface(
        modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp),
        shape = RoundedCornerShape(15.dp),
        color = Color(0xFF181920)
    ) {
        Row(modifier = Modifier.fillMaxWidth().padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(7.dp).clip(CircleShape).background(accent))
            Spacer(Modifier.width(9.dp))
            Text(label, modifier = Modifier.weight(1f), color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
            Text(value, fontWeight = FontWeight.SemiBold, fontSize = 11.sp)
        }
    }
}

@Composable
private fun AionMark(size: androidx.compose.ui.unit.Dp) {
    Surface(
        shape = RoundedCornerShape(size * 0.28f),
        color = Color(0xFF1B102A),
        modifier = Modifier.size(size),
        border = BorderStroke(1.dp, AionPurple.copy(alpha = 0.22f))
    ) {
        Box(contentAlignment = Alignment.Center) {
            Text(
                "A",
                color = AionPurpleSoft,
                fontSize = (size.value * 0.48f).sp,
                fontWeight = FontWeight.Black
            )
            Box(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = size * 0.18f)
                    .size(size * 0.13f)
                    .clip(CircleShape)
                    .background(AionPurple)
            )
        }
    }
}

@Composable
private fun SettingsDialog(
    initialApiKey: String,
    initialModel: String,
    onSave: (String, String) -> Unit,
    onDismiss: () -> Unit
) {
    var key by remember(initialApiKey) { mutableStateOf(initialApiKey) }
    var model by remember(initialModel) { mutableStateOf(initialModel) }

    AlertDialog(
        onDismissRequest = onDismiss,
        icon = { Icon(Icons.Outlined.Settings, contentDescription = null, tint = AionPurple) },
        title = { Text("إعدادات AION") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    "مفتاح OpenAI مشفر محليًا عبر Android Keystore في هذه النسخة التجريبية. قبل النشر العام سننقل الاتصال إلى خادم AION.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 11.sp
                )
                OutlinedTextField(
                    value = key,
                    onValueChange = { key = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("OpenAI API Key") },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation()
                )
                OutlinedTextField(
                    value = model,
                    onValueChange = { model = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("نموذج AION Auto الافتراضي") },
                    supportingText = { Text("الافتراضي: gpt-5.6-luna") },
                    singleLine = true
                )
                Text(
                    "اختيار النموذج لكل رسالة يتم مباشرة من شريحة النموذج فوق صندوق الكتابة.",
                    fontSize = 10.sp,
                    color = AionPurpleSoft
                )
            }
        },
        confirmButton = { TextButton(onClick = { onSave(key, model) }) { Text("حفظ") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}

@Composable
private fun CapabilityDialog(capability: AionCapability, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        icon = { Icon(capability.icon(), contentDescription = null, tint = AionPurple) },
        title = { Text(capability.title) },
        text = {
            Column {
                Text(capability.description)
                Spacer(Modifier.height(12.dp))
                Text("الحالة: ${capability.state.label()}", color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (capability.state != CapabilityState.READY) {
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "البنية الأساسية موجودة وسيتم ربط التنفيذ الكامل ضمن خارطة AION Master.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("حسنًا") } }
    )
}

private fun CapabilityState.label(): String = when (this) {
    CapabilityState.READY -> "جاهز"
    CapabilityState.FOUNDATION -> "البنية جاهزة — الربط مستمر"
    CapabilityState.PLANNED -> "مخطط له"
}

private fun AionCapability.icon(): ImageVector = when (key) {
    "agent" -> Icons.Outlined.SmartToy
    "memory" -> Icons.Outlined.Memory
    "files" -> Icons.Outlined.Folder
    "voice" -> Icons.Outlined.Mic
    "search" -> Icons.Outlined.Search
    "tools" -> Icons.Outlined.Build
    else -> Icons.Outlined.Psychology
}

private fun formatSize(sizeBytes: Long): String = when {
    sizeBytes >= 1024L * 1024L -> String.format(Locale.US, "%.1f MB", sizeBytes / (1024f * 1024f))
    sizeBytes >= 1024L -> String.format(Locale.US, "%.0f KB", sizeBytes / 1024f)
    else -> "$sizeBytes B"
}
