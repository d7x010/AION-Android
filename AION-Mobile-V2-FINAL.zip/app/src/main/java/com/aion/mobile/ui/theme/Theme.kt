package com.aion.mobile.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val AionDarkColors = darkColorScheme(
    primary = Color(0xFFE8EAED),
    onPrimary = Color(0xFF111318),
    primaryContainer = Color(0xFF24272D),
    onPrimaryContainer = Color(0xFFF3F4F6),
    secondary = Color(0xFF9AA0A6),
    onSecondary = Color(0xFF111318),
    background = Color(0xFF0D0F12),
    onBackground = Color(0xFFE8EAED),
    surface = Color(0xFF111318),
    onSurface = Color(0xFFE8EAED),
    surfaceVariant = Color(0xFF1B1E23),
    onSurfaceVariant = Color(0xFFBCC1C7),
    outline = Color(0xFF3B4048)
)

@Composable
fun AionTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = AionDarkColors,
        content = content
    )
}
