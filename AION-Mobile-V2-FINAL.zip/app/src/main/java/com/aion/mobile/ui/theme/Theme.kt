package com.aion.mobile.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val AionPurple = Color(0xFF8B5CF6)
val AionPurpleStrong = Color(0xFF7C3AED)
val AionPurpleSoft = Color(0xFFB89CFF)
val AionBlueSoft = Color(0xFF79A8FF)
val AionBlack = Color(0xFF090A0E)
val AionSurface = Color(0xFF111218)
val AionSurfaceRaised = Color(0xFF191A22)

private val AionDarkColors = darkColorScheme(
    primary = AionPurple,
    onPrimary = Color.White,
    primaryContainer = Color(0xFF2A184A),
    onPrimaryContainer = Color(0xFFE9DDFF),
    secondary = AionBlueSoft,
    onSecondary = Color(0xFF07101F),
    background = AionBlack,
    onBackground = Color(0xFFF2F0F6),
    surface = AionSurface,
    onSurface = Color(0xFFF2F0F6),
    surfaceVariant = AionSurfaceRaised,
    onSurfaceVariant = Color(0xFFC7C3CF),
    outline = Color(0xFF34303E),
    error = Color(0xFFFF6B7A),
    onError = Color(0xFF240308)
)

@Composable
fun AionTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = AionDarkColors,
        content = content
    )
}
