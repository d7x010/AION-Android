package com.aion.mobile.core.ai

import com.aion.mobile.model.ChatMessage
import com.aion.mobile.model.MessageRole
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL

class OpenAiGateway {
    fun complete(
        apiKey: String,
        model: String,
        messages: List<ChatMessage>
    ): String {
        val connection = (URL("https://api.openai.com/v1/responses").openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 30_000
            readTimeout = 120_000
            doOutput = true
            setRequestProperty("Authorization", "Bearer $apiKey")
            setRequestProperty("Content-Type", "application/json")
        }

        val input = JSONArray()
        messages.forEach { message ->
            input.put(
                JSONObject().apply {
                    put("role", if (message.role == MessageRole.USER) "user" else "assistant")
                    put("content", JSONArray().put(
                        JSONObject().apply {
                            put("type", "input_text")
                            put("text", message.text)
                        }
                    ))
                }
            )
        }

        val body = JSONObject().apply {
            put("model", model)
            put("input", input)
            put("instructions", "أنت AION، مساعد شخصي ذكي على أندرويد. أجب بالعربية افتراضيًا ما لم يطلب المستخدم لغة أخرى. كن دقيقًا ومباشرًا ومفيدًا.")
        }

        connection.outputStream.use { out ->
            out.write(body.toString().toByteArray(Charsets.UTF_8))
        }

        val code = connection.responseCode
        val stream = if (code in 200..299) connection.inputStream else connection.errorStream
        val raw = BufferedReader(InputStreamReader(stream, Charsets.UTF_8)).use { it.readText() }

        if (code !in 200..299) {
            val message = runCatching {
                JSONObject(raw).optJSONObject("error")?.optString("message")
            }.getOrNull().orEmpty()
            throw OpenAiException(code, message.ifBlank { "تعذر الاتصال بخدمة الذكاء الاصطناعي." })
        }

        val json = JSONObject(raw)
        val output = json.optJSONArray("output") ?: JSONArray()
        val text = StringBuilder()
        for (i in 0 until output.length()) {
            val item = output.optJSONObject(i) ?: continue
            val content = item.optJSONArray("content") ?: continue
            for (j in 0 until content.length()) {
                val part = content.optJSONObject(j) ?: continue
                if (part.optString("type") == "output_text") {
                    if (text.isNotEmpty()) text.append("\n")
                    text.append(part.optString("text"))
                }
            }
        }

        return text.toString().trim().ifBlank { "لم يصل رد نصي من النموذج." }
    }
}

class OpenAiException(val statusCode: Int, override val message: String) : Exception(message)
