package com.aion.mobile.feature.chat

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.aion.mobile.core.ai.ApiKeyStore
import com.aion.mobile.core.ai.GatewayActivity
import com.aion.mobile.core.ai.OpenAiException
import com.aion.mobile.core.ai.OpenAiGateway
import com.aion.mobile.model.ChatAttachment
import com.aion.mobile.model.ChatMessage
import com.aion.mobile.model.MessageRole
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class AiModelOption(
    val key: String,
    val label: String,
    val provider: String,
    val enabled: Boolean,
    val modelId: String? = null,
    val badge: String? = null
)

class ChatViewModel(application: Application) : AndroidViewModel(application) {
    private val _messages = mutableStateListOf<ChatMessage>()
    val messages: SnapshotStateList<ChatMessage> = _messages

    private val _pendingAttachments = mutableStateListOf<ChatAttachment>()
    val pendingAttachments: SnapshotStateList<ChatAttachment> = _pendingAttachments

    private val gateway = OpenAiGateway()
    private var nextId = 1L
    private var currentSendJob: Job? = null

    var apiKey by mutableStateOf(ApiKeyStore.loadKey(application))
        private set
    var model by mutableStateOf(ApiKeyStore.loadModel(application))
        private set
    var isSending by mutableStateOf(false)
        private set
    var selectedModelKey by mutableStateOf("auto")
        private set
    var activity by mutableStateOf<GatewayActivity?>(null)
        private set

    val isConfigured: Boolean get() = apiKey.isNotBlank()

    val modelOptions: List<AiModelOption>
        get() = listOf(
            AiModelOption(
                key = "auto",
                label = "AION Auto",
                provider = "اختيار AION الذكي",
                enabled = true,
                modelId = model,
                badge = "تلقائي"
            ),
            AiModelOption(
                key = "gpt-luna",
                label = "GPT-5.6 Luna",
                provider = "OpenAI",
                enabled = true,
                modelId = "gpt-5.6-luna"
            ),
            AiModelOption(
                key = "gpt-sol",
                label = "GPT-5.6 Sol",
                provider = "OpenAI",
                enabled = true,
                modelId = "gpt-5.6-sol"
            ),
            AiModelOption("claude", "Claude", "Anthropic", false, badge = "قريبًا"),
            AiModelOption("gemini", "Gemini", "Google", false, badge = "قريبًا"),
            AiModelOption("grok", "Grok", "xAI", false, badge = "قريبًا"),
            AiModelOption("deepseek", "DeepSeek", "DeepSeek", false, badge = "قريبًا")
        )

    val selectedModel: AiModelOption
        get() = modelOptions.firstOrNull { it.key == selectedModelKey } ?: modelOptions.first()

    fun selectModel(key: String) {
        val option = modelOptions.firstOrNull { it.key == key } ?: return
        if (option.enabled && !isSending) selectedModelKey = option.key
    }

    fun saveSettings(newApiKey: String, newModel: String) {
        val cleanKey = newApiKey.trim()
        val cleanModel = newModel.trim().ifBlank { "gpt-5.6-luna" }
        ApiKeyStore.save(getApplication(), cleanKey, cleanModel)
        apiKey = cleanKey
        model = cleanModel
    }

    fun addAttachments(items: List<ChatAttachment>) {
        if (isSending) return
        items.forEach { attachment ->
            if (_pendingAttachments.none { it.id == attachment.id }) {
                _pendingAttachments += attachment
            }
        }
    }

    fun removeAttachment(id: Long) {
        if (!isSending) _pendingAttachments.removeAll { it.id == id }
    }

    fun clearAttachments() {
        if (!isSending) _pendingAttachments.clear()
    }

    fun send(text: String) {
        val clean = text.trim()
        val attachments = _pendingAttachments.toList()
        if ((clean.isEmpty() && attachments.isEmpty()) || isSending) return

        val chosen = selectedModel
        val resolvedModel = chosen.modelId?.takeIf { it.isNotBlank() } ?: model
        val userMessage = ChatMessage(
            id = nextId++,
            role = MessageRole.USER,
            text = clean,
            modelId = resolvedModel,
            modelLabel = chosen.label,
            attachments = attachments
        )
        _messages += userMessage
        _pendingAttachments.clear()

        if (!isConfigured) {
            _messages += ChatMessage(
                id = nextId++,
                role = MessageRole.AION,
                text = "أضف مفتاح OpenAI API من الإعدادات أولًا، ثم أرسل الرسالة من جديد.",
                modelId = resolvedModel,
                modelLabel = chosen.label,
                isError = true
            )
            return
        }

        requestAssistantResponse(chosen = chosen, resolvedModel = resolvedModel)
    }

    fun stopGeneration() {
        currentSendJob?.cancel(CancellationException("أوقف المستخدم إنشاء الرد"))
    }

    fun retryLastResponse() {
        if (isSending || !isConfigured) return
        val lastUserIndex = _messages.indexOfLast { it.role == MessageRole.USER }
        if (lastUserIndex < 0) return

        while (_messages.size > lastUserIndex + 1) {
            _messages.removeAt(_messages.lastIndex)
        }

        val lastUser = _messages[lastUserIndex]
        val chosen = modelOptions.firstOrNull { it.label == lastUser.modelLabel }
            ?: modelOptions.firstOrNull { it.modelId == lastUser.modelId }
            ?: if (selectedModel.enabled) selectedModel else modelOptions.first()
        val resolvedModel = lastUser.modelId?.takeIf { it.isNotBlank() }
            ?: chosen.modelId?.takeIf { it.isNotBlank() }
            ?: model

        requestAssistantResponse(chosen = chosen, resolvedModel = resolvedModel)
    }

    fun newConversation() {
        if (!isSending) {
            _messages.clear()
            _pendingAttachments.clear()
            activity = null
        }
    }

    private fun requestAssistantResponse(chosen: AiModelOption, resolvedModel: String) {
        val placeholderId = nextId++
        _messages += ChatMessage(
            id = placeholderId,
            role = MessageRole.AION,
            text = "",
            modelId = resolvedModel,
            modelLabel = chosen.label,
            isStreaming = true
        )
        isSending = true
        activity = GatewayActivity.THINKING

        val requestMessages = _messages
            .filter { it.id != placeholderId && !it.isError && !it.wasStopped }
            .toList()

        currentSendJob = viewModelScope.launch {
            try {
                val result = gateway.streamComplete(
                    apiKey = apiKey,
                    model = resolvedModel,
                    messages = requestMessages,
                    onDelta = { delta ->
                        withContext(Dispatchers.Main.immediate) {
                            val index = _messages.indexOfFirst { it.id == placeholderId }
                            if (index >= 0) {
                                val current = _messages[index]
                                _messages[index] = current.copy(
                                    text = current.text + delta,
                                    isStreaming = true
                                )
                            }
                        }
                    },
                    onActivity = { newActivity ->
                        withContext(Dispatchers.Main.immediate) {
                            activity = newActivity
                        }
                    }
                )

                val index = _messages.indexOfFirst { it.id == placeholderId }
                if (index >= 0) {
                    _messages[index] = ChatMessage(
                        id = placeholderId,
                        role = MessageRole.AION,
                        text = result.text,
                        modelId = resolvedModel,
                        modelLabel = chosen.label,
                        sources = result.sources,
                        isStreaming = false
                    )
                }
            } catch (cancelled: CancellationException) {
                val index = _messages.indexOfFirst { it.id == placeholderId }
                if (index >= 0) {
                    val current = _messages[index]
                    if (current.text.isBlank()) {
                        _messages.removeAt(index)
                    } else {
                        _messages[index] = current.copy(
                            isStreaming = false,
                            wasStopped = true
                        )
                    }
                }
            } catch (throwable: Throwable) {
                val index = _messages.indexOfFirst { it.id == placeholderId }
                if (index >= 0) {
                    _messages[index] = ChatMessage(
                        id = placeholderId,
                        role = MessageRole.AION,
                        text = readableError(throwable),
                        modelId = resolvedModel,
                        modelLabel = chosen.label,
                        isError = true,
                        isStreaming = false
                    )
                }
            } finally {
                isSending = false
                activity = null
                currentSendJob = null
            }
        }
    }

    private fun readableError(error: Throwable): String = when (error) {
        is OpenAiException -> when (error.statusCode) {
            400 -> "تعذر تنفيذ الطلب بسبب إعدادات النموذج أو صيغة الرسالة: ${error.message}"
            401 -> "مفتاح API غير صحيح أو غير صالح. افتح الإعدادات وتحقق منه."
            404 -> "النموذج المحدد غير متاح لهذا المفتاح. اختر AION Auto أو نموذجًا آخر من داخل الدردشة."
            413 -> "الملف أو الصور المرفقة كبيرة جدًا لهذا الطلب. جرّب ملفات أصغر أو عددًا أقل."
            429 -> "تم بلوغ حد الاستخدام أو الرصيد المتاح للـAPI. تحقق من الفوترة أو الحدود في حساب OpenAI."
            else -> "تعذر الحصول على رد من OpenAI (${error.statusCode}): ${error.message}"
        }
        else -> "تعذر الاتصال بالإنترنت أو بخدمة OpenAI: ${error.message ?: "خطأ غير معروف"}"
    }
}
