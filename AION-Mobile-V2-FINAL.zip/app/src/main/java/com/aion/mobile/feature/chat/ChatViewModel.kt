package com.aion.mobile.feature.chat

import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.lifecycle.ViewModel
import com.aion.mobile.model.ChatMessage
import com.aion.mobile.model.MessageRole

class ChatViewModel : ViewModel() {
    private val _messages = mutableStateListOf<ChatMessage>()
    val messages: SnapshotStateList<ChatMessage> = _messages

    private var nextId = 1L

    fun send(text: String) {
        val clean = text.trim()
        if (clean.isEmpty()) return

        _messages += ChatMessage(nextId++, MessageRole.USER, clean)
        _messages += ChatMessage(
            nextId++,
            MessageRole.AION,
            "وصلت رسالتك. هذه نسخة AION Mobile V2 الأساسية، ومحرك الذكاء الاصطناعي سيُربط في المرحلة التالية بعد تثبيت بناء التطبيق بنجاح."
        )
    }

    fun newConversation() {
        _messages.clear()
    }
}
