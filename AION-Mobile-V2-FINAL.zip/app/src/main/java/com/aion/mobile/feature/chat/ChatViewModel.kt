package com.aion.mobile.feature.chat

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.aion.mobile.core.ai.ApiKeyStore
import com.aion.mobile.core.ai.OpenAiException
import com.aion.mobile.core.ai.OpenAiGateway
import com.aion.mobile.model.ChatMessage
import com.aion.mobile.model.MessageRole
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class ChatViewModel(application: Application) : AndroidViewModel(application) {
    private val _messages = mutableStateListOf<ChatMessage>()
    val messages: SnapshotStateList<ChatMessage> = _messages

    private val gateway = OpenAiGateway()
    private var nextId = 1L

    var apiKey by mutableStateOf(ApiKeyStore.loadKey(application))
        private set
    var model by mutableStateOf(ApiKeyStore.loadModel(application))
        private set
    var isSending by mutableStateOf(false)
        private set

    val isConfigured: Boolean get() = apiKey.isNotBlank()

    fun saveSettings(newApiKey: String, newModel: String) {
        val cleanKey = newApiKey.trim()
        val cleanModel = newModel.trim().ifBlank { "gpt-5.6-luna" }
        ApiKeyStore.save(getApplication(), cleanKey, cleanModel)
        apiKey = cleanKey
        model = cleanModel
    }

    fun send(text: String) {
        val clean = text.trim()
        if (clean.isEmpty() || isSending) return

        _messages += ChatMessage(nextId++, MessageRole.USER, clean)

        if (!isConfigured) {
            _messages += ChatMessage(
                nextId++,
                MessageRole.AION,
                "أضف مفتاح OpenAI API من زر الإعدادات أولًا، ثم أرسل الرسالة من جديد."
            )
            return
        }

        val placeholderId = nextId++
        _messages += ChatMessage(placeholderId, MessageRole.AION, "جارٍ التفكير…")
        isSending = true

        val requestMessages = _messages.filter { it.id != placeholderId }.toList()
        viewModelScope.launch {
            val result = runCatching {
                withContext(Dispatchers.IO) {
                    gateway.complete(apiKey = apiKey, model = model, messages = requestMessages)
                }
            }

            val index = _messages.indexOfFirst { it.id == placeholderId }
            if (index >= 0) {
                _messages[index] = ChatMessage(
                    placeholderId,
                    MessageRole.AION,
                    result.fold(
                        onSuccess = { it },
                        onFailure = { throwable -> readableError(throwable) }
                    )
                )
            }
            isSending = false
        }
    }

    fun newConversation() {
        if (!isSending) _messages.clear()
    }

    private fun readableError(error: Throwable): String = when (error) {
        is OpenAiException -> when (error.statusCode) {
            401 -> "مفتاح API غير صحيح أو غير صالح. افتح الإعدادات وتحقق منه."
            429 -> "تم بلوغ حد الاستخدام أو الرصيد المتاح للـAPI. تحقق من الفوترة أو الحدود في حساب OpenAI."
            else -> "تعذر الحصول على رد من OpenAI (${error.statusCode}): ${error.message}"
        }
        else -> "تعذر الاتصال بالإنترنت أو بخدمة OpenAI: ${error.message ?: "خطأ غير معروف"}"
    }
}
