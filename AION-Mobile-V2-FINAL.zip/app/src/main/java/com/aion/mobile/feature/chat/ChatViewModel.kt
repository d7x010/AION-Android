package com.aion.mobile.feature.chat

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.aion.mobile.core.ai.ApiKeyStore
import com.aion.mobile.core.ai.OpenAiException
import com.aion.mobile.core.ai.OpenAiGateway
import com.aion.mobile.model.ChatMessage
import com.aion.mobile.model.MessageRole
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class AiModelOption(
    val key: String,
    val label: String,
    val provider: String,
    val enabled: Boolean,
    val modelId: String? = null,
    val badge: String? = null
)

class ChatViewModel(application: Application) : AndroidViewModel(application) {
    private val _messages = mutableStateListOf<ChatMessage>()
    val messages: SnapshotStateList<ChatMessage> = _messages

    private val gateway = OpenAiGateway()
    private var nextId = 1L

    var apiKey by mutableStateOf(ApiKeyStore.loadKey(application))
        private set
    var model by mutableStateOf(ApiKeyStore.loadModel(application))
        private set
    var isSending by mutableStateOf(false)
        private set
    var selectedModelKey by mutableStateOf("auto")
        private set

    val isConfigured: Boolean get() = apiKey.isNotBlank()

    val modelOptions: List<AiModelOption>
        get() = listOf(
            AiModelOption(
                key = "auto",
                label = "AION Auto",
                provider = "اختيار AION الذكي",
                enabled = true,
                modelId = model,
                badge = "تلقائي"
            ),
            AiModelOption(
                key = "gpt-luna",
                label = "GPT-5.6 Luna",
                provider = "OpenAI",
                enabled = true,
                modelId = "gpt-5.6-luna"
            ),
            AiModelOption(
                key = "gpt-sol",
                label = "GPT-5.6 Sol",
                provider = "OpenAI",
                enabled = true,
                modelId = "gpt-5.6-sol"
            ),
            AiModelOption("claude", "Claude", "Anthropic", false, badge = "قريبًا"),
            AiModelOption("gemini", "Gemini", "Google", false, badge = "قريبًا"),
            AiModelOption("grok", "Grok", "xAI", false, badge = "قريبًا"),
            AiModelOption("deepseek", "DeepSeek", "DeepSeek", false, badge = "قريبًا")
        )

    val selectedModel: AiModelOption
        get() = modelOptions.firstOrNull { it.key == selectedModelKey } ?: modelOptions.first()

    fun selectModel(key: String) {
        val option = modelOptions.firstOrNull { it.key == key } ?: return
        if (option.enabled && !isSending) selectedModelKey = option.key
    }

    fun saveSettings(newApiKey: String, newModel: String) {
        val cleanKey = newApiKey.trim()
        val cleanModel = newModel.trim().ifBlank { "gpt-5.6-luna" }
        ApiKeyStore.save(getApplication(), cleanKey, cleanModel)
        apiKey = cleanKey
        model = cleanModel
    }

    fun send(text: String) {
        val clean = text.trim()
        if (clean.isEmpty() || isSending) return

        val chosen = selectedModel
        val resolvedModel = chosen.modelId?.takeIf { it.isNotBlank() } ?: model

        _messages += ChatMessage(nextId++, MessageRole.USER, clean)

        if (!isConfigured) {
            _messages += ChatMessage(
                id = nextId++,
                role = MessageRole.AION,
                text = "أضف مفتاح OpenAI API من الإعدادات أولًا، ثم أرسل الرسالة من جديد.",
                modelId = resolvedModel,
                modelLabel = chosen.label,
                isError = true
            )
            return
        }

        val placeholderId = nextId++
        _messages += ChatMessage(
            id = placeholderId,
            role = MessageRole.AION,
            text = "جارٍ التفكير…",
            modelId = resolvedModel,
            modelLabel = chosen.label
        )
        isSending = true

        val requestMessages = _messages
            .filter { it.id != placeholderId && !it.isError }
            .toList()

        viewModelScope.launch {
            val result = runCatching {
                withContext(Dispatchers.IO) {
                    gateway.complete(
                        apiKey = apiKey,
                        model = resolvedModel,
                        messages = requestMessages
                    )
                }
            }

            val index = _messages.indexOfFirst { it.id == placeholderId }
            if (index >= 0) {
                _messages[index] = result.fold(
                    onSuccess = { answer ->
                        ChatMessage(
                            id = placeholderId,
                            role = MessageRole.AION,
                            text = answer,
                            modelId = resolvedModel,
                            modelLabel = chosen.label
                        )
                    },
                    onFailure = { throwable ->
                        ChatMessage(
                            id = placeholderId,
                            role = MessageRole.AION,
                            text = readableError(throwable),
                            modelId = resolvedModel,
                            modelLabel = chosen.label,
                            isError = true
                        )
                    }
                )
            }
            isSending = false
        }
    }

    fun newConversation() {
        if (!isSending) _messages.clear()
    }

    private fun readableError(error: Throwable): String = when (error) {
        is OpenAiException -> when (error.statusCode) {
            400 -> "تعذر تنفيذ الطلب بسبب إعدادات النموذج أو صيغة الرسالة: ${error.message}"
            401 -> "مفتاح API غير صحيح أو غير صالح. افتح الإعدادات وتحقق منه."
            404 -> "النموذج المحدد غير متاح لهذا المفتاح. اختر AION Auto أو نموذجًا آخر من داخل الدردشة."
            429 -> "تم بلوغ حد الاستخدام أو الرصيد المتاح للـAPI. تحقق من الفوترة أو الحدود في حساب OpenAI."
            else -> "تعذر الحصول على رد من OpenAI (${error.statusCode}): ${error.message}"
        }
        else -> "تعذر الاتصال بالإنترنت أو بخدمة OpenAI: ${error.message ?: "خطأ غير معروف"}"
    }
}
