package com.aion.mobile.ui.design

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * AION α7.3 design tokens. UI code should consume these tokens instead of inventing
 * one-off colors, radii or touch sizes in individual screens.
 */
object AionColors {
    // Replica foundation: quiet neutral surfaces, no permanent neon decoration.
    // AION's color skin is applied later without changing this structural system.
    val Background = Color(0xFF0D0D0D)
    val Surface = Color(0xFF171717)
    val SurfaceRaised = Color(0xFF212121)
    val SurfaceInteractive = Color(0xFF2A2A2A)
    val SurfaceMuted = Color(0xFF1B1B1B)
    val SurfaceSelected = Color(0xFF292929)
    val Border = Color(0xFF333333)
    val BorderStrong = Color(0xFF4A4A4A)
    val BorderFocused = Color(0xFF777777)

    val TextPrimary = Color(0xFFF4F4F6)
    val TextSecondary = Color(0xFFA6A6B0)
    // Raised from the earlier α7.3 draft so tertiary labels remain comfortable on raised surfaces.
    val TextTertiary = Color(0xFF8A8A96)
    val TextDisabled = Color(0xFF666671)

    val Intelligence = Color(0xFFECECEC)
    val IntelligenceStrong = Color(0xFFFFFFFF)
    val IntelligenceSoft = Color(0xFFD6D6D6)

    val External = Color(0xFFBDBDBD)
    val ExternalSoft = Color(0xFFE0E0E0)

    val Success = Color(0xFF39D98A)
    val Warning = Color(0xFFE9B85D)
    val Error = Color(0xFFEF6A73)
}

object AionSpacing {
    val Xs: Dp = 4.dp
    val Sm: Dp = 8.dp
    val Md: Dp = 12.dp
    val Lg: Dp = 16.dp
    val Xl: Dp = 20.dp
    val Xxl: Dp = 24.dp
    val Xxxl: Dp = 32.dp
}

object AionRadii {
    val Chip: Dp = 18.dp
    val Card: Dp = 20.dp
    val Attachment: Dp = 18.dp
    val UserBubble: Dp = 22.dp
    val Composer: Dp = 26.dp
}

object AionSizes {
    val Icon: Dp = 24.dp
    val SmallIcon: Dp = 18.dp
    val TouchTarget: Dp = 48.dp
    val ComposerMinHeight: Dp = 54.dp
    val LiveButton: Dp = 48.dp
    val ActivityMark: Dp = 18.dp
    val AttachmentThumb: Dp = 46.dp
    val AttachmentIconBox: Dp = 38.dp
    val AttachmentCardMinWidth: Dp = 176.dp
    val AttachmentCardMaxWidth: Dp = 280.dp
    val AttachmentImageHeight: Dp = 156.dp
    val ContentMaxWidth: Dp = 760.dp
    val DrawerMaxWidth: Dp = 372.dp
    val MiniLiveOrb: Dp = 56.dp
}

object AionLayout {
    /** Maximum width of a user bubble relative to the readable content column. */
    const val UserBubbleMaxFraction: Float = 0.86f

    val ChatHorizontalPadding: Dp = 18.dp
    val ChatVerticalPadding: Dp = 14.dp
    val MessageSpacing: Dp = 24.dp

    val ComposerOuterHorizontal: Dp = 10.dp
    val ComposerOuterTop: Dp = 5.dp
    val ComposerOuterBottom: Dp = 5.dp

    val UserBubbleHorizontalPadding: Dp = 15.dp
    val UserBubbleVerticalPadding: Dp = 11.dp
    val AssistantTextEdgePadding: Dp = 2.dp

    val ScrollReturnBottomGap: Dp = 12.dp
}

object AionMotion {
    const val FastMs = 160
    const val StandardMs = 200
    const val SheetMs = 220
}
