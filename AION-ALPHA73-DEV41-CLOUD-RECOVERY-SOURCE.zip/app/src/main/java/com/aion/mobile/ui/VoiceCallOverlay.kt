package com.aion.mobile.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.AudioFormat
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.Keyboard
import androidx.compose.material.icons.outlined.KeyboardArrowDown
import androidx.compose.material.icons.outlined.Mic
import androidx.compose.material.icons.outlined.MicOff
import androidx.compose.material.icons.outlined.Stop
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import com.aion.mobile.core.ai.GatewayActivity
import com.aion.mobile.core.voice.AionLivePhase
import com.aion.mobile.core.voice.AionLiveAudioSession
import com.aion.mobile.core.voice.AionLivePhasePolicy
import com.aion.mobile.core.voice.AionLivePresentation
import com.aion.mobile.core.voice.AionVoiceSettings
import com.aion.mobile.core.voice.AionVoicePlaybackArbiter
import com.aion.mobile.core.voice.AionVoicePlaybackOwner
import com.aion.mobile.core.voice.NeuralVoicePlaybackResult
import com.aion.mobile.core.voice.NeuralVoicePlayer
import com.aion.mobile.core.voice.MyVoicePolicy
import com.aion.mobile.core.voice.SpeechText
import com.aion.mobile.core.voice.VoiceAmplitude
import com.aion.mobile.core.voice.VoiceBargeInDetector
import com.aion.mobile.core.voice.VoiceTurnPolicy
import com.aion.mobile.model.ChatMessage
import com.aion.mobile.model.MessageRole
import com.aion.mobile.ui.design.AionColors
import com.aion.mobile.ui.design.AionHaptics
import com.aion.mobile.ui.design.AionRadii
import com.aion.mobile.ui.design.AionSizes
import com.aion.mobile.ui.design.AionSpacing
import com.aion.mobile.ui.theme.AionPurpleSoft
import com.aion.mobile.ui.theme.AionPurpleStrong
import kotlinx.coroutines.delay
import java.util.Locale
import java.util.concurrent.atomic.AtomicInteger

/**
 * مكالمة صوتية داخل المحادثة: استماع -> إرسال -> رد -> كلام -> استماع.
 *
 * ليست WebRTC full-duplex بعد، لكن الحركة أثناء كلام AION تعتمد على PCM الحقيقي الذي يولده TTS
 * عبر UtteranceProgressListener.onAudioAvailable بدل نبضة زمنية وهمية. ويمكن للمستخدم مقاطعة
 * كلام AION فورًا بالضغط على الدائرة أو زر الإيقاف لبدء الاستماع إلى دوره الجديد.
 */
@Composable
internal fun VoiceCallOverlay(
    presentation: AionLivePresentation,
    cloudEndpoint: String,
    neuralVoiceAvailable: Boolean,
    voiceSettings: AionVoiceSettings,
    myVoiceToken: String,
    voicePlaybackArbiter: AionVoicePlaybackArbiter,
    messages: List<ChatMessage>,
    isSending: Boolean,
    activity: GatewayActivity?,
    onSend: (String) -> Unit,
    onStop: () -> Unit,
    onPhaseChanged: (AionLivePhase) -> Unit,
    onMutedChanged: (Boolean) -> Unit,
    onMinimize: () -> Unit,
    onRestore: () -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val hapticView = LocalView.current
    val mainHandler = remember { Handler(Looper.getMainLooper()) }
    val neuralVoicePlayer = remember { NeuralVoicePlayer() }
    val audioSession = remember { AionLiveAudioSession(context.applicationContext) }
    val bargeInDetector = remember { VoiceBargeInDetector(context.applicationContext) }
    val latestSending by rememberUpdatedState(isSending)
    var state by remember { mutableStateOf(AionLivePhase.INITIALIZING) }
    var partialText by remember { mutableStateOf("") }
    var rms by remember { mutableFloatStateOf(0f) }
    var assistantLevel by remember { mutableFloatStateOf(0f) }
    var muted by remember { mutableStateOf(false) }
    var recognizer by remember { mutableStateOf<SpeechRecognizer?>(null) }
    var tts by remember { mutableStateOf<TextToSpeech?>(null) }
    var ttsReady by remember { mutableStateOf(false) }
    var requestListenTick by remember { mutableIntStateOf(0) }
    var recognitionFailures by remember { mutableIntStateOf(0) }
    var networkFailures by remember { mutableIntStateOf(0) }
    var suppressRecognizerErrorsUntil by remember { mutableLongStateOf(0L) }
    var livePlaybackLease by remember { mutableStateOf<Long?>(null) }
    val synthesisFormat = remember { AtomicInteger(AudioFormat.ENCODING_PCM_16BIT) }
    var lastHandledAssistantId by remember {
        mutableStateOf(messages.lastOrNull { it.role == MessageRole.AION }?.id)
    }

    LaunchedEffect(state) { onPhaseChanged(state) }
    LaunchedEffect(muted) { onMutedChanged(muted) }

    fun cancelRecognizerSilently() {
        suppressRecognizerErrorsUntil = SystemClock.uptimeMillis() + 650L
        runCatching { recognizer?.cancel() }
        rms = 0f
    }

    fun scheduleListen(delayMs: Long = 180L) {
        mainHandler.postDelayed({
            if (VoiceTurnPolicy.canAutoResumeListening(state, muted, latestSending)) {
                if (voicePlaybackArbiter.isOwnedByOther(AionVoicePlaybackOwner.LIVE)) {
                    // Another AION surface is audible (Preview / Read Aloud). Do not let the
                    // recognizer transcribe AION's own speaker output; retry after that lease ends.
                    scheduleListen(180L)
                } else {
                    requestListenTick += 1
                }
            }
        }, delayMs)
    }

    fun releaseLiveLease(token: Long) {
        voicePlaybackArbiter.release(AionVoicePlaybackOwner.LIVE, token)
        if (livePlaybackLease == token) livePlaybackLease = null
    }

    fun stopPlaybackHardware() {
        bargeInDetector.stop()
        neuralVoicePlayer.stop()
        runCatching { tts?.stop() }
        assistantLevel = 0f
    }

    fun claimLivePlayback(): Long {
        var callbackToken = 0L
        val token = voicePlaybackArbiter.claim(AionVoicePlaybackOwner.LIVE) {
            val interruptedToken = callbackToken
            stopPlaybackHardware()
            mainHandler.post {
                // A stale stop callback from an older LIVE lease must never change a newer turn.
                if (interruptedToken != 0L && livePlaybackLease == interruptedToken) {
                    livePlaybackLease = null
                    if (!latestSending) {
                        state = AionLivePhase.IDLE
                        if (!muted) scheduleListen(180L)
                    }
                }
            }
        }
        callbackToken = token
        livePlaybackLease = token
        return token
    }

    fun stopAudio() {
        cancelRecognizerSilently()
        if (!voicePlaybackArbiter.interrupt(AionVoicePlaybackOwner.LIVE)) {
            stopPlaybackHardware()
        }
        livePlaybackLease = null
        assistantLevel = 0f
    }

    fun interruptAssistantAndListen() {
        AionHaptics.tap(hapticView)
        if (!voicePlaybackArbiter.interrupt(AionVoicePlaybackOwner.LIVE)) {
            stopPlaybackHardware()
        }
        livePlaybackLease = null
        assistantLevel = 0f
        state = VoiceTurnPolicy.passivePhase(muted)
        if (!muted) scheduleListen(90L)
    }

    fun startListeningNow() {
        if (muted || latestSending || state == AionLivePhase.SPEAKING) return
        if (voicePlaybackArbiter.isOwnedByOther(AionVoicePlaybackOwner.LIVE)) {
            state = AionLivePhase.IDLE
            scheduleListen(180L)
            return
        }
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return
        val r = recognizer ?: return
        partialText = ""
        rms = 0f
        state = AionLivePhase.LISTENING
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag())
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, false)
            // فواصل صمت أقصر من الوضع القديم لتقليل التأخير بعد انتهاء المستخدم من الكلام.
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 900L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 520L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 350L)
        }
        runCatching { r.startListening(intent) }
            .onFailure {
                state = AionLivePhase.RECONNECTING
                recognitionFailures += 1
                scheduleListen(VoiceTurnPolicy.retryDelayMs(recognitionFailures, networkRelated = false))
            }
    }

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) {
            requestListenTick += 1
        } else {
            state = AionLivePhase.ERROR
            Toast.makeText(context, "يحتاج AION إذن الميكروفون لبدء المكالمة.", Toast.LENGTH_SHORT).show()
        }
    }

    DisposableEffect(context) {
        audioSession.acquire()
        val removePlaybackListener = voicePlaybackArbiter.addOwnerListener { owner ->
            if (owner != null && owner != AionVoicePlaybackOwner.LIVE) {
                mainHandler.post {
                    cancelRecognizerSilently()
                    rms = 0f
                    if (!latestSending && state in setOf(AionLivePhase.LISTENING, AionLivePhase.SPEAKING)) {
                        state = AionLivePhase.IDLE
                    }
                    if (!muted && !latestSending) scheduleListen(220L)
                }
            }
        }
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            state = AionLivePhase.ERROR
        } else {
            val speech = SpeechRecognizer.createSpeechRecognizer(context)
            speech.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {
                    if (!muted && !voicePlaybackArbiter.isOwnedByOther(AionVoicePlaybackOwner.LIVE)) {
                        state = AionLivePhase.LISTENING
                    }
                }

                override fun onBeginningOfSpeech() {
                    if (voicePlaybackArbiter.isOwnedByOther(AionVoicePlaybackOwner.LIVE)) return
                    recognitionFailures = 0
                    networkFailures = 0
                    if (!muted) state = AionLivePhase.LISTENING
                }

                override fun onRmsChanged(rmsdB: Float) {
                    // SpeechRecognizer يعطي RMS فعليًا للميكروفون؛ لا توجد حركة زمنية مصطنعة هنا.
                    rms = if (voicePlaybackArbiter.isOwnedByOther(AionVoicePlaybackOwner.LIVE)) {
                        0f
                    } else {
                        rmsdB.coerceIn(0f, 12f)
                    }
                }

                override fun onBufferReceived(buffer: ByteArray?) = Unit
                override fun onEndOfSpeech() {
                    rms = 0f
                    if (voicePlaybackArbiter.isOwnedByOther(AionVoicePlaybackOwner.LIVE)) {
                        state = AionLivePhase.IDLE
                        if (!muted && !latestSending) scheduleListen(180L)
                        return
                    }
                    if (!latestSending && !muted) state = AionLivePhase.THINKING
                }

                override fun onError(error: Int) {
                    rms = 0f
                    if (SystemClock.uptimeMillis() <= suppressRecognizerErrorsUntil) return
                    if (voicePlaybackArbiter.isOwnedByOther(AionVoicePlaybackOwner.LIVE)) return
                    if (muted || latestSending || state == AionLivePhase.SPEAKING) return

                    val networkRelated = error == SpeechRecognizer.ERROR_NETWORK ||
                        error == SpeechRecognizer.ERROR_NETWORK_TIMEOUT ||
                        error == SpeechRecognizer.ERROR_SERVER

                    when (error) {
                        SpeechRecognizer.ERROR_NO_MATCH,
                        SpeechRecognizer.ERROR_SPEECH_TIMEOUT,
                        SpeechRecognizer.ERROR_RECOGNIZER_BUSY,
                        SpeechRecognizer.ERROR_NETWORK,
                        SpeechRecognizer.ERROR_NETWORK_TIMEOUT,
                        SpeechRecognizer.ERROR_SERVER -> {
                            recognitionFailures += 1
                            if (networkRelated) networkFailures += 1 else networkFailures = 0
                            if (VoiceTurnPolicy.shouldRequireManualResume(networkFailures)) {
                                state = AionLivePhase.ERROR
                            } else {
                                state = if (networkRelated) AionLivePhase.RECONNECTING else AionLivePhase.LISTENING
                                scheduleListen(VoiceTurnPolicy.retryDelayMs(recognitionFailures, networkRelated))
                            }
                        }
                        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> state = AionLivePhase.ERROR
                        else -> state = AionLivePhase.ERROR
                    }
                }

                override fun onResults(results: Bundle?) {
                    rms = 0f
                    if (voicePlaybackArbiter.isOwnedByOther(AionVoicePlaybackOwner.LIVE)) {
                        partialText = ""
                        state = AionLivePhase.IDLE
                        if (!muted && !latestSending) scheduleListen(180L)
                        return
                    }
                    recognitionFailures = 0
                    networkFailures = 0
                    val spoken = results
                        ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.firstOrNull()
                        ?.trim()
                        .orEmpty()
                    if (spoken.isNotBlank()) {
                        partialText = spoken
                        state = AionLivePhase.THINKING
                        onSend(spoken)
                    } else if (!muted) {
                        partialText = ""
                        scheduleListen(260L)
                    }
                }

                override fun onPartialResults(partialResults: Bundle?) {
                    if (voicePlaybackArbiter.isOwnedByOther(AionVoicePlaybackOwner.LIVE)) {
                        partialText = ""
                        return
                    }
                    partialText = partialResults
                        ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.firstOrNull()
                        .orEmpty()
                }

                override fun onEvent(eventType: Int, params: Bundle?) = Unit
            })
            recognizer = speech
        }

        var engine: TextToSpeech? = null
        engine = runCatching {
            TextToSpeech(context.applicationContext) { status ->
                val ready = engine ?: return@TextToSpeech
                if (status == TextToSpeech.SUCCESS) {
                    runCatching { configureNaturalTts(ready, Locale.getDefault()) }
                    ready.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                        private fun tokenOf(utteranceId: String?): Long? = utteranceId
                            ?.takeIf { it.startsWith("aion-call-") }
                            ?.removePrefix("aion-call-")
                            ?.substringBefore('-')
                            ?.toLongOrNull()

                        override fun onStart(utteranceId: String?) {
                            val token = tokenOf(utteranceId) ?: return
                            mainHandler.post {
                                if (
                                    livePlaybackLease == token &&
                                    voicePlaybackArbiter.isCurrent(AionVoicePlaybackOwner.LIVE, token)
                                ) {
                                    assistantLevel = 0f
                                    state = AionLivePhase.SPEAKING
                                }
                            }
                        }

                        override fun onBeginSynthesis(utteranceId: String?, sampleRateInHz: Int, audioFormat: Int, channelCount: Int) {
                            val token = tokenOf(utteranceId) ?: return
                            if (voicePlaybackArbiter.isCurrent(AionVoicePlaybackOwner.LIVE, token)) {
                                synthesisFormat.set(audioFormat)
                            }
                        }

                        override fun onAudioAvailable(utteranceId: String?, audio: ByteArray?) {
                            val token = tokenOf(utteranceId) ?: return
                            if (!voicePlaybackArbiter.isCurrent(AionVoicePlaybackOwner.LIVE, token)) return
                            val bytes = audio ?: return
                            val rawLevel = when (synthesisFormat.get()) {
                                AudioFormat.ENCODING_PCM_8BIT -> VoiceAmplitude.pcm8Unsigned(bytes)
                                AudioFormat.ENCODING_PCM_16BIT -> VoiceAmplitude.pcm16LittleEndian(bytes)
                                AudioFormat.ENCODING_PCM_FLOAT -> VoiceAmplitude.pcmFloatLittleEndian(bytes)
                                else -> 0f
                            }
                            mainHandler.post {
                                if (
                                    livePlaybackLease == token &&
                                    voicePlaybackArbiter.isCurrent(AionVoicePlaybackOwner.LIVE, token) &&
                                    state == AionLivePhase.SPEAKING
                                ) {
                                    assistantLevel = VoiceAmplitude.smooth(assistantLevel, rawLevel)
                                }
                            }
                        }

                        override fun onDone(utteranceId: String?) {
                            if (utteranceId?.endsWith(":last") != true) return
                            val token = tokenOf(utteranceId) ?: return
                            mainHandler.post {
                                if (voicePlaybackArbiter.isCurrent(AionVoicePlaybackOwner.LIVE, token)) {
                                    assistantLevel = 0f
                                    partialText = ""
                                    releaseLiveLease(token)
                                    state = VoiceTurnPolicy.passivePhase(muted)
                                    if (!muted && !latestSending) scheduleListen(230L)
                                }
                            }
                        }

                        override fun onStop(utteranceId: String?, interrupted: Boolean) {
                            val token = tokenOf(utteranceId) ?: return
                            mainHandler.post {
                                if (voicePlaybackArbiter.isCurrent(AionVoicePlaybackOwner.LIVE, token)) {
                                    assistantLevel = 0f
                                    releaseLiveLease(token)
                                    state = VoiceTurnPolicy.passivePhase(muted)
                                    if (!muted && !latestSending) scheduleListen(180L)
                                }
                            }
                        }

                        @Deprecated("Deprecated in Java")
                        override fun onError(utteranceId: String?) {
                            val token = tokenOf(utteranceId) ?: return
                            mainHandler.post {
                                if (voicePlaybackArbiter.isCurrent(AionVoicePlaybackOwner.LIVE, token)) {
                                    assistantLevel = 0f
                                    releaseLiveLease(token)
                                    state = AionLivePhase.ERROR
                                    if (!muted && !latestSending) scheduleListen(700L)
                                }
                            }
                        }
                    })
                    tts = ready
                    ttsReady = true
                    if (state == AionLivePhase.INITIALIZING) state = AionLivePhase.LISTENING
                } else {
                    ttsReady = false
                    if (state == AionLivePhase.INITIALIZING) state = AionLivePhase.LISTENING
                }
            }
        }.getOrNull()

        if (engine == null) {
            ttsReady = false
            if (state == AionLivePhase.INITIALIZING) state = AionLivePhase.ERROR
        }

        onDispose {
            removePlaybackListener()
            voicePlaybackArbiter.interrupt(AionVoicePlaybackOwner.LIVE)
            livePlaybackLease = null
            bargeInDetector.stop()
            neuralVoicePlayer.stop()
            audioSession.release()
            runCatching { speechRecognizerSafeDestroy(recognizer) }
            engine?.let { current ->
                runCatching { current.stop() }
                runCatching { current.shutdown() }
            }
            mainHandler.removeCallbacksAndMessages(null)
            recognizer = null
            tts = null
            ttsReady = false
        }
    }

    LaunchedEffect(Unit) {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            requestListenTick += 1
        } else {
            permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    LaunchedEffect(requestListenTick) {
        if (requestListenTick > 0 && VoiceTurnPolicy.canAutoResumeListening(state, muted, isSending)) {
            delay(90)
            startListeningNow()
        }
    }

    LaunchedEffect(state, muted) {
        if (state == AionLivePhase.SPEAKING && !muted) {
            bargeInDetector.start {
                mainHandler.post {
                    if (state == AionLivePhase.SPEAKING && !muted) {
                        interruptAssistantAndListen()
                    }
                }
            }
        } else {
            bargeInDetector.stop()
        }
    }

    LaunchedEffect(isSending, activity) {
        if (isSending) {
            // A typed message while AION is speaking is a real interruption: stop the old
            // audio immediately, then move the same live session into the new thinking turn.
            if (VoiceTurnPolicy.shouldInterruptPlaybackOnRequest(state)) {
                if (!voicePlaybackArbiter.interrupt(AionVoicePlaybackOwner.LIVE)) {
                    stopPlaybackHardware()
                }
                livePlaybackLease = null
            }
            assistantLevel = 0f
            cancelRecognizerSilently()
            state = AionLivePhasePolicy.fromGatewayActivity(activity)
        }
    }

    LaunchedEffect(messages.lastOrNull()?.id, isSending, ttsReady, neuralVoiceAvailable, cloudEndpoint, voiceSettings, myVoiceToken) {
        if (isSending) return@LaunchedEffect
        val last = messages.lastOrNull() ?: return@LaunchedEffect
        if (last.role != MessageRole.AION || last.id == lastHandledAssistantId) return@LaunchedEffect

        if (last.isError || last.wasStopped || last.text.isBlank()) {
            lastHandledAssistantId = last.id
            state = AionLivePhase.ERROR
            delay(650)
            if (!muted) scheduleListen(0L)
            return@LaunchedEffect
        }

        lastHandledAssistantId = last.id
        val cleanSpeech = SpeechText.clean(last.text)
        if (cleanSpeech.isBlank()) {
            state = VoiceTurnPolicy.passivePhase(muted)
            if (!muted) scheduleListen(120L)
            return@LaunchedEffect
        }

        suspend fun playLocalFallback(text: String, lease: Long): Boolean {
            if (!voicePlaybackArbiter.isCurrent(AionVoicePlaybackOwner.LIVE, lease)) return false
            val engine = tts
            if (engine == null || !ttsReady) {
                releaseLiveLease(lease)
                state = VoiceTurnPolicy.passivePhase(muted)
                if (!muted && !latestSending) scheduleListen(150L)
                return false
            }
            val chunks = SpeechText.chunks(text)
            if (chunks.isEmpty()) {
                releaseLiveLease(lease)
                state = VoiceTurnPolicy.passivePhase(muted)
                if (!muted && !latestSending) scheduleListen(120L)
                return false
            }

            runCatching { engine.setSpeechRate(voiceSettings.speed.coerceIn(0.72f, 1.20f)) }
            var queued = true
            chunks.forEachIndexed { index, chunk ->
                if (!queued || !voicePlaybackArbiter.isCurrent(AionVoicePlaybackOwner.LIVE, lease)) {
                    queued = false
                    return@forEachIndexed
                }
                val isLast = index == chunks.lastIndex
                val result = engine.speak(
                    chunk,
                    if (index == 0) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD,
                    null,
                    "aion-call-$lease-${last.id}-$index${if (isLast) ":last" else ""}"
                )
                if (result == TextToSpeech.ERROR) queued = false
            }
            if (!queued) {
                runCatching { engine.stop() }
                if (voicePlaybackArbiter.isCurrent(AionVoicePlaybackOwner.LIVE, lease)) {
                    releaseLiveLease(lease)
                    state = AionLivePhase.ERROR
                    if (!muted && !latestSending) scheduleListen(600L)
                }
                return false
            }
            return true
        }

        val lease = claimLivePlayback()
        val canUseNeural = neuralVoiceAvailable ||
            (voiceSettings.voiceKey == MyVoicePolicy.MY_VOICE_KEY && myVoiceToken.isNotBlank())
        if (!canUseNeural) {
            // AION Live is an online-first natural-voice surface. Falling back silently to the
            // OEM speech engine makes the experience sound robotic and breaks the user's choice.
            // Keep the session alive and make the unavailable neural route explicit instead.
            releaseLiveLease(lease)
            state = AionLivePhase.ERROR
            return@LaunchedEffect
        }

        // Natural chunks keep first audio responsive and every chunk independently interruptible.
        // If neural playback fails, only the not-yet-spoken remainder moves to local TTS.
        val neuralChunks = SpeechText.splitNatural(cleanSpeech, 2_200)
        if (neuralChunks.isEmpty()) {
            releaseLiveLease(lease)
            state = VoiceTurnPolicy.passivePhase(muted)
            if (!muted && !latestSending) scheduleListen(120L)
            return@LaunchedEffect
        }

        try {
            for ((index, chunk) in neuralChunks.withIndex()) {
                if (!voicePlaybackArbiter.isCurrent(AionVoicePlaybackOwner.LIVE, lease)) return@LaunchedEffect
                val result = neuralVoicePlayer.speak(
                    endpoint = cloudEndpoint,
                    text = chunk,
                    profile = voiceSettings.profile.key,
                    voiceKey = voiceSettings.voiceKey,
                    speed = voiceSettings.speed,
                    expression = voiceSettings.expression,
                    clarity = voiceSettings.clarity,
                    myVoiceToken = if (voiceSettings.voiceKey == MyVoicePolicy.MY_VOICE_KEY) myVoiceToken else "",
                    onStarted = {
                        mainHandler.post {
                            if (
                                livePlaybackLease == lease &&
                                voicePlaybackArbiter.isCurrent(AionVoicePlaybackOwner.LIVE, lease)
                            ) {
                                state = AionLivePhase.SPEAKING
                            }
                        }
                    },
                    onLevel = { level ->
                        mainHandler.post {
                            if (
                                livePlaybackLease == lease &&
                                voicePlaybackArbiter.isCurrent(AionVoicePlaybackOwner.LIVE, lease) &&
                                state == AionLivePhase.SPEAKING
                            ) {
                                assistantLevel = VoiceAmplitude.smooth(assistantLevel, level)
                            }
                        }
                    }
                )

                when (result) {
                    NeuralVoicePlaybackResult.PLAYED -> Unit
                    NeuralVoicePlaybackResult.INTERRUPTED -> return@LaunchedEffect
                    NeuralVoicePlaybackResult.UNAVAILABLE,
                    NeuralVoicePlaybackResult.FAILED -> {
                        // Never replace a chosen neural voice with Android TTS during a live
                        // session. A clear unavailable state is better than an artificial voice.
                        if (voicePlaybackArbiter.isCurrent(AionVoicePlaybackOwner.LIVE, lease)) {
                            bargeInDetector.stop()
                            assistantLevel = 0f
                            state = AionLivePhase.ERROR
                            releaseLiveLease(lease)
                        }
                        return@LaunchedEffect
                    }
                }
            }
        } finally {
            if (voicePlaybackArbiter.isCurrent(AionVoicePlaybackOwner.LIVE, lease)) {
                bargeInDetector.stop()
                assistantLevel = 0f
                partialText = ""
                releaseLiveLease(lease)
                state = VoiceTurnPolicy.passivePhase(muted)
                if (!muted && !latestSending) scheduleListen(180L)
            } else {
                // Stale completion may release only its own token; never touch a newer owner.
                releaseLiveLease(lease)
            }
        }
    }


    val liveLevel = when (state) {
        AionLivePhase.LISTENING -> (rms / 12f).coerceIn(0f, 1f)
        AionLivePhase.SPEAKING -> assistantLevel.coerceIn(0f, 1f)
        else -> 0f
    }
    val requestedScale = 1f + (liveLevel * if (state == AionLivePhase.SPEAKING) 0.16f else 0.18f)
    val pulseScale by animateFloatAsState(
        targetValue = requestedScale,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium),
        label = "voice-reactive-scale"
    )
    val glowAlpha by animateFloatAsState(
        targetValue = 0.08f + (liveLevel * 0.22f),
        animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
        label = "voice-reactive-glow"
    )

    val status = AionLivePhasePolicy.statusLabel(state, muted)
    val helper = when {
        muted -> "الميكروفون مكتوم"
        state == AionLivePhase.SPEAKING -> if (bargeInDetector.isSupported()) {
            "يمكنك المقاطعة والتحدث في أي وقت"
        } else {
            "اضغط على الدائرة ثم تحدث"
        }
        state == AionLivePhase.LISTENING -> "تحدث بشكل طبيعي"
        AionLivePhasePolicy.isBusy(state) -> "أعمل على ردك…"
        state == AionLivePhase.ERROR -> "تعذر تشغيل الصوت. اضغط للمحاولة مجددًا"
        else -> ""
    }

    var dragOffsetPx by remember { mutableFloatStateOf(0f) }

    if (presentation == AionLivePresentation.MINIMIZED) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .navigationBarsPadding()
                .imePadding()
        ) {
            MiniAionLiveOrb(
                state = state,
                muted = muted,
                liveLevel = liveLevel,
                status = status,
                onRestore = {
                    AionHaptics.tap(hapticView)
                    onRestore()
                },
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(end = AionSpacing.Lg, bottom = 88.dp)
            )
        }
        return
    }

    Dialog(
        onDismissRequest = {
            // Back/dismiss minimizes the live session; only the explicit end control terminates it.
            onMinimize()
        },
        properties = DialogProperties(
            usePlatformDefaultWidth = false,
            dismissOnBackPress = true,
            dismissOnClickOutside = false
        )
    ) {
        Surface(
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer {
                    translationY = dragOffsetPx
                    val fraction = (dragOffsetPx / size.height.coerceAtLeast(1f)).coerceIn(0f, 0.22f)
                    alpha = 1f - fraction
                    scaleX = 1f - fraction * 0.35f
                    scaleY = 1f - fraction * 0.35f
                }
                .pointerInput(onMinimize) {
                    detectVerticalDragGestures(
                        onVerticalDrag = { change, amount ->
                            if (amount > 0f || dragOffsetPx > 0f) {
                                change.consume()
                                dragOffsetPx = (dragOffsetPx + amount).coerceIn(0f, size.height * 0.42f)
                            }
                        },
                        onDragEnd = {
                            if (dragOffsetPx >= 120.dp.toPx()) onMinimize()
                            dragOffsetPx = 0f
                        },
                        onDragCancel = { dragOffsetPx = 0f }
                    )
                },
            color = AionColors.Background
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .navigationBarsPadding()
                    .padding(horizontal = AionSpacing.Xxl, vertical = AionSpacing.Xl),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    androidx.compose.material3.IconButton(
                        onClick = {
                            stopAudio()
                            if (isSending) onStop()
                            onDismiss()
                        },
                        modifier = Modifier.size(AionSizes.TouchTarget)
                    ) {
                        Icon(Icons.Outlined.Close, contentDescription = "إنهاء AION Live")
                    }

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("AION", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.ExtraBold)
                        Text(
                            "المحادثة الصوتية",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    androidx.compose.material3.IconButton(
                        onClick = {
                            AionHaptics.tap(hapticView)
                            onMinimize()
                        },
                        modifier = Modifier.size(AionSizes.TouchTarget)
                    ) {
                        Icon(Icons.Outlined.KeyboardArrowDown, contentDescription = "تصغير AION Live")
                    }
                }

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    AionVoiceOrb(
                        state = state,
                        liveLevel = liveLevel,
                        pulseScale = pulseScale,
                        glowAlpha = glowAlpha,
                        onClick = {
                            when (state) {
                                AionLivePhase.SPEAKING -> interruptAssistantAndListen()
                                AionLivePhase.THINKING, AionLivePhase.READING_FILES,
                                AionLivePhase.SEARCHING, AionLivePhase.COMPARING, AionLivePhase.WRITING -> {
                                    onStop()
                                    if (!muted) scheduleListen(220L)
                                }
                                AionLivePhase.IDLE, AionLivePhase.ERROR, AionLivePhase.RECONNECTING, AionLivePhase.INITIALIZING -> {
                                    recognitionFailures = 0
                                    networkFailures = 0
                                    if (!muted) {
                                        state = AionLivePhase.LISTENING
                                        scheduleListen(50L)
                                    }
                                }
                                AionLivePhase.LISTENING -> Unit
                            }
                        }
                    )
                    Spacer(Modifier.height(AionSpacing.Xxl))
                    Text(
                        status,
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.SemiBold,
                        textAlign = TextAlign.Center
                    )
                    if (helper.isNotBlank()) {
                        Spacer(Modifier.height(AionSpacing.Sm))
                        Text(
                            helper,
                            modifier = Modifier.fillMaxWidth().padding(horizontal = AionSpacing.Md),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center
                        )
                    }
                    if (partialText.isNotBlank()) {
                        Spacer(Modifier.height(AionSpacing.Lg))
                        Surface(
                            shape = androidx.compose.foundation.shape.RoundedCornerShape(18.dp),
                            color = AionColors.SurfaceMuted
                        ) {
                            Text(
                                partialText,
                                modifier = Modifier.padding(horizontal = 18.dp, vertical = 12.dp),
                                style = MaterialTheme.typography.bodyLarge,
                                color = MaterialTheme.colorScheme.onSurface,
                                textAlign = TextAlign.Center,
                                maxLines = 4
                            )
                        }
                    }
                }

                // The orb is the primary live control (listen / interrupt / retry). Keep only
                // secondary actions here so this never resembles a phone-call keypad.
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(AionSpacing.Lg, Alignment.CenterHorizontally),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        onClick = onMinimize,
                        shape = androidx.compose.foundation.shape.RoundedCornerShape(27.dp),
                        color = AionColors.SurfaceRaised,
                        modifier = Modifier.width(132.dp).height(54.dp)
                    ) {
                        Row(horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Outlined.Keyboard, contentDescription = "العودة للكتابة")
                            Spacer(Modifier.width(8.dp))
                            Text("الكتابة", style = MaterialTheme.typography.labelLarge)
                        }
                    }

                    Surface(
                        onClick = {
                            muted = !muted
                            if (muted) {
                                rms = 0f
                                cancelRecognizerSilently()
                            } else if (!isSending && state != AionLivePhase.SPEAKING) {
                                recognitionFailures = 0
                                networkFailures = 0
                                state = AionLivePhase.LISTENING
                                scheduleListen(80L)
                            }
                        },
                        shape = androidx.compose.foundation.shape.RoundedCornerShape(27.dp),
                        color = if (muted) AionColors.SurfaceInteractive else AionColors.SurfaceRaised,
                        modifier = Modifier.width(132.dp).height(54.dp)
                    ) {
                        Row(horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                if (muted) Icons.Outlined.MicOff else Icons.Outlined.Mic,
                                contentDescription = if (muted) "تشغيل الميكروفون" else "كتم الميكروفون"
                            )
                            Spacer(Modifier.width(8.dp))
                            Text(if (muted) "تشغيل" else "كتم", style = MaterialTheme.typography.labelLarge)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun MiniAionLiveOrb(
    state: AionLivePhase,
    muted: Boolean,
    liveLevel: Float,
    status: String,
    onRestore: () -> Unit,
    modifier: Modifier = Modifier
) {
    val accent = activityAccent(state)
    val miniScale by animateFloatAsState(
        targetValue = if (state == AionLivePhase.LISTENING || state == AionLivePhase.SPEAKING) {
            1f + liveLevel * 0.08f
        } else {
            1f
        },
        animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
        label = "mini-live-scale"
    )

    Surface(
        onClick = onRestore,
        shape = CircleShape,
        color = AionColors.SurfaceRaised,
        border = BorderStroke(1.dp, accent.copy(alpha = 0.50f)),
        modifier = modifier
            .size(AionSizes.MiniLiveOrb)
            .scale(miniScale)
            .semantics {
                val accessibilityStatus = if (muted) "الميكروفون مكتوم" else status
                contentDescription = "AION Live: $accessibilityStatus. اضغط للعودة إلى شاشة الصوت"
            }
    ) {
        Box(contentAlignment = Alignment.Center) {
            if (muted) {
                Icon(
                    Icons.Outlined.MicOff,
                    contentDescription = null,
                    tint = AionColors.Error,
                    modifier = Modifier.size(20.dp)
                )
            } else {
                MiniVoiceBars(level = liveLevel, state = state)
            }
        }
    }
}

@Composable
private fun AionVoiceOrb(
    state: AionLivePhase,
    liveLevel: Float,
    pulseScale: Float,
    glowAlpha: Float,
    onClick: () -> Unit
) {
    val accent = activityAccent(state)
    Box(
        modifier = Modifier
            .size(212.dp)
            .scale(pulseScale)
            .background(accent.copy(alpha = glowAlpha), CircleShape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Surface(
            shape = CircleShape,
            color = AionColors.SurfaceRaised,
            border = BorderStroke(1.dp + (liveLevel * 1.2f).dp, accent.copy(alpha = 0.46f + liveLevel * 0.44f)),
            modifier = Modifier.size(142.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                VoiceBars(level = liveLevel, accent = accent, large = true)
            }
        }
    }
}

@Composable
private fun MiniVoiceBars(level: Float, state: AionLivePhase) {
    VoiceBars(level = level, accent = activityAccent(state), large = false)
}

@Composable
private fun VoiceBars(level: Float, accent: Color, large: Boolean) {
    val bases = listOf(0.50f, 0.90f, 0.66f, 1.00f, 0.58f)
    val minHeight = if (large) 14.dp else 7.dp
    val extra = if (large) 28.dp else 12.dp
    val width = if (large) 4.dp else 2.5.dp
    Row(
        horizontalArrangement = Arrangement.spacedBy(if (large) 5.dp else 3.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        bases.forEachIndexed { index, base ->
            val phaseBoost = when {
                level > 0.02f -> (level * base)
                index == 2 -> 0.16f
                else -> 0.06f
            }
            Box(
                Modifier
                    .width(width)
                    .height(minHeight + extra * phaseBoost)
                    .background(if (index == 2) accent else accent.copy(alpha = 0.72f), CircleShape)
            )
        }
    }
}

private fun activityAccent(state: AionLivePhase): Color = when {
    state == AionLivePhase.ERROR -> AionColors.Error
    AionLivePhasePolicy.usesExternalAccent(state) -> AionColors.External
    else -> AionColors.Intelligence
}

internal fun configureNaturalTts(engine: TextToSpeech, locale: Locale): Boolean {
    // كل خطوة اختيارية. بعض محركات TTS على أجهزة OEM لا تنفذ جميع الخصائص
    // القياسية بصورة سليمة؛ فشل تحسين واحد يجب ألا يغلق التطبيق أو المكالمة.
    val selectedLocale = runCatching {
        val available = engine.isLanguageAvailable(locale) >= TextToSpeech.LANG_AVAILABLE
        if (available) locale else Locale.forLanguageTag(locale.language.ifBlank { "ar" })
    }.getOrDefault(locale)

    val languageResult = runCatching { engine.setLanguage(selectedLocale) }
        .getOrDefault(TextToSpeech.LANG_NOT_SUPPORTED)

    runCatching {
        engine.setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ASSISTANT)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build()
        )
    }
    runCatching { engine.setSpeechRate(if (selectedLocale.language == "ar") 0.94f else 0.97f) }
    runCatching { engine.setPitch(1.0f) }

    runCatching {
        val bestVoice = engine.voices
            ?.asSequence()
            ?.filter { it.locale.language == selectedLocale.language }
            ?.maxByOrNull { voice ->
                (voice.quality * 100) - (voice.latency * 6) + if (voice.isNetworkConnectionRequired) 12 else 0
            }
        if (bestVoice != null) engine.voice = bestVoice
    }

    return languageResult != TextToSpeech.LANG_MISSING_DATA &&
        languageResult != TextToSpeech.LANG_NOT_SUPPORTED
}

private fun speechRecognizerSafeDestroy(recognizer: SpeechRecognizer?) {
    recognizer?.cancel()
    recognizer?.destroy()
}
