package com.aion.mobile.feature.chat

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.aion.mobile.core.ai.AionCloudSettings
import com.aion.mobile.core.ai.GatewayActivity
import com.aion.mobile.core.run.AionRunBus
import com.aion.mobile.core.run.AionRunCoordinator
import com.aion.mobile.core.run.AionRunSnapshot
import com.aion.mobile.core.storage.ChatSessionStore
import com.aion.mobile.model.ChatAttachment
import com.aion.mobile.model.ChatMessage
import com.aion.mobile.model.MessageRole
import kotlinx.coroutines.launch

data class AiModelOption(
    val key: String,
    val label: String,
    val provider: String,
    val enabled: Boolean,
    val modelId: String? = null,
    val badge: String? = null
)

class ChatViewModel(application: Application) : AndroidViewModel(application) {
    private val _messages = mutableStateListOf<ChatMessage>()
    val messages: SnapshotStateList<ChatMessage> = _messages

    private val _pendingAttachments = mutableStateListOf<ChatAttachment>()
    val pendingAttachments: SnapshotStateList<ChatAttachment> = _pendingAttachments

    private var nextId = 1L
    private var activeRunId: String? = null

    var cloudEndpoint by mutableStateOf(AionCloudSettings.loadEndpoint(application))
        private set
    var isSending by mutableStateOf(false)
        private set
    var selectedModelKey by mutableStateOf(ChatSessionStore.loadSelectedModel(application))
        private set
    var activity by mutableStateOf<GatewayActivity?>(null)
        private set
    var draft by mutableStateOf(ChatSessionStore.loadDraft(application))
        private set

    init {
        val restored = ChatSessionStore.loadMessages(application)
        val activeSnapshot = AionRunBus.snapshot.value
        _messages.addAll(
            if (activeSnapshot == null) {
                restored.map { message ->
                    if (message.isStreaming) message.copy(isStreaming = false, wasStopped = true) else message
                }
            } else restored
        )
        nextId = (_messages.maxOfOrNull { it.id } ?: 0L) + 1L

        activeSnapshot?.let { applyRunSnapshot(it) }

        viewModelScope.launch {
            AionRunBus.snapshot.collect { snapshot ->
                snapshot?.let { applyRunSnapshot(it) }
            }
        }
    }

    val isConfigured: Boolean get() = cloudEndpoint.isNotBlank()

    val modelOptions: List<AiModelOption>
        get() = listOf(
            AiModelOption(
                key = "auto",
                label = "AION Auto",
                provider = "اختيار AION الذكي",
                enabled = true,
                modelId = "@cf/meta/llama-3.1-8b-instruct",
                badge = "تلقائي"
            ),
            AiModelOption(
                key = "aion-free",
                label = "AION Free",
                provider = "Cloudflare Workers AI",
                enabled = true,
                modelId = "@cf/meta/llama-3.1-8b-instruct",
                badge = "مجاني"
            ),
            AiModelOption("claude", "Claude", "Anthropic", false, badge = "قريبًا"),
            AiModelOption("gemini", "Gemini", "Google", false, badge = "قريبًا"),
            AiModelOption("grok", "Grok", "xAI", false, badge = "قريبًا"),
            AiModelOption("deepseek", "DeepSeek", "DeepSeek", false, badge = "قريبًا")
        )

    val selectedModel: AiModelOption
        get() = modelOptions.firstOrNull { it.key == selectedModelKey } ?: modelOptions.first()

    fun selectModel(key: String) {
        val option = modelOptions.firstOrNull { it.key == key } ?: return
        if (option.enabled && !isSending) {
            selectedModelKey = option.key
            ChatSessionStore.saveSelectedModel(getApplication(), option.key)
        }
    }

    fun updateDraft(value: String) {
        draft = value
        ChatSessionStore.saveDraft(getApplication(), value)
    }

    fun saveSettings(endpoint: String) {
        AionCloudSettings.saveEndpoint(getApplication(), endpoint)
        cloudEndpoint = AionCloudSettings.loadEndpoint(getApplication())
    }

    fun addAttachments(items: List<ChatAttachment>) {
        if (isSending) return
        items.forEach { attachment ->
            if (_pendingAttachments.none { it.id == attachment.id }) {
                _pendingAttachments += attachment
            }
        }
    }

    fun removeAttachment(id: Long) {
        if (!isSending) _pendingAttachments.removeAll { it.id == id }
    }

    fun clearAttachments() {
        if (!isSending) _pendingAttachments.clear()
    }

    fun send(text: String) {
        val clean = text.trim()
        val attachments = _pendingAttachments.toList()
        if ((clean.isEmpty() && attachments.isEmpty()) || isSending) return

        val chosen = selectedModel
        val resolvedModel = chosen.modelId.orEmpty()
        val userMessage = ChatMessage(
            id = nextId++,
            role = MessageRole.USER,
            text = clean,
            modelId = resolvedModel,
            modelLabel = chosen.label,
            attachments = attachments
        )
        _messages += userMessage
        _pendingAttachments.clear()
        updateDraft("")

        if (!isConfigured) {
            _messages += ChatMessage(
                id = nextId++,
                role = MessageRole.AION,
                text = "اربط عنوان AION Cloud من الإعدادات أولًا، ثم أرسل الرسالة من جديد.",
                modelId = resolvedModel,
                modelLabel = chosen.label,
                isError = true
            )
            persistMessages()
            return
        }

        requestAssistantResponse(chosen = chosen, resolvedModel = resolvedModel)
    }

    fun stopGeneration() {
        AionRunCoordinator.stop(getApplication(), activeRunId)
    }

    fun retryLastResponse() {
        if (isSending || !isConfigured) return
        val lastUserIndex = _messages.indexOfLast { it.role == MessageRole.USER }
        if (lastUserIndex < 0) return

        while (_messages.size > lastUserIndex + 1) {
            _messages.removeAt(_messages.lastIndex)
        }

        val lastUser = _messages[lastUserIndex]
        val chosen = modelOptions.firstOrNull { it.label == lastUser.modelLabel }
            ?: modelOptions.firstOrNull { it.modelId == lastUser.modelId }
            ?: if (selectedModel.enabled) selectedModel else modelOptions.first()
        val resolvedModel = lastUser.modelId?.takeIf { it.isNotBlank() } ?: chosen.modelId.orEmpty()

        persistMessages()
        requestAssistantResponse(chosen = chosen, resolvedModel = resolvedModel)
    }

    fun newConversation() {
        if (!isSending) {
            _messages.clear()
            _pendingAttachments.clear()
            activity = null
            updateDraft("")
            ChatSessionStore.clearMessages(getApplication())
            AionRunBus.publish(null)
        }
    }

    private fun requestAssistantResponse(chosen: AiModelOption, resolvedModel: String) {
        val placeholderId = nextId++
        _messages += ChatMessage(
            id = placeholderId,
            role = MessageRole.AION,
            text = "",
            modelId = resolvedModel,
            modelLabel = chosen.label,
            isStreaming = true
        )
        isSending = true
        activity = GatewayActivity.THINKING

        val sessionMessages = _messages.filter { it.id != placeholderId }.toList()
        val requestMessages = sessionMessages
            .filter { !it.isError && !it.wasStopped }
            .map { message ->
                // المرفقات المستعادة بعد إعادة تشغيل التطبيق لا تحمل base64؛ لا نرسل عناصر فارغة للـAPI.
                if (message.attachments.any { it.base64Data.isBlank() }) {
                    message.copy(attachments = message.attachments.filter { it.base64Data.isNotBlank() })
                } else message
            }
            .toList()

        persistMessages()
        activeRunId = AionRunCoordinator.start(
            context = getApplication(),
            placeholderId = placeholderId,
            modelId = resolvedModel,
            modelLabel = chosen.label,
            messages = requestMessages,
            sessionMessages = sessionMessages,
            forceWebSearch = shouldForceWebSearch(requestMessages)
        )
    }

    private fun shouldForceWebSearch(messages: List<ChatMessage>): Boolean {
        val text = messages.lastOrNull { it.role == MessageRole.USER }?.text
            ?.lowercase()
            ?.replace("إ", "ا")
            ?.replace("أ", "ا")
            ?.replace("آ", "ا")
            .orEmpty()

        if (text.isBlank()) return false

        val explicitSearch = listOf(
            "ابحث", "بحث في الويب", "ابحث في الويب", "فتش في الويب",
            "دور في الويب", "دور بالويب", "من الانترنت", "من الإنترنت",
            "على الانترنت", "على الإنترنت", "مصادر حديثة", "اخر الاخبار",
            "آخر الأخبار", "احدث الاخبار", "أحدث الأخبار"
        ).any { phrase ->
            val normalized = phrase.lowercase()
                .replace("إ", "ا")
                .replace("أ", "ا")
                .replace("آ", "ا")
            text.contains(normalized)
        }

        return explicitSearch
    }

    private fun applyRunSnapshot(snapshot: AionRunSnapshot) {
        activeRunId = if (snapshot.isRunning) snapshot.runId else null
        isSending = snapshot.isRunning
        activity = if (snapshot.isRunning) snapshot.activity else null

        val index = _messages.indexOfFirst { it.id == snapshot.placeholderId }
        val updated = ChatMessage(
            id = snapshot.placeholderId,
            role = MessageRole.AION,
            text = snapshot.text,
            modelId = snapshot.modelId,
            modelLabel = snapshot.modelLabel,
            sources = snapshot.sources,
            isError = snapshot.errorText != null,
            isStreaming = snapshot.isRunning,
            wasStopped = snapshot.wasStopped
        )

        when {
            index >= 0 && snapshot.wasStopped && snapshot.text.isBlank() -> _messages.removeAt(index)
            index >= 0 -> _messages[index] = updated
            snapshot.text.isNotBlank() || snapshot.isRunning -> _messages += updated
        }

        if (!snapshot.isRunning) {
            persistMessages()
        }
    }

    private fun persistMessages() {
        ChatSessionStore.saveMessages(getApplication(), _messages)
    }
}
