package com.aion.mobile.core.agent

object AionMindPromptPolicy {
 fun guidance(request:String):String { val a=AionMindRegistry.assign(request); return buildString {
  val advanced=AionAdvancedMindRegistry.relevant(request)
  append("العقل القائد ينسق المهمة. ")
  if(AionMindRegistry.Mind.MEMORY in a.collaborators) append("استرجع الذكريات المرتبطة فقط. ")
  if(AionMindRegistry.Mind.RESEARCH in a.collaborators) append("تحقق من حداثة المصدر وتاريخه. ")
  if(AionMindRegistry.Mind.PLANNING in a.collaborators) append("حوّل النتيجة إلى خطوات قابلة للمتابعة. ")
  if(AionMindRegistry.Mind.LEARNING in a.collaborators) append("حوّل التصحيح إلى قاعدة قابلة للمراجعة ولا تكرر الخطأ. ")
  if(AionMindRegistry.Mind.PRODUCT in a.collaborators) append("حلل أثر التغيير على التطبيق والاختبارات قبل اقتراح التنفيذ. ")
  if(AionMindRegistry.Mind.QUALITY in a.collaborators) append("راجع أن الإجابة مكتملة ودقيقة ومفيدة. ")
  if(AionMindRegistry.Mind.SAFETY in a.collaborators) append("لا تكشف خصوصية ولا تنفذ إجراءً حساسًا بلا حماية. ")
  if(AionMindRegistry.Mind.MONITORING in a.collaborators) append("حدد ما الذي يجب متابعته وسبب أهميته دون إزعاج غير ضروري. ")
  if(advanced.isNotEmpty()) append("عقول مساندة مطلوبة: ").append(advanced.joinToString()).append(". ")
  append("عقل الحوار يجيب بالعربية بوضوح وبحسب طلب المستخدم.")
 }}
}
