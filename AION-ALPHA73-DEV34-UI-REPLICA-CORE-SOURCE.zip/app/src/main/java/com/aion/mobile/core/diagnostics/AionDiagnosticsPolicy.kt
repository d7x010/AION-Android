package com.aion.mobile.core.diagnostics

data class AionDiagnostic(val key:String,val healthy:Boolean,val label:String,val action:String)
object AionDiagnosticsPolicy {
 fun snapshot(configured:Boolean, memory:Boolean, attachments:Int, neuralVoice:Boolean)=listOf(
  AionDiagnostic("cloud",configured,"اتصال AION Cloud",if(configured) "جاهز للتحقق" else "افتح الإعدادات وأدخل العنوان الصحيح"),
  AionDiagnostic("memory",memory,"الذاكرة","فعّالة"),
  AionDiagnostic("attachments",true,"المرفقات",if(attachments>0) "$attachments جاهزة للإرسال" else "لا توجد مرفقات معلقة"),
  AionDiagnostic("voice",neuralVoice,"الصوت الطبيعي",if(neuralVoice) "جاهز" else "يحتاج خدمة صوت عصبي")
 )
}
