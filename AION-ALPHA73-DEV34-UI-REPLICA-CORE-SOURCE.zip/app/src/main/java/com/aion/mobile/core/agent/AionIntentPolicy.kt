package com.aion.mobile.core.agent

/** Local, explainable first pass; remote reasoning may refine it but never replaces safety routing. */
object AionIntentPolicy {
    enum class Intent { QUESTION, COMMAND, CORRECTION, CURRENT_EVENT, PLAN, UNKNOWN }
    fun classify(text: String): Intent = when {
        text.containsAny("صحح", "خطأ", "مو صحيح", "لا تسوي") -> Intent.CORRECTION
        text.containsAny("اليوم", "الآن", "اخر", "آخر", "سعر", "خبر") -> Intent.CURRENT_EVENT
        text.containsAny("خطط", "خطة", "مراحل", "التالي") -> Intent.PLAN
        text.containsAny("ابدأ", "اكمل", "أكمل", "سوي", "نفذ") -> Intent.COMMAND
        text.contains('?') || text.contains('؟') -> Intent.QUESTION
        else -> Intent.UNKNOWN
    }
    private fun String.containsAny(vararg values: String) = values.any { contains(it, true) }
}
