package com.aion.mobile.core.agent

/** Contracts the Android client will use once the always-on AION Core is deployed. */
object AionCoreContracts {
 const val RESEARCH_SCHEDULE = "research.schedule.v1"
 const val LEARNING_REVIEW = "learning.review.v1"
 const val HEALTH_MONITOR = "health.monitor.v1"
 const val RELEASE_CANDIDATE = "release.candidate.v1"
 val protectedOperations=setOf("release.publish","account.change","payment.change","data.delete")
}
