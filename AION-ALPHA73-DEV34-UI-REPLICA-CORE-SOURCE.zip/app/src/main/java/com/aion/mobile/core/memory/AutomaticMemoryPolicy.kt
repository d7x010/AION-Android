package com.aion.mobile.core.memory

/**
 * Small, deterministic first pass for continuity memory.
 *
 * It deliberately saves only clear, user-authored preferences/instructions/facts. It never
 * guesses from an assistant answer, and it rejects sensitive or volatile material. A model
 * based extractor can be added later, but this gives new conversations useful continuity now.
 */
object AutomaticMemoryPolicy {
    const val CONTRACT = 1
    private const val MAX_CANDIDATES = 8

    data class Candidate(
        val kind: MemoryKind,
        val text: String,
        val slot: String = "",
        val confidence: Float = 0.94f
    )

    fun extract(userText: String): List<Candidate> {
        val clean = MemoryEnginePolicy.normalizeText(userText)
        if (clean.length < 4 || isSensitive(clean)) return emptyList()
        // A normal information-seeking question should never turn into a permanent fact.
        // Explicit instructions such as "تذكر ..." remain eligible even when phrased as a question.
        if (clean.endsWith('?') || clean.endsWith('؟')) {
            if (!containsAny(clean, "تذكر", "احفظ", "لا تنس")) return emptyList()
        }

        val candidates = buildList {
            nameCandidate(clean)?.let(::add)
            languageCandidate(clean)?.let(::add)
            responseStyleCandidate(clean)?.let(::add)
            learningCandidate(clean)?.let(::add)
            preferenceCandidate(clean)?.let(::add)
            instructionCandidate(clean)?.let(::add)
            decisionCandidate(clean)?.let(::add)
            taskCandidate(clean)?.let(::add)
            relationshipCandidate(clean)?.let(::add)
            stableFactCandidate(clean)?.let(::add)
        }
        return candidates
            .distinctBy { "${it.kind}:${MemoryEnginePolicy.canonical(it.text)}" }
            .take(MAX_CANDIDATES)
    }

    private fun nameCandidate(text: String): Candidate? {
        val match = Regex("(?:^|[،,.]\\s*)(?:اسمي|أنا اسمي)\\s+([\\p{L}]{2,40})(?:\\s|$|[،,.])")
            .find(text) ?: return null
        val name = match.groupValues[1]
        return Candidate(MemoryKind.FACT, "اسم المستخدم $name", "profile.name", 0.99f)
    }

    private fun preferenceCandidate(text: String): Candidate? {
        if (!Regex("(?:احب|أحب|افضل|أفضل|ما احب|ما أحب|اكره|أكره)", RegexOption.IGNORE_CASE).containsMatchIn(text)) return null
        if (containsAny(text, "بالاختصار", "مختصر", "بالتفصيل", "تفصيلي", "بالعربية", "بالعربي")) return null
        return Candidate(MemoryKind.PREFERENCE, text.take(320), confidence = 0.94f)
    }

    private fun languageCandidate(text: String): Candidate? {
        val match = Regex("(?:لغتي|اللغة التي أحبها|اللغة المفضلة|أحب أتعلم)\\s+(?:هي\\s+)?([\\p{L}]{3,30})", RegexOption.IGNORE_CASE)
            .find(text) ?: return null
        return Candidate(MemoryKind.PREFERENCE, "اللغة المهمة للمستخدم ${match.groupValues[1]}", "profile.language", 0.95f)
    }

    private fun responseStyleCandidate(text: String): Candidate? {
        if (!containsAny(text, "بالاختصار", "مختصر", "بالتفصيل", "تفصيلي", "بالعربية", "بالعربي")) return null
        return Candidate(MemoryKind.PREFERENCE, text.take(320), "profile.response-style", 0.95f)
    }

    private fun instructionCandidate(text: String): Candidate? {
        if (!Regex("(?:اريدك|أريدك|دائما|دائمًا|لا تسوي|لا تفعل|جاوبني|أجبني)", RegexOption.IGNORE_CASE).containsMatchIn(text)) return null
        return Candidate(MemoryKind.INSTRUCTION, text.take(420), confidence = 0.96f)
    }

    /** User corrections are high-value training signals, but remain visible and reversible memory. */
    private fun learningCandidate(text: String): Candidate? {
        if (!containsAny(text, "صحح", "هذا خطأ", "مو صحيح", "لا تسوي", "لا تفعل", "تعلم من")) return null
        return Candidate(MemoryKind.INSTRUCTION, "قاعدة تحسين من المستخدم: ${text.take(360)}", confidence = 0.98f)
    }

    private fun decisionCandidate(text: String): Candidate? {
        if (!containsAny(text, "اعتمد", "اتفقنا", "قررنا", "خلاص", "بدون ", "بدل ", "نستخدم", "لا نستخدم")) return null
        return Candidate(MemoryKind.DECISION, text.take(420), confidence = 0.97f)
    }

    private fun taskCandidate(text: String): Candidate? {
        if (!containsAny(text, "ابدأ", "أكمل", "بعد ذلك", "الخطوة التالية", "لا تنس", "مهمة", "سوي ", "سوِ ")) return null
        return Candidate(MemoryKind.TASK, text.take(420), confidence = 0.91f)
    }

    private fun relationshipCandidate(text: String): Candidate? {
        if (!containsAny(text, "صديقي", "صديقتي", "أخي", "اخوي", "أختي", "اختي", "والدي", "والدتي", "أمي", "امي", "أبي", "ابوي")) return null
        return Candidate(MemoryKind.RELATIONSHIP, text.take(360), confidence = 0.88f)
    }

    private fun stableFactCandidate(text: String): Candidate? {
        if (!Regex("(?:عمري|طولي|لغتي|اشتغل|أعمل|ادرس|أدرس|عندي مشروع|لدي مشروع)", RegexOption.IGNORE_CASE).containsMatchIn(text)) return null
        return Candidate(MemoryKind.FACT, text.take(320), confidence = 0.90f)
    }

    private fun isSensitive(text: String): Boolean = Regex(
        "(?:كلمة المرور|رمز التحقق|بطاقة|رقم الحساب|cvv|otp|api[_ -]?key|مفتاح|عنواني|موقعي|رقم هاتفي|هاتف|مرض|دواء|تشخيص)",
        RegexOption.IGNORE_CASE
    ).containsMatchIn(text)

    private fun containsAny(text: String, vararg values: String): Boolean = values.any { text.contains(it, ignoreCase = true) }
}
