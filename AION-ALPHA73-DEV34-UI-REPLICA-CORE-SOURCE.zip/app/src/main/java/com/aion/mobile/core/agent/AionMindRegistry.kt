package com.aion.mobile.core.agent

/** Deterministic foundation for AION's coordinated specialist minds. */
object AionMindRegistry {
    enum class Mind { LEADER, DIALOGUE, MEMORY, RESEARCH, PLANNING, LEARNING, PRODUCT, QUALITY, SAFETY, MONITORING }
    data class Assignment(val lead: Mind, val collaborators: Set<Mind>, val requiresApproval: Boolean)

    fun assign(request: String): Assignment {
        val text = request.lowercase()
        val selected = linkedSetOf(Mind.LEADER, Mind.DIALOGUE, Mind.SAFETY)
        when (AionIntentPolicy.classify(request)) {
            AionIntentPolicy.Intent.CORRECTION -> selected += Mind.LEARNING
            AionIntentPolicy.Intent.CURRENT_EVENT -> selected += Mind.RESEARCH
            AionIntentPolicy.Intent.PLAN, AionIntentPolicy.Intent.COMMAND -> selected += Mind.PLANNING
            else -> Unit
        }
        if (text.containsAny("تذكر", "ذاكرة", "سابق")) selected += Mind.MEMORY
        if (text.containsAny("خطأ", "صحح", "مو صحيح", "تعلم", "لا تسوي")) selected += Mind.LEARNING
        if (text.containsAny("راقب", "دوري", "كل يوم", "تابع", "نبهني")) selected += Mind.MONITORING
        if (text.containsAny("ابحث", "خبر", "اليوم", "مصدر")) selected += Mind.RESEARCH
        if (text.containsAny("خطط", "مهمة", "التالي", "ابدأ", "اكمل")) selected += Mind.PLANNING
        if (text.containsAny("طور التطبيق", "كود", "apk", "خطأ")) selected += Mind.PRODUCT
        selected += Mind.QUALITY
        val sensitive = text.containsAny("انشر", "حذف", "ادفع", "كلمة المرور", "صلاحية", "حساب")
        return Assignment(selected.firstOrNull { it != Mind.LEADER && it != Mind.DIALOGUE && it != Mind.SAFETY } ?: Mind.DIALOGUE, selected, sensitive)
    }
    private fun String.containsAny(vararg keys: String) = keys.any(::contains)
}
