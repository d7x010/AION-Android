package com.aion.mobile.core.agent

/** Conservative contradiction detector: flags direct preference/decision reversals, never guesses facts. */
object AionContradictionPolicy {
    fun conflicts(previous: String, incoming: String): Boolean {
        val old = previous.normalized(); val next = incoming.normalized()
        val negationFlip = (old.contains("لا ") || old.contains("بدون ")) != (next.contains("لا ") || next.contains("بدون "))
        val sameTopic = old.split(' ').intersect(next.split(' ').toSet()).count { it.length > 2 } >= 2
        return negationFlip && sameTopic
    }
    private fun String.normalized() = lowercase().replace(Regex("\\s+"), " ").trim()
}
