package com.aion.mobile.core.agent

/** Roadmap-ready specialist minds; capabilities stay explicit until their backend is connected. */
object AionAdvancedMindRegistry {
 enum class Mind { INTENT, CONTRADICTION, TIME, SOURCES, MEDIA, RECOVERY, REAL_WORLD_TEST, RESOURCES, PREDICTION, KNOWLEDGE_HYGIENE, AUTONOMOUS_RELEASE }
 fun relevant(request:String):Set<Mind> = buildSet {
  val t=request.lowercase()
  if(t.containsAny("اليوم","اخر","آخر","خبر","سعر")) addAll(listOf(Mind.TIME,Mind.SOURCES))
  if(t.containsAny("صورة","فيديو","pdf","ملف","صوت")) add(Mind.MEDIA)
  if(t.containsAny("فشل","ما يشتغل","تعذر","خطأ")) add(Mind.RECOVERY)
  if(t.containsAny("طور","تحديث","apk","اختبر")) addAll(listOf(Mind.REAL_WORLD_TEST,Mind.AUTONOMOUS_RELEASE))
  if(t.containsAny("توقع","لاحق","المستقبل")) add(Mind.PREDICTION)
 }
 private fun String.containsAny(vararg k:String)=k.any{contains(it,true)}
}
