package com.aion.mobile.core.memory

enum class MemoryScope { USER, PROJECT, CONVERSATION }
/**
 * The kind is deliberately stored with the memory instead of inferred at retrieval time.
 * This makes important promises and unfinished work survive a very large history.
 */
enum class MemoryKind { FACT, PREFERENCE, DECISION, INSTRUCTION, TASK, RELATIONSHIP, NOTE }
enum class MemorySource { USER_SETTINGS, PROJECT_NOTES, EXPLICIT, AUTOMATIC }

data class AionMemoryEntry(
    val id: String,
    val scope: MemoryScope,
    val ownerId: String = "",
    val kind: MemoryKind = MemoryKind.NOTE,
    val text: String,
    val slot: String = "",
    val source: MemorySource,
    val confidence: Float = 1f,
    val createdAt: Long,
    val updatedAt: Long,
    val expiresAt: Long = 0L,
    val active: Boolean = true
)

data class AionMemoryContext(
    val contract: Int = MemoryEnginePolicy.CONTRACT,
    val retrievalContract: Int = MemoryEnginePolicy.RETRIEVAL_CONTRACT,
    val retrievalPolicy: String = MemoryEnginePolicy.RETRIEVAL_POLICY,
    val text: String = "",
    val entryCount: Int = 0,
    val candidateCount: Int = 0,
    val matchedCount: Int = 0,
    val scopes: Set<MemoryScope> = emptySet(),
    val truncated: Boolean = false
)
