package com.aion.mobile.core.agent
import org.junit.Assert.assertEquals
import org.junit.Test
class AionIntentPolicyTest {
 @Test fun currentInformationIsNeverTreatedAsTimeless(){assertEquals(AionIntentPolicy.Intent.CURRENT_EVENT,AionIntentPolicy.classify("ما آخر خبر اليوم؟"))}
}
