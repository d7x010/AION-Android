package com.aion.mobile.core.agent
import org.junit.Assert.assertTrue
import org.junit.Test
class AionMindRegistryTest {
 @Test fun routesResearchWithoutBypassingSafety() { val a=AionMindRegistry.assign("ابحث عن خبر اليوم"); assertTrue(AionMindRegistry.Mind.RESEARCH in a.collaborators); assertTrue(AionMindRegistry.Mind.SAFETY in a.collaborators) }
 @Test fun routesCorrectionsAndRecurringWork() { val a=AionMindRegistry.assign("صحح هذا الخطأ وراقب الأمر كل يوم"); assertTrue(AionMindRegistry.Mind.LEARNING in a.collaborators); assertTrue(AionMindRegistry.Mind.MONITORING in a.collaborators) }
 @Test fun blocksSensitiveAutonomy() { assertTrue(AionMindRegistry.assign("انشر التحديث على كل الحسابات").requiresApproval) }
}
