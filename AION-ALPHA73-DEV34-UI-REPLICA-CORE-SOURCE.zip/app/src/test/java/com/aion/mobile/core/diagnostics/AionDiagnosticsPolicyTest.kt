package com.aion.mobile.core.diagnostics
import org.junit.Assert.assertTrue
import org.junit.Test
class AionDiagnosticsPolicyTest {
 @Test fun exposesConcreteRepairForMissingCloud(){val cloud=AionDiagnosticsPolicy.snapshot(false,true,0,false).first();assertTrue(!cloud.healthy);assertTrue(cloud.action.contains("الإعدادات"))}
}
