package com.aion.mobile.core.context

import com.aion.mobile.model.ChatMessage
import com.aion.mobile.model.MessageRole
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class AionContextEngineTest {

    @Test
    fun `continuity snapshot keeps literal goal decisions and open questions`() {
        val turns = listOf(
            msg(1, MessageRole.USER, "أريد أن يكون التطبيق عربياً بالكامل."),
            msg(2, MessageRole.AION, "تم."),
            msg(3, MessageRole.USER, "اعتمد الذاكرة للمشاريع أيضاً."),
            msg(4, MessageRole.USER, "ما الخطوة التالية؟")
        )

        val snapshot = AionContextEngine.continuitySnapshot(turns)

        assertEquals("ما الخطوة التالية؟", snapshot.currentGoal)
        assertTrue(snapshot.decisions.any { it.contains("الذاكرة للمشاريع") })
        assertEquals(listOf("ما الخطوة التالية؟"), snapshot.openItems)
    }
    private fun msg(id: Long, role: MessageRole, text: String) = ChatMessage(id = id, role = role, text = text)

    @Test fun longConversationKeepsRecentTailAndBuildsExtractiveDigest() {
        val messages = (1L..140L).map { id ->
            val role = if (id % 2L == 0L) MessageRole.AION else MessageRole.USER
            val marker = if (id == 25L) "قرار مهم: لا تغير اسم المشروع" else "رسالة $id"
            msg(id, role, "$marker ${"x".repeat(1200)}")
        }
        val result = AionContextEngine.build(messages)
        assertTrue(result.messages.size <= AionContextEngine.MAX_CONTEXT_MESSAGES)
        assertEquals(140L, result.messages.last().id)
        assertTrue(result.omittedMessageCount > 0)
        assertTrue(result.supplementalContext.contains("قرار مهم"))
        assertTrue(result.supplementalContext.contains("مقتطفات حرفية"))
        assertTrue(result.estimatedInputTokens > 0)
    }

    @Test fun shortConversationDoesNotInventDigest() {
        val messages = listOf(
            msg(1, MessageRole.USER, "مرحبا"),
            msg(2, MessageRole.AION, "أهلا")
        )
        val result = AionContextEngine.build(messages)
        assertEquals(2, result.messages.size)
        assertEquals(0, result.omittedMessageCount)
        assertFalse(result.supplementalContext.contains("مقتطفات حرفية"))
    }

    @Test fun projectContextIsSeparatedFromMemoryAndBounded() {
        val result = AionContextEngine.build(
            messages = listOf(msg(1, MessageRole.USER, "كمل المشروع")),
            memoryContext = "ذاكرة شخصية",
            relatedProjectContext = "سياق مشروع ".repeat(2_000)
        )
        assertTrue(result.supplementalContext.contains("سياق حديث من محادثات أخرى"))
        assertTrue(result.supplementalContext.length <= AionContextEngine.MAX_SUPPLEMENTAL_CHARS)
        assertTrue(result.truncated)
    }

    @Test fun arabicTokenEstimateIsConservative() {
        val arabic = AionContextEngine.estimateTokens("هذا نص عربي طويل نسبيًا")
        val latin = AionContextEngine.estimateTokens("this is a similarly sized text")
        assertTrue(arabic > 0)
        assertTrue(latin > 0)
    }
}
