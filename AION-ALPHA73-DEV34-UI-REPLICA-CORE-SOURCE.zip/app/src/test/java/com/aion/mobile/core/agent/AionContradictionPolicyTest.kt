package com.aion.mobile.core.agent
import org.junit.Assert.assertTrue
import org.junit.Test
class AionContradictionPolicyTest { @Test fun findsDirectDecisionReversal(){assertTrue(AionContradictionPolicy.conflicts("استخدم البحث في الويب", "لا تستخدم البحث في الويب"))} }
