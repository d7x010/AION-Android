# 2.0.0-alpha7.3-dev15 / code29 — Step 6.6 Cross‑Model Context Compatibility

- أضيف provider-neutral conversation normalizer داخل AION Cloud.
- توحيد تحويل history بين Claude/Gemini/Grok مع دمج same-role turns.
- Gemini يحصل على alternating user/model history، بينما Claude/xAI يحتفظان user/assistant.
- حماية من leading orphan assistant وrequire-user-last.
- status context contract=1.
- لا تغيير على pinned external routing أو cross-provider failover=false.

## α7.3 — Step 6.5 Provider Routing & Failover / dev14 (2026-09-10)
- رفع Android إلى `2.0.0-alpha7.3-dev14 / versionCode 28`.
- فصل selection عن execution provenance.
- منع cross-provider fallback الصامت للمزودات الخارجية.
- حصر fallback المدمج في Workers AI وقبل أول token.
- إضافة routing metadata إلى sync وSSE done وحفظها محليًا وعرضها أسفل الرد.
- إضافة اختبارات fallback/continuity/pinned-provider.

## α7.3 — Step 6.4 Grok Execution / dev13 (2026-09-10)
- رفع Android إلى `2.0.0-alpha7.3-dev13 / versionCode 27`.
- تفعيل Grok فعليًا عبر xAI Responses API من AION Cloud عند وجود `XAI_API_KEY` و`AION_GROK_MODEL`.
- دعم Sync وSSE Streaming وVision لـJPEG/PNG مع `store=false`.
- بحث Grok يستخدم Firecrawl فقط في هذه النقطة، ولا fallback صامت إلى مزود مختلف.
- إضافة اختبارات Grok Sync/Streaming/Vision/Search وحماية الأسرار.

## α7.3 — Step 6.2 Claude Execution / dev11 (2026-09-10)
- رفع Android إلى `2.0.0-alpha7.3-dev11 / versionCode 25`.
- تفعيل Claude فعليًا عبر Anthropic Messages API من AION Cloud عند وجود `ANTHROPIC_API_KEY` و`AION_CLAUDE_MODEL`.
- دعم Sync وSSE Streaming الحقيقي لـClaude بدون المرور عبر Workers AI.
- تحويل system prompt وسياق AION إلى صيغة Anthropic الصحيحة، ودعم صور JPEG/PNG/GIF/WebP كـbase64 image blocks.
- إبقاء model ID ديناميكيًا على الخادم وعدم وضع API key داخل APK أو status response.
- منع fallback الصامت إلى مزود آخر إذا اختار المستخدم Claude.
- بحث Claude الحي يستخدم Firecrawl في 6.2؛ عند غيابه يعاد خطأ واضح بدل استخدام Workers AI Web Search ضمنيًا.
- Gemini/Grok يبقيان Foundation وغير جاهزين للتنفيذ.
- إضافة اختبارات Worker لمسار Claude Sync/Streaming/Vision/Search وحماية الأسرار.


## α7.3 — Step 6.1 Multi‑Provider Core / dev10 (2026-09-10)
- رفع Android إلى `2.0.0-alpha7.3-dev10 / versionCode 24`.
- إضافة Model/Provider Catalog خادمي بعقد versioned (`contract=1`) لـClaude/Gemini/Grok.
- فصل `configured` عن `chatReady` حتى لا يظهر مزود كجاهز لمجرد وجود API key.
- model IDs تُضبط خادميًا ولا تثبت داخل APK.
- إضافة `ModelCatalogPolicy` في Android للتحقق من keys/model IDs والرجوع الآمن إلى AION Auto.
- Model Picker يدمج الخيارات الخارجية القادمة من AION Cloud، وتبقى Disabled ما لم يعلن الخادم `chatReady=true`.
- رفض `mode=claude|gemini|grok` بـHTTP 409 في Foundation بدل fallback صامت إلى AION Auto.
- `/v1/status` لا يعرض API keys أو secrets، مع اختبارات صريحة لمنع التسريب.
- إضافة Worker regression لاختبار provider catalog وحظر inference الخارجي قبل الجاهزية.
- لا يتضمن dev10 استدعاء Anthropic أو Gemini فعليًا؛ ذلك يبدأ في Step 6.2/6.3.

# AION α7.3 dev7 — STEP5 / Point 2 Voice Selection + Preview + Tuning

- إضافة اختيار أصوات Neural Voice من Catalog الخادم الحقيقي مع وسم ذكر/أنثى/محايد ودون خيارات وهمية.
- إضافة Preview حقيقي للصوت المختار من داخل الإعدادات بنفس إعدادات التشغيل الفعلية.
- حفظ voice key وprofile وspeed/expression/clarity محليًا وربطها بـAION Live وRead Aloud.
- إضافة Presets هادئ/متوازن/تعبيري مع Sliders مستقلة للسرعة والتعبير والوضوح.
- الحفاظ على اختيار المستخدم عند تعطل Voice Catalog مؤقتًا وحل الصوت الفعلي عبر `VoiceSelectionPolicy`.
- تطبيق سرعة المستخدم على Android TTS عند fallback، وإيقاف Preview عند أي تغيير أو إغلاق الإعدادات.
- إضافة اختبارات `AionVoiceSettingsTest` و`VoiceSelectionPolicyTest`.
- versionCode 21 / versionName 2.0.0-alpha7.3-dev7.

# AION α7.3 dev6 — STEP5 / Point 1 Neural Voice Core

- تأسيس Voice Catalog خادمي حتى 12 صوتًا مع بقاء Voice IDs ومفاتيح المزود خارج APK وخارج `/v1/status`.
- دعم `AION_VOICES_JSON` مع توافق خلفي لـ`AION_VOICE_ID` واختيار `AION_DEFAULT_VOICE_KEY` عند توفره.
- `/v1/voice/tts` يقبل voice/profile وضبط speed/expression/clarity ضمن حدود خادمية آمنة.
- إضافة `NeuralVoiceContract` على Android لتوحيد التحقق من PCM وقواعد fallback وتطبيع voice/profile/tuning.
- توسيع fallback إلى 404/408/429/5xx بدل ترك المستخدم في صمت عند الأعطال المؤقتة.
- لا تنتقل حالة AION إلى SPEAKING قبل وصول أول PCM فعلي من الخادم.
- إضافة اختبارات Worker وAndroid للنواة الجديدة مع الحفاظ على سلوك AION Live المعتمد في Step 4.
- versionCode 20 / versionName 2.0.0-alpha7.3-dev6.

# α7.3-dev5 — Step 4 / AION Live

- توحيد Live phase state وربطه بحالات Gateway الحقيقية.
- Fullscreen -> Mini Orb بدون إنهاء الصوت، مع حفظ phase/mute/conversationId.
- Typed interruption: إرسال النص يوقف صوت AION الجاري فقط ويبقي نفس الجلسة.
- Voice barge-in اختياري وآمن باستخدام AudioRecord + AcousticEchoCanceler + NoiseSuppressor عند توفرها.
- إضافة Android audio focus + MODE_IN_COMMUNICATION مع استعادة وضع الصوت عند نهاية Live.
- حماية سياق Live من القفز إلى محادثة/Project آخر أو حذف/نقل المحادثة الحية.
- إصلاح حالات بقاء SPEAKING بعد انتهاء الصوت عندما يكون الميكروفون مكتومًا.
- منع إعادة تشغيل recognizer أثناء THINKING/SEARCHING/WRITING بسبب callbacks متأخرة.
- versionCode 19 / versionName 2.0.0-alpha7.3-dev5.

# AION α7.3 dev4 — Attachments + Rendering + Sources

- إغلاق الخطوة 3: المرفقات والصور وPDF وMarkdown وCode Blocks والجداول والمصادر.
- PDF page count حقيقي على IO + FileProvider آمن لفتح النسخ الداخلية.
- Fullscreen image viewer مع pinch/double-tap zoom وتصحيح EXIF orientation.
- دعم HEIC/HEIF وإصلاح اتجاه الصور الكبيرة قبل إعادة ترميزها.
- MarkdownRenderPolicy قابل للاختبار، مع Streaming code fences مستقرة وطي الكود الطويل.
- Markdown links وcitations [n] قابلة للفتح عند وجود مصدر مطابق.
- Source snippets من Worker محفوظة ومقدمة داخل Sources Sheet.
- تنظيف المرفقات المؤقتة/المرفوضة لمنع تراكم الملفات اليتيمة.
- versionCode 18 / versionName 2.0.0-alpha7.3-dev4.

# AION α7.3 dev3 — Drawer + Search + Projects

- بحث محلي غير حاجب مع debounce ونتائج على مستوى الرسالة.
- الانتقال من نتيجة البحث إلى الرسالة نفسها مع Highlight مؤقت.
- تطبيع بحث عربي أفضل.
- Project Workspace Sheet حقيقي للمحادثات والتعليمات والذاكرة.
- ترتيب المشاريع بحسب آخر نشاط، مع تقليل ازدحام الدرج.
- versionCode 17 / versionName 2.0.0-alpha7.3-dev3.

# AION 2.0.0-alpha7.3-dev2 — Chat Shell

- إغلاق الخطوة 1 من α7.3: Top Bar، Composer، الرسائل، Activity System، Auto-follow، وDesign Tokens الخاصة بالـChat Shell.
- إصلاح تتبع نهاية الردود الطويلة عبر Bottom Anchor.
- فصل Dictation عن AION Live وتثبيت Send/Stop dynamic slot.
- تحسين Contrast للـContext Chips وإظهار cursor واضح.
- إصلاح أخطاء source-level في واجهة α7.3 التجريبية قبل الانتقال للخطوة 2.

# AION α7.2.1 — Hotfix Runtime

- إصلاح crash محتمل بعد التحديث فوق α7.1 دون مسح بيانات المستخدم.
- نقل إعادة بناء فهرس البحث القديم إلى IO بعد ظهور الواجهة بدل تنفيذها أثناء الإقلاع.
- قراءة متسامحة لقيم SharedPreferences القديمة.
- حماية تهيئة TTS المتقدمة من استثناءات محركات OEM.
- تطبيع IDs القديمة ومنع duplicate keys في Compose.
- إضافة مسار Startup Recovery وتشخيص محلي عند الحاجة.

## α7.2 — الخطوة 6: بوابة الإصدار النهائية
- مراجعة شجرة المصدر كاملة والتأكد من versionCode 13 / `2.0.0-alpha7.2`.
- فحص XML للـManifest والثيمات والموارد: PASS محليًا.
- فحص JavaScript syntax للـWorker: PASS محليًا.
- تشغيل Worker regression suite: `AION worker tests: PASS`.
- تشغيل Kotlin core smoke لسياسات السياق/المشاريع/Streaming/الصوت: PASS.
- فحص حزمة المصدر بحثًا عن مفاتيح API حقيقية: لم تُكتشف أسرار تطبيقية ضمن الملفات النصية.
- تحديث README ليطابق التوجيه الفعلي للنماذج وProjects وVision في α7.2.
- بوابة Android الكاملة (Unit + Lint + assembleDebug) تبقى شرط الاعتماد النهائي عبر GitHub Actions بعد رفع الأرشيف.


## α7.2 — الخطوة 1: ثبات السياق وذاكرة المشاريع
- إضافة مرساة سياق تحفظ بداية المهمة مع أحدث الرسائل في المحادثات الطويلة بدل فقدان الهدف الأصلي بالكامل.
- ذاكرة مستقلة لكل Project مع توجيه زر «تذكّر» تلقائيًا إلى ذاكرة المشروع عند تفعيل «ذاكرة خاصة بالمشروع».
- إدخال سياق مختصر من أحدث المحادثات الأخرى التابعة للمشروع عند الطلب الحالي.
- تخفيف الحفظ أثناء Streaming عبر checkpoint ذري خفيف بدل إعادة بناء فهرس المحادثات باستمرار.
- ترقية تخزين المشاريع من SharedPreferences إلى ملف JSON ذري AtomicFile مع ترحيل تلقائي للبيانات القديمة ومسار fallback إذا تعذر filesDir.
- فحص بنيوي لملفات Kotlin المتأثرة، واختبارات Worker ما زالت PASS.

## α7.2 — 2026-09-09
- إضافة Projects محلية فعلية: محادثات مرتبطة بالمشروع، تعليمات مشروع، سياق بين محادثاته، وخيار ذاكرة خاصة بالمشروع.
- رفع حد سجل المحادثات المحلي إلى 120 وإضافة Pin وArchive/Restore وMove-to-Project وShare.
- إضافة Search Index داخل محتوى الرسائل وأسماء المرفقات مع ترقية تلقائية لسجلات α7.1 القديمة.
- تحسين بحث السجل للعربية عبر إزالة التشكيل وتوحيد أشكال الألف/الياء/التاء المربوطة، وإدخال اسم المشروع في البحث.
- توسيع Markdown rendering: headings، قوائم، اقتباسات، فواصل، bold، inline code، fenced code، وتحديد نص الرد.
- اعتماد Qwen 3.8 27B كمحرك General/Auto مع fallback؛ إبقاء GLM للسريع وGPT-OSS-120B للعميق وGemma 4 كاحتياط Vision/Research.
- تحسين Auto routing للطلبات الطويلة/التحليلية/البرمجية ومراجعة المستندات.
- تمرير conversationId كـx-session-affinity إلى Workers AI للاستفادة من Prompt/Prefix Caching.
- تحسين التقاط citations/annotations من بحث Workers AI المدمج وإرسالها كتحديث Sources أثناء Streaming.
- ضغط الصور الكبيرة على Android: downsample + حد أبعاد 2048px + JPEG quality تدريجي، مع إبقاء الصور الصغيرة دون إعادة ترميز غير ضرورية.
- رفع حدود التعليمات/الذاكرة إلى 10k/16k عبر Android وWorker.
- تحسين Voice turn-by-turn: فترات صمت أطول قليلًا، retry لأخطاء recognizer المؤقتة، وإبقاء الحركة مرتبطة بـRMS الحقيقي.
- تحديث Android إلى versionCode 13 / `2.0.0-alpha7.2`.
- اختبارات Worker بعد التغييرات: PASS؛ Android الكامل ينتظر بوابة GitHub Actions قبل الاعتماد.


## α7.1 — 2026-09-09
- إصلاح Connection reset عبر fallback تلقائي من SSE إلى الطلب المتزامن.
- تفعيل بحث Workers AI المدمج عندما لا يكون Firecrawl معدًا.
- تحويل الصور إلى Vision native structured content وتوجيهها إلى Gemma 4.
- تحديث Android إلى versionCode 12 / alpha7.1.
- إضافة اختبارات routing للرؤية والبحث المدمج.


## α6.1.1 — إصلاح الاستقرار بعد اختبار الهاتف
- إصلاح حالة رجوع النموذج برد فارغ: يتم الآن الانتقال تلقائيًا إلى النموذج الاحتياطي حتى لو كان الطلب ناجحًا تقنيًا لكن بلا نص.
- منع قبول الردود المبتورة الناتجة عن انقطاع Streaming؛ مسار البث أصبح يبث جوابًا مُتحققًا منه على دفعات.
- جعل AION Auto يرفع الطلب تلقائيًا إلى Deep عند وجود إشارات واضحة مثل «تحليل عميق» و«فلسفي».
- زيادة ميزانية الإكمال للطلبات العميقة والبحثية.
- توضيح أن البحث الحي يحتاج FIRECRAWL_API_KEY على الخادم؛ لم يعد النظام يدّعي أن Firecrawl يعمل بلا مفتاح.

# سجل تغييرات AION Mobile V2 α4

## الهوية والتصميم
- تحويل اللون الأساسي للهوية إلى البنفسجي القوي، مع الأزرق كلون ثانوي خفيف فقط.
- إعادة تصميم أيقونة التطبيق الخارجية بهوية AION البنفسجية.
- تبسيط الشاشة الرئيسية وإزالة الشرح والبطاقات الكبيرة لصالح واجهة أكثر نضجًا.
- شعار AION مصغر ومتكرر في الواجهة بدل دائرة A البيضاء القديمة.
- القائمة اليسرى أصبحت مخفية افتراضيًا وتفتح من زر القائمة.
- إضافة لوحة سياق مخفية تفتح عند الحاجة بدل إبقائها على الشاشة.

## الدردشة
- اختيار النموذج أصبح من داخل صندوق الدردشة نفسه.
- يمكن تغيير النموذج لكل رسالة مع بقاء الرسائل في نفس المحادثة والسياق.
- إظهار اسم النموذج الذي أجاب فوق كل رد.
- إضافة AION Auto كنمط افتراضي.
- إضافة واجهة جاهزة لربط Claude وGemini وGrok وDeepSeek لاحقًا دون تغيير تصميم الدردشة.
- إضافة نسخ الرد بنقرة واحدة.
- تمرير تلقائي إلى آخر رسالة.
- تحسين شكل رسائل المستخدم وردود AION والأخطاء.

## استقرار الرسائل
- الحفاظ على إصلاح Responses API لرسائل المساعد باستخدام output_text.
- عدم إرسال رسائل الأخطاء المحلية إلى النموذج ضمن سجل المحادثة، حتى لا تفسد السياق التالي.
- رسائل أوضح لأخطاء 400 و401 و404 و429.
- إبقاء web_search متاحًا عبر OpenAI Responses API.

## الإعدادات
- إعدادات النموذج أصبحت تحدد نموذج AION Auto الافتراضي فقط.
- التبديل الفعلي للنموذج يتم من داخل المحادثة.

## الإصدار
- versionCode: 4
- versionName: 2.0.0-alpha4

## التوقيع أثناء التطوير
- إضافة مفتاح Debug ثابت خاص بتطوير AION حتى لا يتغير توقيع APK في كل تشغيل GitHub Actions.
- بعد تثبيت α4 مرة واحدة، يفترض أن تُثبت تحديثات Debug التالية فوقها مباشرة ما دام هذا المفتاح نفسه مستخدمًا.
- هذا المفتاح للتطوير فقط وليس توقيع Release أو متجر.

---

# α5 — Living Chat Foundation

## المحادثة الحية
- تحويل الاتصال إلى Streaming عبر Responses API.
- النص يظهر تدريجيًا بدل الوصول دفعة واحدة.
- إضافة زر إيقاف الرد أثناء التوليد.
- إضافة إعادة المحاولة.
- إزالة اسم النموذج الدائم من أعلى كل جواب؛ يظهر فقط كحالة تشغيل مؤقتة قبل بداية النص ثم يختفي.
- إضافة حالة AION متحركة بنبض ونقاط حية.
- حالة "يبحث في الويب" لا تظهر إلا عند وصول حدث بحث فعلي من API.

## أسلوب الرد
- تعليمات جديدة تجعل طول الرد متكيفًا مع النية.
- تقليل المقدمات الفارغة، تكرار السؤال، والمدح غير الضروري.
- فصل أفضل بين الحقيقة والرأي والافتراض عند الحاجة.

## Composer
- إعادة بناء صندوق الكتابة ليكون أقصر وأقرب إلى تطبيق ناضج.
- النموذج يظهر كشريحة صغيرة فوق صندوق الكتابة.
- إلغاء النص التطويري الدائم أسفل Composer.
- زر + يفتح Bottom Sheet للمرفقات بدل تشتيت الواجهة بأزرار كثيرة.
- الميكروفون يتحول إلى إرسال عند وجود نص أو مرفقات، وإلى إيقاف أثناء التوليد.

## الملفات والصور
- رفع الصور فعليًا وتحويلها إلى input_image في Responses API.
- رفع الملفات فعليًا وتحويلها إلى input_file.
- Preview على شكل شرائح للمرفقات قبل الإرسال.
- إزالة المرفق قبل الإرسال.
- حد تطويري 12 MB لكل عنصر و6 عناصر لكل رسالة لتقليل ضغط الذاكرة على الهاتف.

## الصوت
- تشغيل الإملاء الصوتي الفعلي عبر Android SpeechRecognizer.
- نتائج جزئية تظهر أثناء الكلام.
- حركة الميكروفون تستجيب لشدة الصوت.
- قراءة رد AION صوتيًا عبر TextToSpeech من أدوات الرد.
- المحادثة الصوتية Realtime الكاملة مؤجلة لمرحلة لاحقة.

## البحث والمصادر
- عرض المصادر كبطاقة "المصادر N" بدل إلحاق روابط خام داخل النص.
- فتح Bottom Sheet مرتب للمصادر.

## التصميم
- تقليل ازدحام أعلى الشاشة والقائمة الجانبية.
- مركزية اسم AION في Top Bar.
- الأدوات الثانوية أصبحت تظهر عند الحاجة فقط.
- البنفسجي هو الهوية الرئيسية؛ الأزرق ثانوي.
- تحديث أيقونة التطبيق لتقليل الأزرق وإبراز النواة البنفسجية.
- ضبط Typography ومسافات القراءة للعربية.

## الإصدار
- versionCode: 5
- versionName: 2.0.0-alpha5

## α5.1 — الثبات والحضور
- إصلاح P0 لمساحة لوحة المفاتيح: إزالة تطبيق IME inset المزدوج واعتماد `adjustResize` مع padding سفلي محدود للـnavigation bar فقط.
- فصل تشغيل الرد عن `ViewModel` ونقله إلى Foreground Service حتى يستمر الرد/البحث عند الخروج من الشاشة أو الانتقال لتطبيق آخر.
- إضافة إشعار حي أثناء العمل وحالة مختصرة: يفهم طلبك / يبحث في الويب / يصيغ الإجابة.
- إضافة إشعار عند اكتمال الرد خارج التطبيق، مع فتح المحادثة بالنقر عليه.
- حفظ المحادثة الحالية محليًا واستعادتها بعد إعادة إنشاء الواجهة.
- حفظ مسودة الكتابة تلقائيًا واستعادتها عند الرجوع.
- حفظ اختيار النموذج الحالي.
- تحسين سلوك التمرير: لا يسحب المستخدم للأسفل بالقوة إذا صعد لقراءة رسائل قديمة، ويظهر زر «آخر رد» للرجوع.
- اسم النموذج لم يعد جزءًا ثابتًا من حالة التفكير؛ الحالة الحية تظهر باسم AION فقط.
- إضافة صلاحيات Android اللازمة للإشعارات وForeground Service من نوع dataSync.

ملاحظة معمارية: α5.1 يستخدم Foreground Service لاستمرار المهمة على الجهاز. قبل إصدار المتجر العام، المهام السحابية طويلة العمر ستنتقل إلى AION Backend حتى تظل قادرة على الاكتمال حتى لو قتل النظام عملية التطبيق بالكامل.


## α5.2 — إصلاحات P0 للحوار الحي
- إصلاح موضع Composer مع لوحة المفاتيح بإضافة IME padding على شريط الكتابة نفسه بدل تركه خلف الكيبورد.
- تحسين تحمل أخطاء OpenAI المؤقتة: إعادة محاولة تلقائية محدودة لأخطاء 429/5xx قبل عرض الفشل، طالما لم يبدأ وصول النص.
- تحسين استخراج سبب أخطاء Streaming بدل رسالة 500 عامة كلما أمكن.
- البحث الصريح مثل «ابحث في الويب» يجبر Responses API على استخدام web_search بدل الاعتماد على Auto فقط.
- طلب مصادر web_search action ضمن النتيجة لتحسين طبقة المصادر.
- تحويل الميكروفون إلى Voice Turn: الكلام لا يكتب في مربع النص؛ يظهر كنص حي مؤقت، ثم يرسل تلقائيًا عند نهاية الكلام، ويُقرأ رد AION صوتيًا تلقائيًا.
- هذا Voice Turn وليس Realtime speech-to-speech الكامل؛ AION Live/WebRTC يبقى مرحلة لاحقة قبل 1.0.
- تحديث رقم النسخة إلى 2.0.0-alpha5.2 / versionCode 7.

## α5.3 — موثوقية المحادثة + المتابعة التلقائية + AION Voice
- إصلاح المتابعة التلقائية للمحادثة: إرسال رسالة جديدة يعيد الشاشة لآخر الرسائل ويتابع النص أثناء البث.
- إذا صعد المستخدم يدويًا أثناء البث يتوقف التمرير التلقائي ويظهر زر «آخر رد» بدل سحب الشاشة بالقوة.
- إضافة مسار احتياطي غير متدفق عند تعثر Streaming قبل وصول أي نص.
- تقليل تعقيد طلبات الدردشة العادية بعدم إرفاق أداة الويب إلا عندما يحتاج الطلب البحث.
- عند طلب البحث صراحة يستخدم web_search بإجبار tool_choice=required، مع الاحتفاظ بالمصادر.
- إضافة شاشة AION Voice لمكالمة صوتية داخل نفس المحادثة: استماع تلقائي، إرسال الكلام، قراءة الرد، ثم العودة للاستماع.
- دعم مقاطعة القراءة الصوتية والعودة للاستماع، وكتم الميكروفون وإنهاء المكالمة.
- رفع الإصدار إلى 2.0.0-alpha5.3 (versionCode 8).

## α6.1 — Living Research Core
- نقل اختيار الواجهة من أسماء نماذج شكلية إلى أوضاع AION فعلية: Auto / سريع / عميق / بحث.
- إضافة دستور حوار داخلي لـ AION على الخادم: طول متكيف، تصحيح طبيعي، فصل الحقيقة عن الرأي، وعدم ادعاء البحث دون مصادر فعلية.
- إضافة بحث ويب حي من الخادم عبر Firecrawl Keyless عند طلب البحث صراحة أو اختيار وضع «بحث».
- إرجاع مصادر البحث إلى Android وعرضها عبر بطاقة المصادر الموجودة.
- إضافة Streaming حقيقي من AION Cloud إلى التطبيق عبر SSE بدل انتظار الرد كاملًا.
- حالات تشغيل صادقة: يفهم طلبك / يبحث في الويب / يصيغ الرد.
- إضافة نموذج احتياطي تلقائي في Cloudflare إذا تعذر النموذج الأساسي قبل بدء البث.
- إضافة مسار `/v1/status` ومسار `/v1/chat/stream` مع إبقاء `/v1/chat` كمسار احتياطي.
- إصلاح زر الإيقاف ليحمل نبضًا بصريًا أثناء الرد بدل أن يبدو جامدًا.
- رفع الإصدار إلى 2.0.0-alpha6.1 / versionCode 10.

### ملاحظات α6.1
- البحث الحي يعتمد على الحصة المجانية Keyless ويجب أن يفشل بوضوح بدل ادعاء البحث إذا لم تتوفر الخدمة.
- المرفقات في مسار AION Cloud ما زالت تحتاج طبقة Multimodal مستقلة؛ لا نعد تحليل الصور/PDF مكتملًا في α6.1.
- الحماية الحالية تطويرية. قبل الإطلاق العام نحتاج Rate Limiting موزعًا ومصادقة عميل/جلسة.


## α7 — Conversation OS / True Cloud Runtime
- تحويل AION Cloud إلى Streaming حقيقي من Workers AI بدل انتظار النص كاملًا وتقسيمه محليًا.
- إضافة Routing فعلي للأوضاع: GLM-4.7-Flash للسريع/التلقائي، GPT-OSS-120B للعميق، وGemma 4 لوضع البحث مع fallback قبل أول token.
- رفع جودة وضع «عميق» وإبقاء وضع «بحث» منفصلًا عن الوضع العادي.
- رفع المرفقات نفسها إلى AION Cloud بدل إرسال أسمائها فقط، مع قراءة النص والكود مباشرة وتحويل PDF/Word/Excel والصور عبر Workers AI toMarkdown.
- حدود حماية للمرفقات: 4 عناصر، 5 MB إجماليًا على Android، وحدود نص وسياق على الخادم لمنع تضخم الطلب.
- إضافة حالة تشغيل «يقرأ المرفقات» وربطها فعليًا بين Worker وAndroid.
- إضافة سجل محادثات متعدد محليًا: عنوان تلقائي، معاينة آخر رسالة، بحث، تبديل، حذف، مسودة مستقلة لكل محادثة، وترحيل جلسة α6 القديمة.
- ضمان ارتباط Foreground Service بمعرّف المحادثة الصحيح حتى لا ينتقل رد يعمل بالخلفية إلى دردشة أخرى.
- نقل اختيار وضع AION إلى أعلى المحادثة ليكون أقرب لتجربة تطبيقات الذكاء الحديثة.
- إضافة عرض كتل الكود بخط monospace، تمرير أفقي، وزر نسخ.
- تحسين AION Voice: حركة الأيقونة تستجيب فعليًا لشدة الصوت، ضبط مدد الصمت، واختيار أفضل صوت TTS متاح للغة الجهاز بدل حركة ثابتة/صوت افتراضي جامد قدر الإمكان.
- إضافة ذاكرة محلية صريحة وتعليمات شخصية قابلة للتحكم تُرسل فقط كسياق عند الطلب.
- تحديث الإصدار إلى 2.0.0-alpha7 / versionCode 11.

### فحوص α7
- `node --check` للـWorker: ناجح.
- اختبارات Worker: Streaming حقيقي، مرفق نصي، PDF conversion، fallback قبل أول token، وتوجيه الوضع العميق: PASS.
- فحص parser لكل ملفات Kotlin: لا أخطاء syntax من نوع expecting/unexpected tokens.
- البناء Android الكامل يجب أن يمر عبر GitHub Actions/Android SDK قبل اعتبار APK إصدارًا معتمدًا.

### حدود صادقة ما زالت قائمة
- AION Voice الحالي دورة استماع → رد → TTS محسّنة، وليس Full-Duplex speech-to-speech مثل أنظمة الصوت الحي المتخصصة.
- الوكلاء/المشاريع ما زالوا Foundation وليست واجهات مكتملة؛ لا نعرضهم على أنهم جاهزون.
- Claude/Gemini/Grok تظهر كخيارات مستقبلية معطلة؛ لا ندّعي اتصالًا غير موجود.
- الذاكرة الحالية صريحة ومحلية، وليست استخراجًا تلقائيًا واسعًا لكل ما يقوله المستخدم.

## α7.2 — الخطوة 1: ثبات السياق والبث
- توحيد اختيار نافذة السياق في `ContextWindow` بدل وجود منطقين منفصلين بين الواجهة والبوابة السحابية.
- الحفاظ على مرساة من بداية المحادثة مع أحدث الرسائل في المحادثات الطويلة، مع حدود للحروف وعدد الرسائل ومنع التكرار.
- إضافة اختبارات وحدة لنافذة السياق واختبار smoke مستقل عبر Kotlin؛ النتيجة PASS.
- تخفيف checkpoint أثناء Streaming إلى كل 2500 حرف أو 6 ثوانٍ تقريبًا بدل الكتابة المتقاربة، مع بقاء الحفظ النهائي الكامل عند انتهاء/إيقاف/فشل الرد.
- اختبارات Cloud Worker بعد التغييرات: PASS.

## α7.2 — الخطوة 2: ذاكرة المشاريع المعزولة
- تثبيت قاعدة النطاق: وجود Project نشط يجعل زر «تذكّر» يحفظ في ذاكرة ذلك المشروع دائمًا؛ خيار «ذاكرة خاصة بالمشروع» يتحكم في قراءة الذاكرة العامة ولا يغيّر وجهة الحفظ.
- إضافة `ProjectMemoryPolicy` كطبقة مستقلة قابلة للاختبار لتحديد نطاق الذاكرة، منع التكرار، وحدود الحجم، وتركيب سياق الذاكرة قبل الإرسال.
- منع تسرب الذاكرة العامة إلى المشروع عند تفعيل `projectOnlyMemory`، مع إبقاء ذاكرة المشروع وسياق محادثاته الأخرى متاحين.
- دعم وضع الذاكرة المشتركة: يمكن للمشروع قراءة الذاكرة العامة + ذاكرته الخاصة، بينما الذكريات الجديدة من داخله تبقى ملك المشروع.
- تحسين منع التكرار بعد تطبيع التعداد والمسافات وبعض أشكال الحروف العربية.
- قص الذاكرة القديمة على حدود أسطر قدر الإمكان بدل قطع النص عشوائيًا عند تجاوز 16,000 حرف.
- إضافة عمليات `appendMemory` و`clearMemory` في `ProjectStore` بحيث لا يمسح تنظيف ذاكرة مشروع أي ذاكرة عامة أو محادثات.
- توضيح حالة الذاكرة في قائمة المشاريع: معزولة/مشتركة وعدد المحفوظات، وإضافة خيار مسح ذاكرة المشروع من نافذة الإعدادات قبل الحفظ.
- إضافة اختبارات وحدة لوجهة الحفظ، العزل عن الذاكرة العامة، الوضع المشترك، منع التكرار وحد الحجم؛ smoke test مستقل عبر Kotlin: PASS.

## α7.2 — الخطوة 3: الأداء (2026-09-09)

- استبدال تجميع نص الـStreaming داخل `AionRunService` من `String += delta` إلى `StringBuilder` لتجنب نسخ النص كاملًا مع كل token.
- تحويل checkpoint أثناء الـStreaming إلى sidecar ذري صغير للرد الجاري فقط؛ لم يعد AION يعيد كتابة مئات رسائل السجل كل عدة ثوانٍ أثناء الرد الطويل، مع دمج checkpoint تلقائيًا بعد إعادة فتح التطبيق وحذفه عند الحفظ النهائي.
- إضافة `StreamingRenderPolicy`: تحديث واجهة الرد بحد أقصى عملي يقارب 20 إطارًا/ثانية أو عند وصول دفعة نصية كبيرة، بدل إعادة تركيب Compose لكل token صغير.
- إضافة اختبار وحدة لسياسة عرض الـStreaming.
- تقليل عمليات التخزين أثناء الإرسال: لا تُحفظ رسالة المستخدم مرتين قبل بدء الرد، ولا تعيد الواجهة حفظ النتيجة النهائية بعد أن تكون خدمة الخلفية قد حفظتها بالفعل.
- جعل حفظ المسودة Debounced (400ms) بدل الكتابة إلى SharedPreferences مع كل ضغطة مفتاح، مع Flush فوري عند الإرسال/تبديل المحادثة/الأرشفة/إغلاق ViewModel.
- تحميل فهرس المحادثات النشطة والمؤرشفة في قراءة واحدة عبر `ConversationBuckets` بدل تحليل الفهرس مرتين في كل Refresh.
- إضافة cache داخل العملية لفهرس `ConversationSummary` لتجنب إعادة JSON parse لنفس الفهرس في القراءات المتتابعة.
- عدم قراءة سجل المحادثة القديم كاملًا عند كل حفظ طبيعي؛ فحص المرفقات المحذوفة صار يُنفذ فقط عند اقتطاع/حذف رسائل أو تجاوز حد السجل.
- إزالة كتابة SharedPreferences غير الضرورية من نقاط حفظ الـStreaming عندما لا يوجد مفتاح ترحيل قديم أصلًا.
- تحسين بناء Search index بإلغاء `sumOf` المتكرر داخل الحلقة.
- تسريع بحث درج المحادثات: تطبيع النص العربي الكبير يُحسب مرة عند تغير الفهرس، لا مع كل حرف يكتبه المستخدم في خانة البحث.
- تثبيت قائمة النماذج داخل ViewModel بدل إعادة إنشائها في كل قراءة Compose.

## α7.2 — الخطوة 4: الواجهة وتجربة الاستخدام (2026-09-09)

- إعادة بناء شاشة البداية لتصبح أكثر تركيزًا: هوية AION في المنتصف + أربع بطاقات إجراءات واضحة (بحث/تحليل/كتابة/مهمة) بدل شريط اقتراحات أفقي ضيق.
- جعل عرض المحادثة Responsive بعرض أقصى 820dp للمحتوى حتى لا تتمدد الرسائل بشكل مرهق على الشاشات الكبيرة/الأجهزة اللوحية.
- تضييق فقاعة المستخدم إلى 82% من العرض وإبقاء رد AION بلا فقاعة ثقيلة، مع لون مستخدم أكثر حيادية وأقل تشبعًا بالبنفسجي.
- أفعال رد AION تبقى متاحة بعد اكتمال الرد، بينما أفعال رسالة المستخدم تظهر بالنقر لتقليل الضوضاء البصرية.
- تطوير حالة التفكير الحية: أيقونة مرتبطة بالنشاط الحقيقي (تفكير/بحث/قراءة ملفات/صياغة) + اسم وضع/نموذج الرد بدل مؤشر زخرفي مبهم.
- تحسين سلوك التمرير: إرسال المستخدم يعيد Auto-follow دائمًا؛ وإذا صعد المستخدم تظهر كبسولة «العودة لآخر رد» أو عدد الرسائل الجديدة بدل سحبه قسرًا.
- تطوير Composer: حدود تتفاعل مع focus والاستماع، مساحة نص تتمدد حتى 7 أسطر، زر إيقاف أوضح، ورسالة خطأ مباشرة إذا حاول الإرسال والخدمة السحابية غير مضبوطة.
- إضافة معاينة حقيقية للصور قبل الإرسال داخل شريط المرفقات، مع الاسم والحجم وإزالة المرفق من نفس البطاقة.
- إضافة عرض صورة بالحجم الكبير داخل Dialog عند النقر على صورة موجودة في رسالة، بدل بقاء الصورة Thumbnail فقط.
- تحسين واجهة الاستماع داخل Composer: حالة مستقلة بنص التعرف الجزئي ومؤشر مستوى مرتبط بـRMS بدل نص صغير منفصل.
- إضافة نص تنبيه صغير أسفل Composer: «قد يخطئ AION؛ تحقق من المعلومات المهمة.»
- استبدال حقل بحث درج المحادثات Material التقليدي بحقل أخف بصريًا مع زر مسح، وتوسيع الدرج قليلًا وتحسين قابلية قراءة النصوص الصغيرة.
- رفع كل نصوص 8sp في الواجهة إلى 9sp على الأقل لتحسين المقروئية والوصول.
- تحسين بطاقة المصادر لتعرض نطاق المصدر الأساسي (+عدد النطاقات الأخرى) بدل رقم مصادر مجرد عندما تتوفر عناوين URL.
- تصحيح وصف Model Picker من «للرسالة التالية» إلى «لهذه المحادثة» لأن اختيار الوضع محفوظ فعليًا لكل محادثة.
- ضبط الخلفيات والأسطح الأساسية لتدرج فحمي موحد وتقليل التباين البنفسجي الزائد، مع توحيد ألوان status/navigation/splash مع Compose.
- حذف مكوّن ModelChip غير المستخدم لتقليل الكود الميت.

### فحوص الخطوة 4
- Kotlin parser static check على `AionApp.kt`: لا diagnostics من نوع `expecting / unexpected tokens / missing }`.
- XML parse لملفات theme/colors المعدلة: PASS.
- `node --check cloudflare/aion-core/src/index.js`: PASS.
- Worker regression suite: `AION worker tests: PASS` (رسائل الخطأ المطبوعة ضمن الاختبارات حالات سلبية متوقعة يتم اختبار fallback/413 بها).
- البناء Android الكامل (Unit + Lint + assembleDebug) يبقى بوابة إغلاق α7.2 عبر GitHub Actions بعد الخطوتين 5 و6.

## α7.2 — الخطوة 5: الصوت والمكالمة (2026-09-09)

- إزالة نبضة TTS الزمنية المصطنعة من شاشة AION Voice؛ حركة الدائرة أثناء كلام AION أصبحت مبنية على عينات PCM الحقيقية الخارجة من `UtteranceProgressListener.onAudioAvailable`، مع دعم PCM 8-bit و16-bit وFloat.
- إبقاء حركة الاستماع مرتبطة بـ`RecognitionListener.onRmsChanged` فقط، لذلك تبقى الدائرة ساكنة فعليًا تقريبًا عند الصمت بدل الحركة الدورية المستمرة.
- إضافة `VoiceAmplitude` لقياس/تنعيم مستوى الصوت بشكل مستقل وقابل للاختبار، مع ارتفاع سريع للحركة وانخفاض أهدأ لتقليل الاهتزاز البصري.
- إضافة مقاطعة مباشرة أثناء كلام AION: الضغط على الدائرة أو زر الإيقاف يوقف TTS فورًا ويعيد الميكروفون للاستماع للدور الجديد.
- فصل كتم الميكروفون عن حالة المحادثة؛ كتم الميكروفون لا يغيّر حالة كلام AION ولا يوقف الصوت الخارج منه.
- إضافة حالة `RECONNECTING` وإعادة محاولة متدرجة عند أخطاء SpeechRecognizer المؤقتة بدل حلقة إعادة تشغيل سريعة، مع طلب تدخل المستخدم بعد تكرار أعطال الشبكة عدة مرات.
- تجاهل أخطاء SpeechRecognizer الناتجة عن `cancel()` المقصود عند انتقال AION من الاستماع إلى التفكير/الكلام، لمنع ظهور خطأ وهمي أثناء الدورة الطبيعية.
- تخفيض فواصل الصمت المطلوبة لإنهاء جملة المستخدم إلى 900/520ms تقريبًا مع حد أدنى 350ms، لتقليل زمن الانتقال من الكلام إلى التفكير في Voice Call والإملاء داخل Composer.
- إصلاح سباق تهيئة TTS: إذا وصل رد AION قبل اكتمال تهيئة محرك الصوت، لا تُعلَّم الرسالة كمقروءة قبل أن يصبح المحرك جاهزًا.
- تقسيم النص المسموع إلى مقاطع أقصر (حتى نحو 1200 حرف) لتحسين زمن بدء القراءة واستجابة المقاطعة وتقليل عبء طابور TTS.
- تحسين إعداد TTS بإسناد `USAGE_ASSISTANT` و`CONTENT_TYPE_SPEECH`، سرعة عربية أهدأ قليلًا، واختيار الصوت الأعلى جودة مع مراعاة latency.
- إضافة نصوص حالة صريحة في شاشة المكالمة: الاستماع/الفهم/البحث/الكلام/إعادة الاتصال، مع إرشاد واضح للمقاطعة والكتم.
- تنظيف Handler/Recognizer/TTS عند إغلاق المكالمة لمنع بقاء callbacks أو جلسات صوتية بعد خروج المستخدم من الشاشة.
- إضافة `VoiceTurnPolicy` واختبارات مستقلة لسياسة backoff وإجبار الاستئناف اليدوي بعد أعطال شبكة متكررة.

### فحوص الخطوة 5
- `VOICE CORE TESTS: PASS` عبر Kotlin JVM smoke test لـPCM level/smoothing/retry policy.
- Kotlin syntax diagnostic scan لـ`VoiceCallOverlay.kt`: لا أخطاء `expecting/unexpected tokens`.
- Kotlin syntax diagnostic scan لـ`AionApp.kt` بعد تعديل إعدادات SpeechRecognizer: لا أخطاء نحوية مستهدفة.
- `node --check cloudflare/aion-core/src/index.js`: PASS.
- Worker regression suite: `AION worker tests: PASS`.
- البناء Android الكامل + Lint + Unit Tests يبقى ضمن الخطوة 6 على GitHub Actions.

## α7.3 — Step 4 Gate Fix (2026-09-09)
- إصلاح فشل Kotlin في بوابة GitHub لـAION Live dev5 دون تغيير سلوك الجلسة أو رقم الإصدار.
- تصحيح استيراد `graphicsLayer` إلى `androidx.compose.ui.graphics.graphicsLayer` في `AionApp.kt` و`VoiceCallOverlay.kt`.
- إضافة استيراد `width` الناقص في `VoiceCallOverlay.kt`.
- إضافة `@OptIn(ExperimentalMaterial3Api::class)` إلى `ChatComposer` لاستخدام Material3 التجريبي بشكل صريح.
- يبقى الإصدار `2.0.0-alpha7.3-dev5 / versionCode 19`، ولا تُعد Step 4 مغلقة حتى نجاح Unit + Lint + assembleDebug + apksigner على GitHub Actions.
## α7.3 — Step 4 Gate Test Fix (2026-09-09)
- إصلاح `SpeechText.splitNatural` بحيث تحترم أولوية حدود الجمل/الفقرات قبل المسافات العادية بدل اختيار أبعد delimiter بلا تمييز.
- يحافظ التقسيم على `hardLimit` ويمنع مقاطع TTS الطويلة من الانتهاء في منتصف العبارة عندما توجد نهاية جملة مناسبة داخل النافذة.
- إصلاح اختبار `SpeechTextTest.naturalSplitPrefersSentenceBoundaries` من خلال تصحيح المنطق المنتج نفسه، لا إضعاف الاختبار.
- لا تغيير في AION Live أو Conversation ID أو Voice interruption أو رقم الإصدار: `2.0.0-alpha7.3-dev5 / versionCode 19`.

## α7.3 — Step 4 Gate Lint Permission Fix (2026-09-09)
- إصلاح خطأي Android Lint من نوع `MissingPermission` في `VoiceBargeInDetector` دون إنشاء lint baseline ودون تعطيل الفحص.
- إعادة فحص `RECORD_AUDIO` مباشرة قبل إنشاء `AudioRecord`، ثم إعادة الفحص داخل خيط التسجيل قبل `startRecording()` للتعامل مع احتمال سحب الإذن أثناء الجلسة.
- تبقى المقاطعة الصوتية اختيارية؛ عند غياب الإذن أو سحبه يفشل Barge-in بأمان ويبقى Tap-to-interrupt متاحًا.
- لا تغيير في AION Live أو Conversation ID أو رقم الإصدار: `2.0.0-alpha7.3-dev5 / versionCode 19`.

## α7.3 — Step 4 Gate Lint API Fix (2026-09-09)
- إصلاح آخر خطأ Android Lint من نوع `NewApi` دون رفع `minSdk` ودون استخدام lint baseline.
- نقل `android:windowLayoutInDisplayCutoutMode=shortEdges` من `values/themes.xml` إلى `values-v27/themes.xml` لأن الخاصية متاحة من API 27 بينما AION يدعم API 26.
- يحتفظ API 26 بالثيم الأساسي دون خاصية cutout، وتُفعّل الخاصية تلقائيًا من API 27 فما فوق.
- لا تغيير في AION Live أو Conversation ID أو رقم الإصدار: `2.0.0-alpha7.3-dev5 / versionCode 19`.

## α7.3 — Step 5.3 My Voice / dev8 (2026-09-09)
- رفع Android إلى `2.0.0-alpha7.3-dev8 / versionCode 22`.
- إضافة My Voice لصوت المستخدم نفسه فقط مع موافقة صريحة قبل أي رفع.
- إضافة تسجيل WAV محلي 16 kHz Mono PCM16 بحد 15–90 ثانية، واستيراد WAV متوافق عبر Storage Access Framework.
- التحقق من بنية WAV ومدتها وحجمها على Android ثم إعادة التحقق على AION Cloud.
- إضافة `MyVoicePolicy` و`MyVoiceSampleRecorder` و`MyVoiceCloudGateway` و`MyVoiceCredentialStore`.
- تخزين capability token باستخدام Android Keystore؛ Voice ID ومفتاح ElevenLabs لا يدخلان APK.
- تشفير Voice ID داخل capability token على الخادم بـAES-GCM بدل token قابل للقراءة.
- استخدام My Voice في Preview وRead Aloud وAION Live من نفس `AionVoiceSettings`.
- إذا احتاج الصوت Verification لدى المزود لا يُفعل تلقائيًا.
- حذف العينة المحلية تلقائيًا بعد نجاح الإنشاء، وحذف My Voice عن بُعد قبل حذف الاعتماد المحلي.
- إضافة تأكيد حذف نهائي ومنع مسح الاعتماد عند فشل حذف النسخة السحابية.
- إضافة rate limit مستقل لمسار My Voice وتوسيع CORS للرؤوس المطلوبة.
- تحديث Worker tests لتغطية: عدم تسريب الأسرار/Voice ID، رفض secret الخاطئ، رفض WAV غير صالح، إنشاء token مشفر، TTS بصوت My Voice، رفض token مزور، والحذف.
- لا يتضمن dev8 Playback Arbiter أو تغييرات Step 5.4.

- تشديد ربط My Voice بخادم AION Cloud: لا يُفعّل الاعتماد إلا إذا كان عنوان الاعتماد، عنوان Cloud المحفوظ، وعنوان آخر Health check ناجح متطابقة؛ والحذف يرجع دائمًا إلى الخادم الذي أنشأ الاعتماد.


## α7.3 — Step 5.4 Voice Playback Arbitration / dev9 (2026-09-10)
- رفع Android إلى `2.0.0-alpha7.3-dev9 / versionCode 23`.
- إضافة `AionVoicePlaybackArbiter` لمنع تداخل Read Aloud وPreview وAION Live.
- إضافة lease tokens تمنع stale callbacks من تحرير أو تغيير حالة playback أحدث.
- منع Live SpeechRecognizer من الاستماع أثناء Preview/Read Aloud لتجنب self-transcription، مع استئناف آمن بعد انتهاء الصوت الآخر.
- تقوية `NeuralVoicePlayer` بجيل monotonic/resource lock، fail-fast 7s/30s، وPCM chunks أصغر لتحسين الاستجابة.
- إضافة `VoiceAudioFocus` لـPreview وRead Aloud مع cleanup في completion/interruption/error.
- إضافة neural-to-local remainder handoff: لا إعادة للكلمات التي بدأ PCM الخاص بها، ولا قطع لبقية الرد عند فشل chunk لاحق.
- إضافة token داخل utterance IDs لـAndroid TTS في Live وRead Aloud وحماية `onDone/onStop/onError/onAudioAvailable`.
- فحص `TextToSpeech.speak()` وإغلاق الحالة عند فشل queue بدل بقاء الصوت عالقًا.
- إبقاء AION Live audio session/Conversation binding/My Voice/Cloud Worker من dev8 بلا تغييرات خارج النطاق.
- إضافة اختبارات `AionVoicePlaybackArbiterTest` و`VoicePlaybackPolicyTest`.


## α7.3 — Step 6.3 Gemini Execution / dev12 (2026-09-10)
- رفع Android إلى `2.0.0-alpha7.3-dev12 / versionCode 26`.
- تفعيل Gemini كمسار تنفيذ حقيقي فقط عند وجود `GEMINI_API_KEY` و`AION_GEMINI_MODEL` على AION Cloud.
- إضافة Sync وSSE Streaming عبر Google Gemini Generate Content API.
- تحويل AION system prompt إلى `systemInstruction` وسجل assistant إلى role=`model`.
- دعم Vision عبر `inline_data` للصور JPEG/PNG/GIF/WebP.
- منع fallback الصامت من Gemini إلى Workers AI عند اختيار Gemini صراحة.
- بحث Gemini يستخدم Firecrawl في هذه المرحلة؛ غيابه يؤدي إلى خطأ صريح بدل تشغيل Google Search Grounding بلا UI attribution contract.
- إضافة Worker tests لـGemini Sync/Streaming/Vision/Firecrawl Search ورفض Search بلا Firecrawl.
- Claude من dev11 وVoice/My Voice/AION Live لا تتغير خارج نطاق 6.3.
