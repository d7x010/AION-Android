# AION α7 — ملف انتقال مختصر

المرجع الحاكم لهذه الجولة هو مشروع Android في هذا الأرشيف مع Worker داخل `cloudflare/aion-core`.

## ما تغير جوهريًا
- Streaming حقيقي على Workers AI.
- مرفقات حقيقية وقراءة مستندات/صور.
- Multi-conversation + بحث محلي في السجل + مسودات مستقلة.
- ربط مهام الخلفية بمعرّف المحادثة.
- اختيار الوضع في Top Bar.
- Code blocks + copy.
- Voice RMS/TTS محسّن.
- ذاكرة محلية وتعليمات شخصية صريحة.
- Routing: Auto/Fast=GLM 4.7 Flash، Deep=GPT-OSS-120B، Research=Gemma 4، مع fallback.

## لا تعتبر مكتملًا
- Full-duplex voice الحقيقي.
- Agents/Projects كاملة.
- مزودات Claude/Gemini/Grok.
- ذاكرة تلقائية شاملة.

## بوابة البناء
Gradle tasks المطلوبة: `:app:testDebugUnitTest :app:lintDebug :app:assembleDebug`. لا تعتمد APK قبل نجاحها.
