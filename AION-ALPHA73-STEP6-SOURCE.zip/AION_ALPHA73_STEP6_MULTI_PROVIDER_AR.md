# AION α7.3 — Step 6: Multi‑Provider Models

## الحالة الحالية
Step 6.5 — Provider Routing & Failover Policy

الإصدار:
- versionCode: 28
- versionName: 2.0.0-alpha7.3-dev14

## الهدف
فصل هوية النموذج والمزود عن APK، وجعل AION Cloud مصدر الحقيقة لما هو مهيأ وما هو جاهز للتنفيذ فعلًا.

## Step 6.1 المنفذ
- إضافة Provider Catalog خادمي لـAnthropic / Gemini / xAI.
- إضافة Model Catalog contract رقم 1 في `/v1/status`.
- لا يعرض `/v1/status` أي API key أو secret.
- model IDs تأتي من إعداد الخادم ولا تُثبت داخل APK:
  - `AION_CLAUDE_MODEL`
  - `AION_GEMINI_MODEL`
  - `AION_GROK_MODEL`
- وجود API key + model ID يعني `configured` فقط، وليس `chatReady`.
- في 6.1 تبقى Claude/Gemini/Grok `chatReady=false` حتى يوجد مسار inference حقيقي ومختبر لكل مزود.
- Android يقرأ catalog ديناميكيًا، ويتحقق من key/modelId/label/provider قبل إظهارها.
- أي خيار خارجي غير جاهز يظهر Disabled بحالته الواقعية، ولا يصبح قابلاً للنقر.
- إذا أرسل عميل معدل `mode=claude|gemini|grok` قبل جاهزية المسار، يرد AION Cloud بـ409 بدل السقوط بصمت إلى AION Auto.
- عند غياب catalog أو استخدام خادم أقدم، تبقى أوضاع AION المدمجة Auto/Fast/Deep/Research تعمل كـfallback.

## الضوابط
- مفاتيح Anthropic/Gemini/xAI أسرار خادمية فقط.
- لا API keys داخل APK أو SharedPreferences أو `/v1/status`.
- لا نموذج خارجي يُعد READY بمجرد وجود المفتاح.
- لا fallback صامت من نموذج اختاره المستخدم صراحةً إلى مزود مختلف.
- اختيار نموذج محفوظ سابقًا يعود إلى AION Auto إذا لم يعد الخيار متاحًا/جاهزًا.

## Step 6.2 المنفذ
- Claude يصبح `chatReady=true` فقط عند وجود `ANTHROPIC_API_KEY` و`AION_CLAUDE_MODEL` على AION Cloud.
- تنفيذ فعلي عبر Anthropic Messages API من Worker؛ مفتاح Anthropic لا يدخل APK.
- دعم Sync وSSE Streaming الحقيقي مع text deltas.
- تحويل رسائل النظام إلى الحقل `system` الخاص بـAnthropic بدل إرسالها كرسالة system عادية.
- دعم الصور الأصلية JPEG/PNG/GIF/WebP عبر تحويل `image_url` الداخلي إلى Anthropic base64 image blocks.
- الملفات النصية/PDF/Office تستمر في المرور عبر طبقة hydration الحالية ثم تدخل Claude كنص سياق.
- model ID يبقى إعدادًا خادميًا (`AION_CLAUDE_MODEL`) ولا يُثبت داخل Android.
- لا يوجد fallback صامت من Claude إلى Workers AI إذا تعطل Anthropic؛ اختيار المستخدم يبقى صريحًا.
- بحث الويب مع Claude في 6.2 يستخدم Firecrawl عند تهيئته؛ إن لم يكن مهيأ يفشل الطلب البحثي بوضوح بدل تشغيل Workers AI Web Search خلف ظهر المستخدم.
- Gemini وGrok يبقيان Foundation وغير قابلين للتنفيذ.

## المراحل التالية
- Step 6.4 مغلقة: Grok execution path.
- Step 6.5 الحالية: cross-provider continuity / routing / failover policy واختبارات الانقطاع والفشل.

## بوابة الإغلاق
لا تُغلق 6.2 رسميًا قبل:
- Worker regression.
- Android Unit Tests.
- Android Lint.
- assembleDebug.
- APK signature verification.
- Artifact upload.


## Step 6.3 المنفذ
- Gemini يصبح `chatReady=true` فقط عند وجود `GEMINI_API_KEY` و`AION_GEMINI_MODEL` على AION Cloud.
- تنفيذ فعلي عبر Gemini Generate Content REST API من Worker؛ مفتاح Google لا يدخل APK.
- دعم Sync وSSE Streaming الحقيقي عبر `generateContent` و`streamGenerateContent`.
- تحويل system prompt إلى `systemInstruction`، ورسائل assistant إلى role=`model`.
- دعم الصور JPEG/PNG/GIF/WebP عبر تحويل `image_url` الداخلي إلى `inline_data` base64.
- الملفات النصية/PDF/Office تستمر عبر hydration الحالية ثم تدخل Gemini كسياق نصي.
- model ID يبقى إعدادًا خادميًا (`AION_GEMINI_MODEL`) ولا يثبت داخل Android.
- لا يوجد fallback صامت من Gemini إلى Workers AI عند اختيار المستخدم Gemini صراحةً.
- بحث الويب مع Gemini في 6.3 يستخدم Firecrawl فقط؛ عند غيابه يفشل البحث بوضوح بدل تفعيل Google Search Grounding دون متطلبات UI الخاصة بالاقتراحات/الإسناد.
- Claude يبقى كما هو من 6.2، وGrok يبقى Foundation وغير قابل للتنفيذ.

## بوابة إغلاق 6.3
- Worker regression + Gemini Sync/Streaming/Vision/Search tests.
- Android Unit Tests.
- Android Lint.
- assembleDebug.
- APK signature verification.
- Artifact upload.


## Step 6.4 المنفذ
- Grok يصبح `chatReady=true` فقط عند وجود `XAI_API_KEY` و`AION_GROK_MODEL` على AION Cloud.
- التنفيذ الفعلي يستخدم xAI Responses API `POST https://api.x.ai/v1/responses` بدل Chat Completions القديمة.
- دعم Sync وSSE Streaming عبر أحداث `response.output_text.delta`/`response.text.delta`.
- system prompt ينتقل إلى `instructions`، وسجل الرسائل ينتقل إلى `input`.
- يرسل Worker `store=false` صراحةً لعدم تخزين سجل الطلب/الرد لدى xAI في هذا المسار.
- دعم Vision الأصلي لـJPEG/PNG عبر `input_image` data URLs؛ لا تمر الصور إلى Markdown converter.
- الملفات النصية/PDF/Office تستمر عبر hydration الحالية ثم تدخل Grok كسياق نصي.
- model ID يبقى إعدادًا خادميًا (`AION_GROK_MODEL`) ولا يثبت داخل Android.
- لا fallback صامت من Grok إلى Workers AI أو Claude/Gemini عند اختيار المستخدم Grok صراحةً.
- بحث الويب مع Grok في 6.4 يستخدم Firecrawl فقط؛ عند غيابه يفشل الطلب البحثي بوضوح.
- Claude وGemini يبقيان كما أُغلقا في 6.2/6.3.

## بوابة إغلاق 6.4
- Worker regression + Grok Sync/Streaming/Vision/Search tests.
- Android Unit Tests.
- Android Lint.
- assembleDebug.
- APK signature verification.
- Artifact upload.


## Step 6.5 المنفذ
- فصل صريح بين **Selection** (الخيار الذي حدده المستخدم) و**Execution** (المزود/model id الذي نفذ فعليًا).
- Claude/Gemini/Grok اختيارات pinned: لا يوجد cross-provider fallback صامت عند فشل المزود المحدد.
- أوضاع AION Auto/Fast/Deep/Research تسمح فقط بـfallback داخلي داخل Workers AI وقبل أول token؛ بعد أول token لا يبدأ نموذج آخر من الصفر.
- `/v1/status` يرفع `models.contract` إلى 2 ويعلن routing contract آمنًا: external pinned، built-in fallback داخل Workers AI فقط، و`crossProviderFailover=false`.
- ردود sync وحدث SSE `done` يعيدان routing metadata: providerKey/providerLabel/modelId/policy/fallbackUsed/attempts.
- Android يحفظ execution metadata مع رد المساعد بشكل backward-compatible ويعرض chip صغيرًا للمزود/model الفعلي؛ `modelId` القديم يبقى selection key حتى لا ينكسر Retry.
- تبديل المزود بين جولة وأخرى داخل نفس المحادثة مسموح ويحافظ على التاريخ النصي نفسه.
- الخادم القديم الذي لا يعيد routing metadata يبقى متوافقًا؛ التطبيق يخفي chip بدل اختراع provenance.

## بوابة إغلاق 6.5
- Worker regression + routing/fallback/continuity tests.
- Android Unit Tests.
- Android Lint.
- assembleDebug.
- APK signature verification.
- Artifact upload.
