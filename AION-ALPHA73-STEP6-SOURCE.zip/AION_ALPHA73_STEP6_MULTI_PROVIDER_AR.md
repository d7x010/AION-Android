# AION α7.3 — Step 6: Multi‑Provider Models

## الحالة الحالية
Step 6.1 — Multi‑Provider Core / Foundation

الإصدار:
- versionCode: 24
- versionName: 2.0.0-alpha7.3-dev10

## الهدف
فصل هوية النموذج والمزود عن APK، وجعل AION Cloud مصدر الحقيقة لما هو مهيأ وما هو جاهز للتنفيذ فعلًا.

## Step 6.1 المنفذ
- إضافة Provider Catalog خادمي لـAnthropic / Gemini / xAI.
- إضافة Model Catalog contract رقم 1 في `/v1/status`.
- لا يعرض `/v1/status` أي API key أو secret.
- model IDs تأتي من إعداد الخادم ولا تُثبت داخل APK:
  - `AION_CLAUDE_MODEL`
  - `AION_GEMINI_MODEL`
  - `AION_GROK_MODEL`
- وجود API key + model ID يعني `configured` فقط، وليس `chatReady`.
- في 6.1 تبقى Claude/Gemini/Grok `chatReady=false` حتى يوجد مسار inference حقيقي ومختبر لكل مزود.
- Android يقرأ catalog ديناميكيًا، ويتحقق من key/modelId/label/provider قبل إظهارها.
- أي خيار خارجي غير جاهز يظهر Disabled بحالته الواقعية، ولا يصبح قابلاً للنقر.
- إذا أرسل عميل معدل `mode=claude|gemini|grok` قبل جاهزية المسار، يرد AION Cloud بـ409 بدل السقوط بصمت إلى AION Auto.
- عند غياب catalog أو استخدام خادم أقدم، تبقى أوضاع AION المدمجة Auto/Fast/Deep/Research تعمل كـfallback.

## الضوابط
- مفاتيح Anthropic/Gemini/xAI أسرار خادمية فقط.
- لا API keys داخل APK أو SharedPreferences أو `/v1/status`.
- لا نموذج خارجي يُعد READY بمجرد وجود المفتاح.
- لا fallback صامت من نموذج اختاره المستخدم صراحةً إلى مزود مختلف.
- اختيار نموذج محفوظ سابقًا يعود إلى AION Auto إذا لم يعد الخيار متاحًا/جاهزًا.

## المراحل التالية
- Step 6.2: Claude execution path.
- Step 6.3: Gemini execution path.
- Step 6.4: cross-provider continuity / switching policy واختبارات الانقطاع والفشل.
- Grok يبقى Foundation حتى يُفتح له مسار مستقل لاحقًا؛ لا ندعي جاهزيته.

## بوابة الإغلاق
لا تُغلق 6.1 رسميًا قبل:
- Worker regression.
- Android Unit Tests.
- Android Lint.
- assembleDebug.
- APK signature verification.
- Artifact upload.
