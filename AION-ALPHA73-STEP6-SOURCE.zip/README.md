# AION Android — 2.0.0-alpha7.3-dev12

## مسار التطوير الحالي: α7.3
- Step 1: Chat Shell / Composer / Activity System.
- Step 2: Drawer / Search / Projects.
- Step 3: Attachments / Images / PDF / Markdown / Code / Tables / Sources.
- Step 4: AION Live / Mini Orb / interruption / safe voice barge-in / Android audio session.
- Step 5: Neural Voice + Voice Selection/Tuning + My Voice + Playback Arbitration — مغلق رسميًا عند dev9.
- Step 6.1: Multi‑Provider Core — مغلق رسميًا.
- Step 6.2: Claude Execution — مغلق رسميًا عند dev11.
- Step 6.3: Gemini Execution — Generate Content API حقيقي عبر AION Cloud مع Sync/Streaming/Vision؛ Grok ما زال Foundation.
- الإصدار الداخلي الحالي: `versionCode = 26` / `versionName = 2.0.0-alpha7.3-dev12`.
- Claude يعمل فعليًا عند تهيئة Anthropic، وGemini يعمل فعليًا عند تهيئة Google Gemini على AION Cloud. Grok لا يزال غير جاهز.
# خط الأساس المستقر: AION Mobile V2 α7.2.1 — Runtime Hotfix

AION هو تطبيق ذكاء شخصي لـAndroid بواجهة عربية أولًا وهوية مستقلة. إصدار α7.2.1 يبني على α7.2، مع Hotfix خاص بالإقلاع بعد التحديث. α7.2 يركز على استقرار المحادثات الطويلة، Projects وذاكرتها المستقلة، تحسين الأداء، صقل واجهة الاستخدام، وتحسين المكالمة الصوتية turn-by-turn.

## ما يعمل في α7.2.1
- محادثات متعددة محليًا مع بحث داخل محتوى الرسائل، مسودة مستقلة، Pin، Archive/Restore، Share، ونقل المحادثة إلى Project.
- Projects محلية فعلية: تعليمات مشروع، ذاكرة مشروع مستقلة، وخيار عزل الذاكرة العامة.
- Streaming حقيقي عبر AION Cloud/Workers AI مع Stop، Retry، حفظ checkpoint خفيف، واستمرار المهمة في Foreground Service.
- نافذة سياق للمحادثات الطويلة تحفظ بداية المهمة مع أحدث الرسائل بدل إسقاط البداية بالكامل.
- أوضاع AION:
  - Auto / General: Qwen 3.8 27B.
  - Fast: GLM-4.7-Flash.
  - Deep: GPT-OSS-120B.
  - Vision / Research: Qwen 3.8 27B مع Gemma 4 كاحتياط عند الحاجة.
- بحث ويب حي مع Workers AI Web Search، واستخدام Firecrawl اختياريًا عند وجود `FIRECRAWL_API_KEY`.
- مرفقات فعلية: صور، نص، كود، PDF وOffice؛ الصور تمر إلى Vision مباشرة، والمستندات تُحوّل على Cloud عند الحاجة.
- عرض Markdown موسع يشمل العناوين والقوائم والاقتباسات والكود والجداول القابلة للتمرير.
- ذاكرة محلية صريحة + ذاكرة مستقلة لكل Project.
- AION Voice بنمط turn-by-turn قابل للمقاطعة مع SpeechRecognizer + TTS، وحركة تعتمد على RMS/PCM الحقيقي بدل Animation ثابت.
- تحسينات أداء في Streaming، فهرس المحادثات، البحث المحلي، المسودات، الصور، وعمليات التخزين.
- اتصالات HTTPS فقط مع تعطيل Android Backup لمحادثات ومرفقات AION في نسخة التطوير الحالية.

## ما لا ندعي أنه مكتمل
- Full-Duplex speech-to-speech الحقيقي ما زال مرحلة لاحقة.
- Agent runtime متعدد الأدوات ما زال Foundation وليس وكيل تنفيذ كاملًا.
- Claude وGemini متصلان فعليًا عند تهيئة مزوديهما على AION Cloud؛ Grok ما زال غير متصل ولا يظهر كخيار فعال.
- الذاكرة لا تستخرج تلقائيًا كل حقيقة من جميع المحادثات؛ الحفظ الصريح هو المسار الموثوق حاليًا.
- المزامنة السحابية متعددة الأجهزة ليست جزءًا من α7.2.

## إصدار Android
- `versionCode = 26`
- `versionName = 2.0.0-alpha7.3-dev12`
- `minSdk = 26`
- `targetSdk = 36`
- `compileSdk = 36`

## البناء الرسمي
المتطلبات الحالية:
- Java 17
- Android SDK 36 / Build Tools 36.0.0
- Gradle 9.6.1 في GitHub Actions

بوابة Android:
```bash
gradle :app:testDebugUnitTest :app:lintDebug :app:assembleDebug --stacktrace --no-daemon
```

اختبارات Worker المحلية:
```bash
node --check cloudflare/aion-core/src/index.js
node cloudflare/aion-core/test-worker.mjs
```

المتوقع: `AION worker tests: PASS`.

## Cloudflare
`cloudflare/aion-core/wrangler.toml` يستخدم Workers AI binding باسم `AI`. البحث الحي يعمل عبر Workers AI Web Search حتى دون Firecrawl. الصور تُرسل كرؤية أصلية إلى Qwen 3.8، مع Gemma 4 كمسار احتياطي للرؤية/البحث عند الحاجة.

## بوابة اعتماد α7.2.1
لا يعتبر APK معتمدًا إلا بعد نجاح GitHub Actions في:
1. Unit Tests.
2. Android Lint.
3. `assembleDebug`.
4. رفع Artifact.
5. نشر `aion-core` بنجاح.

ثم تُنفذ اختبارات الهاتف الواردة في `ALPHA7_TEST_PLAN_AR.md`، خصوصًا Streaming، Projects، الصور، البحث، المكالمة الصوتية، وإدارة المرفقات.
