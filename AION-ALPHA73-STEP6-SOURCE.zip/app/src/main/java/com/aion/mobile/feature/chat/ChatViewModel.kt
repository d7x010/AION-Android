package com.aion.mobile.feature.chat

import android.app.Application
import android.content.Intent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.aion.mobile.core.files.AttachmentLoader
import com.aion.mobile.core.ai.AionCloudGateway
import com.aion.mobile.core.ai.AionCloudVoiceOption
import com.aion.mobile.core.ai.AionCloudSettings
import com.aion.mobile.core.ai.GatewayActivity
import com.aion.mobile.core.ai.ModelCatalogPolicy
import com.aion.mobile.core.memory.LocalMemoryStore
import com.aion.mobile.core.memory.ProjectMemoryPolicy
import com.aion.mobile.core.project.AionProject
import com.aion.mobile.core.project.ProjectStore
import com.aion.mobile.core.search.ConversationSearchHit
import com.aion.mobile.core.run.AionRunBus
import com.aion.mobile.core.run.AionRunCoordinator
import com.aion.mobile.core.run.AionRunSnapshot
import com.aion.mobile.core.storage.ChatSessionStore
import com.aion.mobile.core.voice.AionVoiceProfile
import com.aion.mobile.core.voice.AionVoiceSettings
import com.aion.mobile.core.voice.MyVoiceCloudGateway
import com.aion.mobile.core.voice.MyVoiceCredential
import com.aion.mobile.core.voice.MyVoiceCredentialStore
import com.aion.mobile.core.voice.MyVoicePolicy
import com.aion.mobile.core.voice.VoicePreferences
import com.aion.mobile.core.voice.VoiceSelectionPolicy
import com.aion.mobile.core.storage.ConversationBuckets
import com.aion.mobile.core.storage.ConversationSummary
import com.aion.mobile.model.ChatAttachment
import com.aion.mobile.model.ChatMessage
import com.aion.mobile.model.MessageRole
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

data class AiModelOption(
    val key: String,
    val label: String,
    val provider: String,
    val enabled: Boolean,
    val modelId: String? = null,
    val badge: String? = null
)

class ChatViewModel(application: Application) : AndroidViewModel(application) {
    private val _messages = mutableStateListOf<ChatMessage>()
    val messages: SnapshotStateList<ChatMessage> = _messages

    private val _pendingAttachments = mutableStateListOf<ChatAttachment>()
    val pendingAttachments: SnapshotStateList<ChatAttachment> = _pendingAttachments

    private val _conversations = mutableStateListOf<ConversationSummary>()
    val conversations: SnapshotStateList<ConversationSummary> = _conversations

    private val _archivedConversations = mutableStateListOf<ConversationSummary>()
    val archivedConversations: SnapshotStateList<ConversationSummary> = _archivedConversations

    private val _projects = mutableStateListOf<AionProject>()
    val projects: SnapshotStateList<AionProject> = _projects

    private val _drawerSearchResults = mutableStateListOf<ConversationSearchHit>()
    val drawerSearchResults: SnapshotStateList<ConversationSearchHit> = _drawerSearchResults

    private var nextId = 1L
    private var activeRunId: String? = null
    private var draftSaveJob: Job? = null
    private var drawerSearchJob: Job? = null
    private var draftSaveConversationId: String? = null
    private val cloudGateway = AionCloudGateway()
    private val myVoiceGateway = MyVoiceCloudGateway()

    var activeConversationId by mutableStateOf("")
        private set
    var cloudEndpoint by mutableStateOf(AionCloudSettings.loadEndpoint(application))
        private set
    var cloudHealthLabel by mutableStateOf("لم يُفحص")
        private set
    var cloudHealthOk by mutableStateOf<Boolean?>(null)
        private set
    var cloudHealthEndpoint by mutableStateOf("")
        private set
    var neuralVoiceAvailable by mutableStateOf(false)
        private set
    var neuralVoiceProvider by mutableStateOf("")
        private set
    var myVoiceCloudAvailable by mutableStateOf(false)
        private set
    var myVoiceProvider by mutableStateOf("")
        private set
    var myVoiceMaxSampleBytes by mutableStateOf(MyVoicePolicy.MAX_SAMPLE_BYTES)
        private set
    var myVoiceCredential by mutableStateOf(MyVoiceCredentialStore.load(application))
        private set
    var isMyVoiceBusy by mutableStateOf(false)
        private set
    var myVoiceStatusLabel by mutableStateOf(
        if (MyVoiceCredentialStore.load(application).exists) "My Voice محفوظ على هذا الجهاز" else "لم يتم إنشاء My Voice بعد"
    )
        private set
    var isCheckingCloud by mutableStateOf(false)
        private set
    var isSending by mutableStateOf(false)
        private set
    var selectedModelKey by mutableStateOf(ChatSessionStore.loadSelectedModel(application))
        private set
    var activity by mutableStateOf<GatewayActivity?>(null)
        private set
    var draft by mutableStateOf("")
        private set
    var startupWarning by mutableStateOf<String?>(null)
        private set
    var voiceSettings by mutableStateOf(VoicePreferences.loadSettings(application))
        private set
    val voiceProfile: AionVoiceProfile get() = voiceSettings.profile
    var neuralVoiceOptions by mutableStateOf<List<AionCloudVoiceOption>>(emptyList())
        private set
    var neuralVoiceDefaultKey by mutableStateOf("")
        private set
    private var cloudExternalModels by mutableStateOf<List<AiModelOption>>(emptyList())
    var cloudProviderStatuses by mutableStateOf<List<com.aion.mobile.core.ai.AionCloudProviderStatus>>(emptyList())
        private set

    val resolvedVoiceSettings: AionVoiceSettings
        get() {
            val availableKeys = buildList {
                addAll(neuralVoiceOptions.map { it.key })
                val credentialEndpoint = myVoiceCredential.cloudEndpoint.trim().trimEnd('/')
                if (
                    myVoiceCloudAvailable &&
                    myVoiceCredential.usable &&
                    cloudHealthEndpoint == cloudEndpoint.trim().trimEnd('/') &&
                    credentialEndpoint.isNotBlank() &&
                    credentialEndpoint == cloudEndpoint.trim().trimEnd('/')
                ) {
                    add(MyVoicePolicy.MY_VOICE_KEY)
                }
            }
            return voiceSettings.copy(
                voiceKey = VoiceSelectionPolicy.resolve(
                    savedKey = voiceSettings.voiceKey,
                    defaultKey = neuralVoiceDefaultKey,
                    availableKeys = availableKeys
                )
            ).normalized()
        }

    val myVoiceToken: String
        get() {
            val credentialEndpoint = myVoiceCredential.cloudEndpoint.trim().trimEnd('/')
            return myVoiceCredential.token.takeIf {
                myVoiceCloudAvailable &&
                    myVoiceCredential.usable &&
                    cloudHealthEndpoint == cloudEndpoint.trim().trimEnd('/') &&
                    credentialEndpoint.isNotBlank() &&
                    credentialEndpoint == cloudEndpoint.trim().trimEnd('/')
            }.orEmpty()
        }
    var drawerSearchQuery by mutableStateOf("")
        private set
    var isDrawerSearching by mutableStateOf(false)
        private set
    var scrollTargetMessageId by mutableStateOf<Long?>(null)
        private set

    private val initialPersonalization = LocalMemoryStore.load(application)
    var customInstructions by mutableStateOf(initialPersonalization.instructions)
        private set
    var memoryNotes by mutableStateOf(initialPersonalization.memory)
        private set

    init {
        val activeSnapshot = AionRunBus.snapshot.value
        runCatching {
            activeConversationId = activeSnapshot?.conversationId?.takeIf { it.isNotBlank() }
                ?: ChatSessionStore.ensureActiveConversation(application)
            loadConversation(activeConversationId, preserveDraft = true)
            refreshProjects()
            refreshConversations()

            if (activeSnapshot != null && activeSnapshot.conversationId == activeConversationId) {
                applyRunSnapshot(activeSnapshot)
            } else {
                normalizeInterruptedStreamingMessages()
            }
        }.onFailure { error ->
            // لا نحذف بيانات المستخدم عند فشل ترحيل نسخة تجريبية قديمة.
            // نسمح للتطبيق بالإقلاع في جلسة استرداد ونحتفظ بتشخيص محلي.
            recordStartupFailure(error)
            startupWarning = "تم تجاوز مشكلة في بيانات إصدار سابق. بياناتك لم تُحذف."
            activeConversationId = runCatching { ChatSessionStore.createConversation(application) }
                .getOrDefault("startup-recovery")
            runCatching { loadConversation(activeConversationId, preserveDraft = true) }
            runCatching { refreshProjects() }
            runCatching { refreshConversations() }
        }

        // بناء فهرس البحث قد يقرأ عشرات المحادثات القديمة. يجب ألا يحدث على Main thread
        // أثناء أول إطار بعد التحديث. إذا فشل، يبقى البحث بالعنوان والمعاينة ويستمر التطبيق طبيعيًا.
        viewModelScope.launch(Dispatchers.IO) {
            val rebuilt = ChatSessionStore.rebuildSearchIndexIfNeeded(application)
            if (rebuilt) {
                val buckets = ChatSessionStore.loadConversationBuckets(application)
                withContext(Dispatchers.Main) { applyConversationBuckets(buckets) }
            }
        }

        viewModelScope.launch {
            AionRunBus.snapshot.collect { snapshot ->
                snapshot?.let(::applyRunSnapshot)
            }
        }

        // فحص خفيف بعد الإقلاع لتحديد قدرات الخادم (ومنها Neural Voice) من دون
        // تعطيل أول إطار أو جعل الصوت العصبي خيارًا وهميًا في الواجهة.
        viewModelScope.launch {
            delay(280L)
            checkCloudConnection(cloudEndpoint)
        }
    }

    val isConfigured: Boolean get() = cloudEndpoint.isNotBlank()

    val currentConversationTitle: String
        get() = _conversations.firstOrNull { it.id == activeConversationId }?.title ?: "محادثة جديدة"

    val activeProject: AionProject?
        get() {
            val projectId = _conversations.firstOrNull { it.id == activeConversationId }?.projectId
            return _projects.firstOrNull { it.id == projectId }
        }

    private val builtInModels: List<AiModelOption> = listOf(
            AiModelOption(
                key = "auto",
                label = "AION Auto",
                provider = "Qwen 3.8 + توجيه تلقائي حسب المهمة",
                enabled = true,
                modelId = "auto",
                badge = "تلقائي"
            ),
            AiModelOption(
                key = "fast",
                label = "سريع",
                provider = "GLM — زمن استجابة أقل",
                enabled = true,
                modelId = "fast",
                badge = "خفيف"
            ),
            AiModelOption(
                key = "deep",
                label = "عميق",
                provider = "GPT-OSS 120B — استدلال أعمق",
                enabled = true,
                modelId = "deep",
                badge = "عميق"
            ),
            AiModelOption(
                key = "research",
                label = "بحث",
                provider = "ويب حي مع مصادر",
                enabled = true,
                modelId = "research",
                badge = "ويب"
            )
        )

    val modelOptions: List<AiModelOption>
        get() = builtInModels + cloudExternalModels.filter { remote ->
            builtInModels.none { it.key == remote.key }
        }

    val selectedModel: AiModelOption
        get() = modelOptions.firstOrNull { it.key == selectedModelKey } ?: modelOptions.first()

    fun selectModel(key: String) {
        val option = modelOptions.firstOrNull { it.key == key } ?: return
        if (option.enabled && !isSending) {
            selectedModelKey = option.key
            ChatSessionStore.saveSelectedModel(getApplication(), option.key)
            if (activeConversationId.isNotBlank()) {
                ChatSessionStore.saveConversationModel(getApplication(), activeConversationId, option.key)
            }
        }
    }

    fun updateDraft(value: String) {
        draft = value
        scheduleDraftSave()
    }

    private fun scheduleDraftSave() {
        val conversationId = activeConversationId.takeIf { it.isNotBlank() } ?: return
        val value = draft
        draftSaveJob?.cancel()
        draftSaveConversationId = conversationId
        draftSaveJob = viewModelScope.launch {
            delay(DRAFT_SAVE_DEBOUNCE_MS)
            ChatSessionStore.saveDraft(getApplication(), conversationId, value)
            if (draftSaveConversationId == conversationId) {
                draftSaveConversationId = null
                draftSaveJob = null
            }
        }
    }

    private fun flushDraftNow() {
        val conversationId = draftSaveConversationId ?: activeConversationId.takeIf { it.isNotBlank() }
        val value = draft
        draftSaveJob?.cancel()
        draftSaveJob = null
        draftSaveConversationId = null
        if (!conversationId.isNullOrBlank()) {
            ChatSessionStore.saveDraft(getApplication(), conversationId, value)
        }
    }

    fun saveSettings(endpoint: String) {
        val clean = endpoint.trim().trimEnd('/')
        if (!clean.startsWith("https://")) {
            cloudHealthOk = false
            cloudHealthLabel = "العنوان يجب أن يبدأ بـ https://"
            return
        }
        AionCloudSettings.saveEndpoint(getApplication(), clean)
        cloudEndpoint = AionCloudSettings.loadEndpoint(getApplication())
        checkCloudConnection(cloudEndpoint)
    }

    fun checkCloudConnection(endpoint: String = cloudEndpoint) {
        if (isCheckingCloud) return
        val target = endpoint.trim().trimEnd('/')
        isCheckingCloud = true
        cloudHealthEndpoint = target
        cloudHealthLabel = "جارٍ الفحص…"
        viewModelScope.launch {
            runCatching { cloudGateway.checkStatus(target) }
                .onSuccess { health ->
                    cloudHealthOk = health.ok
                    neuralVoiceAvailable = health.neuralVoiceAvailable
                    neuralVoiceProvider = health.neuralVoiceProvider
                    neuralVoiceOptions = health.voices
                    neuralVoiceDefaultKey = health.defaultVoiceKey
                    myVoiceCloudAvailable = health.myVoiceAvailable
                    myVoiceProvider = health.myVoiceProvider
                    myVoiceMaxSampleBytes = health.myVoiceMaxSampleBytes
                    cloudProviderStatuses = health.providers
                    cloudExternalModels = health.externalModels.map { remote ->
                        AiModelOption(
                            key = remote.key,
                            label = remote.label,
                            provider = remote.provider,
                            enabled = ModelCatalogPolicy.canEnableExternal(
                                remote.key,
                                remote.modelId,
                                remote.chatReady
                            ),
                            modelId = remote.key,
                            badge = remote.badge.ifBlank {
                                if (remote.chatReady) "جاهز" else if (remote.configured) "Foundation" else "غير مهيأ"
                            }
                        )
                    }
                    if (modelOptions.none { it.key == selectedModelKey && it.enabled }) {
                        selectedModelKey = "auto"
                        ChatSessionStore.saveSelectedModel(getApplication(), "auto")
                        if (activeConversationId.isNotBlank()) {
                            ChatSessionStore.saveConversationModel(getApplication(), activeConversationId, "auto")
                        }
                    }
                    cloudHealthLabel = if (health.ok) {
                        if (health.neuralVoiceAvailable) "متصل • خادم ${health.version} • صوت عصبي" else "متصل • خادم ${health.version}"
                    } else "الخادم ردّ بحالة غير جاهزة"
                }
                .onFailure { error ->
                    cloudHealthOk = false
                    neuralVoiceAvailable = false
                    neuralVoiceProvider = ""
                    neuralVoiceOptions = emptyList()
                    neuralVoiceDefaultKey = ""
                    myVoiceCloudAvailable = false
                    myVoiceProvider = ""
                    myVoiceMaxSampleBytes = MyVoicePolicy.MAX_SAMPLE_BYTES
                    cloudProviderStatuses = emptyList()
                    cloudExternalModels = emptyList()
                    cloudHealthLabel = error.message?.take(120).orEmpty().ifBlank { "تعذر الاتصال بالخادم" }
                }
            isCheckingCloud = false
        }
    }

    fun saveVoiceSettings(settings: AionVoiceSettings) {
        val clean = settings.normalized()
        VoicePreferences.saveSettings(getApplication(), clean)
        voiceSettings = clean
    }

    fun saveVoiceProfile(profileKey: String) {
        val profile = AionVoiceProfile.fromKey(profileKey)
        saveVoiceSettings(voiceSettings.copy(profile = profile))
    }

    fun createMyVoice(targetEndpoint: String, sampleFile: File, displayName: String, enrollmentSecret: String, consent: Boolean) {
        if (isMyVoiceBusy) return
        val cleanTarget = targetEndpoint.trim().trimEnd('/')
        if (!cleanTarget.startsWith("https://")) {
            myVoiceStatusLabel = "عنوان AION Cloud غير صالح"
            return
        }
        if (!myVoiceCloudAvailable || cloudHealthEndpoint != cleanTarget) {
            myVoiceStatusLabel = "اختبر اتصال عنوان AION Cloud الحالي وتأكد أن My Voice مفعّل عليه"
            return
        }
        if (!MyVoicePolicy.sampleReady(sampleFile)) {
            myVoiceStatusLabel = "العينة يجب أن تكون WAV 16 kHz أحادي PCM 16-bit ولمدة 15–90 ثانية"
            return
        }
        if (sampleFile.length() > myVoiceMaxSampleBytes) {
            myVoiceStatusLabel = "العينة أكبر من الحد الذي يسمح به AION Cloud"
            return
        }
        if (!consent) {
            myVoiceStatusLabel = "يجب تأكيد أن العينة لصوتك والموافقة على إرسالها"
            return
        }
        if (enrollmentSecret.trim().length < 16) {
            myVoiceStatusLabel = "أدخل رمز إعداد My Voice الصحيح"
            return
        }

        isMyVoiceBusy = true
        myVoiceStatusLabel = "جارٍ إنشاء My Voice…"
        viewModelScope.launch {
            runCatching {
                myVoiceGateway.create(
                    endpoint = cleanTarget,
                    sample = sampleFile,
                    displayName = displayName,
                    enrollmentSecret = enrollmentSecret,
                    consent = consent
                )
            }.onSuccess { result ->
                val credential = MyVoiceCredential(
                    token = result.token,
                    label = result.label,
                    cloudEndpoint = cleanTarget,
                    createdAtEpochMs = System.currentTimeMillis(),
                    requiresVerification = result.requiresVerification
                )
                val stored = runCatching {
                    MyVoiceCredentialStore.save(getApplication(), credential)
                    true
                }.getOrDefault(false)
                if (!stored) {
                    // Avoid leaving a provider-side clone without a local deletion capability.
                    runCatching { myVoiceGateway.delete(cleanTarget, result.token) }
                    myVoiceStatusLabel = "تعذر حفظ اعتماد My Voice بأمان؛ طُلب حذف النسخة السحابية ولم تُحذف العينة المحلية"
                    return@onSuccess
                }
                myVoiceCredential = credential
                runCatching { sampleFile.delete() }
                if (credential.usable) {
                    if (cleanTarget == cloudEndpoint.trim().trimEnd('/')) {
                        saveVoiceSettings(voiceSettings.copy(voiceKey = MyVoicePolicy.MY_VOICE_KEY))
                        myVoiceStatusLabel = "تم إنشاء My Voice وتفعيله"
                    } else {
                        myVoiceStatusLabel = "تم إنشاء My Voice؛ احفظ عنوان AION Cloud الجديد لتفعيله"
                    }
                } else {
                    myVoiceStatusLabel = "تم إنشاء الصوت، لكنه يتطلب تحققًا لدى مزود الصوت قبل الاستخدام"
                }
            }.onFailure { error ->
                myVoiceStatusLabel = error.message?.take(180).orEmpty().ifBlank { "تعذر إنشاء My Voice" }
            }
            isMyVoiceBusy = false
        }
    }

    fun deleteMyVoice() {
        if (isMyVoiceBusy) return
        val credential = myVoiceCredential
        if (!credential.exists) {
            MyVoiceCredentialStore.clear(getApplication())
            myVoiceCredential = MyVoiceCredential()
            myVoiceStatusLabel = "لا يوجد My Voice محفوظ"
            return
        }
        val deleteEndpoint = credential.cloudEndpoint.trim().trimEnd('/').takeIf { it.startsWith("https://") }
            ?: cloudEndpoint.trim().trimEnd('/')
        if (!deleteEndpoint.startsWith("https://")) {
            myVoiceStatusLabel = "لا يوجد عنوان Cloud صالح لحذف My Voice"
            return
        }
        isMyVoiceBusy = true
        myVoiceStatusLabel = "جارٍ حذف My Voice من الخادم…"
        viewModelScope.launch {
            runCatching { myVoiceGateway.delete(deleteEndpoint, credential.token) }
                .onSuccess { deleted ->
                    if (deleted) {
                        MyVoiceCredentialStore.clear(getApplication())
                        myVoiceCredential = MyVoiceCredential()
                        if (voiceSettings.voiceKey == MyVoicePolicy.MY_VOICE_KEY) {
                            saveVoiceSettings(voiceSettings.copy(voiceKey = ""))
                        }
                        myVoiceStatusLabel = "تم حذف My Voice من الخادم والجهاز"
                    } else {
                        myVoiceStatusLabel = "تعذر حذف My Voice من الخادم؛ أبقينا الاعتماد المحلي لإعادة المحاولة"
                    }
                }
                .onFailure { error ->
                    myVoiceStatusLabel = error.message?.take(180).orEmpty().ifBlank { "تعذر حذف My Voice" }
                }
            isMyVoiceBusy = false
        }
    }

    fun savePersonalization(instructions: String, memory: String) {
        LocalMemoryStore.save(getApplication(), instructions, memory)
        val snapshot = LocalMemoryStore.load(getApplication())
        customInstructions = snapshot.instructions
        memoryNotes = snapshot.memory
    }

    /**
     * حفظ صريح من المستخدم فقط. وجود مشروع نشط يعني أن الذكرى تخص المشروع دائمًا؛
     * خيار projectOnlyMemory يحدد هل تُقرأ الذاكرة العامة معه، ولا يغيّر وجهة الحفظ.
     */
    fun rememberText(text: String) {
        val clean = ProjectMemoryPolicy.normalizeEntry(text)
        if (clean.isBlank()) return

        when (ProjectMemoryPolicy.writeTarget(activeProject?.id)) {
            ProjectMemoryPolicy.WriteTarget.PROJECT -> {
                val projectId = activeProject?.id ?: return
                ProjectStore.appendMemory(getApplication(), projectId, clean)
                refreshProjects()
            }
            ProjectMemoryPolicy.WriteTarget.GLOBAL -> {
                val merged = ProjectMemoryPolicy.append(memoryNotes, clean)
                if (merged != memoryNotes.trim()) savePersonalization(customInstructions, merged)
            }
        }
    }

    fun clearActiveProjectMemory() {
        val projectId = activeProject?.id ?: return
        ProjectStore.clearMemory(getApplication(), projectId)
        refreshProjects()
    }

    fun addAttachments(items: List<ChatAttachment>) {
        if (isSending) {
            items.forEach { AttachmentLoader.deleteLocalCopy(getApplication(), it) }
            return
        }
        items.forEach { attachment ->
            if (_pendingAttachments.none { it.id == attachment.id }) {
                _pendingAttachments += attachment
            } else {
                AttachmentLoader.deleteLocalCopy(getApplication(), attachment)
            }
        }
    }

    fun removeAttachment(id: Long) {
        if (isSending) return
        val removed = _pendingAttachments.firstOrNull { it.id == id }
        _pendingAttachments.removeAll { it.id == id }
        if (removed != null) AttachmentLoader.deleteLocalCopy(getApplication(), removed)
    }

    fun clearAttachments() {
        if (isSending) return
        val removed = _pendingAttachments.toList()
        _pendingAttachments.clear()
        removed.forEach { AttachmentLoader.deleteLocalCopy(getApplication(), it) }
    }

    fun send(text: String) {
        val clean = text.trim()
        val attachments = _pendingAttachments.toList()
        if ((clean.isEmpty() && attachments.isEmpty()) || isSending) return

        if (activeConversationId.isBlank()) {
            activeConversationId = ChatSessionStore.createConversation(getApplication())
        }

        val chosen = selectedModel
        val resolvedModel = chosen.modelId.orEmpty()
        _messages += ChatMessage(
            id = nextId++,
            role = MessageRole.USER,
            text = clean,
            modelId = resolvedModel,
            modelLabel = chosen.label,
            attachments = attachments
        )
        _pendingAttachments.clear()
        updateDraft("")
        flushDraftNow()

        if (!isConfigured) {
            _messages += ChatMessage(
                id = nextId++,
                role = MessageRole.AION,
                text = "اربط عنوان AION Cloud من الإعدادات أولًا، ثم أرسل الرسالة من جديد.",
                modelId = resolvedModel,
                modelLabel = chosen.label,
                isError = true
            )
            persistMessages()
            return
        }

        requestAssistantResponse(chosen = chosen, resolvedModel = resolvedModel)
    }

    fun stopGeneration() {
        AionRunCoordinator.stop(getApplication(), activeRunId)
    }

    fun retryLastResponse() {
        val lastAssistant = _messages.lastOrNull { it.role == MessageRole.AION } ?: return
        retryResponse(lastAssistant.id)
    }

    /** يعيد التوليد من الرد المحدد بدل إعادة آخر رد خطأً عند الضغط على رد أقدم. */
    fun retryResponse(messageId: Long) {
        if (isSending || !isConfigured || activeConversationId.isBlank()) return
        val assistantIndex = _messages.indexOfFirst { it.id == messageId && it.role == MessageRole.AION }
        if (assistantIndex < 0) return
        val userIndex = (assistantIndex - 1 downTo 0).firstOrNull { _messages[it].role == MessageRole.USER } ?: return

        val assistant = _messages[assistantIndex]
        val user = _messages[userIndex]
        while (_messages.size > assistantIndex) _messages.removeAt(_messages.lastIndex)

        val chosen = modelOptions.firstOrNull { it.label == assistant.modelLabel }
            ?: modelOptions.firstOrNull { it.modelId == assistant.modelId }
            ?: modelOptions.firstOrNull { it.label == user.modelLabel }
            ?: modelOptions.firstOrNull { it.modelId == user.modelId }
            ?: selectedModel
        val resolvedModel = assistant.modelId?.takeIf { it.isNotBlank() }
            ?: user.modelId?.takeIf { it.isNotBlank() }
            ?: chosen.modelId.orEmpty()

        persistMessages()
        requestAssistantResponse(chosen = chosen, resolvedModel = resolvedModel)
    }

    /**
     * يعدّل رسالة مستخدم سابقة ثم يعيد توليد المسار من تلك النقطة.
     * هذا سلوك branch-by-truncation متعمد في α7؛ حفظ عدة فروع مرئية يأتي لاحقًا.
     */
    fun editAndResend(messageId: Long, newText: String) {
        if (isSending || activeConversationId.isBlank()) return
        val index = _messages.indexOfFirst { it.id == messageId && it.role == MessageRole.USER }
        if (index < 0) return

        val original = _messages[index]
        val clean = newText.trim()
        if (clean.isBlank() && original.attachments.isEmpty()) return

        while (_messages.size > index + 1) _messages.removeAt(_messages.lastIndex)
        _messages[index] = original.copy(text = clean)
        persistMessages()

        val chosen = modelOptions.firstOrNull { it.label == original.modelLabel }
            ?: modelOptions.firstOrNull { it.modelId == original.modelId }
            ?: selectedModel
        val resolvedModel = original.modelId?.takeIf { it.isNotBlank() } ?: chosen.modelId.orEmpty()

        if (!isConfigured) {
            _messages += ChatMessage(
                id = nextId++,
                role = MessageRole.AION,
                text = "اربط عنوان AION Cloud من الإعدادات أولًا، ثم أعد المحاولة.",
                modelId = resolvedModel,
                modelLabel = chosen.label,
                isError = true
            )
            persistMessages()
            return
        }

        requestAssistantResponse(chosen = chosen, resolvedModel = resolvedModel)
    }

    fun updateDrawerSearchQuery(value: String) {
        drawerSearchQuery = value.take(140)
        drawerSearchJob?.cancel()
        val snapshot = drawerSearchQuery
        if (snapshot.trim().length < 2) {
            isDrawerSearching = false
            _drawerSearchResults.clear()
            return
        }

        isDrawerSearching = true
        drawerSearchJob = viewModelScope.launch {
            delay(DRAWER_SEARCH_DEBOUNCE_MS)
            val results = withContext(Dispatchers.IO) {
                ChatSessionStore.searchMessages(getApplication(), snapshot, maxResults = 24)
            }
            if (drawerSearchQuery == snapshot) {
                _drawerSearchResults.clear()
                _drawerSearchResults.addAll(results)
                isDrawerSearching = false
            }
        }
    }

    fun clearDrawerSearch() {
        drawerSearchJob?.cancel()
        drawerSearchQuery = ""
        isDrawerSearching = false
        _drawerSearchResults.clear()
    }

    fun openSearchHit(hit: ConversationSearchHit) {
        if (isSending || hit.conversationId.isBlank()) return
        if (hit.conversationId != activeConversationId) {
            switchConversation(hit.conversationId)
        }
        scrollTargetMessageId = hit.messageId
        clearDrawerSearch()
    }

    fun consumeScrollTargetMessage(messageId: Long) {
        if (scrollTargetMessageId == messageId) scrollTargetMessageId = null
    }

    fun newConversation(projectId: String? = activeProject?.id) {
        if (isSending) return
        flushDraftNow()
        val id = ChatSessionStore.createConversation(getApplication(), projectId)
        switchConversation(id, flushCurrentDraft = false)
    }

    fun createProject(name: String, instructions: String = "") {
        if (isSending) return
        val project = ProjectStore.create(getApplication(), name, instructions)
        refreshProjects()
        newConversation(project.id)
    }

    fun updateProject(project: AionProject) {
        ProjectStore.update(getApplication(), project)
        refreshProjects()
    }

    fun deleteProject(projectId: String) {
        if (isSending) return
        ChatSessionStore.detachProject(getApplication(), projectId)
        ProjectStore.delete(getApplication(), projectId)
        refreshProjects()
        refreshConversations()
    }

    fun openProject(projectId: String) {
        if (isSending) return
        val target = _conversations
            .filter { it.projectId == projectId && !it.archived }
            .maxByOrNull { it.updatedAt }
        if (target != null) switchConversation(target.id) else newConversation(projectId)
    }

    fun moveConversationToProject(conversationId: String, projectId: String?) {
        if (isSending) return
        ChatSessionStore.moveToProject(getApplication(), conversationId, projectId)
        refreshConversations()
    }

    fun togglePinned(conversationId: String) {
        ChatSessionStore.togglePinned(getApplication(), conversationId)
        refreshConversations()
    }

    fun archiveConversation(conversationId: String) {
        if (isSending || conversationId.isBlank()) return
        if (conversationId == activeConversationId) flushDraftNow()
        ChatSessionStore.setArchived(getApplication(), conversationId, true)
        if (conversationId == activeConversationId) {
            val next = ChatSessionStore.loadConversations(getApplication()).firstOrNull()?.id
                ?: ChatSessionStore.createConversation(getApplication())
            activeConversationId = next
            ChatSessionStore.setActiveConversation(getApplication(), next)
            loadConversation(next, preserveDraft = true)
        }
        refreshConversations()
    }

    fun restoreConversation(conversationId: String) {
        if (isSending || conversationId.isBlank()) return
        ChatSessionStore.setArchived(getApplication(), conversationId, false)
        refreshConversations()
    }

    fun switchConversation(conversationId: String) {
        switchConversation(conversationId, flushCurrentDraft = true)
    }

    private fun switchConversation(conversationId: String, flushCurrentDraft: Boolean) {
        if (isSending || conversationId.isBlank() || conversationId == activeConversationId) return
        if (flushCurrentDraft) flushDraftNow()
        activeConversationId = conversationId
        ChatSessionStore.setActiveConversation(getApplication(), conversationId)
        loadConversation(conversationId, preserveDraft = true)
        normalizeInterruptedStreamingMessages()
        refreshConversations()
    }

    fun renameConversation(conversationId: String, title: String) {
        if (conversationId.isBlank()) return
        ChatSessionStore.renameConversation(getApplication(), conversationId, title)
        refreshConversations()
    }

    fun shareConversation(conversationId: String) {
        if (conversationId.isBlank()) return
        val summary = (conversations + archivedConversations).firstOrNull { it.id == conversationId }
        val body = ChatSessionStore.loadMessages(getApplication(), conversationId)
            .filter { it.text.isNotBlank() && !it.isStreaming }
            .joinToString("\n\n") { message ->
                val speaker = if (message.role == MessageRole.USER) "أنت" else "AION"
                "$speaker:\n${message.text.trim()}"
            }
            .take(180_000)
        if (body.isBlank()) return
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, summary?.title ?: "محادثة AION")
            putExtra(Intent.EXTRA_TEXT, body)
        }
        val chooser = Intent.createChooser(send, "مشاركة محادثة AION").apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        getApplication<Application>().startActivity(chooser)
    }

    fun deleteConversation(conversationId: String) {
        if (isSending || conversationId.isBlank()) return
        val wasActive = conversationId == activeConversationId
        val nextId = ChatSessionStore.deleteConversation(getApplication(), conversationId)
        if (wasActive) {
            activeConversationId = nextId
            loadConversation(nextId, preserveDraft = true)
        }
        refreshConversations()
    }

    private fun loadConversation(conversationId: String, preserveDraft: Boolean) {
        draftSaveJob?.cancel()
        draftSaveJob = null
        draftSaveConversationId = null
        selectedModelKey = ChatSessionStore.loadConversationModel(getApplication(), conversationId)
            .takeIf { key -> modelOptions.any { it.key == key && it.enabled } }
            ?: "auto"
        _messages.clear()
        val abandonedPending = _pendingAttachments.toList()
        _pendingAttachments.clear()
        abandonedPending.forEach { AttachmentLoader.deleteLocalCopy(getApplication(), it) }
        val restored = ChatSessionStore.loadMessages(getApplication(), conversationId)
        _messages.addAll(restored)
        nextId = (_messages.maxOfOrNull { it.id } ?: 0L) + 1L
        draft = ChatSessionStore.loadDraft(getApplication(), conversationId)
        if (!preserveDraft && draft.isNotEmpty()) updateDraft("")
    }

    private fun normalizeInterruptedStreamingMessages() {
        var changed = false
        for (index in _messages.indices) {
            val message = _messages[index]
            if (message.isStreaming) {
                _messages[index] = message.copy(isStreaming = false, wasStopped = true)
                changed = true
            }
        }
        if (changed) persistMessages()
    }

    private fun requestAssistantResponse(chosen: AiModelOption, resolvedModel: String) {
        val placeholderId = nextId++
        _messages += ChatMessage(
            id = placeholderId,
            role = MessageRole.AION,
            text = "",
            modelId = resolvedModel,
            modelLabel = chosen.label,
            isStreaming = true
        )
        isSending = true
        activity = GatewayActivity.THINKING

        val sessionMessages = _messages.filter { it.id != placeholderId }.toList()
        val eligibleMessages = selectRequestContext(
            sessionMessages.filter { !it.isError && !it.wasStopped }
        )
        val latestUserMessageId = eligibleMessages.lastOrNull { it.role == MessageRole.USER }?.id
        val requestMessages = eligibleMessages.map { message ->
            // لا نعيد إرسال ملفات كل السجل مع كل طلب. نرسل مرفقات آخر رسالة مستخدم فقط؛
            // وهذا يمنع تضخم الحمولة ويتيح استعادتها من النسخة المحلية عند Retry.
            if (message.id == latestUserMessageId) message
            else if (message.attachments.isNotEmpty()) message.copy(attachments = emptyList())
            else message
        }

        persistMessages()

        val project = activeProject
        val effectiveInstructions = buildString {
            if (customInstructions.isNotBlank()) append(customInstructions.trim())
            if (project?.instructions?.isNotBlank() == true) {
                if (isNotEmpty()) append("\n\n")
                append("تعليمات المشروع «").append(project.name).append("»:\n")
                append(project.instructions.trim())
            }
        }.take(10_000)

        val projectMemory = project?.let {
            ChatSessionStore.projectContext(getApplication(), it.id, activeConversationId)
        }.orEmpty()
        val effectiveMemory = ProjectMemoryPolicy.composeContext(
            globalMemory = memoryNotes,
            projectName = project?.name,
            projectMemory = project?.memoryNotes.orEmpty(),
            projectOnlyMemory = project?.projectOnlyMemory == true,
            relatedProjectContext = projectMemory
        )

        activeRunId = AionRunCoordinator.start(
            context = getApplication(),
            conversationId = activeConversationId,
            placeholderId = placeholderId,
            modelId = resolvedModel,
            modelLabel = chosen.label,
            messages = requestMessages,
            sessionMessages = sessionMessages,
            forceWebSearch = chosen.key == "research" || shouldForceWebSearch(requestMessages),
            customInstructions = effectiveInstructions,
            memoryContext = effectiveMemory
        )

        // الطلب احتفظ بنسخته غير القابلة للتغيير، لذلك نستطيع تحرير Base64 من حالة الواجهة
        // فورًا. يبقى localPath لاستعادة الملف عند Retry، وهذا يمنع تضخم RAM في محادثات الصور.
        releaseAttachmentPayloadsFromUi()
    }

    /**
     * يحافظ على مرساة صغيرة من بداية المحادثة مع أحدث الرسائل.
     * نافذة السياق مشتركة مع بوابة الشبكة حتى لا تختلف قواعد القص بين طبقات التطبيق.
     */
    private fun selectRequestContext(messages: List<ChatMessage>): List<ChatMessage> =
        com.aion.mobile.core.ai.ContextWindow.select(
            messages = messages,
            maxMessages = MAX_REQUEST_MESSAGES,
            anchorMessages = CONTEXT_ANCHOR_MESSAGES
        )

    private fun releaseAttachmentPayloadsFromUi() {
        for (index in _messages.indices) {
            val message = _messages[index]
            if (message.attachments.none { it.base64Data.isNotBlank() }) continue
            _messages[index] = message.copy(
                attachments = message.attachments.map { attachment ->
                    if (attachment.base64Data.isBlank()) attachment else attachment.copy(base64Data = "")
                }
            )
        }
    }

    private fun shouldForceWebSearch(messages: List<ChatMessage>): Boolean {
        val text = messages.lastOrNull { it.role == MessageRole.USER }?.text
            ?.lowercase()
            ?.replace("إ", "ا")
            ?.replace("أ", "ا")
            ?.replace("آ", "ا")
            .orEmpty()
        if (text.isBlank()) return false

        return listOf(
            "ابحث", "بحث في الويب", "ابحث في الويب", "فتش في الويب", "دور في الويب", "دور بالويب",
            "من الانترنت", "من الإنترنت", "على الانترنت", "على الإنترنت", "مصادر حديثة", "اخر الاخبار",
            "آخر الأخبار", "احدث الاخبار", "أحدث الأخبار", "اخر تحديث", "آخر تحديث", "احدث اصدار",
            "أحدث إصدار", "سعر اليوم", "الطقس", "نتيجة المباراة", "متوفر حاليا", "متوفر حاليًا"
        ).any { phrase ->
            val normalized = phrase.lowercase().replace("إ", "ا").replace("أ", "ا").replace("آ", "ا")
            text.contains(normalized)
        }
    }

    private fun applyRunSnapshot(snapshot: AionRunSnapshot) {
        if (snapshot.conversationId.isNotBlank() && snapshot.conversationId != activeConversationId) {
            if (!snapshot.isRunning) refreshConversations()
            return
        }

        activeRunId = if (snapshot.isRunning) snapshot.runId else null
        isSending = snapshot.isRunning
        activity = if (snapshot.isRunning) snapshot.activity else null

        val index = _messages.indexOfFirst { it.id == snapshot.placeholderId }
        val updated = ChatMessage(
            id = snapshot.placeholderId,
            role = MessageRole.AION,
            text = snapshot.text,
            modelId = snapshot.modelId,
            modelLabel = snapshot.modelLabel,
            sources = snapshot.sources,
            isError = snapshot.errorText != null,
            isStreaming = snapshot.isRunning,
            wasStopped = snapshot.wasStopped
        )

        when {
            index >= 0 && snapshot.wasStopped && snapshot.text.isBlank() -> _messages.removeAt(index)
            index >= 0 -> _messages[index] = updated
            snapshot.text.isNotBlank() || snapshot.isRunning -> _messages += updated
        }

        if (!snapshot.isRunning) {
            // AionRunService حفظ النتيجة النهائية/الإيقاف/الخطأ قبل نشر هذه اللقطة.
            // إعادة الحفظ هنا كانت تكتب السجل والفهرس مرتين بلا فائدة.
            refreshConversations()
        }
    }

    private fun persistMessages() {
        if (activeConversationId.isBlank()) return
        ChatSessionStore.saveMessages(getApplication(), activeConversationId, _messages)
        refreshConversations()
    }

    private fun refreshConversations() {
        applyConversationBuckets(ChatSessionStore.loadConversationBuckets(getApplication()))
    }

    private fun applyConversationBuckets(buckets: ConversationBuckets) {
        _conversations.clear()
        _conversations.addAll(buckets.active)
        _archivedConversations.clear()
        _archivedConversations.addAll(buckets.archived)
    }

    private fun recordStartupFailure(error: Throwable) {
        runCatching {
            val dir = File(getApplication<Application>().filesDir, "aion_diagnostics").apply { mkdirs() }
            File(dir, "last_startup_error.txt").writeText(
                buildString {
                    appendLine("AION startup recovery")
                    appendLine("version=2.0.0-alpha7.2.1")
                    appendLine("type=${error::class.java.name}")
                    appendLine("message=${error.message.orEmpty()}")
                    appendLine()
                    append(error.stackTraceToString().take(24_000))
                }
            )
        }
    }

    private fun refreshProjects() {
        _projects.clear()
        _projects.addAll(ProjectStore.load(getApplication()))
    }

    override fun onCleared() {
        drawerSearchJob?.cancel()
        flushDraftNow()
        super.onCleared()
    }

    private companion object {
        const val MAX_REQUEST_MESSAGES = 120
        const val CONTEXT_ANCHOR_MESSAGES = 4
        const val DRAFT_SAVE_DEBOUNCE_MS = 400L
        const val DRAWER_SEARCH_DEBOUNCE_MS = 180L
    }

}
