# خطة فحص AION α7.2

## بوابة الإصدار
لا يُسمى APK «α7.2 معتمد» إلا بعد نجاح Unit Test + Lint + assembleDebug، رفع Artifact، ثم نجاح نشر aion-core.

## P0 — الدردشة والاستمرارية
1. محادثة جديدة: أول token يظهر قبل اكتمال الرد.
2. Stop بعد وصول نص: يبقى الجزء الظاهر بعلامة stopped بلا duplicate.
3. Retry يعيد الرد المحدد لا آخر رد عشوائي.
4. تعديل رسالة مستخدم قديمة يحذف ما بعدها من الفرع الحالي ويولد من النقطة الصحيحة.
5. الخروج أثناء الرد ثم العودة: نفس conversationId يستقبل النتيجة.
6. التبديل بين محادثتين لا يخلط الرسائل أو المسودات.
7. حذف محادثة غير نشطة/مؤرشفة لا يبدل المحادثة المفتوحة.

## P0 — المشاريع
1. إنشاء مشروع يفتح محادثة داخله.
2. تعليمات المشروع تدخل في الطلبات داخل المشروع فقط.
3. محادثة ثانية في المشروع تستطيع الاستفادة من سياق مختصر من محادثات المشروع السابقة.
4. project-only memory ON: الذاكرة العامة لا تدخل في المشروع.
5. project-only memory OFF: الذاكرة العامة + ذاكرة المشروع + سياق المشروع تعمل معًا.
6. زر «تذكّر» داخل أي محادثة مرتبطة بمشروع يكتب في ذاكرة ذلك المشروع، سواء كان project-only ON أو OFF.
7. زر «تذكّر» خارج المشاريع يكتب في الذاكرة العامة فقط.
8. حفظ الذكرى نفسها مرتين لا يكررها بعد تطبيع التعداد والمسافات.
9. مسح ذاكرة مشروع لا يمس الذاكرة العامة ولا محادثات المشروع.
10. نقل محادثة من/إلى مشروع يحفظ الرسائل ويغيّر نطاق الذكريات الجديدة وفق المشروع الحالي.
11. حذف المشروع لا يحذف المحادثات؛ يفصل projectId فقط وتُحذف ذاكرة المشروع مع تعريف المشروع.

## P0 — سجل المحادثات
1. البحث يطابق العنوان والمعاينة ومحتوى الرسائل وأسماء المرفقات واسم المشروع.
2. المحادثات القديمة من α7.1 تحصل على Search Index مرة واحدة بلا فقد.
3. Pin يصعد المحادثة أعلى السجل.
4. Archive يخفيها من السجل، وقسم الأرشيف يستطيع Restore/Delete.
5. Share يفتح Android Share Sheet بنص المحادثة.

## P0 — المرفقات والرؤية
1. JPG/PNG/WebP كبير: يُصغّر حتى 2048px تقريبًا ويظل أقل من 5MB قبل الإرسال.
2. صورة صغيرة: لا يعاد ترميزها دون حاجة.
3. صورة: تمر إلى Vision مباشرة وليست toMarkdown.
4. TXT/MD/JSON/كود: يقرأ المحتوى الحقيقي.
5. PDF/DOCX/XLSX: تظهر حالة «يقرأ المرفقات» ثم جواب مبني على المحتوى.
6. إعادة فتح محادثة: المرفق يُستعاد من النسخة الداخلية عند Retry.
7. ملف مفقود: رفض واضح بدل ادعاء قراءته.

## P0 — النماذج والبحث
1. Auto يبدأ بـQwen 3.8 27B، ثم fallback قبل أول token فقط.
2. Fast يبدأ بـGLM-4.7-Flash.
3. Deep يبدأ بـGPT-OSS-120B.
4. Vision/Research يستخدم Qwen 3.8 ويستطيع fallback إلى Gemma 4.
5. Auto لطلب تحليلي/برمجي طويل ينتقل إلى mode=deep تلقائيًا.
6. بحث بلا Firecrawl يستخدم Workers AI Web Search ولا يعرض خطأ إعداد Firecrawl.
7. إذا أعاد النموذج citations/annotations، تصل المصادر إلى Android.
8. لا يبدأ نموذج احتياط بعد وصول جزء من النص إذا كان سيكرر الإجابة.
9. conversationId يصل إلى Workers AI كـx-session-affinity.

## P1 — عرض الردود
1. Markdown: headings/bullets/numbered/quote/divider/bold/inline-code صحيحة.
2. fenced code يظهر monospace + LTR + horizontal scroll + copy.
3. الرد قابل لتحديد النص.
4. مصادر البحث تظهر كبطاقة وتفتح الروابط.
5. مشاركة رد AION تشمل النص والمصادر.

## P1 — Composer والتمرير
1. Composer لا يختفي خلف لوحة المفاتيح.
2. صور المرفقات لها preview حقيقي.
3. أثناء Streaming يبقى Auto-follow ما لم يصعد المستخدم يدويًا.
4. بعد الصعود يظهر «آخر رد» ولا يسحب المستخدم بالقوة.

## P1 — الصوت
1. Orb ساكن نسبيًا عند الصمت ويتغير مع RMS عند الكلام.
2. SpeechRecognizer لا يوقف الدور بسرعة شديدة بعد وقفة قصيرة.
3. أخطاء network/busy المؤقتة يعاد الاستماع بعدها تلقائيًا.
4. TTS يختار أفضل صوت متاح للغة الجهاز.
5. النقر أثناء SPEAKING يوقف TTS ويعود للاستماع.
6. mute/end لا يتركان recognizer أو TTS عالقًا.

## اختبارات Worker المحلية
```bash
node --check cloudflare/aion-core/src/index.js
node cloudflare/aion-core/test-worker.mjs
```
المتوقع: `AION worker tests: PASS`.

### α7.2 / الخطوة 3 — الأداء
- [x] StreamingRenderPolicy: أول جزء مرئي يظهر مباشرة.
- [x] StreamingRenderPolicy: الدفعات الصغيرة المتقاربة تُدمج بدل تحديث Compose لكل token.
- [x] StreamingRenderPolicy: مرور 48ms أو وصول 96 حرفًا يسمح بتحديث جديد.
- [x] checkpoint الجديد يكتب الرد الجاري فقط في ملف sidecar بدل إعادة كتابة سجل المحادثة كاملًا.
- [x] الحفظ النهائي يحذف checkpoint؛ والاستعادة تدمجه فقط إذا ظل الرد في حالة Streaming.
- [x] Worker regression: `AION worker tests: PASS`.
- [x] فحص parser ساكن للملفات المعدلة: لا توجد diagnostics من نوع `expecting/unexpected tokens/redeclaration`.
- [ ] Android unit tests + lint + assembleDebug على GitHub Actions عند إغلاق جولة α7.2.
- [ ] اختبار يدوي على هاتف: كتابة مسودة طويلة ثم تبديل المحادثة فورًا والتأكد من عدم فقدها.
- [ ] اختبار يدوي: رد طويل Streaming مع مراقبة السلاسة وعدم تقطع التمرير.
- [ ] اختبار يدوي: البحث داخل 100+ محادثة ومقارنة زمن الاستجابة قبل/بعد.

### α7.2 / الخطوة 4 — الواجهة وتجربة الاستخدام
- [x] شاشة البداية تحتوي أربع إجراءات واضحة في شبكة 2×2 ولا تعتمد على LazyRow فقط.
- [x] الرسائل/Composer لهما max content width مناسب للشاشات الكبيرة.
- [x] إرسال رسالة مستخدم يعيد Auto-follow حتى لو كان المستخدم قد صعد سابقًا.
- [x] الصعود أثناء Streaming يوقف المتابعة القسرية ويظهر زر الرجوع للأسفل/عدد الرسائل الجديدة.
- [x] أفعال المستخدم مخفية افتراضيًا وتظهر بالنقر؛ أفعال AION تظهر بعد اكتمال الرد.
- [x] Live thinking يعرض النشاط الحقيقي واسم الوضع/النموذج.
- [x] Composer يعرض focus/listening state بصريًا بدون تغيير منطق الإرسال الأساسي.
- [x] Pending image attachment يعرض thumbnail حقيقي + الاسم + الحجم + إزالة.
- [x] صورة الرسالة قابلة للفتح في Preview أكبر وإغلاقها دون مغادرة المحادثة.
- [x] Drawer search يملك clear action ويبحث بنفس الفهرس المحلي السابق.
- [x] Model picker copy يطابق السلوك الحقيقي: الاختيار لهذه المحادثة وليس للرسالة التالية فقط.
- [x] لا يوجد نص 8sp متبقٍ في `AionApp.kt` بعد جولة قابلية القراءة.
- [x] Kotlin parser diagnostics: 0 للأخطاء النحوية المستهدفة.
- [x] Theme XML parsing: PASS.
- [x] Worker regression: PASS.
- [ ] اختبار يدوي على هاتف 360–430dp: بطاقات البداية لا تقطع النص ولا تتداخل.
- [ ] اختبار يدوي: فتح صورة كبيرة ثم إغلاقها أثناء محادثة طويلة.
- [ ] اختبار يدوي مع لوحة المفاتيح العربية: Composer يتمدد حتى 7 أسطر ولا يقفز خلف IME.
- [ ] اختبار يدوي أثناء Streaming: الصعود 5–10 رسائل ثم وصول محتوى جديد دون سحب الشاشة.
- [ ] Android Unit + Lint + assembleDebug على GitHub Actions عند إغلاق الجولة.

### α7.2 / الخطوة 5 — الصوت والمكالمة
- [x] مستوى الميكروفون في واجهة المكالمة يعتمد على `onRmsChanged` وليس مؤقت Animation ثابت.
- [x] مستوى AION أثناء TTS يعتمد على PCM الحقيقي من `onAudioAvailable` مع دعم PCM 8/16/Float.
- [x] VoiceAmplitude: الصمت = 0، PCM فعلي ينتج مستوى مرئي، والتنعيم يرفع بسرعة ويهبط تدريجيًا.
- [x] الضغط على الدائرة أثناء `SPEAKING` يوقف TTS ويطلب الاستماع مباشرة.
- [x] زر الإيقاف أثناء `THINKING/SEARCHING` يوقف التوليد ثم يعيد الاستماع ما لم يكن الميكروفون مكتومًا.
- [x] mute مستقل عن حالة SPEAKING ولا يوقف كلام AION.
- [x] أخطاء SpeechRecognizer المؤقتة تستخدم backoff بدل إعادة تشغيل متقاربة بلا حد.
- [x] 4 أعطال شبكة متتالية في التعرف الصوتي تنتقل إلى حالة تحتاج ضغطة المستخدم بدل loop لا نهائي.
- [x] cancel المقصود للRecognizer عند بدء الرد لا يعرض ERROR_CLIENT وهميًا.
- [x] الرد الذي يصل قبل جاهزية TTS لا يُعلّم كمقروء قبل تهيئة المحرك.
- [x] فواصل الصمت في Voice Call وComposer مضبوطة إلى 900/520ms تقريبًا وحد أدنى 350ms.
- [x] TTS يستخدم AudioAttributes للمساعد ومقاطع قراءة أقصر لتحسين زمن البداية والمقاطعة.
- [x] إغلاق المكالمة يدمر SpeechRecognizer ويوقف/يغلق TTS ويمسح callbacks.
- [x] Kotlin smoke tests لطبقة الصوت: PASS.
- [x] Worker regression: PASS.
- [ ] اختبار يدوي على الهاتف: الدائرة لا تتحرك أثناء صمت المستخدم.
- [ ] اختبار يدوي على الهاتف: حركة الدائرة تتغير مع شدة صوت المستخدم لا بنمط دوري.
- [ ] اختبار يدوي على الهاتف: أثناء كلام AION، الحركة تتبع نطق TTS وتتوقف عند نهاية الصوت.
- [ ] اختبار يدوي: مقاطعة AION في منتصف جواب طويل ثم قول سؤال جديد دون سماع بقية الجواب القديم.
- [ ] اختبار يدوي: كتم الميكروفون أثناء كلام AION ثم فك الكتم بعد انتهاء الرد.
- [ ] اختبار يدوي: مكالمة 10 أدوار متتالية بالعربية دون Recognizer busy loop أو TTS عالق.
- [ ] اختبار يدوي: إغلاق شاشة المكالمة أثناء LISTENING وأثناء SPEAKING والتأكد من توقف الميكروفون/الصوت فورًا.
- [ ] Android Unit + Lint + assembleDebug على GitHub Actions ضمن الخطوة 6.

### α7.2 / الخطوة 6 — فحص ما قبل GitHub
- [x] Worker JavaScript syntax: PASS.
- [x] Worker regression suite: `AION worker tests: PASS`.
- [x] Android Manifest + resource XML parsing: PASS.
- [x] Kotlin core smoke: ContextWindow + ProjectMemoryPolicy + StreamingRenderPolicy + VoiceAmplitude + VoiceTurnPolicy = PASS.
- [x] التحقق من `versionCode 13` و`2.0.0-alpha7.2`.
- [x] فحص نصي للبحث عن API keys/tokens الحقيقية في المصدر: لا أسرار تطبيقية مكتشفة.
- [ ] GitHub Actions: `testDebugUnitTest`.
- [ ] GitHub Actions: `lintDebug`.
- [ ] GitHub Actions: `assembleDebug`.
- [ ] GitHub Actions: رفع APK Artifact.
- [ ] GitHub Actions: نشر `aion-core`.
- [ ] Smoke test يدوي على الهاتف بعد تثبيت APK.

### α7.3 / STEP5 Point 3 — My Voice
- [x] MyVoicePolicy: مدة WAV محسوبة من PCM 16 kHz mono/16-bit وحدود 15–90 ثانية.
- [x] enrollment لا يُسمح به دون Cloud support + عينة صالحة + موافقة صريحة + owner enrollment secret قوي.
- [x] تسجيل العينة محلي فقط ولا يرسلها أثناء التسجيل.
- [x] Worker status لا يكشف enrollment secret ولا provider API key.
- [x] Worker يرفض owner secret الخاطئ قبل استدعاء مزود الصوت.
- [x] Worker ينشئ My Voice ويعيد capability token موقّعًا عند التهيئة الصحيحة.
- [x] TTS لـ`my_voice` يرفض token غير الصالح ويستخدم voice id المستخرج من token الصالح فقط.
- [x] حذف My Voice يستخدم token ثم يطلب حذف الصوت من المزود.
- [x] Worker regression suite: PASS.
- [x] XML parsing + Kotlin lexical delimiter scan + MyVoicePolicy compile: PASS محليًا.
- [ ] Android Unit + Lint + assembleDebug على GitHub Actions لـdev8.
- [ ] اختبار هاتف: رفض إذن الميكروفون لا يسبب crash ولا ينشئ ملفًا صالحًا.
- [ ] اختبار هاتف: تسجيل أقل من 15 ثانية يبقى غير صالح للإنشاء.
- [ ] اختبار هاتف: تسجيل 15–90 ثانية يظهر المدة والحجم ويقبل الحذف المحلي.
- [ ] اختبار هاتف: لا يبدأ enrollment قبل تحديد الموافقة الصريحة.
- [ ] اختبار هاتف: بعد نجاح enrollment تختفي العينة المحلية ويصبح «صوتي» قابلًا للاختيار والمعاينة.
- [ ] اختبار هاتف: My Voice يعمل في قراءة الردود وAION Live، مع fallback محلي عند تعطل Cloud.
- [ ] اختبار هاتف: حذف My Voice يمسح الصوت البعيد أولًا ثم الاعتماد المحلي؛ فشل الحذف البعيد لا يمسح token محليًا.
