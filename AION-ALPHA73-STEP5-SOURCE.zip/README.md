# AION Mobile V2 α7.3-dev7 — Neural Voice Settings

AION هو تطبيق ذكاء شخصي لـAndroid بواجهة عربية أولًا وهوية مستقلة. الإصدار التطويري α7.3-dev7 يبني فوق α7.2.1 المستقرة، ويركز حاليًا على إعادة تأسيس الواجهة والبحث والمرفقات وAION Live مع الحفاظ على حماية الترقية وبيانات المستخدم.

## ما يعمل في α7.3-dev7 محليًا
- محادثات متعددة محليًا مع بحث داخل محتوى الرسائل، مسودة مستقلة، Pin، Archive/Restore، Share، ونقل المحادثة إلى Project.
- Projects محلية فعلية: تعليمات مشروع، ذاكرة مشروع مستقلة، وخيار عزل الذاكرة العامة.
- Streaming حقيقي عبر AION Cloud/Workers AI مع Stop، Retry، حفظ checkpoint خفيف، واستمرار المهمة في Foreground Service.
- نافذة سياق للمحادثات الطويلة تحفظ بداية المهمة مع أحدث الرسائل بدل إسقاط البداية بالكامل.
- أوضاع AION:
  - Auto / General: Qwen 3.8 27B.
  - Fast: GLM-4.7-Flash.
  - Deep: GPT-OSS-120B.
  - Vision / Research: Qwen 3.8 27B مع Gemma 4 كاحتياط عند الحاجة.
- بحث ويب حي مع Workers AI Web Search، واستخدام Firecrawl اختياريًا عند وجود `FIRECRAWL_API_KEY`.
- مرفقات فعلية: صور، نص، كود، PDF وOffice؛ الصور تمر إلى Vision مباشرة، والمستندات تُحوّل على Cloud عند الحاجة.
- عرض Markdown موسع يشمل العناوين والقوائم والاقتباسات والكود والجداول القابلة للتمرير.
- ذاكرة محلية صريحة + ذاكرة مستقلة لكل Project.
- AION Live داخل المحادثة نفسها: Fullscreen + Mini Orb + Typed interruption + Manual/Best-effort voice barge-in، وحركة تعتمد على RMS/PCM الحقيقي.
- Neural Voice: Voice Catalog خادمي، اختيار صوت فعلي مع ذكر/أنثى/محايد حسب Catalog، Preview، Presets، وضبط speed/expression/clarity محفوظ محليًا ومستخدم في Live وقراءة الردود.
- تحسينات أداء في Streaming، فهرس المحادثات، البحث المحلي، المسودات، الصور، وعمليات التخزين.
- اتصالات HTTPS فقط مع تعطيل Android Backup لمحادثات ومرفقات AION في نسخة التطوير الحالية.

## ما لا ندعي أنه مكتمل
- My Voice / استنساخ صوت المستخدم لم يُنفذ بعد؛ يحتاج enrollment وموافقة وخصوصية صريحة.
- Full-Duplex speech-to-speech الحقيقي ما زال مرحلة لاحقة.
- Agent runtime متعدد الأدوات ما زال Foundation وليس وكيل تنفيذ كاملًا.
- Claude/Gemini/Grok غير متصلين في هذا الإصدار ولا تُعرض خيارات وهمية فعالة لهم.
- الذاكرة لا تستخرج تلقائيًا كل حقيقة من جميع المحادثات؛ الحفظ الصريح هو المسار الموثوق حاليًا.
- المزامنة السحابية متعددة الأجهزة ليست جزءًا من α7.2.

## إصدار Android
- `versionCode = 21`
- `versionName = 2.0.0-alpha7.3-dev7`
- `minSdk = 26`
- `targetSdk = 36`
- `compileSdk = 36`

## البناء الرسمي
المتطلبات الحالية:
- Java 17
- Android SDK 36 / Build Tools 36.0.0
- Gradle 9.6.1 في GitHub Actions

بوابة Android:
```bash
gradle :app:testDebugUnitTest :app:lintDebug :app:assembleDebug --stacktrace --no-daemon
```

اختبارات Worker المحلية:
```bash
node --check cloudflare/aion-core/src/index.js
node cloudflare/aion-core/test-worker.mjs
```

المتوقع: `AION worker tests: PASS`.

## Cloudflare
`cloudflare/aion-core/wrangler.toml` يستخدم Workers AI binding باسم `AI`. البحث الحي يعمل عبر Workers AI Web Search حتى دون Firecrawl. الصور تُرسل كرؤية أصلية إلى Qwen 3.8، مع Gemma 4 كمسار احتياطي للرؤية/البحث عند الحاجة.

## بوابة اعتماد α7.2.1
لا يعتبر APK معتمدًا إلا بعد نجاح GitHub Actions في:
1. Unit Tests.
2. Android Lint.
3. `assembleDebug`.
4. رفع Artifact.
5. نشر `aion-core` بنجاح.

ثم تُنفذ اختبارات الهاتف الواردة في `ALPHA7_TEST_PLAN_AR.md`، خصوصًا Streaming، Projects، الصور، البحث، المكالمة الصوتية، وإدارة المرفقات.
