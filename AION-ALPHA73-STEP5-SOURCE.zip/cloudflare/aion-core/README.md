# AION α7.3 Obsidian Core

Cloudflare Worker لـAION. مفاتيح المزودات تبقى في الخادم ولا تدخل APK.

## المسارات

- `GET /health` فحص عام وقدرات الخادم.
- `GET /v1/status` حالة النسخة والنماذج والصوت.
- `POST /v1/chat` محادثة متزامنة.
- `POST /v1/chat/stream` بث SSE حقيقي للمحادثة.
- `POST /v1/voice/tts` بث PCM 24 kHz للصوت العصبي عند تفعيله.

## Neural Voice (اختياري)

AION يعمل دائمًا مع Android TTS كمسار احتياطي. لتفعيل الصوت العصبي على الخادم:

- Secret: `ELEVENLABS_API_KEY`
- للتوافق الخلفي: `AION_VOICE_ID` لصوت واحد.
- للأصوات المتعددة: `AION_VOICES_JSON` حتى 12 صوتًا، مثل:

```json
[
  {"key":"male_1","label":"AION Male","gender":"male","voiceId":"<provider-voice-id>"},
  {"key":"female_1","label":"AION Female","gender":"female","voiceId":"<provider-voice-id>"}
]
```

- Optional var: `AION_DEFAULT_VOICE_KEY` لاختيار الصوت الافتراضي من الـCatalog.
- Optional var: `ELEVENLABS_MODEL_ID` (الافتراضي `eleven_flash_v2_5`).

`/v1/status` يعرض للتطبيق فقط `key / label / gender / defaultVoice` ولا يعرض `voiceId` أو مفاتيح المزود. `/v1/voice/tts` يقبل `voice` و`profile` وضبطًا اختياريًا `speed / expression / clarity` وتُقيد القيم على الخادم. عند غياب الصوت العصبي أو حدوث فشل مؤقت يعود Android إلى TTS المحلي.

## الحماية الحالية

يطبّق Worker حدًا أوليًا للطلبات لكل IP داخل النسخة التجريبية. قبل النشر العام نحتاج مصادقة مستخدم، Rate Limiting دائم، وحصص مستقلة لمسار الصوت لأنه مدفوع لكل حرف.
