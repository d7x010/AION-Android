# AION α7.3 Obsidian Core

Cloudflare Worker لـAION. مفاتيح المزودات تبقى في الخادم ولا تدخل APK.

## المسارات

- `GET /health` فحص عام وقدرات الخادم.
- `GET /v1/status` حالة النسخة والنماذج والصوت.
- `POST /v1/chat` محادثة متزامنة.
- `POST /v1/chat/stream` بث SSE حقيقي للمحادثة.
- `POST /v1/voice/tts` بث PCM 24 kHz للصوت العصبي عند تفعيله.

## Neural Voice (اختياري)

AION يعمل دائمًا مع Android TTS كمسار احتياطي. لتفعيل الصوت العصبي على الخادم:

- Secret: `ELEVENLABS_API_KEY`
- Secret/var: `AION_VOICE_ID`
- Optional var: `ELEVENLABS_MODEL_ID` (الافتراضي `eleven_flash_v2_5`)

لا تضع هذه القيم داخل تطبيق Android أو داخل المستودع. عند غيابها يعيد `/v1/voice/tts` حالة 503 صريحة ويعود التطبيق تلقائيًا للصوت المحلي.

## الحماية الحالية

يطبّق Worker حدًا أوليًا للطلبات لكل IP داخل النسخة التجريبية. قبل النشر العام نحتاج مصادقة مستخدم، Rate Limiting دائم، وحصص مستقلة لمسار الصوت لأنه مدفوع لكل حرف.

### STEP5: Voice Catalog (اختياري)

لأكثر من صوت، يمكن تعريف `AION_VOICES_JSON` كمتغير/Secret خادمي بصيغة JSON، مثال بنيوي فقط:

```json
[
  {"key":"male_1","label":"AION Male","gender":"male","voiceId":"<provider-voice-id>"},
  {"key":"female_1","label":"AION Female","gender":"female","voiceId":"<provider-voice-id>"}
]
```

الخادم يعيد للتطبيق `key/label/gender` فقط ولا يعيد `voiceId`. يبقى `AION_VOICE_ID` القديم مدعومًا كخيار توافق خلفي عندما لا يوجد Catalog.
