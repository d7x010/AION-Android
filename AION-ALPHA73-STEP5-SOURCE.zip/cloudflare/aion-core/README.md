# AION α7.3 Obsidian Core

Cloudflare Worker لـAION. مفاتيح المزودات تبقى في الخادم ولا تدخل APK.

## المسارات

- `GET /health` فحص عام وقدرات الخادم.
- `GET /v1/status` حالة النسخة والنماذج والصوت.
- `POST /v1/chat` محادثة متزامنة.
- `POST /v1/chat/stream` بث SSE حقيقي للمحادثة.
- `POST /v1/voice/tts` بث PCM 24 kHz للصوت العصبي عند تفعيله.
- `POST /v1/voice/my-voice` enrollment محمي لإنشاء My Voice.
- `DELETE /v1/voice/my-voice` حذف My Voice باستخدام capability token.

## Neural Voice (اختياري)

AION يعمل دائمًا مع Android TTS كمسار احتياطي. لتفعيل الصوت العصبي على الخادم:

- Secret: `ELEVENLABS_API_KEY`
- Secret/var: `AION_VOICE_ID`
- Optional var: `ELEVENLABS_MODEL_ID` (الافتراضي `eleven_flash_v2_5`)

لا تضع هذه القيم داخل تطبيق Android أو داخل المستودع. عند غيابها يعيد `/v1/voice/tts` حالة 503 صريحة ويعود التطبيق تلقائيًا للصوت المحلي.

## الحماية الحالية

يطبّق Worker حدًا أوليًا للطلبات لكل IP داخل النسخة التجريبية. قبل النشر العام نحتاج مصادقة مستخدم، Rate Limiting دائم، وحصص مستقلة لمسار الصوت لأنه مدفوع لكل حرف.

### STEP5: Voice Catalog (اختياري)

لأكثر من صوت، يمكن تعريف `AION_VOICES_JSON` كمتغير/Secret خادمي بصيغة JSON، مثال بنيوي فقط:

```json
[
  {"key":"male_1","label":"AION Male","gender":"male","voiceId":"<provider-voice-id>"},
  {"key":"female_1","label":"AION Female","gender":"female","voiceId":"<provider-voice-id>"}
]
```

الخادم يعيد للتطبيق `key/label/gender` فقط ولا يعيد `voiceId`. يبقى `AION_VOICE_ID` القديم مدعومًا كخيار توافق خلفي عندما لا يوجد Catalog.


### STEP5: My Voice (Alpha / owner-only enrollment)

My Voice غير مفتوح للعامة افتراضيًا. لتفعيله على AION Cloud يجب وجود:

- `ELEVENLABS_API_KEY` كـSecret.
- `AION_MY_VOICE_ENROLLMENT_SECRET` كـSecret قوي لا يقل عن 16 محرفًا.

مثال إعداد السر فقط (لا تكتب قيمة السر في المستودع):

```bash
wrangler secret put AION_MY_VOICE_ENROLLMENT_SECRET
```

التطبيق يطلب هذا الرمز أثناء enrollment فقط ولا يحفظه. بعد إنشاء الصوت يعيد Worker capability token موقّعًا ويخزنه Android مشفرًا بواسطة Keystore. لا تفعّل My Voice لمستخدمين عامّين بهذه الآلية؛ قبل النشر العام يجب استبدال owner secret بمصادقة وهوية وحصص دائمة.

العينة المحلية WAV mono 16 kHz، وحد AION الحالي 3.6 MB و15–90 ثانية. عند نجاح الإنشاء يحذف التطبيق ملف العينة المحلي. حذف My Voice يطلب حذف الصوت من المزود أولًا، ثم يمسح الاعتماد المحلي عند نجاح العملية.
