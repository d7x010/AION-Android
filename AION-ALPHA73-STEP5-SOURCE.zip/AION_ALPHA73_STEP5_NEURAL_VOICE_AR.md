# AION α7.3 — Step 5: Neural Voice

الحالة: النقطة 1 مغلقة رسميًا ببوابة GitHub، والنقطة 2 مكتملة محليًا وتنتظر البوابة الرسمية.
الإصدار: `2.0.0-alpha7.3-dev7` / versionCode 21.

## النقطة 1 — Neural Voice Core Architecture

- Voice Catalog خادمي حتى 12 صوتًا دون كشف Voice IDs للتطبيق.
- توافق خلفي مع `AION_VOICE_ID`، والإعداد المتعدد الاختياري هو `AION_VOICES_JSON`.
- `/v1/status` يعرض فقط key/label/gender/defaultVoice ومعلومات الصيغة العامة.
- `/v1/voice/tts` يقبل voice + profile + settings اختيارية: speed / expression / clarity.
- القيم تُقيد على الخادم، وAndroid يطبّعها كذلك قبل النقل.
- Android يتحقق من PCM S16LE قبل التشغيل.
- 404 و408 و429 و5xx تعود لمسار Android TTS بدل الصمت.
- AION لا يدخل SPEAKING إلا بعد وصول أول PCM فعلي.
- إضافة `NeuralVoiceContract` واختبارات Worker/Android.

## النقطة 2 — Voice Selection / Preview / Tuning

- حفظ إعداد صوت موحد محليًا: voice key + profile + speed + expression + clarity.
- قراءة Voice Catalog الحقيقي من `/v1/status` مع `defaultVoice` وsample rate، دون إنشاء أصوات وهمية داخل APK.
- سياسة اختيار واحدة: الاختيار المحفوظ إذا ما زال متاحًا، ثم defaultVoice، ثم أول صوت فعلي؛ وإذا اختفى Catalog مؤقتًا لا يُمسح الاختيار المحفوظ.
- عرض label + ذكر/أنثى/محايد، مع وسم الصوت الافتراضي الحقيقي.
- Preview عصبي من داخل الإعدادات بنفس الصوت والإعدادات التي ستستخدمها المحادثة.
- Presets: هادئ / متوازن / تعبيري، مع ضبط يدوي للسرعة والتعبير والوضوح.
- أي تغيير في الصوت أو preset أو sliders يوقف المعاينة الجارية لمنع صوت قديم عالق.
- إغلاق/حفظ نافذة الإعدادات يوقف Preview ويحرر المشغل.
- Read Aloud وAION Live يستخدمان نفس `AionVoiceSettings`.
- Android TTS fallback يطبّق سرعة المستخدم أيضًا.
- إضافة `VoiceSelectionPolicy` واختبارات normalization/fallback/presets.
- قاعدة Step 4 النهائية محفوظة: Conversation binding، Mini Orb، phase state، microphone permission، وAPI 26/27 fixes لم تُستبدل.

## ليس ضمن النقطة 2
- My Voice / enrollment: النقطة 3 وبموافقة صريحة.
- Playback arbitration polish: النقطة 4.

## Release gate
يلزم نجاح: Worker regression + `:app:testDebugUnitTest` + `:app:lintDebug` + `:app:assembleDebug` + `apksigner verify`.
