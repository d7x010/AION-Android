# AION α7.3 — Step 5: Neural Voice

الحالة: قيد التنفيذ — النقاط 1 و2 أُغلقت ببوابة Android الرسمية، والنقطة 3 My Voice مكتملة محليًا وتنتظر البوابة.
الإصدار: `2.0.0-alpha7.3-dev8` / versionCode 22.

## النقطة 1 — Neural Voice Core Architecture

- تحويل Neural Voice من صوت خادم مفرد إلى Catalog خادمي قابل للتوسع حتى 12 صوتًا دون كشف Voice IDs للتطبيق.
- توافق خلفي مع `AION_VOICE_ID` القديم؛ الإعداد الجديد الاختياري هو `AION_VOICES_JSON`.
- `/v1/status` يعرض فقط key/label/gender وdefaultVoice، ولا يعرض مفاتيح المزود أو Voice IDs.
- `/v1/voice/tts` يقبل `voice` و`profile` وتهيئة آمنة اختيارية: speed / expression / clarity.
- جميع قيم الضبط محدودة على الخادم قبل إرسالها للمزود.
- Android يتحقق أن الاستجابة PCM S16LE قبل تشغيلها.
- 429 و5xx و404/408 تعتبر Neural Voice غير متاحة مؤقتًا ويعود التطبيق للصوت المحلي بدل الصمت.
- بدء حالة التشغيل مرتبط بوصول أول PCM فعلي بدل بدء AudioTrack قبل وصول أي صوت.
- طبقة `NeuralVoiceContract` تفصل سياسة النقل/fallback عن Compose وتجهز النقاط التالية لاختيار الصوت والإعدادات وMy Voice.


## النقطة 2 — Voice Selection / Preview / Tuning

- حفظ إعداد صوت موحد يتضمن voice key + profile + speed + expression + clarity في SharedPreferences المحلية.
- استهلاك Voice Catalog الحقيقي من `/v1/status` مع اختيار آمن: المحفوظ أولًا، ثم defaultVoice، ثم أول صوت متاح.
- عدم إسقاط اختيار المستخدم إذا تعطل Catalog مؤقتًا؛ يعود الاختيار عند عودة الخادم.
- عرض أصوات الخادم الفعلية فقط مع وسم ذكر/أنثى/محايد وعدم إنشاء خيارات وهمية داخل التطبيق.
- معاينة Neural Voice من داخل الإعدادات بنفس voice/profile/tuning الذي سيستخدمه AION فعليًا.
- Presets هادئ/متوازن/تعبيري مع ضبط يدوي مستقل للسرعة والتعبير والوضوح.
- ربط الإعدادات نفسها بـAION Live وقراءة الردود، مع تطبيق سرعة المستخدم أيضًا على Android TTS عند fallback.
- إيقاف المعاينة عند تغيير الإعدادات أو إغلاق النافذة لمنع صوت عالق.
- إضافة `VoiceSelectionPolicy` واختبارات normalization/fallback/presets.

## النقطة 3 — My Voice / Enrollment / Privacy

- تسجيل عينة محلية خاصة داخل مساحة التطبيق بصيغة WAV PCM mono 16 kHz لمدة 15–90 ثانية.
- لا يُرسل التسجيل تلقائيًا؛ الإنشاء يتطلب موافقة صريحة بأن العينة لصوت المستخدم نفسه.
- حذف العينة المحلية يدويًا في أي وقت، وحذفها تلقائيًا بعد نجاح enrollment.
- اعتماد My Voice يُحفظ كـcapability token مشفر بواسطة Android Keystore؛ مفتاح ElevenLabs لا يدخل APK.
- AION Cloud يعلن My Voice كقدرة مستقلة في `/v1/status` ولا يفعّل الإنشاء افتراضيًا.
- enrollment السحابي محمي في نسخة Alpha بـ`AION_MY_VOICE_ENROLLMENT_SECRET` ولا يسمح بواجهة إنشاء عامة غير محمية.
- الخادم يمرر العينة إلى endpoint الرسمي لإنشاء IVC لدى مزود الصوت، ثم يعيد token موقّع بدل كشف اعتماد المزود كحقل مستقل.
- `/v1/voice/tts` يستطيع استخدام `my_voice` فقط مع token صالح؛ الاعتماد غير الصالح يعود لمسار fallback بدل تشغيل صوت خاطئ.
- حذف My Voice يطلب حذف النسخة لدى المزود أولًا، ثم يمسح الاعتماد المحلي فقط بعد نجاح الحذف البعيد.
- إذا تعذر حفظ token محليًا بعد الإنشاء، يطلب AION حذف النسخة البعيدة لتقليل احتمال وجود صوت يتيم.
- ربط My Voice بمعاينة الصوت وقراءة الردود وAION Live عند وجود اعتماد صالح.
- إضافة rate limit منفصل لمسار enrollment واختبارات Worker لحالات: disabled / wrong secret / create / TTS token / delete.

## ما لم يُنفذ بعد في STEP5

- استبدال رمز المالك المؤقت بنظام حساب/هوية إنتاجي قبل نشر My Voice لمستخدمين عامّين.
- التحقق التفاعلي من الحالات التي يعيد فيها المزود `requires_verification=true` سيحتاج تدفق تحقق منفصل؛ النسخة الحالية لا تختار الصوت تلقائيًا في هذه الحالة.
