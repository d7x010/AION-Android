# AION α7.3 — Step 5: Neural Voice

الحالة: النقطة 1 مكتملة محليًا وتنتظر بوابة Android الرسمية.
الإصدار: `2.0.0-alpha7.3-dev6` / versionCode 20.

## النقطة 1 — Neural Voice Core Architecture

- Voice Catalog خادمي حتى 12 صوتًا دون كشف Voice IDs للتطبيق.
- توافق خلفي مع `AION_VOICE_ID`، والإعداد المتعدد الاختياري هو `AION_VOICES_JSON`.
- `/v1/status` يعرض فقط key/label/gender/defaultVoice ومعلومات الصيغة العامة.
- `/v1/voice/tts` يقبل voice + profile + settings اختيارية: speed / expression / clarity.
- القيم تُقيد على الخادم، وAndroid يطبّعها كذلك قبل النقل.
- Android يتحقق من PCM S16LE قبل التشغيل.
- 404 و408 و429 و5xx تعود لمسار Android TTS بدل الصمت.
- AION لا يدخل SPEAKING إلا بعد وصول أول PCM فعلي.
- إضافة `NeuralVoiceContract` واختبارات Worker/Android.
- قاعدة Step 4 النهائية محفوظة: Conversation binding، Mini Orb، phase state، microphone permission، وAPI 26/27 fixes لم تُستبدل.

## ليس ضمن النقطة 1
- Voice Selection / Preview / tuning UI: النقطة 2.
- My Voice / enrollment: النقطة 3 وبموافقة صريحة.
- Playback arbitration polish: النقطة 4.

## Release gate
يلزم نجاح: Worker regression + `:app:testDebugUnitTest` + `:app:lintDebug` + `:app:assembleDebug` + `apksigner verify`.
