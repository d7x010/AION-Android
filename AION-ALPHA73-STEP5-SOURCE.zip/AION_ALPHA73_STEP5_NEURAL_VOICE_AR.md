# AION α7.3 — Step 5: Neural Voice

الحالة: قيد التنفيذ — النقطة 1 مكتملة محليًا.
الإصدار: `2.0.0-alpha7.3-dev6` / versionCode 20.

## النقطة 1 — Neural Voice Core Architecture

- تحويل Neural Voice من صوت خادم مفرد إلى Catalog خادمي قابل للتوسع حتى 12 صوتًا دون كشف Voice IDs للتطبيق.
- توافق خلفي مع `AION_VOICE_ID` القديم؛ الإعداد الجديد الاختياري هو `AION_VOICES_JSON`.
- `/v1/status` يعرض فقط key/label/gender وdefaultVoice، ولا يعرض مفاتيح المزود أو Voice IDs.
- `/v1/voice/tts` يقبل `voice` و`profile` وتهيئة آمنة اختيارية: speed / expression / clarity.
- جميع قيم الضبط محدودة على الخادم قبل إرسالها للمزود.
- Android يتحقق أن الاستجابة PCM S16LE قبل تشغيلها.
- 429 و5xx و404/408 تعتبر Neural Voice غير متاحة مؤقتًا ويعود التطبيق للصوت المحلي بدل الصمت.
- بدء حالة التشغيل مرتبط بوصول أول PCM فعلي بدل بدء AudioTrack قبل وصول أي صوت.
- طبقة `NeuralVoiceContract` تفصل سياسة النقل/fallback عن Compose وتجهز النقاط التالية لاختيار الصوت والإعدادات وMy Voice.

## ما لم يُنفذ بعد في STEP5

- واجهة اختيار الأصوات الذكر/الأنثى وPreview.
- حفظ voice key وspeed/expression/clarity في إعدادات المستخدم.
- My Voice / enrollment وإدارة الخصوصية والموافقة.

هذه البنود تُنفذ كنقاط منفصلة بعد إغلاق النقطة 1 بالاختبارات.
