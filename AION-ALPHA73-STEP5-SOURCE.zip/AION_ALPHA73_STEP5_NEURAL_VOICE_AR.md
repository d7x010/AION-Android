# AION α7.3 — Step 5: Neural Voice

الحالة: قيد التنفيذ — النقطتان 1 و2 مكتملتان محليًا، والنقطة 2 تنتظر بوابة Android الرسمية.
الإصدار: `2.0.0-alpha7.3-dev7` / versionCode 21.

## النقطة 1 — Neural Voice Core Architecture

- تحويل Neural Voice من صوت خادم مفرد إلى Catalog خادمي قابل للتوسع حتى 12 صوتًا دون كشف Voice IDs للتطبيق.
- توافق خلفي مع `AION_VOICE_ID` القديم؛ الإعداد الجديد الاختياري هو `AION_VOICES_JSON`.
- `/v1/status` يعرض فقط key/label/gender وdefaultVoice، ولا يعرض مفاتيح المزود أو Voice IDs.
- `/v1/voice/tts` يقبل `voice` و`profile` وتهيئة آمنة اختيارية: speed / expression / clarity.
- جميع قيم الضبط محدودة على الخادم قبل إرسالها للمزود.
- Android يتحقق أن الاستجابة PCM S16LE قبل تشغيلها.
- 429 و5xx و404/408 تعتبر Neural Voice غير متاحة مؤقتًا ويعود التطبيق للصوت المحلي بدل الصمت.
- بدء حالة التشغيل مرتبط بوصول أول PCM فعلي بدل بدء AudioTrack قبل وصول أي صوت.
- طبقة `NeuralVoiceContract` تفصل سياسة النقل/fallback عن Compose وتجهز النقاط التالية لاختيار الصوت والإعدادات وMy Voice.


## النقطة 2 — Voice Selection / Preview / Tuning

- حفظ إعداد صوت موحد يتضمن voice key + profile + speed + expression + clarity في SharedPreferences المحلية.
- استهلاك Voice Catalog الحقيقي من `/v1/status` مع اختيار آمن: المحفوظ أولًا، ثم defaultVoice، ثم أول صوت متاح.
- عدم إسقاط اختيار المستخدم إذا تعطل Catalog مؤقتًا؛ يعود الاختيار عند عودة الخادم.
- عرض أصوات الخادم الفعلية فقط مع وسم ذكر/أنثى/محايد وعدم إنشاء خيارات وهمية داخل التطبيق.
- معاينة Neural Voice من داخل الإعدادات بنفس voice/profile/tuning الذي سيستخدمه AION فعليًا.
- Presets هادئ/متوازن/تعبيري مع ضبط يدوي مستقل للسرعة والتعبير والوضوح.
- ربط الإعدادات نفسها بـAION Live وقراءة الردود، مع تطبيق سرعة المستخدم أيضًا على Android TTS عند fallback.
- إيقاف المعاينة عند تغيير الإعدادات أو إغلاق النافذة لمنع صوت عالق.
- إضافة `VoiceSelectionPolicy` واختبارات normalization/fallback/presets.

## ما لم يُنفذ بعد في STEP5

- My Voice / enrollment وإدارة الخصوصية والموافقة.

هذا البند يُنفذ كنقطة منفصلة بعد إغلاق النقطة 2 ببوابة Android الرسمية.
