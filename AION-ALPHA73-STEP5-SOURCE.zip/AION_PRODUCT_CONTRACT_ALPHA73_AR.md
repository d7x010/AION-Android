# AION α7.3 — Product / Design Contract

هذا الملف هو المرجع الحاكم لتطوير α7.3. أي شاشة أو مكوّن جديد يجب أن يتبع هذه القواعد ما لم تُسجَّل مراجعة صريحة.

## 1) فلسفة المنتج
- الأسلوب: **AION Obsidian / Quiet Intelligence**.
- الدردشة هادئة ومحايدة، والتعبير البصري يظهر فقط عندما يكون للنظام نشاط حقيقي.
- لا ميزات وهمية، لا أزرار بلا وظيفة، ولا Animations مستمرة للزينة.
- Primary > Secondary > Tertiary: المحتوى وComposer أولًا، المصادر والحالة ثانيًا، الأدوات النادرة خلف المزيد.

## 2) اللون
- Obsidian Background: #0B0B0E
- Surface: #111116
- Surface Raised: #18181F
- Border: #292932
- Text Primary: #F4F4F6
- Text Secondary: #A6A6B0
- AION Violet: #825CFF  = الذكاء الداخلي / التفكير / الذاكرة / Voice
- AION Blue: #4B8DFF    = الويب / المصادر / الأدوات الخارجية / الشبكة
- Success: #39D98A
- Warning: #E9B85D
- Error: #EF6A73
- لا يلوَّن النص الكامل بالحالة؛ Accent صغير فقط.
- OLED Black سيكون وضعًا منفصلًا لاحقًا، وليس Default.

## 3) Typography
- Body: 16sp / line-height 26sp.
- Secondary body: 14sp / 22sp.
- Small UI: 12sp كحد عملي أدنى في الواجهة الأساسية.
- Title: 20–22sp.
- العربية RTL أصلية. Code / URL / JSON تبقى LTR.
- الخط النهائي Prototype: Noto Sans Arabic، واختبار Noto + Beiruti للعناوين قبل الاعتماد.

## 4) Spacing / Shapes
- شبكة مسافات: 4, 8, 12, 16, 20, 24, 32dp.
- Touch target: 48dp على الأقل.
- Composer radius: 28dp.
- User bubble radius: 22dp.
- Card radius: 16–18dp.
- Chip radius: 12–14dp.
- لا نجعل كل عنصر Pill كاملًا.

## 5) Top Bar
- RTL: Menu في اليمين، AION/الوضع في الوسط، New Chat في اليسار.
- 3 عناصر أساسية فقط. Voice لا يبقى في Top Bar.
- زر المزيد يظهر حسب السياق وليس دائمًا.

## 6) الرسائل
- User: Bubble فقط، max width ~78%.
- AION: بلا Bubble عادية؛ النص على الخلفية مباشرة.
- صف الأدوات منخفض التأكيد، والمصادر منفصلة عن Actions.
- الضغط المطول يفتح الأدوات غير الشائعة.
- لا Scroll قسري إذا كان المستخدم يقرأ أعلى المحادثة.

## 7) Composer
- فارغ بلا مرفقات: + / النص / Mic Dictation / AION Live.
- عند الكتابة أو وجود مرفقات: + / النص / Send.
- أثناء التوليد: زر Send يتحول إلى Stop.
- Mic = إملاء إلى Draft فقط، لا إرسال تلقائي.
- AION Live = جلسة صوتية حيّة مرتبطة بنفس Conversation ID.
- أدوات Deep/Web/File تظهر كـContext Chips لا كصف أزرار دائم.

## 8) Activity System
لا نعرض Chain-of-Thought. نعرض فقط عملًا خارجيًا/منتجيًا حقيقيًا يمكن إثباته.
الحالات الأساسية:
- جارٍ التفكير…
- أقرأ المرفقات…
- أبحث في الويب…
- أقارن النتائج… (عند وجود إشارة حقيقية مستقبلًا)
- أصيغ الإجابة…
- أرفع الملفات…
- أعيد الاتصال…
- أستمع إليك…
- AION يتحدث…

التمثيل: Activity Mark صغير حي + نص واضح. اللون البنفسجي للداخل، الأزرق للخارج.
عند أول نص من الرد تختفي حالة الانتظار من نفس الموضع بسلاسة.

## 9) AION Live
- Fullscreen Voice يُصغّر إلى Mini Orb دون إنهاء الجلسة؛ Back/Swipe-down = Minimize، والإنهاء يحتاج زرًا صريحًا.
- النص والصوت في سجل محادثة واحد.
- الكلام أثناء كلام AION = Voice interruption. المقاطعة التلقائية تستخدم AEC عند توفره، وإلا يبقى Tap-to-interrupt كـFallback آمن.
- إرسال نص أثناء كلام AION = Typed interruption؛ يوقف الصوت الجاري فقط ويحافظ على نفس جلسة Live.
- الجلسة لا تعمل في الخلفية دون Foreground Service/إشعار واضح وفق قواعد Android.
- Mic Dictation منفصل بصريًا وسلوكيًا عن Live.
- جلسة Live مرتبطة بـConversation ID واحد؛ لا يجوز أن تقفز بصمت إلى محادثة/Project آخر أثناء استمرار الصوت.
- أثناء Live لا يغيَّر Project context للمحادثة الحية بصمت.
- Android Audio Focus وMODE_IN_COMMUNICATION يعيشان فقط مدة الجلسة ثم يُستعاد وضع الجهاز السابق.

## 10) Motion / Haptics
- Standard motion للمحادثة/Drawer/Sheets.
- Expressive motion فقط للـOrb/Live/Activity/Splash.
- أغلب الانتقالات 160–220ms.
- Haptics قليلة ودلالية: Send، Long-press، Live start، Stop/interruption.
- Reduce Motion يحترم إعداد النظام.

## 11) Android-native behavior
- Edge-to-edge + WindowInsets، لا bottom padding ثابت.
- Predictive Back لاحقًا: Voice→Mini، Viewer→Chat، Drawer→Closed.
- Adaptive layout من البداية: Phone / Medium / Tablet-Fold.
- Share-to-AION / App Shortcuts / Widget في مراحل لاحقة.

## 12) Release Safety
- كل ترقية بيانات لها schemaVersion واضح.
- اختبار Fresh install + Upgrade من الإصدار السابق إلزامي قبل Stable.
- Feature flags للتجارب الكبيرة.
- Safe-start عند تكرر Crash مستقبلاً.
- Diagnostics لا ينسخ محتوى المحادثات أو الأسرار.

## 13) قرارات مرفوضة
- Glassmorphism ثقيل.
- Gradients في كل مكان.
- Neumorphism.
- Pure black كافتراضي وحيد.
- Emoji كأيقونات UI النهائية.
- أكثر من Icon family بلا سبب.
- Spinner واحد لكل العمليات.
- Animation دائم بلا نشاط حقيقي.

## 14) ترتيب تنفيذ α7.3
0. Contract + tokens + state foundations + release safety.
1. Chat shell / Top Bar / Composer / Activity System.
2. Drawer + Search + Projects.
3. Attachments + Sources + Images + Markdown.
4. AION Live / Mini Orb architecture.
5. Neural Voice architecture / Voice settings / My Voice.
6. Motion / Haptics / Accessibility / Adaptive.
7. Golden/upgrade/performance tests + GitHub build.

## ملحق α7.3 / Step 3 — Content Rendering Contract
- المرفقات والمصادر = External context وتستخدم AION Blue لا Purple افتراضيًا.
- لا progress مزيف للملفات أو PDF؛ نعرض عدد الصفحات فقط إذا تم استخراجه فعليًا.
- الصور تُعرض من نسخة sampled، وتصحح EXIF orientation عند توفره.
- الملفات الداخلية لا تُشارك كـfile://؛ أي فتح خارجي يمر عبر FileProvider محصور داخل aion_attachments.
- الكود دائمًا LTR حتى داخل المحادثة العربية، مع Copy وCollapse للكود الطويل.
- الجدول يمرر أفقيًا داخل حدوده فقط.
- المصادر منفصلة بصريًا عن إجراءات الرسالة، وcitation [n] يمكن أن تربط بالمصدر الفعلي.
- روابط Markdown والمصادر المسموح بفتحها من واجهة AION هي HTTP/HTTPS فقط.
- أي مرفق pending يُلغى أو يُرفض يجب حذف نسخته الداخلية لتجنب orphan files.

## ملحق حالة التنفيذ — Step 4 Gate
- تنفيذ AION Live يبقى على `2.0.0-alpha7.3-dev5 / versionCode 19` أثناء إصلاح بوابة البناء؛ لا تغيير في Product Contract أو سلوك Live بسبب إصلاحات التجميع.
- لا يُعلن Step 4 مكتملًا قبل نجاح بوابة GitHub الكاملة: Unit Tests + Lint + assembleDebug + apksigner.
- إصلاحات التجميع لا تفتح Step 5 ولا تغيّر قرار إبقاء Neural Voice / My Voice خارج Step 4.
## ملحق Step 4 — Speech chunking gate fix
- مسار TTS المحلي يفضّل الفقرة ثم نهاية الجملة ثم علامات الوقف الأخف ثم السطر ثم المسافة عند تقسيم الردود الطويلة.
- لا يجوز أن يؤدي إصلاح تقسيم الصوت إلى تغيير Conversation ID أو دورة AION Live أو فتح Step 5.
- يبقى الإغلاق الرسمي مشروطًا بنجاح Unit + Lint + assembleDebug + apksigner على GitHub Actions.


## ملحق Step 4 — Microphone permission gate fix
- مسار Voice Barge-in لا ينشئ `AudioRecord` ولا يبدأ التسجيل إلا بعد تحقق مباشر من `RECORD_AUDIO` في موضع الاستخدام.
- إذا سُحب إذن الميكروفون بين بدء Live وتشغيل خيط التسجيل، تتوقف المقاطعة الصوتية بأمان وتبقى المقاطعة اليدوية متاحة.
- لا يُستخدم Lint baseline أو `SuppressLint` لإخفاء أخطاء الصلاحيات؛ يجب أن تبقى بوابة Lint فعلية.
- يبقى الإغلاق الرسمي مشروطًا بنجاح Unit + Lint + assembleDebug + apksigner على GitHub Actions.

## ملحق Step 4 — Display cutout gate fix
- يظل `minSdk` عند 26؛ لا يُرفع فقط لإرضاء Lint.
- الخاصية `android:windowLayoutInDisplayCutoutMode` موجودة فقط في موارد `values-v27` وما فوق، ولا تُحمّل على API 26.
- لا يُستخدم Lint baseline أو إخفاء `NewApi` لتجاوز توافق الإصدارات.
- يبقى الإغلاق الرسمي مشروطًا بنجاح Unit + Lint + assembleDebug + apksigner على GitHub Actions.


## ملحق α7.3 / Step 5 — Point 1 Neural Voice Core
- Voice IDs ومفاتيح مزود الصوت أسرار خادمية ولا تدخل APK ولا `/v1/status`.
- Android يتعامل فقط مع AION voice keys مستقرة؛ الخادم يحولها إلى Voice IDs داخليًا.
- Voice Catalog يقبل حتى 12 صوتًا مع `key/label/gender` فقط، مع توافق خلفي لصوت `AION_VOICE_ID` الواحد.
- `voice/profile/speed/expression/clarity` مدخلات غير موثوقة؛ تُطبّع وتُقيد على Android ثم يعاد تقييدها على الخادم.
- لا يقبل Android Neural playback إذا لم تكن الاستجابة PCM S16LE متوافقة.
- 404/408/429/5xx في Neural Voice حالات fallback محلي، وليست سببًا لصمت الواجهة.
- حالة SPEAKING تبدأ بعد أول PCM فعلي، لا بمجرد فتح AudioTrack أو بدء طلب الشبكة.
- هذه النقطة لا تضيف بعد Voice Picker أو Preview أو My Voice؛ تبقى للنقاط التالية من Step 5.


## ملحق α7.3 / Step 5 — Point 2 Voice Selection / Preview / Tuning
- قائمة الأصوات في Android مصدرها `/v1/status` فقط؛ لا تُنشأ أسماء/خيارات صوتية وهمية داخل التطبيق.
- اختيار المستخدم المخزن لا يُحذف لمجرد تعطل Catalog مؤقتًا؛ عند عودة الخادم يعاد تطبيقه إذا بقي معلنًا.
- ترتيب حل الصوت: saved voice ثم server default ثم أول صوت معلن.
- `AionVoiceSettings` هو المصدر الموحد لـvoice/profile/speed/expression/clarity في Preview وRead Aloud وAION Live.
- Preset يغيّر profile ويعيد tuning إلى قيم preset المرجعية، ولا يغيّر voice key.
- أي تغيير في إعدادات الصوت يوقف Preview القديم قبل تشغيل/حفظ إعداد جديد.
- Android TTS fallback يطبق سرعة المستخدم ضمن الحدود الآمنة نفسها.
- هذه النقطة لا تضيف My Voice ولا enrollment ولا مفاتيح مزود داخل APK.

## ملحق α7.3 / Step 5 — Point 3 My Voice
- My Voice لا يُنشأ إلا من عينة يقر المستخدم صراحة بأنها لصوته الشخصي؛ لا توجد واجهة مقصودة لاستنساخ صوت طرف ثالث.
- التسجيل/الاستيراد يظل محليًا حتى الموافقة، ولا يرسل AION العينة تلقائيًا.
- صيغة Alpha المقبولة: WAV PCM 16-bit Mono 16 kHz لمدة 15–90 ثانية وبحد 3.6 MB؛ يتحقق Android والخادم من الشروط.
- Provider API key وProvider Voice ID أسرار خادمية. Voice ID لا يُعاد حتى داخل payload مقروء؛ capability token مشفر ومصادق عليه.
- Android يحفظ capability token باستخدام Android Keystore فقط، ولا يحفظ Enrollment Secret.
- إذا فشل حفظ credential بعد إنشاء الصوت يجب محاولة حذف النسخة الخادمية وعدم اعتبار My Voice مكتملًا.
- إذا تطلب المزود Verification فلا يستخدم AION الصوت حتى يصبح credential usable.
- حذف My Voice = حذف provider-side أولًا ثم credential المحلي. عند فشل الحذف السحابي يُحتفظ بالcredential لإعادة المحاولة.
- `my_voice` voice key يعمل عبر Preview وRead Aloud وAION Live ولا يغير Conversation ID أو سياق Live.
- Owner enrollment secret حل Alpha مؤقت؛ قبل الإطلاق متعدد المستخدمين يجب استبداله بمصادقة مستخدم/جلسة وسياسة صلاحية خادمية.
- Playback arbitration بين مصادر الصوت يبقى Point 4 ولا يُدمج ضمن Point 3.

- My Voice credential MUST be endpoint-bound: enrollment, runtime use, preview and deletion may not silently cross AION Cloud endpoints.
