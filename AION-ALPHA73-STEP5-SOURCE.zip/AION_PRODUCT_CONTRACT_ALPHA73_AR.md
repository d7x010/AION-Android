# AION α7.3 — Product / Design Contract

هذا الملف هو المرجع الحاكم لتطوير α7.3. أي شاشة أو مكوّن جديد يجب أن يتبع هذه القواعد ما لم تُسجَّل مراجعة صريحة.

## 1) فلسفة المنتج
- الأسلوب: **AION Obsidian / Quiet Intelligence**.
- الدردشة هادئة ومحايدة، والتعبير البصري يظهر فقط عندما يكون للنظام نشاط حقيقي.
- لا ميزات وهمية، لا أزرار بلا وظيفة، ولا Animations مستمرة للزينة.
- Primary > Secondary > Tertiary: المحتوى وComposer أولًا، المصادر والحالة ثانيًا، الأدوات النادرة خلف المزيد.

## 2) اللون
- Obsidian Background: #0B0B0E
- Surface: #111116
- Surface Raised: #18181F
- Border: #292932
- Text Primary: #F4F4F6
- Text Secondary: #A6A6B0
- AION Violet: #825CFF  = الذكاء الداخلي / التفكير / الذاكرة / Voice
- AION Blue: #4B8DFF    = الويب / المصادر / الأدوات الخارجية / الشبكة
- Success: #39D98A
- Warning: #E9B85D
- Error: #EF6A73
- لا يلوَّن النص الكامل بالحالة؛ Accent صغير فقط.
- OLED Black سيكون وضعًا منفصلًا لاحقًا، وليس Default.

## 3) Typography
- Body: 16sp / line-height 26sp.
- Secondary body: 14sp / 22sp.
- Small UI: 12sp كحد عملي أدنى في الواجهة الأساسية.
- Title: 20–22sp.
- العربية RTL أصلية. Code / URL / JSON تبقى LTR.
- الخط النهائي Prototype: Noto Sans Arabic، واختبار Noto + Beiruti للعناوين قبل الاعتماد.

## 4) Spacing / Shapes
- شبكة مسافات: 4, 8, 12, 16, 20, 24, 32dp.
- Touch target: 48dp على الأقل.
- Composer radius: 28dp.
- User bubble radius: 22dp.
- Card radius: 16–18dp.
- Chip radius: 12–14dp.
- لا نجعل كل عنصر Pill كاملًا.

## 5) Top Bar
- RTL: Menu في اليمين، AION/الوضع في الوسط، New Chat في اليسار.
- 3 عناصر أساسية فقط. Voice لا يبقى في Top Bar.
- زر المزيد يظهر حسب السياق وليس دائمًا.

## 6) الرسائل
- User: Bubble فقط، max width ~78%.
- AION: بلا Bubble عادية؛ النص على الخلفية مباشرة.
- صف الأدوات منخفض التأكيد، والمصادر منفصلة عن Actions.
- الضغط المطول يفتح الأدوات غير الشائعة.
- لا Scroll قسري إذا كان المستخدم يقرأ أعلى المحادثة.

## 7) Composer
- فارغ بلا مرفقات: + / النص / Mic Dictation / AION Live.
- عند الكتابة أو وجود مرفقات: + / النص / Send.
- أثناء التوليد: زر Send يتحول إلى Stop.
- Mic = إملاء إلى Draft فقط، لا إرسال تلقائي.
- AION Live = جلسة صوتية حيّة مرتبطة بنفس Conversation ID.
- أدوات Deep/Web/File تظهر كـContext Chips لا كصف أزرار دائم.

## 8) Activity System
لا نعرض Chain-of-Thought. نعرض فقط عملًا خارجيًا/منتجيًا حقيقيًا يمكن إثباته.
الحالات الأساسية:
- جارٍ التفكير…
- أقرأ المرفقات…
- أبحث في الويب…
- أقارن النتائج… (عند وجود إشارة حقيقية مستقبلًا)
- أصيغ الإجابة…
- أرفع الملفات…
- أعيد الاتصال…
- أستمع إليك…
- AION يتحدث…

التمثيل: Activity Mark صغير حي + نص واضح. اللون البنفسجي للداخل، الأزرق للخارج.
عند أول نص من الرد تختفي حالة الانتظار من نفس الموضع بسلاسة.

## 9) AION Live
- Fullscreen Voice يُصغّر فعليًا إلى Mini Orb دون إنهاء الجلسة.
- النص والصوت في سجل محادثة واحد.
- الكلام أثناء كلام AION = Voice interruption.
- إرسال نص أثناء كلام AION = Typed interruption.
- الجلسة لا تعمل في الخلفية دون Foreground Service/إشعار واضح وفق قواعد Android.
- Mic Dictation منفصل بصريًا وسلوكيًا عن Live.

## 10) Motion / Haptics
- Standard motion للمحادثة/Drawer/Sheets.
- Expressive motion فقط للـOrb/Live/Activity/Splash.
- أغلب الانتقالات 160–220ms.
- Haptics قليلة ودلالية: Send، Long-press، Live start، Stop/interruption.
- Reduce Motion يحترم إعداد النظام.

## 11) Android-native behavior
- Edge-to-edge + WindowInsets، لا bottom padding ثابت.
- Predictive Back لاحقًا: Voice→Mini، Viewer→Chat، Drawer→Closed.
- Adaptive layout من البداية: Phone / Medium / Tablet-Fold.
- Share-to-AION / App Shortcuts / Widget في مراحل لاحقة.

## 12) Release Safety
- كل ترقية بيانات لها schemaVersion واضح.
- اختبار Fresh install + Upgrade من الإصدار السابق إلزامي قبل Stable.
- Feature flags للتجارب الكبيرة.
- Safe-start عند تكرر Crash مستقبلاً.
- Diagnostics لا ينسخ محتوى المحادثات أو الأسرار.

## 13) قرارات مرفوضة
- Glassmorphism ثقيل.
- Gradients في كل مكان.
- Neumorphism.
- Pure black كافتراضي وحيد.
- Emoji كأيقونات UI النهائية.
- أكثر من Icon family بلا سبب.
- Spinner واحد لكل العمليات.
- Animation دائم بلا نشاط حقيقي.

## 14) ترتيب تنفيذ α7.3
0. Contract + tokens + state foundations + release safety.
1. Chat shell / Top Bar / Composer / Activity System.
2. Drawer + Search + Projects.
3. Attachments + Sources + Images + Markdown.
4. AION Live / Mini Orb architecture.
5. Neural Voice architecture / Voice settings / My Voice.
6. Motion / Haptics / Accessibility / Adaptive.
7. Golden/upgrade/performance tests + GitHub build.

## ملحق α7.3 / Step 3 — Content Rendering Contract
- المرفقات والمصادر = External context وتستخدم AION Blue لا Purple افتراضيًا.
- لا progress مزيف للملفات أو PDF؛ نعرض عدد الصفحات فقط إذا تم استخراجه فعليًا.
- الصور تُعرض من نسخة sampled، وتصحح EXIF orientation عند توفره.
- الملفات الداخلية لا تُشارك كـfile://؛ أي فتح خارجي يمر عبر FileProvider محصور داخل aion_attachments.
- الكود دائمًا LTR حتى داخل المحادثة العربية، مع Copy وCollapse للكود الطويل.
- الجدول يمرر أفقيًا داخل حدوده فقط.
- المصادر منفصلة بصريًا عن إجراءات الرسالة، وcitation [n] يمكن أن تربط بالمصدر الفعلي.
- روابط Markdown والمصادر المسموح بفتحها من واجهة AION هي HTTP/HTTPS فقط.
- أي مرفق pending يُلغى أو يُرفض يجب حذف نسخته الداخلية لتجنب orphan files.


## ملحق α7.3 / Step 4 — AION Live Contract
- AION Live مرتبط بـConversation ID واحد؛ لا يسمح بصمت بإرسال صوت الجلسة إلى محادثة أخرى.
- Fullscreen → سحب للأسفل/Keyboard → Mini Orb؛ التصغير Presentation change فقط وليس End session.
- Mini Orb يبقى فوق المحادثة ويأخذ IME/navigation insets حتى لا يغطي Composer.
- الحالة النصية المصغرة تظهر مؤقتًا ثم تختفي، ويبقى الـOrb فقط لتقليل التشويش.
- Listening/Speaking تتحرك من RMS/PCM الحقيقي، أما Thinking/Search/Reading/Compare/Writing فلها Motion دلالي مستقل.
- Purple = عمليات AION الداخلية، Blue = بحث/عالم خارجي.
- Voice interruption: الضغط على Orb متاح دائمًا؛ barge-in التلقائي لا يعمل فوق speaker إلا عند توفر AcousticEchoCanceler فعلي، أو على مسار headset منخفض التسرب.
- barge-in لا يخزن أو يرسل PCM؛ يحسب RMS قصيرًا محليًا ويطرح العينات.
- Mute يكتم الميكروفون فقط ولا يوقف جواب AION الصوتي.
- Typed interruption يوقف TTS/Neural playback القديم فور بدء طلب نصي جديد داخل نفس الجلسة.
- AION لا ينطق رسالة wasStopped بعد إيقاف التوليد.
- Audio focus يُطلب عند كلام AION ويُحرر عند الانتهاء/المقاطعة/إغلاق Live.
- Android communication mode مؤقت فقط أثناء Live، مع استعادة mode/route السابق عند الإغلاق، وعدم فرض speaker فوق headset/بلوتوث متصل.
- نصوص Live وحالة اللون تمر عبر `AionLiveUiPolicy` كمصدر واحد لتجنب تناقض «يفكر» أثناء البحث أو الاستماع.
- الإنهاء له زر أحمر صريح واحد؛ Back/Swipe/Keyboard تصغّر الجلسة ولا تنهيها.
- الخلفية خارج التطبيق وForeground mic service ليست جزءًا من Step 4؛ تأتي في مرحلة Android integration اللاحقة.
