package com.aion.mobile.core.voice

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class NeuralVoiceContractTest {
    @Test
    fun voiceKeyRejectsUnsafeOrUnknownShape() {
        assertEquals("aion_female_1", NeuralVoiceContract.normalizedVoiceKey(" AION_FEMALE_1 "))
        assertEquals("", NeuralVoiceContract.normalizedVoiceKey("../secret"))
        assertEquals("", NeuralVoiceContract.normalizedVoiceKey(""))
    }

    @Test
    fun temporaryServerFailuresUseLocalFallback() {
        assertTrue(NeuralVoiceContract.shouldUseLocalFallback(429))
        assertTrue(NeuralVoiceContract.shouldUseLocalFallback(503))
        assertTrue(NeuralVoiceContract.shouldUseLocalFallback(502))
        assertFalse(NeuralVoiceContract.shouldUseLocalFallback(400))
    }

    @Test
    fun pcmContractRejectsUnexpectedAudio() {
        assertTrue(NeuralVoiceContract.acceptsPcm("audio/pcm", "pcm_s16le"))
        assertTrue(NeuralVoiceContract.acceptsPcm("audio/pcm; charset=binary", ""))
        assertFalse(NeuralVoiceContract.acceptsPcm("audio/mpeg", "pcm_s16le"))
        assertFalse(NeuralVoiceContract.acceptsPcm("audio/pcm", "float32"))
    }

    @Test
    fun tuningIsBounded() {
        assertEquals(0.72f, NeuralVoiceContract.clampSpeed(0.1f)!!, 0.0001f)
        assertEquals(1.20f, NeuralVoiceContract.clampSpeed(2f)!!, 0.0001f)
        assertEquals(1f, NeuralVoiceContract.clampExpression(2f)!!, 0.0001f)
        assertEquals(0f, NeuralVoiceContract.clampClarity(-1f)!!, 0.0001f)
    }
}
