package com.aion.mobile.core.voice

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class VoiceBargeInPolicyTest {
    @Test
    fun shortSpikeDoesNotInterrupt() {
        var frames = 0
        frames = VoiceBargeInPolicy.nextStrongFrames(frames, 0.20f)
        frames = VoiceBargeInPolicy.nextStrongFrames(frames, 0.02f)
        assertFalse(VoiceBargeInPolicy.shouldInterrupt(frames))
    }

    @Test
    fun sustainedVoiceInterrupts() {
        var frames = 0
        repeat(VoiceBargeInPolicy.REQUIRED_STRONG_FRAMES) {
            frames = VoiceBargeInPolicy.nextStrongFrames(frames, 0.20f)
        }
        assertTrue(VoiceBargeInPolicy.shouldInterrupt(frames))
    }
}
