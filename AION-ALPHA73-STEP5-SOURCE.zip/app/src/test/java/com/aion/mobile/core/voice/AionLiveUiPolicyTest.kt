package com.aion.mobile.core.voice

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class AionLiveUiPolicyTest {
    @Test
    fun searchUsesExternalVisualLanguage() {
        val copy = AionLiveUiPolicy.describe(AionLivePhase.SEARCHING, muted = false, automaticBargeInActive = false)
        assertEquals("أبحث في الويب…", copy.status)
        assertEquals(AionLiveVisualDomain.EXTERNAL, copy.visualDomain)
    }

    @Test
    fun speakingExplainsAutomaticInterruptionOnlyWhenAvailable() {
        val automatic = AionLiveUiPolicy.describe(AionLivePhase.SPEAKING, muted = false, automaticBargeInActive = true)
        val manual = AionLiveUiPolicy.describe(AionLivePhase.SPEAKING, muted = false, automaticBargeInActive = false)
        assertTrue(automatic.helper.contains("تكلم مباشرة"))
        assertTrue(manual.helper.contains("اضغط على الدائرة"))
    }

    @Test
    fun mutedStateNeverPretendsToListen() {
        val copy = AionLiveUiPolicy.describe(AionLivePhase.LISTENING, muted = true, automaticBargeInActive = false)
        assertEquals("الميكروفون مكتوم", copy.status)
        assertTrue(copy.helper.contains("القراءة والكتابة"))
    }
}
