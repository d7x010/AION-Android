package com.aion.mobile.core.voice

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class AionLiveSessionStateTest {
    @Test
    fun liveSession_minimizeDoesNotEndConversation() {
        val started = AionLiveReducer.reduce(AionLiveSessionState(), AionLiveEvent.Start("chat-1"))
        val minimized = AionLiveReducer.reduce(started, AionLiveEvent.Minimize)
        assertTrue(minimized.isActive)
        assertEquals("chat-1", minimized.conversationId)
        assertEquals(AionLivePresentation.MINIMIZED, minimized.presentation)
    }

    @Test
    fun restoreReturnsToFullscreen() {
        val started = AionLiveReducer.reduce(AionLiveSessionState(), AionLiveEvent.Start("chat-1"))
        val minimized = AionLiveReducer.reduce(started, AionLiveEvent.Minimize)
        val restored = AionLiveReducer.reduce(minimized, AionLiveEvent.Restore)
        assertEquals(AionLivePresentation.FULLSCREEN, restored.presentation)
    }

    @Test
    fun endResetsLiveState() {
        val started = AionLiveReducer.reduce(AionLiveSessionState(), AionLiveEvent.Start("chat-1"))
        val ended = AionLiveReducer.reduce(started, AionLiveEvent.End)
        assertFalse(ended.isActive)
        assertEquals(AionLivePhase.IDLE, ended.phase)
    }

    @Test
    fun phaseAndMuteSurviveMinimizeRestore() {
        var state = AionLiveReducer.reduce(AionLiveSessionState(), AionLiveEvent.Start("chat-2"))
        state = AionLiveReducer.reduce(state, AionLiveEvent.PhaseChanged(AionLivePhase.SEARCHING))
        state = AionLiveReducer.reduce(state, AionLiveEvent.SetMuted(true))
        state = AionLiveReducer.reduce(state, AionLiveEvent.Minimize)
        state = AionLiveReducer.reduce(state, AionLiveEvent.Restore)

        assertTrue(state.isActive)
        assertTrue(state.muted)
        assertEquals(AionLivePhase.SEARCHING, state.phase)
        assertEquals(AionLivePresentation.FULLSCREEN, state.presentation)
    }

    @Test
    fun minimizeAndRestorePreserveActivePhase() {
        var state = AionLiveReducer.reduce(AionLiveSessionState(), AionLiveEvent.Start("chat-live"))
        state = AionLiveReducer.reduce(state, AionLiveEvent.PhaseChanged(AionLivePhase.SPEAKING))
        val minimized = AionLiveReducer.reduce(state, AionLiveEvent.Minimize)
        val restored = AionLiveReducer.reduce(minimized, AionLiveEvent.Restore)

        assertEquals(AionLivePhase.SPEAKING, minimized.phase)
        assertEquals(AionLivePhase.SPEAKING, restored.phase)
        assertEquals("chat-live", restored.conversationId)
    }

    @Test
    fun minimizingHiddenSessionIsNoOp() {
        val initial = AionLiveSessionState()
        assertEquals(initial, AionLiveReducer.reduce(initial, AionLiveEvent.Minimize))
    }

    @Test
    fun inactiveSessionIgnoresPhaseAndMuteEvents() {
        var state = AionLiveReducer.reduce(AionLiveSessionState(), AionLiveEvent.PhaseChanged(AionLivePhase.SPEAKING))
        state = AionLiveReducer.reduce(state, AionLiveEvent.SetMuted(true))
        assertFalse(state.isActive)
        assertFalse(state.muted)
        assertEquals(AionLivePhase.IDLE, state.phase)
    }
}
