package com.aion.mobile.core.voice

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class VoiceTurnPolicyTest {
    @Test
    fun retriesBackOffInsteadOfSpinning() {
        assertTrue(VoiceTurnPolicy.retryDelayMs(3, false) > VoiceTurnPolicy.retryDelayMs(0, false))
        assertTrue(VoiceTurnPolicy.retryDelayMs(3, true) > VoiceTurnPolicy.retryDelayMs(3, false))
    }

    @Test
    fun repeatedNetworkFailureEventuallyNeedsTap() {
        assertFalse(VoiceTurnPolicy.shouldRequireManualResume(3))
        assertTrue(VoiceTurnPolicy.shouldRequireManualResume(4))
    }
}
