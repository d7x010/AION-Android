package com.aion.mobile.core.voice

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class MyVoicePolicyTest {
    @Test
    fun durationUses16kMonoPcm16() {
        assertEquals(1_000L, MyVoicePolicy.durationMsFromPcmBytes(32_000L))
        assertEquals(15_000L, MyVoicePolicy.durationMsFromPcmBytes(480_000L))
    }

    @Test
    fun enrollmentRequiresCloudSampleConsentAndSecret() {
        assertTrue(MyVoicePolicy.canEnroll(true, true, true, "1234567890123456"))
        assertFalse(MyVoicePolicy.canEnroll(false, true, true, "1234567890123456"))
        assertFalse(MyVoicePolicy.canEnroll(true, false, true, "1234567890123456"))
        assertFalse(MyVoicePolicy.canEnroll(true, true, false, "1234567890123456"))
        assertFalse(MyVoicePolicy.canEnroll(true, true, true, "short"))
    }

    @Test
    fun nameIsNormalizedAndBounded() {
        assertEquals("صوتي في AION", MyVoicePolicy.normalizedName("  \n "))
        assertEquals("My Voice", MyVoicePolicy.normalizedName(" My\n Voice "))
        assertTrue(MyVoicePolicy.normalizedName("x".repeat(100)).length <= 48)
    }

    @Test
    fun wavReadinessUsesDurationAndSizeLimits() {
        val file = File.createTempFile("aion-my-voice", ".wav")
        try {
            file.writeBytes(ByteArray(44 + 480_000))
            assertTrue(MyVoicePolicy.sampleReady(file))
            file.writeBytes(ByteArray(44 + 32_000))
            assertFalse(MyVoicePolicy.sampleReady(file))
        } finally {
            file.delete()
        }
    }
}
