package com.aion.mobile.core.voice

import java.io.File

/** Pure rules for STEP5 My Voice. */
object MyVoicePolicy {
    const val SAMPLE_RATE_HZ = 16_000
    const val BYTES_PER_SAMPLE = 2
    const val MIN_DURATION_MS = 15_000L
    const val MAX_DURATION_MS = 90_000L
    const val MAX_SAMPLE_BYTES = 3_600_000L
    const val MY_VOICE_KEY = "my_voice"

    fun normalizedName(value: String?): String = value.orEmpty()
        .replace(Regex("[\\r\\n\\u0000]+"), " ")
        .replace(Regex("\\s+"), " ")
        .trim()
        .take(48)
        .ifBlank { "صوتي في AION" }

    fun durationMsFromPcmBytes(bytes: Long): Long {
        if (bytes <= 0L) return 0L
        val bytesPerSecond = SAMPLE_RATE_HZ.toLong() * BYTES_PER_SAMPLE
        return (bytes * 1000L) / bytesPerSecond
    }

    fun durationMsFromWav(file: File?): Long {
        if (file == null || !file.isFile || file.length() <= 44L) return 0L
        return durationMsFromPcmBytes(file.length() - 44L)
    }

    fun sampleReady(file: File?): Boolean {
        if (file == null || !file.isFile) return false
        val duration = durationMsFromWav(file)
        return duration in MIN_DURATION_MS..MAX_DURATION_MS && file.length() <= MAX_SAMPLE_BYTES
    }

    fun canEnroll(
        cloudAvailable: Boolean,
        sampleReady: Boolean,
        consent: Boolean,
        enrollmentSecret: String
    ): Boolean = cloudAvailable && sampleReady && consent && enrollmentSecret.trim().length >= 16

    fun formatDuration(ms: Long): String {
        val seconds = (ms.coerceAtLeast(0L) / 1000L).toInt()
        val minutes = seconds / 60
        val rest = seconds % 60
        return "%d:%02d".format(minutes, rest)
    }
}

data class MyVoiceCredential(
    val token: String = "",
    val label: String = "صوتي",
    val createdAtEpochMs: Long = 0L,
    val requiresVerification: Boolean = false
) {
    val exists: Boolean get() = token.isNotBlank()
    val usable: Boolean get() = exists && !requiresVerification
}
