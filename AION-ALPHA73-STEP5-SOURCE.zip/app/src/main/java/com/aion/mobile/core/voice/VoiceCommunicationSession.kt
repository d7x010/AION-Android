package com.aion.mobile.core.voice

import android.content.Context
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.os.Build

/**
 * Owns temporary Android communication-mode changes for AION Live.
 *
 * We keep an already-connected headset/Bluetooth route untouched. Without a headset, communication
 * mode can move OEM devices to the earpiece, so AION best-effort keeps speech on the phone speaker
 * and restores the previous route when Live ends.
 */
class VoiceCommunicationSession(context: Context) {
    private val manager = context.applicationContext.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private var entered = false
    private var previousMode = AudioManager.MODE_NORMAL
    private var previousSpeakerphone = false
    private var previousCommunicationDevice: AudioDeviceInfo? = null

    fun enter() {
        if (entered) return
        previousMode = manager.mode
        previousSpeakerphone = manager.isSpeakerphoneOn
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            previousCommunicationDevice = manager.communicationDevice
        }

        runCatching { manager.mode = AudioManager.MODE_IN_COMMUNICATION }
        preferSafeOutputRoute()
        entered = true
    }

    fun exit() {
        if (!entered) return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            runCatching {
                val previous = previousCommunicationDevice
                if (previous != null && manager.availableCommunicationDevices.any { it.id == previous.id }) {
                    manager.setCommunicationDevice(previous)
                } else {
                    manager.clearCommunicationDevice()
                }
            }
        } else {
            @Suppress("DEPRECATION")
            runCatching { manager.isSpeakerphoneOn = previousSpeakerphone }
        }
        runCatching { manager.mode = previousMode }
        entered = false
    }

    private fun preferSafeOutputRoute() {
        val outputs = manager.getDevices(AudioManager.GET_DEVICES_OUTPUTS)
        val headsetConnected = outputs.any(::isHeadsetLike)
        if (headsetConnected) return

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val speaker = manager.availableCommunicationDevices.firstOrNull { it.type == AudioDeviceInfo.TYPE_BUILTIN_SPEAKER }
            if (speaker != null) runCatching { manager.setCommunicationDevice(speaker) }
        } else {
            @Suppress("DEPRECATION")
            runCatching { manager.isSpeakerphoneOn = true }
        }
    }

    private fun isHeadsetLike(device: AudioDeviceInfo): Boolean = when (device.type) {
        AudioDeviceInfo.TYPE_WIRED_HEADSET,
        AudioDeviceInfo.TYPE_WIRED_HEADPHONES,
        AudioDeviceInfo.TYPE_BLUETOOTH_SCO,
        AudioDeviceInfo.TYPE_BLUETOOTH_A2DP,
        AudioDeviceInfo.TYPE_USB_HEADSET -> true
        else -> false
    }
}
