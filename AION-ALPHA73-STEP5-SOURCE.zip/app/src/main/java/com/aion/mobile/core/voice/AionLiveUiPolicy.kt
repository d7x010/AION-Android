package com.aion.mobile.core.voice

/**
 * User-visible AION Live status. This deliberately describes observable work only and never
 * exposes hidden model reasoning.
 */
enum class AionLiveVisualDomain {
    INTELLIGENCE,
    EXTERNAL,
    ERROR
}

data class AionLiveUiCopy(
    val status: String,
    val helper: String,
    val visualDomain: AionLiveVisualDomain
)

object AionLiveUiPolicy {
    fun describe(
        phase: AionLivePhase,
        muted: Boolean,
        automaticBargeInActive: Boolean
    ): AionLiveUiCopy {
        val status = when (phase) {
            AionLivePhase.IDLE -> "AION Live"
            AionLivePhase.INITIALIZING -> "تهيئة الصوت…"
            AionLivePhase.LISTENING -> if (muted) "الميكروفون مكتوم" else "أسمعك…"
            AionLivePhase.THINKING -> "جارٍ التفكير…"
            AionLivePhase.READING_FILES -> "أقرأ المرفقات…"
            AionLivePhase.SEARCHING -> "أبحث في الويب…"
            AionLivePhase.COMPARING -> "أقارن النتائج…"
            AionLivePhase.WRITING -> "أصيغ الإجابة…"
            AionLivePhase.SPEAKING -> "AION يتحدث…"
            AionLivePhase.RECONNECTING -> "أعيد الاتصال بالصوت…"
            AionLivePhase.ERROR -> "الصوت متوقف"
        }

        val helper = when {
            muted -> "الميكروفون مكتوم؛ يمكنك متابعة القراءة والكتابة"
            phase == AionLivePhase.SPEAKING && automaticBargeInActive ->
                "تكلم مباشرة لمقاطعة AION، أو اضغط على الدائرة"
            phase == AionLivePhase.SPEAKING ->
                "اضغط على الدائرة لمقاطعة AION والتحدث"
            phase == AionLivePhase.LISTENING ->
                "تحدث بشكل طبيعي؛ سأرسل كلامك عند انتهاء الجملة"
            phase == AionLivePhase.THINKING || phase == AionLivePhase.READING_FILES ||
                phase == AionLivePhase.SEARCHING || phase == AionLivePhase.COMPARING ||
                phase == AionLivePhase.WRITING ->
                "يمكنك تصغير AION Live ومتابعة القراءة أو الكتابة"
            phase == AionLivePhase.RECONNECTING ->
                "أحاول استعادة الاستماع بدون إنهاء الجلسة"
            phase == AionLivePhase.ERROR ->
                "اضغط على الدائرة لإعادة تشغيل الاستماع"
            else -> ""
        }

        val visualDomain = when (phase) {
            AionLivePhase.SEARCHING -> AionLiveVisualDomain.EXTERNAL
            AionLivePhase.ERROR -> AionLiveVisualDomain.ERROR
            else -> AionLiveVisualDomain.INTELLIGENCE
        }

        return AionLiveUiCopy(status, helper, visualDomain)
    }
}
