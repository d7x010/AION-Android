package com.aion.mobile.core.voice

/** Pure policy for the barge-in detector; audio capture itself stays Android-specific. */
object VoiceBargeInPolicy {
    const val DEFAULT_THRESHOLD: Float = 0.105f
    const val WARMUP_FRAMES: Int = 8
    const val REQUIRED_STRONG_FRAMES: Int = 4

    fun nextStrongFrames(current: Int, level: Float, threshold: Float = DEFAULT_THRESHOLD): Int =
        if (level >= threshold) (current + 1).coerceAtMost(REQUIRED_STRONG_FRAMES)
        else (current - 1).coerceAtLeast(0)

    fun shouldInterrupt(strongFrames: Int): Boolean = strongFrames >= REQUIRED_STRONG_FRAMES
}
