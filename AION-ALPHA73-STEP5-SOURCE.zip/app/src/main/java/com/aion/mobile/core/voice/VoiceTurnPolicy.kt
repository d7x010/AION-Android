package com.aion.mobile.core.voice

/** سياسات صغيرة قابلة للاختبار لمنع حلقات إعادة الاستماع العدوانية. */
object VoiceTurnPolicy {
    fun retryDelayMs(consecutiveFailures: Int, networkRelated: Boolean): Long {
        val failures = consecutiveFailures.coerceIn(0, 5)
        val base = if (networkRelated) 720L else 280L
        val step = if (networkRelated) 320L else 180L
        return (base + (failures * step)).coerceAtMost(2_200L)
    }

    fun shouldRequireManualResume(consecutiveNetworkFailures: Int): Boolean =
        consecutiveNetworkFailures >= 4
}
