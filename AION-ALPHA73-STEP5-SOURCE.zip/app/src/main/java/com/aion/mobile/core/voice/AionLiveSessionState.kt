package com.aion.mobile.core.voice

/** Presentation survives Fullscreen <-> Mini transitions without ending the live session. */
enum class AionLivePresentation {
    HIDDEN,
    FULLSCREEN,
    MINIMIZED
}

enum class AionLivePhase {
    IDLE,
    INITIALIZING,
    LISTENING,
    THINKING,
    READING_FILES,
    SEARCHING,
    COMPARING,
    WRITING,
    SPEAKING,
    RECONNECTING,
    ERROR
}

data class AionLiveSessionState(
    val presentation: AionLivePresentation = AionLivePresentation.HIDDEN,
    val phase: AionLivePhase = AionLivePhase.IDLE,
    val conversationId: String? = null,
    val muted: Boolean = false
) {
    val isActive: Boolean get() = presentation != AionLivePresentation.HIDDEN
}

sealed interface AionLiveEvent {
    data class Start(val conversationId: String) : AionLiveEvent
    data object Minimize : AionLiveEvent
    data object Restore : AionLiveEvent
    data object End : AionLiveEvent
    data class PhaseChanged(val phase: AionLivePhase) : AionLiveEvent
    data class SetMuted(val muted: Boolean) : AionLiveEvent
}

object AionLiveReducer {
    fun reduce(state: AionLiveSessionState, event: AionLiveEvent): AionLiveSessionState = when (event) {
        is AionLiveEvent.Start -> AionLiveSessionState(
            presentation = AionLivePresentation.FULLSCREEN,
            phase = AionLivePhase.INITIALIZING,
            conversationId = event.conversationId,
            muted = false
        )
        AionLiveEvent.Minimize -> if (state.isActive) state.copy(presentation = AionLivePresentation.MINIMIZED) else state
        AionLiveEvent.Restore -> if (state.isActive) state.copy(presentation = AionLivePresentation.FULLSCREEN) else state
        AionLiveEvent.End -> AionLiveSessionState()
        is AionLiveEvent.PhaseChanged -> if (state.isActive) state.copy(phase = event.phase) else state
        is AionLiveEvent.SetMuted -> if (state.isActive) state.copy(muted = event.muted) else state
    }
}
