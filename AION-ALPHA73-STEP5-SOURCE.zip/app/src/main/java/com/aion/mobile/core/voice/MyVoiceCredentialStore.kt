package com.aion.mobile.core.voice

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * Stores only the opaque My Voice capability token, encrypted with Android Keystore.
 * The provider API key never enters the APK. The app stores only a signed capability token, not a standalone provider voice id.
 */
object MyVoiceCredentialStore {
    private const val PREFS = "aion_my_voice"
    private const val KEY_TOKEN = "token_v1"
    private const val KEY_LABEL = "label"
    private const val KEY_CREATED = "created_at"
    private const val KEY_REQUIRES_VERIFICATION = "requires_verification"
    private const val KEY_ALIAS = "aion_my_voice_token_aes_v1"
    private const val TRANSFORMATION = "AES/GCM/NoPadding"

    fun load(context: Context): MyVoiceCredential {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val encrypted = runCatching { prefs.getString(KEY_TOKEN, "") }.getOrNull().orEmpty()
        val token = if (encrypted.isBlank()) "" else runCatching { decrypt(encrypted) }.getOrDefault("")
        return MyVoiceCredential(
            token = token,
            label = runCatching { prefs.getString(KEY_LABEL, "صوتي") }.getOrNull().orEmpty().ifBlank { "صوتي" },
            createdAtEpochMs = runCatching { prefs.getLong(KEY_CREATED, 0L) }.getOrDefault(0L),
            requiresVerification = runCatching { prefs.getBoolean(KEY_REQUIRES_VERIFICATION, false) }.getOrDefault(false)
        )
    }

    fun save(context: Context, credential: MyVoiceCredential) {
        if (credential.token.isBlank()) {
            clear(context)
            return
        }
        val encrypted = encrypt(credential.token)
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(KEY_TOKEN, encrypted)
            .putString(KEY_LABEL, credential.label.take(48))
            .putLong(KEY_CREATED, credential.createdAtEpochMs)
            .putBoolean(KEY_REQUIRES_VERIFICATION, credential.requiresVerification)
            .apply()
    }

    fun clear(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().clear().apply()
    }

    private fun key(): SecretKey {
        val keyStore = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (keyStore.getKey(KEY_ALIAS, null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(
            KeyGenParameterSpec.Builder(
                KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            )
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setRandomizedEncryptionRequired(true)
                .build()
        )
        return generator.generateKey()
    }

    private fun encrypt(value: String): String {
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.ENCRYPT_MODE, key())
        val encrypted = cipher.doFinal(value.toByteArray(Charsets.UTF_8))
        val packed = ByteArray(cipher.iv.size + encrypted.size)
        System.arraycopy(cipher.iv, 0, packed, 0, cipher.iv.size)
        System.arraycopy(encrypted, 0, packed, cipher.iv.size, encrypted.size)
        return Base64.encodeToString(packed, Base64.NO_WRAP)
    }

    private fun decrypt(value: String): String {
        val packed = Base64.decode(value, Base64.NO_WRAP)
        require(packed.size > 12) { "invalid credential" }
        val iv = packed.copyOfRange(0, 12)
        val encrypted = packed.copyOfRange(12, packed.size)
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, iv))
        return cipher.doFinal(encrypted).toString(Charsets.UTF_8)
    }
}
