package com.aion.mobile.core.voice

import java.util.concurrent.atomic.AtomicLong

enum class AionVoicePlaybackOwner {
    READ_ALOUD,
    PREVIEW,
    LIVE
}

/**
 * Process-local arbitration for every audible AION surface.
 *
 * Only one voice surface may own playback at a time. Claiming a new owner synchronously
 * interrupts the previous owner's local stop callback, which prevents Read Aloud, previews,
 * and AION Live from talking over each other.
 *
 * Tokens make stale completion callbacks harmless: an old playback can never release a newer
 * lease that already replaced it.
 */
class AionVoicePlaybackArbiter {
    private data class Active(
        val owner: AionVoicePlaybackOwner,
        val token: Long,
        val stop: () -> Unit,
    )

    private val lock = Any()
    private val sequence = AtomicLong(0L)
    private var active: Active? = null

    fun claim(owner: AionVoicePlaybackOwner, stop: () -> Unit): Long {
        val token = sequence.incrementAndGet()
        val previous = synchronized(lock) {
            val old = active
            active = Active(owner, token, stop)
            old
        }
        // Invoke outside the lock: a stop callback may itself release an old token.
        runCatching { previous?.stop?.invoke() }
        return token
    }

    fun release(owner: AionVoicePlaybackOwner, token: Long) {
        synchronized(lock) {
            val current = active
            if (current?.owner == owner && current.token == token) active = null
        }
    }

    fun isCurrent(owner: AionVoicePlaybackOwner, token: Long): Boolean = synchronized(lock) {
        val current = active
        current?.owner == owner && current.token == token
    }

    fun interrupt(owner: AionVoicePlaybackOwner): Boolean {
        val target = synchronized(lock) {
            val current = active
            if (current?.owner == owner) {
                active = null
                current
            } else null
        } ?: return false
        runCatching { target.stop() }
        return true
    }

    fun interruptAll(): Boolean {
        val target = synchronized(lock) {
            val current = active
            active = null
            current
        } ?: return false
        runCatching { target.stop() }
        return true
    }

    internal fun activeOwnerForTest(): AionVoicePlaybackOwner? = synchronized(lock) { active?.owner }
}
