package com.aion.mobile.core.voice

import android.content.Context

enum class AionVoiceProfile(val key: String, val label: String, val description: String) {
    CALM("calm", "هادئ", "أبطأ قليلًا ونبرة أكثر ثباتًا"),
    BALANCED("balanced", "متوازن", "النبرة الافتراضية للمحادثة اليومية"),
    EXPRESSIVE("expressive", "تعبيري", "تنوّع أكبر في الإلقاء مع ثبات أقل");

    companion object {
        fun fromKey(key: String?): AionVoiceProfile = entries.firstOrNull { it.key == key } ?: BALANCED
    }
}

object VoicePreferences {
    private const val PREFS = "aion_voice_preferences"
    private const val KEY_PROFILE = "profile"

    fun loadProfile(context: Context): AionVoiceProfile {
        val raw = runCatching {
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_PROFILE, AionVoiceProfile.BALANCED.key)
        }.getOrNull()
        return AionVoiceProfile.fromKey(raw)
    }

    fun saveProfile(context: Context, profile: AionVoiceProfile) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_PROFILE, profile.key)
            .apply()
    }
}
