package com.aion.mobile.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.AudioFormat
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.CallEnd
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.Keyboard
import androidx.compose.material.icons.outlined.KeyboardArrowDown
import androidx.compose.material.icons.outlined.Mic
import androidx.compose.material.icons.outlined.MicOff
import androidx.compose.material.icons.outlined.Stop
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import com.aion.mobile.core.ai.GatewayActivity
import com.aion.mobile.core.voice.AionLivePhase
import com.aion.mobile.core.voice.AionLiveAudioSession
import com.aion.mobile.core.voice.AionLivePhasePolicy
import com.aion.mobile.core.voice.AionLivePresentation
import com.aion.mobile.core.voice.NeuralVoicePlaybackResult
import com.aion.mobile.core.voice.NeuralVoicePlayer
import com.aion.mobile.core.voice.SpeechText
import com.aion.mobile.core.voice.VoiceAmplitude
import com.aion.mobile.core.voice.VoiceBargeInDetector
import com.aion.mobile.core.voice.VoiceTurnPolicy
import com.aion.mobile.model.ChatMessage
import com.aion.mobile.model.MessageRole
import com.aion.mobile.ui.design.AionColors
import com.aion.mobile.ui.design.AionHaptics
import com.aion.mobile.ui.design.AionRadii
import com.aion.mobile.ui.design.AionSizes
import com.aion.mobile.ui.design.AionSpacing
import com.aion.mobile.ui.theme.AionPurpleSoft
import com.aion.mobile.ui.theme.AionPurpleStrong
import kotlinx.coroutines.delay
import java.util.Locale
import java.util.concurrent.atomic.AtomicInteger

/**
 * مكالمة صوتية داخل المحادثة: استماع -> إرسال -> رد -> كلام -> استماع.
 *
 * ليست WebRTC full-duplex بعد، لكن الحركة أثناء كلام AION تعتمد على PCM الحقيقي الذي يولده TTS
 * عبر UtteranceProgressListener.onAudioAvailable بدل نبضة زمنية وهمية. ويمكن للمستخدم مقاطعة
 * كلام AION فورًا بالضغط على الدائرة أو زر الإيقاف لبدء الاستماع إلى دوره الجديد.
 */
@Composable
internal fun VoiceCallOverlay(
    presentation: AionLivePresentation,
    cloudEndpoint: String,
    neuralVoiceAvailable: Boolean,
    voiceProfile: String,
    messages: List<ChatMessage>,
    isSending: Boolean,
    activity: GatewayActivity?,
    onSend: (String) -> Unit,
    onStop: () -> Unit,
    onPhaseChanged: (AionLivePhase) -> Unit,
    onMutedChanged: (Boolean) -> Unit,
    onMinimize: () -> Unit,
    onRestore: () -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val hapticView = LocalView.current
    val mainHandler = remember { Handler(Looper.getMainLooper()) }
    val neuralVoicePlayer = remember { NeuralVoicePlayer() }
    val audioSession = remember { AionLiveAudioSession(context.applicationContext) }
    val bargeInDetector = remember { VoiceBargeInDetector(context.applicationContext) }
    val latestSending by rememberUpdatedState(isSending)
    var state by remember { mutableStateOf(AionLivePhase.INITIALIZING) }
    var partialText by remember { mutableStateOf("") }
    var rms by remember { mutableFloatStateOf(0f) }
    var assistantLevel by remember { mutableFloatStateOf(0f) }
    var muted by remember { mutableStateOf(false) }
    var recognizer by remember { mutableStateOf<SpeechRecognizer?>(null) }
    var tts by remember { mutableStateOf<TextToSpeech?>(null) }
    var ttsReady by remember { mutableStateOf(false) }
    var requestListenTick by remember { mutableIntStateOf(0) }
    var recognitionFailures by remember { mutableIntStateOf(0) }
    var networkFailures by remember { mutableIntStateOf(0) }
    var suppressRecognizerErrorsUntil by remember { mutableLongStateOf(0L) }
    val synthesisFormat = remember { AtomicInteger(AudioFormat.ENCODING_PCM_16BIT) }
    var lastHandledAssistantId by remember {
        mutableStateOf(messages.lastOrNull { it.role == MessageRole.AION }?.id)
    }

    LaunchedEffect(state) { onPhaseChanged(state) }
    LaunchedEffect(muted) { onMutedChanged(muted) }

    fun cancelRecognizerSilently() {
        suppressRecognizerErrorsUntil = SystemClock.uptimeMillis() + 650L
        runCatching { recognizer?.cancel() }
        rms = 0f
    }

    fun scheduleListen(delayMs: Long = 180L) {
        mainHandler.postDelayed({
            if (VoiceTurnPolicy.canAutoResumeListening(state, muted, latestSending)) {
                requestListenTick += 1
            }
        }, delayMs)
    }

    fun stopAudio() {
        cancelRecognizerSilently()
        bargeInDetector.stop()
        neuralVoicePlayer.stop()
        runCatching { tts?.stop() }
        assistantLevel = 0f
    }

    fun interruptAssistantAndListen() {
        AionHaptics.tap(hapticView)
        bargeInDetector.stop()
        neuralVoicePlayer.stop()
        runCatching { tts?.stop() }
        assistantLevel = 0f
        state = VoiceTurnPolicy.passivePhase(muted)
        if (!muted) scheduleListen(90L)
    }

    fun startListeningNow() {
        if (muted || latestSending || state == AionLivePhase.SPEAKING) return
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return
        val r = recognizer ?: return
        partialText = ""
        rms = 0f
        state = AionLivePhase.LISTENING
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag())
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, false)
            // فواصل صمت أقصر من الوضع القديم لتقليل التأخير بعد انتهاء المستخدم من الكلام.
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 900L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 520L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 350L)
        }
        runCatching { r.startListening(intent) }
            .onFailure {
                state = AionLivePhase.RECONNECTING
                recognitionFailures += 1
                scheduleListen(VoiceTurnPolicy.retryDelayMs(recognitionFailures, networkRelated = false))
            }
    }

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) {
            requestListenTick += 1
        } else {
            state = AionLivePhase.ERROR
            Toast.makeText(context, "يحتاج AION إذن الميكروفون لبدء المكالمة.", Toast.LENGTH_SHORT).show()
        }
    }

    DisposableEffect(context) {
        audioSession.acquire()
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            state = AionLivePhase.ERROR
        } else {
            val speech = SpeechRecognizer.createSpeechRecognizer(context)
            speech.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {
                    if (!muted) state = AionLivePhase.LISTENING
                }

                override fun onBeginningOfSpeech() {
                    recognitionFailures = 0
                    networkFailures = 0
                    if (!muted) state = AionLivePhase.LISTENING
                }

                override fun onRmsChanged(rmsdB: Float) {
                    // SpeechRecognizer يعطي RMS فعليًا للميكروفون؛ لا توجد حركة زمنية مصطنعة هنا.
                    rms = rmsdB.coerceIn(0f, 12f)
                }

                override fun onBufferReceived(buffer: ByteArray?) = Unit
                override fun onEndOfSpeech() {
                    rms = 0f
                    if (!latestSending && !muted) state = AionLivePhase.THINKING
                }

                override fun onError(error: Int) {
                    rms = 0f
                    if (SystemClock.uptimeMillis() <= suppressRecognizerErrorsUntil) return
                    if (muted || latestSending || state == AionLivePhase.SPEAKING) return

                    val networkRelated = error == SpeechRecognizer.ERROR_NETWORK ||
                        error == SpeechRecognizer.ERROR_NETWORK_TIMEOUT ||
                        error == SpeechRecognizer.ERROR_SERVER

                    when (error) {
                        SpeechRecognizer.ERROR_NO_MATCH,
                        SpeechRecognizer.ERROR_SPEECH_TIMEOUT,
                        SpeechRecognizer.ERROR_RECOGNIZER_BUSY,
                        SpeechRecognizer.ERROR_NETWORK,
                        SpeechRecognizer.ERROR_NETWORK_TIMEOUT,
                        SpeechRecognizer.ERROR_SERVER -> {
                            recognitionFailures += 1
                            if (networkRelated) networkFailures += 1 else networkFailures = 0
                            if (VoiceTurnPolicy.shouldRequireManualResume(networkFailures)) {
                                state = AionLivePhase.ERROR
                            } else {
                                state = if (networkRelated) AionLivePhase.RECONNECTING else AionLivePhase.LISTENING
                                scheduleListen(VoiceTurnPolicy.retryDelayMs(recognitionFailures, networkRelated))
                            }
                        }
                        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> state = AionLivePhase.ERROR
                        else -> state = AionLivePhase.ERROR
                    }
                }

                override fun onResults(results: Bundle?) {
                    rms = 0f
                    recognitionFailures = 0
                    networkFailures = 0
                    val spoken = results
                        ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.firstOrNull()
                        ?.trim()
                        .orEmpty()
                    if (spoken.isNotBlank()) {
                        partialText = spoken
                        state = AionLivePhase.THINKING
                        onSend(spoken)
                    } else if (!muted) {
                        partialText = ""
                        scheduleListen(260L)
                    }
                }

                override fun onPartialResults(partialResults: Bundle?) {
                    partialText = partialResults
                        ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.firstOrNull()
                        .orEmpty()
                }

                override fun onEvent(eventType: Int, params: Bundle?) = Unit
            })
            recognizer = speech
        }

        var engine: TextToSpeech? = null
        engine = runCatching {
            TextToSpeech(context.applicationContext) { status ->
                val ready = engine ?: return@TextToSpeech
                if (status == TextToSpeech.SUCCESS) {
                    runCatching { configureNaturalTts(ready, Locale.getDefault()) }
                    ready.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                        override fun onStart(utteranceId: String?) {
                            mainHandler.post {
                                assistantLevel = 0f
                                state = AionLivePhase.SPEAKING
                            }
                        }

                        override fun onBeginSynthesis(utteranceId: String?, sampleRateInHz: Int, audioFormat: Int, channelCount: Int) {
                            synthesisFormat.set(audioFormat)
                        }

                        override fun onAudioAvailable(utteranceId: String?, audio: ByteArray?) {
                            val bytes = audio ?: return
                            val rawLevel = when (synthesisFormat.get()) {
                                AudioFormat.ENCODING_PCM_8BIT -> VoiceAmplitude.pcm8Unsigned(bytes)
                                AudioFormat.ENCODING_PCM_16BIT -> VoiceAmplitude.pcm16LittleEndian(bytes)
                                AudioFormat.ENCODING_PCM_FLOAT -> VoiceAmplitude.pcmFloatLittleEndian(bytes)
                                else -> 0f
                            }
                            mainHandler.post {
                                if (state == AionLivePhase.SPEAKING) {
                                    assistantLevel = VoiceAmplitude.smooth(assistantLevel, rawLevel)
                                }
                            }
                        }

                        override fun onDone(utteranceId: String?) {
                            if (utteranceId?.endsWith(":last") != true) return
                            mainHandler.post {
                                assistantLevel = 0f
                                partialText = ""
                                state = VoiceTurnPolicy.passivePhase(muted)
                                if (!muted) scheduleListen(230L)
                            }
                        }

                        override fun onStop(utteranceId: String?, interrupted: Boolean) {
                            mainHandler.post { assistantLevel = 0f }
                        }

                        @Deprecated("Deprecated in Java")
                        override fun onError(utteranceId: String?) {
                            mainHandler.post {
                                assistantLevel = 0f
                                state = AionLivePhase.ERROR
                                if (!muted) scheduleListen(700L)
                            }
                        }
                    })
                    tts = ready
                    ttsReady = true
                    if (state == AionLivePhase.INITIALIZING) state = AionLivePhase.LISTENING
                } else {
                    ttsReady = false
                    if (state == AionLivePhase.INITIALIZING) state = AionLivePhase.LISTENING
                }
            }
        }.getOrNull()

        if (engine == null) {
            ttsReady = false
            if (state == AionLivePhase.INITIALIZING) state = AionLivePhase.ERROR
        }

        onDispose {
            bargeInDetector.stop()
            neuralVoicePlayer.stop()
            audioSession.release()
            runCatching { speechRecognizerSafeDestroy(recognizer) }
            engine?.let { current ->
                runCatching { current.stop() }
                runCatching { current.shutdown() }
            }
            mainHandler.removeCallbacksAndMessages(null)
            recognizer = null
            tts = null
            ttsReady = false
        }
    }

    LaunchedEffect(Unit) {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            requestListenTick += 1
        } else {
            permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    LaunchedEffect(requestListenTick) {
        if (requestListenTick > 0 && VoiceTurnPolicy.canAutoResumeListening(state, muted, isSending)) {
            delay(90)
            startListeningNow()
        }
    }

    LaunchedEffect(state, muted) {
        if (state == AionLivePhase.SPEAKING && !muted) {
            bargeInDetector.start {
                mainHandler.post {
                    if (state == AionLivePhase.SPEAKING && !muted) {
                        interruptAssistantAndListen()
                    }
                }
            }
        } else {
            bargeInDetector.stop()
        }
    }

    LaunchedEffect(isSending, activity) {
        if (isSending) {
            // A typed message while AION is speaking is a real interruption: stop the old
            // audio immediately, then move the same live session into the new thinking turn.
            if (VoiceTurnPolicy.shouldInterruptPlaybackOnRequest(state)) {
                neuralVoicePlayer.stop()
                runCatching { tts?.stop() }
            }
            assistantLevel = 0f
            cancelRecognizerSilently()
            state = AionLivePhasePolicy.fromGatewayActivity(activity)
        }
    }

    LaunchedEffect(messages.lastOrNull()?.id, isSending, ttsReady, neuralVoiceAvailable, cloudEndpoint, voiceProfile) {
        if (isSending) return@LaunchedEffect
        val last = messages.lastOrNull() ?: return@LaunchedEffect
        if (last.role != MessageRole.AION || last.id == lastHandledAssistantId) return@LaunchedEffect

        if (last.isError || last.text.isBlank()) {
            lastHandledAssistantId = last.id
            state = AionLivePhase.ERROR
            delay(650)
            if (!muted) scheduleListen(0L)
            return@LaunchedEffect
        }

        lastHandledAssistantId = last.id
        val cleanSpeech = SpeechText.clean(last.text)
        if (cleanSpeech.isBlank()) {
            state = VoiceTurnPolicy.passivePhase(muted)
            if (!muted) scheduleListen(120L)
            return@LaunchedEffect
        }

        suspend fun playLocalFallback() {
            val engine = tts
            if (engine == null || !ttsReady) {
                state = VoiceTurnPolicy.passivePhase(muted)
                if (!muted) scheduleListen(150L)
                return
            }
            state = AionLivePhase.SPEAKING
            val chunks = SpeechText.chunks(last.text)
            if (chunks.isEmpty()) {
                state = VoiceTurnPolicy.passivePhase(muted)
                if (!muted) scheduleListen(120L)
                return
            }
            chunks.forEachIndexed { index, chunk ->
                val isLast = index == chunks.lastIndex
                engine.speak(
                    chunk,
                    if (index == 0) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD,
                    null,
                    "aion-call-${last.id}-$index${if (isLast) ":last" else ""}"
                )
            }
        }

        if (!neuralVoiceAvailable) {
            playLocalFallback()
            return@LaunchedEffect
        }

        // دفعات أطول من Android TTS لكنها محدودة حتى يبدأ الصوت العصبي بسرعة ويبقى
        // قابلًا للمقاطعة. الصوت يصل PCM خامًا من AION Cloud وتتحرك الـOrb من نفس العينات.
        val neuralChunks = SpeechText.splitNatural(cleanSpeech, 2_200)
        var playedAnyNeuralAudio = false
        for (chunk in neuralChunks) {
            val result = neuralVoicePlayer.speak(
                endpoint = cloudEndpoint,
                text = chunk,
                profile = voiceProfile,
                onStarted = {
                    playedAnyNeuralAudio = true
                    mainHandler.post { state = AionLivePhase.SPEAKING }
                },
                onLevel = { level ->
                    mainHandler.post {
                        if (state == AionLivePhase.SPEAKING) {
                            assistantLevel = VoiceAmplitude.smooth(assistantLevel, level)
                        }
                    }
                }
            )

            when (result) {
                NeuralVoicePlaybackResult.PLAYED -> Unit
                NeuralVoicePlaybackResult.INTERRUPTED -> return@LaunchedEffect
                NeuralVoicePlaybackResult.UNAVAILABLE,
                NeuralVoicePlaybackResult.FAILED -> {
                    if (!playedAnyNeuralAudio) {
                        playLocalFallback()
                    } else {
                        state = VoiceTurnPolicy.passivePhase(muted)
                        if (!muted) scheduleListen(180L)
                    }
                    return@LaunchedEffect
                }
            }
        }

        assistantLevel = 0f
        partialText = ""
        state = VoiceTurnPolicy.passivePhase(muted)
        if (!muted) scheduleListen(180L)
    }

    val liveLevel = when (state) {
        AionLivePhase.LISTENING -> (rms / 12f).coerceIn(0f, 1f)
        AionLivePhase.SPEAKING -> assistantLevel.coerceIn(0f, 1f)
        else -> 0f
    }
    val requestedScale = 1f + (liveLevel * if (state == AionLivePhase.SPEAKING) 0.16f else 0.18f)
    val pulseScale by animateFloatAsState(
        targetValue = requestedScale,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium),
        label = "voice-reactive-scale"
    )
    val glowAlpha by animateFloatAsState(
        targetValue = 0.08f + (liveLevel * 0.22f),
        animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
        label = "voice-reactive-glow"
    )

    val status = AionLivePhasePolicy.statusLabel(state, muted)
    val helper = when {
        muted -> "الميكروفون مكتوم"
        state == AionLivePhase.SPEAKING -> if (bargeInDetector.isSupported()) {
            "تكلم لمقاطعة AION، أو اضغط على الدائرة"
        } else {
            "اضغط على الدائرة لمقاطعة AION والتحدث"
        }
        state == AionLivePhase.LISTENING -> "تحدث بشكل طبيعي؛ سأرسل كلامك عند انتهاء الجملة"
        AionLivePhasePolicy.isBusy(state) -> "يمكنك إيقاف الرد من الزر السفلي"
        state == AionLivePhase.ERROR -> "اضغط على الدائرة لإعادة تشغيل الاستماع"
        else -> ""
    }

    var dragOffsetPx by remember { mutableFloatStateOf(0f) }

    if (presentation == AionLivePresentation.MINIMIZED) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .navigationBarsPadding()
                .imePadding()
        ) {
            MiniAionLiveOrb(
                state = state,
                muted = muted,
                liveLevel = liveLevel,
                status = status,
                onRestore = {
                    AionHaptics.tap(hapticView)
                    onRestore()
                },
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(end = AionSpacing.Lg, bottom = 88.dp)
            )
        }
        return
    }

    Dialog(
        onDismissRequest = {
            // Back/dismiss minimizes the live session; only the explicit end control terminates it.
            onMinimize()
        },
        properties = DialogProperties(
            usePlatformDefaultWidth = false,
            dismissOnBackPress = true,
            dismissOnClickOutside = false
        )
    ) {
        Surface(
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer {
                    translationY = dragOffsetPx
                    val fraction = (dragOffsetPx / size.height.coerceAtLeast(1f)).coerceIn(0f, 0.22f)
                    alpha = 1f - fraction
                    scaleX = 1f - fraction * 0.35f
                    scaleY = 1f - fraction * 0.35f
                }
                .pointerInput(onMinimize) {
                    detectVerticalDragGestures(
                        onVerticalDrag = { change, amount ->
                            if (amount > 0f || dragOffsetPx > 0f) {
                                change.consume()
                                dragOffsetPx = (dragOffsetPx + amount).coerceIn(0f, size.height * 0.42f)
                            }
                        },
                        onDragEnd = {
                            if (dragOffsetPx >= 120.dp.toPx()) onMinimize()
                            dragOffsetPx = 0f
                        },
                        onDragCancel = { dragOffsetPx = 0f }
                    )
                },
            color = AionColors.Background
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .navigationBarsPadding()
                    .padding(horizontal = AionSpacing.Xxl, vertical = AionSpacing.Xl),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    androidx.compose.material3.IconButton(
                        onClick = {
                            stopAudio()
                            if (isSending) onStop()
                            onDismiss()
                        },
                        modifier = Modifier.size(AionSizes.TouchTarget)
                    ) {
                        Icon(Icons.Outlined.Close, contentDescription = "إنهاء AION Live")
                    }

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("AION Live", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.ExtraBold)
                        Text(
                            "الصوت والنص في المحادثة نفسها",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    androidx.compose.material3.IconButton(
                        onClick = {
                            AionHaptics.tap(hapticView)
                            onMinimize()
                        },
                        modifier = Modifier.size(AionSizes.TouchTarget)
                    ) {
                        Icon(Icons.Outlined.KeyboardArrowDown, contentDescription = "تصغير AION Live")
                    }
                }

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    AionVoiceOrb(
                        state = state,
                        liveLevel = liveLevel,
                        pulseScale = pulseScale,
                        glowAlpha = glowAlpha,
                        onClick = {
                            when (state) {
                                AionLivePhase.SPEAKING -> interruptAssistantAndListen()
                                AionLivePhase.THINKING, AionLivePhase.READING_FILES,
                                AionLivePhase.SEARCHING, AionLivePhase.COMPARING, AionLivePhase.WRITING -> {
                                    onStop()
                                    if (!muted) scheduleListen(220L)
                                }
                                AionLivePhase.IDLE, AionLivePhase.ERROR, AionLivePhase.RECONNECTING, AionLivePhase.INITIALIZING -> {
                                    recognitionFailures = 0
                                    networkFailures = 0
                                    if (!muted) {
                                        state = AionLivePhase.LISTENING
                                        scheduleListen(50L)
                                    }
                                }
                                AionLivePhase.LISTENING -> Unit
                            }
                        }
                    )
                    Spacer(Modifier.height(AionSpacing.Xxl))
                    Text(
                        status,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.SemiBold,
                        textAlign = TextAlign.Center
                    )
                    if (helper.isNotBlank()) {
                        Spacer(Modifier.height(AionSpacing.Sm))
                        Text(
                            helper,
                            modifier = Modifier.fillMaxWidth().padding(horizontal = AionSpacing.Md),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center
                        )
                    }
                    if (partialText.isNotBlank()) {
                        Spacer(Modifier.height(AionSpacing.Lg))
                        Surface(
                            shape = androidx.compose.foundation.shape.RoundedCornerShape(AionRadii.Card),
                            color = AionColors.Surface,
                            border = BorderStroke(1.dp, AionColors.Border)
                        ) {
                            Text(
                                partialText,
                                modifier = Modifier.padding(horizontal = AionSpacing.Lg, vertical = AionSpacing.Md),
                                style = MaterialTheme.typography.bodyLarge,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                textAlign = TextAlign.Center,
                                maxLines = 4
                            )
                        }
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        onClick = onMinimize,
                        shape = CircleShape,
                        color = AionColors.SurfaceRaised,
                        modifier = Modifier.size(58.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(Icons.Outlined.Keyboard, contentDescription = "العودة للكتابة")
                        }
                    }

                    Surface(
                        onClick = {
                            muted = !muted
                            if (muted) {
                                rms = 0f
                                cancelRecognizerSilently()
                            } else if (!isSending && state != AionLivePhase.SPEAKING) {
                                recognitionFailures = 0
                                networkFailures = 0
                                state = AionLivePhase.LISTENING
                                scheduleListen(80L)
                            }
                        },
                        shape = CircleShape,
                        color = if (muted) AionColors.Error.copy(alpha = 0.16f) else AionColors.SurfaceRaised,
                        modifier = Modifier.size(58.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                if (muted) Icons.Outlined.MicOff else Icons.Outlined.Mic,
                                contentDescription = if (muted) "تشغيل الميكروفون" else "كتم الميكروفون"
                            )
                        }
                    }

                    Surface(
                        onClick = {
                            stopAudio()
                            if (isSending) onStop()
                            onDismiss()
                        },
                        shape = CircleShape,
                        color = AionColors.Error.copy(alpha = 0.82f),
                        modifier = Modifier.size(68.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(Icons.Outlined.CallEnd, contentDescription = "إنهاء AION Live", tint = Color.White, modifier = Modifier.size(30.dp))
                        }
                    }

                    Surface(
                        onClick = {
                            when {
                                state == AionLivePhase.SPEAKING -> interruptAssistantAndListen()
                                isSending -> {
                                    onStop()
                                    state = VoiceTurnPolicy.passivePhase(muted)
                                    if (!muted) scheduleListen(220L)
                                }
                                else -> {
                                    cancelRecognizerSilently()
                                    if (!muted) scheduleListen(100L)
                                }
                            }
                        },
                        shape = CircleShape,
                        color = AionColors.SurfaceRaised,
                        modifier = Modifier.size(58.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(Icons.Outlined.Stop, contentDescription = "إيقاف أو مقاطعة")
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun MiniAionLiveOrb(
    state: AionLivePhase,
    muted: Boolean,
    liveLevel: Float,
    status: String,
    onRestore: () -> Unit,
    modifier: Modifier = Modifier
) {
    val accent = activityAccent(state)
    val miniScale by animateFloatAsState(
        targetValue = if (state == AionLivePhase.LISTENING || state == AionLivePhase.SPEAKING) {
            1f + liveLevel * 0.08f
        } else {
            1f
        },
        animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
        label = "mini-live-scale"
    )

    Surface(
        onClick = onRestore,
        shape = CircleShape,
        color = AionColors.SurfaceRaised,
        border = BorderStroke(1.dp, accent.copy(alpha = 0.50f)),
        modifier = modifier
            .size(AionSizes.MiniLiveOrb)
            .scale(miniScale)
            .semantics {
                val accessibilityStatus = if (muted) "الميكروفون مكتوم" else status
                contentDescription = "AION Live: $accessibilityStatus. اضغط للعودة إلى شاشة الصوت"
            }
    ) {
        Box(contentAlignment = Alignment.Center) {
            if (muted) {
                Icon(
                    Icons.Outlined.MicOff,
                    contentDescription = null,
                    tint = AionColors.Error,
                    modifier = Modifier.size(20.dp)
                )
            } else {
                MiniVoiceBars(level = liveLevel, state = state)
            }
        }
    }
}

@Composable
private fun AionVoiceOrb(
    state: AionLivePhase,
    liveLevel: Float,
    pulseScale: Float,
    glowAlpha: Float,
    onClick: () -> Unit
) {
    val accent = activityAccent(state)
    Box(
        modifier = Modifier
            .size(176.dp)
            .scale(pulseScale)
            .background(accent.copy(alpha = glowAlpha), CircleShape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Surface(
            shape = CircleShape,
            color = AionColors.SurfaceRaised,
            border = BorderStroke(1.dp + (liveLevel * 1.2f).dp, accent.copy(alpha = 0.46f + liveLevel * 0.44f)),
            modifier = Modifier.size(118.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                VoiceBars(level = liveLevel, accent = accent, large = true)
            }
        }
    }
}

@Composable
private fun MiniVoiceBars(level: Float, state: AionLivePhase) {
    VoiceBars(level = level, accent = activityAccent(state), large = false)
}

@Composable
private fun VoiceBars(level: Float, accent: Color, large: Boolean) {
    val bases = listOf(0.50f, 0.90f, 0.66f, 1.00f, 0.58f)
    val minHeight = if (large) 14.dp else 7.dp
    val extra = if (large) 28.dp else 12.dp
    val width = if (large) 4.dp else 2.5.dp
    Row(
        horizontalArrangement = Arrangement.spacedBy(if (large) 5.dp else 3.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        bases.forEachIndexed { index, base ->
            val phaseBoost = when {
                level > 0.02f -> (level * base)
                index == 2 -> 0.16f
                else -> 0.06f
            }
            Box(
                Modifier
                    .width(width)
                    .height(minHeight + extra * phaseBoost)
                    .background(if (index == 2) accent else accent.copy(alpha = 0.72f), CircleShape)
            )
        }
    }
}

private fun activityAccent(state: AionLivePhase): Color = when {
    state == AionLivePhase.ERROR -> AionColors.Error
    AionLivePhasePolicy.usesExternalAccent(state) -> AionColors.External
    else -> AionColors.Intelligence
}

internal fun configureNaturalTts(engine: TextToSpeech, locale: Locale): Boolean {
    // كل خطوة اختيارية. بعض محركات TTS على أجهزة OEM لا تنفذ جميع الخصائص
    // القياسية بصورة سليمة؛ فشل تحسين واحد يجب ألا يغلق التطبيق أو المكالمة.
    val selectedLocale = runCatching {
        val available = engine.isLanguageAvailable(locale) >= TextToSpeech.LANG_AVAILABLE
        if (available) locale else Locale.forLanguageTag(locale.language.ifBlank { "ar" })
    }.getOrDefault(locale)

    val languageResult = runCatching { engine.setLanguage(selectedLocale) }
        .getOrDefault(TextToSpeech.LANG_NOT_SUPPORTED)

    runCatching {
        engine.setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ASSISTANT)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build()
        )
    }
    runCatching { engine.setSpeechRate(if (selectedLocale.language == "ar") 0.94f else 0.97f) }
    runCatching { engine.setPitch(1.0f) }

    runCatching {
        val bestVoice = engine.voices
            ?.asSequence()
            ?.filter { it.locale.language == selectedLocale.language }
            ?.maxByOrNull { voice ->
                (voice.quality * 100) - (voice.latency * 6) + if (voice.isNetworkConnectionRequired) 12 else 0
            }
        if (bestVoice != null) engine.voice = bestVoice
    }

    return languageResult != TextToSpeech.LANG_MISSING_DATA &&
        languageResult != TextToSpeech.LANG_NOT_SUPPORTED
}

private fun speechRecognizerSafeDestroy(recognizer: SpeechRecognizer?) {
    recognizer?.cancel()
    recognizer?.destroy()
}
