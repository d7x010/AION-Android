package com.aion.mobile.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.AudioFormat
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.spring
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.CallEnd
import androidx.compose.material.icons.outlined.Keyboard
import androidx.compose.material.icons.outlined.KeyboardArrowDown
import androidx.compose.material.icons.outlined.Mic
import androidx.compose.material.icons.outlined.MicOff
import androidx.compose.material.icons.outlined.Stop
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import com.aion.mobile.core.ai.GatewayActivity
import com.aion.mobile.core.voice.AionLivePhase
import com.aion.mobile.core.voice.AionLivePresentation
import com.aion.mobile.core.voice.AionLiveUiPolicy
import com.aion.mobile.core.voice.AionLiveVisualDomain
import com.aion.mobile.core.voice.AionVoiceSettings
import com.aion.mobile.core.voice.AionVoicePlaybackArbiter
import com.aion.mobile.core.voice.AionVoicePlaybackOwner
import com.aion.mobile.core.voice.VoiceAudioFocus
import com.aion.mobile.core.voice.VoiceCommunicationSession
import com.aion.mobile.core.voice.VoiceBargeInDetector
import com.aion.mobile.core.voice.NeuralVoicePlaybackResult
import com.aion.mobile.core.voice.NeuralVoicePlayer
import com.aion.mobile.core.voice.SpeechText
import com.aion.mobile.core.voice.VoiceAmplitude
import com.aion.mobile.core.voice.VoiceTurnPolicy
import com.aion.mobile.core.voice.VoicePlaybackPolicy
import com.aion.mobile.model.ChatMessage
import com.aion.mobile.model.MessageRole
import com.aion.mobile.ui.design.AionColors
import com.aion.mobile.ui.design.AionHaptics
import com.aion.mobile.ui.design.AionRadii
import com.aion.mobile.ui.design.AionSizes
import com.aion.mobile.ui.design.AionSpacing
import kotlinx.coroutines.delay
import java.util.Locale
import java.util.concurrent.atomic.AtomicInteger

private enum class VoiceCallState {
    INITIALIZING,
    LISTENING,
    THINKING,
    READING_FILES,
    SEARCHING,
    COMPARING,
    WRITING,
    SPEAKING,
    RECONNECTING,
    ERROR
}

/**
 * مكالمة صوتية داخل المحادثة: استماع -> إرسال -> رد -> كلام -> استماع.
 *
 * ليست WebRTC full-duplex بعد، لكن الحركة أثناء كلام AION تعتمد على PCM الحقيقي الذي يولده TTS
 * عبر UtteranceProgressListener.onAudioAvailable بدل نبضة زمنية وهمية. ويمكن للمستخدم مقاطعة
 * كلام AION فورًا بالضغط على الدائرة أو زر الإيقاف لبدء الاستماع إلى دوره الجديد.
 */
@Composable
internal fun VoiceCallOverlay(
    presentation: AionLivePresentation,
    cloudEndpoint: String,
    neuralVoiceAvailable: Boolean,
    voiceSettings: AionVoiceSettings,
    myVoiceToken: String,
    voicePlaybackArbiter: AionVoicePlaybackArbiter,
    messages: List<ChatMessage>,
    isSending: Boolean,
    activity: GatewayActivity?,
    muted: Boolean,
    onSend: (String) -> Unit,
    onStop: () -> Unit,
    onPhaseChanged: (AionLivePhase) -> Unit,
    onMutedChanged: (Boolean) -> Unit,
    onMinimize: () -> Unit,
    onRestore: () -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val hapticView = LocalView.current
    val mainHandler = remember { Handler(Looper.getMainLooper()) }
    val neuralVoicePlayer = remember { NeuralVoicePlayer() }
    val bargeInDetector = remember { VoiceBargeInDetector() }
    val audioFocus = remember { VoiceAudioFocus(context) }
    val communicationSession = remember { VoiceCommunicationSession(context) }
    val latestSending by rememberUpdatedState(isSending)
    val latestMuted by rememberUpdatedState(muted)
    var state by remember { mutableStateOf(VoiceCallState.INITIALIZING) }
    var partialText by remember { mutableStateOf("") }
    var rms by remember { mutableFloatStateOf(0f) }
    var assistantLevel by remember { mutableFloatStateOf(0f) }
    var recognizer by remember { mutableStateOf<SpeechRecognizer?>(null) }
    var tts by remember { mutableStateOf<TextToSpeech?>(null) }
    var ttsReady by remember { mutableStateOf(false) }
    var requestListenTick by remember { mutableIntStateOf(0) }
    var recognitionFailures by remember { mutableIntStateOf(0) }
    var networkFailures by remember { mutableIntStateOf(0) }
    var suppressRecognizerErrorsUntil by remember { mutableLongStateOf(0L) }
    val synthesisFormat = remember { AtomicInteger(AudioFormat.ENCODING_PCM_16BIT) }
    var lastHandledAssistantId by remember {
        mutableStateOf(messages.lastOrNull { it.role == MessageRole.AION }?.id)
    }
    var lastAssistantTranscript by remember { mutableStateOf("") }
    var automaticBargeInActive by remember { mutableStateOf(false) }
    var showMiniLabel by remember { mutableStateOf(true) }
    var livePlaybackLease by remember { mutableStateOf<Long?>(null) }

    fun cancelRecognizerSilently() {
        suppressRecognizerErrorsUntil = SystemClock.uptimeMillis() + 650L
        runCatching { recognizer?.cancel() }
        rms = 0f
    }

    fun scheduleListen(delayMs: Long = 180L) {
        mainHandler.postDelayed({
            if (!latestMuted && !latestSending && state != VoiceCallState.SPEAKING) {
                requestListenTick += 1
            }
        }, delayMs)
    }

    fun stopPlaybackHardware() {
        bargeInDetector.stop()
        automaticBargeInActive = false
        neuralVoicePlayer.stop()
        runCatching { tts?.stop() }
        assistantLevel = 0f
        audioFocus.abandon()
    }

    fun releaseLiveLease(token: Long?) {
        token ?: return
        voicePlaybackArbiter.release(AionVoicePlaybackOwner.LIVE, token)
        if (livePlaybackLease == token) livePlaybackLease = null
    }

    fun claimLivePlayback(): Long {
        var claimedToken = 0L
        val token = voicePlaybackArbiter.claim(AionVoicePlaybackOwner.LIVE) {
            // Audio is stopped synchronously so another AION surface can start without overlap.
            stopPlaybackHardware()
            mainHandler.post {
                if (livePlaybackLease == claimedToken) livePlaybackLease = null
                if (!latestMuted && !latestSending && state == VoiceCallState.SPEAKING) {
                    state = VoiceCallState.LISTENING
                    scheduleListen(70L)
                }
            }
        }
        claimedToken = token
        livePlaybackLease = token
        return token
    }

    fun stopAudio() {
        cancelRecognizerSilently()
        if (!voicePlaybackArbiter.interrupt(AionVoicePlaybackOwner.LIVE)) {
            stopPlaybackHardware()
        }
        livePlaybackLease = null
    }

    fun interruptAssistantAndListen(haptic: Boolean = true) {
        if (haptic) AionHaptics.tap(hapticView)
        if (!voicePlaybackArbiter.interrupt(AionVoicePlaybackOwner.LIVE)) {
            stopPlaybackHardware()
        }
        livePlaybackLease = null
        if (!latestMuted) {
            state = VoiceCallState.LISTENING
            scheduleListen(70L)
        }
    }

    fun startAutomaticBargeInIfSupported() {
        if (latestMuted || state != VoiceCallState.SPEAKING) return
        bargeInDetector.stop()
        automaticBargeInActive = bargeInDetector.start(context) {
            mainHandler.post {
                if (state == VoiceCallState.SPEAKING && !latestMuted) {
                    interruptAssistantAndListen(haptic = false)
                    AionHaptics.confirm(hapticView)
                }
            }
        }
    }

    fun liveTokenOf(utteranceId: String?): Long? = utteranceId
        ?.takeIf { it.startsWith("aion-call-") }
        ?.removePrefix("aion-call-")
        ?.substringBefore('-')
        ?.toLongOrNull()

    fun startListeningNow() {
        if (latestMuted || latestSending || state == VoiceCallState.SPEAKING) return
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return
        val r = recognizer ?: return
        partialText = ""
        rms = 0f
        state = VoiceCallState.LISTENING
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag())
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, false)
            // فواصل صمت أقصر من الوضع القديم لتقليل التأخير بعد انتهاء المستخدم من الكلام.
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 900L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 520L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 350L)
        }
        runCatching { r.startListening(intent) }
            .onFailure {
                state = VoiceCallState.RECONNECTING
                recognitionFailures += 1
                scheduleListen(VoiceTurnPolicy.retryDelayMs(recognitionFailures, networkRelated = false))
            }
    }

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) {
            requestListenTick += 1
        } else {
            state = VoiceCallState.ERROR
            Toast.makeText(context, "يحتاج AION إذن الميكروفون لبدء المكالمة.", Toast.LENGTH_SHORT).show()
        }
    }

    DisposableEffect(context) {
        communicationSession.enter()
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            state = VoiceCallState.ERROR
        } else {
            val speech = SpeechRecognizer.createSpeechRecognizer(context)
            speech.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {
                    if (!latestMuted) state = VoiceCallState.LISTENING
                }

                override fun onBeginningOfSpeech() {
                    recognitionFailures = 0
                    networkFailures = 0
                    if (!latestMuted) state = VoiceCallState.LISTENING
                }

                override fun onRmsChanged(rmsdB: Float) {
                    // SpeechRecognizer يعطي RMS فعليًا للميكروفون؛ لا توجد حركة زمنية مصطنعة هنا.
                    rms = rmsdB.coerceIn(0f, 12f)
                }

                override fun onBufferReceived(buffer: ByteArray?) = Unit
                override fun onEndOfSpeech() {
                    rms = 0f
                    if (!latestSending && !latestMuted) state = VoiceCallState.THINKING
                }

                override fun onError(error: Int) {
                    rms = 0f
                    if (SystemClock.uptimeMillis() <= suppressRecognizerErrorsUntil) return
                    if (latestMuted || latestSending || state == VoiceCallState.SPEAKING) return

                    val networkRelated = error == SpeechRecognizer.ERROR_NETWORK ||
                        error == SpeechRecognizer.ERROR_NETWORK_TIMEOUT ||
                        error == SpeechRecognizer.ERROR_SERVER

                    when (error) {
                        SpeechRecognizer.ERROR_NO_MATCH,
                        SpeechRecognizer.ERROR_SPEECH_TIMEOUT,
                        SpeechRecognizer.ERROR_RECOGNIZER_BUSY,
                        SpeechRecognizer.ERROR_NETWORK,
                        SpeechRecognizer.ERROR_NETWORK_TIMEOUT,
                        SpeechRecognizer.ERROR_SERVER -> {
                            recognitionFailures += 1
                            if (networkRelated) networkFailures += 1 else networkFailures = 0
                            if (VoiceTurnPolicy.shouldRequireManualResume(networkFailures)) {
                                state = VoiceCallState.ERROR
                            } else {
                                state = if (networkRelated) VoiceCallState.RECONNECTING else VoiceCallState.LISTENING
                                scheduleListen(VoiceTurnPolicy.retryDelayMs(recognitionFailures, networkRelated))
                            }
                        }
                        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> state = VoiceCallState.ERROR
                        else -> state = VoiceCallState.ERROR
                    }
                }

                override fun onResults(results: Bundle?) {
                    rms = 0f
                    recognitionFailures = 0
                    networkFailures = 0
                    val spoken = results
                        ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.firstOrNull()
                        ?.trim()
                        .orEmpty()
                    if (spoken.isNotBlank()) {
                        partialText = spoken
                        state = VoiceCallState.THINKING
                        onSend(spoken)
                    } else if (!latestMuted) {
                        partialText = ""
                        scheduleListen(260L)
                    }
                }

                override fun onPartialResults(partialResults: Bundle?) {
                    partialText = partialResults
                        ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.firstOrNull()
                        .orEmpty()
                }

                override fun onEvent(eventType: Int, params: Bundle?) = Unit
            })
            recognizer = speech
        }

        var engine: TextToSpeech? = null
        engine = runCatching {
            TextToSpeech(context.applicationContext) { status ->
                val ready = engine ?: return@TextToSpeech
                if (status == TextToSpeech.SUCCESS) {
                    runCatching { configureNaturalTts(ready, Locale.getDefault()) }
                    ready.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                        override fun onStart(utteranceId: String?) {
                            val token = liveTokenOf(utteranceId) ?: return
                            mainHandler.post {
                                if (!voicePlaybackArbiter.isCurrent(AionVoicePlaybackOwner.LIVE, token)) return@post
                                assistantLevel = 0f
                                audioFocus.request()
                                state = VoiceCallState.SPEAKING
                                startAutomaticBargeInIfSupported()
                            }
                        }

                        override fun onBeginSynthesis(utteranceId: String?, sampleRateInHz: Int, audioFormat: Int, channelCount: Int) {
                            val token = liveTokenOf(utteranceId) ?: return
                            if (voicePlaybackArbiter.isCurrent(AionVoicePlaybackOwner.LIVE, token)) {
                                synthesisFormat.set(audioFormat)
                            }
                        }

                        override fun onAudioAvailable(utteranceId: String?, audio: ByteArray?) {
                            val token = liveTokenOf(utteranceId) ?: return
                            if (!voicePlaybackArbiter.isCurrent(AionVoicePlaybackOwner.LIVE, token)) return
                            val bytes = audio ?: return
                            val rawLevel = when (synthesisFormat.get()) {
                                AudioFormat.ENCODING_PCM_8BIT -> VoiceAmplitude.pcm8Unsigned(bytes)
                                AudioFormat.ENCODING_PCM_16BIT -> VoiceAmplitude.pcm16LittleEndian(bytes)
                                AudioFormat.ENCODING_PCM_FLOAT -> VoiceAmplitude.pcmFloatLittleEndian(bytes)
                                else -> 0f
                            }
                            mainHandler.post {
                                if (
                                    voicePlaybackArbiter.isCurrent(AionVoicePlaybackOwner.LIVE, token) &&
                                    state == VoiceCallState.SPEAKING
                                ) {
                                    assistantLevel = VoiceAmplitude.smooth(assistantLevel, rawLevel)
                                }
                            }
                        }

                        override fun onDone(utteranceId: String?) {
                            if (utteranceId?.endsWith(":last") != true) return
                            val token = liveTokenOf(utteranceId) ?: return
                            mainHandler.post {
                                if (!voicePlaybackArbiter.isCurrent(AionVoicePlaybackOwner.LIVE, token)) return@post
                                bargeInDetector.stop()
                                automaticBargeInActive = false
                                audioFocus.abandon()
                                assistantLevel = 0f
                                partialText = ""
                                releaseLiveLease(token)
                                if (!latestMuted) {
                                    state = VoiceCallState.LISTENING
                                    scheduleListen(140L)
                                }
                            }
                        }

                        override fun onStop(utteranceId: String?, interrupted: Boolean) {
                            val token = liveTokenOf(utteranceId) ?: return
                            mainHandler.post {
                                if (!voicePlaybackArbiter.isCurrent(AionVoicePlaybackOwner.LIVE, token)) return@post
                                bargeInDetector.stop()
                                automaticBargeInActive = false
                                audioFocus.abandon()
                                assistantLevel = 0f
                                releaseLiveLease(token)
                            }
                        }

                        @Deprecated("Deprecated in Java")
                        override fun onError(utteranceId: String?) {
                            val token = liveTokenOf(utteranceId) ?: return
                            mainHandler.post {
                                if (!voicePlaybackArbiter.isCurrent(AionVoicePlaybackOwner.LIVE, token)) return@post
                                bargeInDetector.stop()
                                automaticBargeInActive = false
                                audioFocus.abandon()
                                assistantLevel = 0f
                                releaseLiveLease(token)
                                state = VoiceCallState.ERROR
                                if (!latestMuted) scheduleListen(650L)
                            }
                        }
                    })
                    tts = ready
                    ttsReady = true
                    if (state == VoiceCallState.INITIALIZING) state = VoiceCallState.LISTENING
                } else {
                    ttsReady = false
                    if (state == VoiceCallState.INITIALIZING) state = VoiceCallState.LISTENING
                }
            }
        }.getOrNull()

        if (engine == null) {
            ttsReady = false
            if (state == VoiceCallState.INITIALIZING) state = VoiceCallState.ERROR
        }

        onDispose {
            voicePlaybackArbiter.interrupt(AionVoicePlaybackOwner.LIVE)
            bargeInDetector.stop()
            audioFocus.abandon()
            communicationSession.exit()
            neuralVoicePlayer.stop()
            runCatching { speechRecognizerSafeDestroy(recognizer) }
            engine?.let { current ->
                runCatching { current.stop() }
                runCatching { current.shutdown() }
            }
            mainHandler.removeCallbacksAndMessages(null)
            recognizer = null
            tts = null
            ttsReady = false
        }
    }

    LaunchedEffect(Unit) {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            requestListenTick += 1
        } else {
            permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    LaunchedEffect(requestListenTick) {
        if (requestListenTick > 0 && !muted && !isSending && state != VoiceCallState.SPEAKING) {
            delay(90)
            startListeningNow()
        }
    }

    LaunchedEffect(state, muted, automaticBargeInActive, presentation) {
        onPhaseChanged(state.toLivePhase())
        if (presentation == AionLivePresentation.MINIMIZED) {
            showMiniLabel = true
            delay(2_400L)
            showMiniLabel = false
        }
    }

    LaunchedEffect(muted) {
        if (muted) {
            rms = 0f
            cancelRecognizerSilently()
            bargeInDetector.stop()
            automaticBargeInActive = false
        } else if (!isSending && state != VoiceCallState.SPEAKING) {
            recognitionFailures = 0
            networkFailures = 0
            state = VoiceCallState.LISTENING
            scheduleListen(80L)
        }
    }

    LaunchedEffect(isSending, activity) {
        if (isSending) {
            // A typed message while AION is speaking is a real interruption: stop the old
            // audio immediately, then move the same live session into the new thinking turn.
            if (state == VoiceCallState.SPEAKING) {
                if (!voicePlaybackArbiter.interrupt(AionVoicePlaybackOwner.LIVE)) {
                    stopPlaybackHardware()
                }
                livePlaybackLease = null
            }
            assistantLevel = 0f
            cancelRecognizerSilently()
            state = when (activity) {
                GatewayActivity.SEARCHING_WEB -> VoiceCallState.SEARCHING
                GatewayActivity.READING_FILES -> VoiceCallState.READING_FILES
                GatewayActivity.COMPARING -> VoiceCallState.COMPARING
                GatewayActivity.WRITING -> VoiceCallState.WRITING
                else -> VoiceCallState.THINKING
            }
        }
    }

    LaunchedEffect(messages.lastOrNull()?.id, isSending, ttsReady) {
        if (isSending) return@LaunchedEffect
        val last = messages.lastOrNull() ?: return@LaunchedEffect
        if (last.role != MessageRole.AION || last.id == lastHandledAssistantId) return@LaunchedEffect

        if (last.isError || last.wasStopped || last.text.isBlank()) {
            lastHandledAssistantId = last.id
            state = VoiceCallState.ERROR
            delay(650)
            if (!latestMuted) scheduleListen(0L)
            return@LaunchedEffect
        }

        lastHandledAssistantId = last.id
        val cleanSpeech = SpeechText.clean(last.text)
        lastAssistantTranscript = cleanSpeech.take(420)
        if (cleanSpeech.isBlank()) {
            if (!latestMuted) scheduleListen(120L)
            return@LaunchedEffect
        }

        suspend fun playLocalFallback(text: String, lease: Long): Boolean {
            if (!voicePlaybackArbiter.isCurrent(AionVoicePlaybackOwner.LIVE, lease)) return false
            val engine = tts
            if (engine == null || !ttsReady) {
                releaseLiveLease(lease)
                if (!latestMuted) {
                    state = VoiceCallState.LISTENING
                    scheduleListen(140L)
                }
                return false
            }
            val chunks = SpeechText.chunks(text)
            if (chunks.isEmpty()) {
                releaseLiveLease(lease)
                if (!latestMuted) scheduleListen(120L)
                return false
            }

            audioFocus.request()
            state = VoiceCallState.SPEAKING
            runCatching { engine.setSpeechRate(voiceSettings.speed.coerceIn(0.72f, 1.20f)) }
            var queued = true
            chunks.forEachIndexed { index, chunk ->
                if (!queued) return@forEachIndexed
                val isLast = index == chunks.lastIndex
                val result = engine.speak(
                    chunk,
                    if (index == 0) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD,
                    null,
                    "aion-call-$lease-${last.id}-$index${if (isLast) ":last" else ""}"
                )
                if (result == TextToSpeech.ERROR) queued = false
            }
            if (!queued) {
                runCatching { engine.stop() }
                if (voicePlaybackArbiter.isCurrent(AionVoicePlaybackOwner.LIVE, lease)) {
                    audioFocus.abandon()
                    releaseLiveLease(lease)
                    state = VoiceCallState.ERROR
                    if (!latestMuted) scheduleListen(600L)
                }
                return false
            }
            return true
        }

        val lease = claimLivePlayback()
        val canUseNeural = neuralVoiceAvailable ||
            (voiceSettings.voiceKey == "my_voice" && myVoiceToken.isNotBlank())
        if (!canUseNeural) {
            playLocalFallback(last.text, lease)
            return@LaunchedEffect
        }

        // Natural chunks keep first audio responsive and make every chunk independently
        // interruptible. If neural playback fails, continue only the not-yet-spoken remainder
        // through local TTS instead of repeating the answer or truncating it completely.
        val neuralChunks = SpeechText.splitNatural(cleanSpeech, 2_200)
        if (neuralChunks.isEmpty()) {
            releaseLiveLease(lease)
            if (!latestMuted) scheduleListen(120L)
            return@LaunchedEffect
        }

        var handedOffToLocal = false
        try {
            for ((index, chunk) in neuralChunks.withIndex()) {
                if (!voicePlaybackArbiter.isCurrent(AionVoicePlaybackOwner.LIVE, lease)) return@LaunchedEffect
                var chunkStarted = false
                val result = neuralVoicePlayer.speak(
                    endpoint = cloudEndpoint,
                    text = chunk,
                    profile = voiceSettings.profile.key,
                    voiceKey = voiceSettings.voiceKey,
                    speed = voiceSettings.speed,
                    expression = voiceSettings.expression,
                    clarity = voiceSettings.clarity,
                    myVoiceToken = myVoiceToken,
                    onStarted = {
                        chunkStarted = true
                        mainHandler.post {
                            if (!voicePlaybackArbiter.isCurrent(AionVoicePlaybackOwner.LIVE, lease)) return@post
                            audioFocus.request()
                            state = VoiceCallState.SPEAKING
                            startAutomaticBargeInIfSupported()
                        }
                    },
                    onLevel = { level ->
                        mainHandler.post {
                            if (
                                voicePlaybackArbiter.isCurrent(AionVoicePlaybackOwner.LIVE, lease) &&
                                state == VoiceCallState.SPEAKING
                            ) {
                                assistantLevel = VoiceAmplitude.smooth(assistantLevel, level)
                            }
                        }
                    }
                )

                when (result) {
                    NeuralVoicePlaybackResult.PLAYED -> Unit
                    NeuralVoicePlaybackResult.INTERRUPTED -> return@LaunchedEffect
                    NeuralVoicePlaybackResult.UNAVAILABLE,
                    NeuralVoicePlaybackResult.FAILED -> {
                        val remainder = VoicePlaybackPolicy.localFallbackText(
                            chunks = neuralChunks,
                            failedIndex = index,
                            failedChunkStarted = chunkStarted
                        )
                        if (remainder.isNotBlank() && voicePlaybackArbiter.isCurrent(AionVoicePlaybackOwner.LIVE, lease)) {
                            bargeInDetector.stop()
                            automaticBargeInActive = false
                            assistantLevel = 0f
                            handedOffToLocal = playLocalFallback(remainder, lease)
                        }
                        return@LaunchedEffect
                    }
                }
            }
        } finally {
            if (!handedOffToLocal) {
                if (voicePlaybackArbiter.isCurrent(AionVoicePlaybackOwner.LIVE, lease)) {
                    bargeInDetector.stop()
                    automaticBargeInActive = false
                    audioFocus.abandon()
                    assistantLevel = 0f
                    partialText = ""
                    releaseLiveLease(lease)
                    if (!latestMuted && !latestSending) {
                        state = VoiceCallState.LISTENING
                        scheduleListen(140L)
                    }
                } else {
                    // Stale completion: release only its own token and never touch newer audio.
                    releaseLiveLease(lease)
                }
            }
        }
    }

    val liveLevel = when (state) {
        VoiceCallState.LISTENING -> (rms / 12f).coerceIn(0f, 1f)
        VoiceCallState.SPEAKING -> assistantLevel.coerceIn(0f, 1f)
        else -> 0f
    }
    val requestedScale = 1f + (liveLevel * if (state == VoiceCallState.SPEAKING) 0.16f else 0.18f)
    val pulseScale by animateFloatAsState(
        targetValue = requestedScale,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium),
        label = "voice-reactive-scale"
    )
    val glowAlpha by animateFloatAsState(
        targetValue = 0.08f + (liveLevel * 0.22f),
        animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
        label = "voice-reactive-glow"
    )

    val uiCopy = AionLiveUiPolicy.describe(
        phase = state.toLivePhase(),
        muted = muted,
        automaticBargeInActive = automaticBargeInActive
    )
    val status = uiCopy.status
    val helper = uiCopy.helper

    var dragOffsetPx by remember { mutableFloatStateOf(0f) }

    if (presentation == AionLivePresentation.MINIMIZED) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .navigationBarsPadding()
                .imePadding()
        ) {
            Row(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(end = AionSpacing.Lg, bottom = 82.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(AionSpacing.Sm)
            ) {
                AnimatedVisibility(visible = showMiniLabel) {
                    Surface(
                        shape = androidx.compose.foundation.shape.RoundedCornerShape(AionRadii.Chip),
                        color = AionColors.SurfaceRaised.copy(alpha = 0.96f),
                        border = BorderStroke(1.dp, AionColors.Border)
                    ) {
                        Text(
                            text = when {
                                muted -> "الميكروفون مكتوم"
                                automaticBargeInActive && state == VoiceCallState.SPEAKING -> "تحدث لمقاطعة AION"
                                else -> status.replace("…", "")
                            },
                            modifier = Modifier.padding(horizontal = AionSpacing.Md, vertical = 7.dp),
                            style = MaterialTheme.typography.labelMedium,
                            color = when (uiCopy.visualDomain) {
                                AionLiveVisualDomain.EXTERNAL -> AionColors.ExternalSoft
                                AionLiveVisualDomain.ERROR -> AionColors.Error
                                AionLiveVisualDomain.INTELLIGENCE -> AionColors.TextSecondary
                            },
                            maxLines = 1
                        )
                    }
                }
                Box {
                    Surface(
                        onClick = onRestore,
                        shape = CircleShape,
                        color = AionColors.SurfaceRaised,
                        border = BorderStroke(1.dp, activityAccent(state).copy(alpha = 0.46f)),
                        modifier = Modifier
                            .size(AionSizes.MiniLiveOrb)
                            .semantics {
                                contentDescription = "AION Live مصغر"
                                stateDescription = status
                            }
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            AionLiveMark(state = state, level = liveLevel, large = false)
                        }
                    }
                    if (muted) {
                        Surface(
                            shape = CircleShape,
                            color = AionColors.Error,
                            modifier = Modifier
                                .size(20.dp)
                                .align(Alignment.BottomStart)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    Icons.Outlined.MicOff,
                                    contentDescription = "الميكروفون مكتوم",
                                    tint = Color.White,
                                    modifier = Modifier.size(12.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
        return
    }

    Dialog(
        onDismissRequest = {
            // Back/dismiss minimizes the live session; only the explicit end control terminates it.
            onMinimize()
        },
        properties = DialogProperties(
            usePlatformDefaultWidth = false,
            dismissOnBackPress = true,
            dismissOnClickOutside = false
        )
    ) {
        Surface(
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer {
                    translationY = dragOffsetPx
                    val fraction = (dragOffsetPx / size.height.coerceAtLeast(1f)).coerceIn(0f, 0.22f)
                    alpha = 1f - fraction
                    scaleX = 1f - fraction * 0.35f
                    scaleY = 1f - fraction * 0.35f
                }
                .pointerInput(onMinimize) {
                    detectVerticalDragGestures(
                        onVerticalDrag = { change, amount ->
                            if (amount > 0f) {
                                change.consume()
                                dragOffsetPx = (dragOffsetPx + amount).coerceAtMost(size.height * 0.42f)
                            }
                        },
                        onDragEnd = {
                            if (dragOffsetPx >= 120.dp.toPx()) onMinimize()
                            dragOffsetPx = 0f
                        },
                        onDragCancel = { dragOffsetPx = 0f }
                    )
                },
            color = AionColors.Background
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .statusBarsPadding()
                    .navigationBarsPadding()
                    .padding(horizontal = AionSpacing.Xxl, vertical = AionSpacing.Xl),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Spacer(Modifier.size(AionSizes.TouchTarget))

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("AION Live", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.ExtraBold)
                        Text(
                            "الصوت والنص في المحادثة نفسها",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    androidx.compose.material3.IconButton(
                        onClick = {
                            AionHaptics.tap(hapticView)
                            onMinimize()
                        },
                        modifier = Modifier.size(AionSizes.TouchTarget)
                    ) {
                        Icon(Icons.Outlined.KeyboardArrowDown, contentDescription = "تصغير AION Live")
                    }
                }

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    AionVoiceOrb(
                        state = state,
                        liveLevel = liveLevel,
                        pulseScale = pulseScale,
                        glowAlpha = glowAlpha,
                        status = status,
                        onClick = {
                            when (state) {
                                VoiceCallState.SPEAKING -> interruptAssistantAndListen()
                                VoiceCallState.THINKING, VoiceCallState.READING_FILES,
                                VoiceCallState.SEARCHING, VoiceCallState.COMPARING, VoiceCallState.WRITING -> {
                                    onStop()
                                    if (!muted) scheduleListen(220L)
                                }
                                VoiceCallState.ERROR, VoiceCallState.RECONNECTING, VoiceCallState.INITIALIZING -> {
                                    recognitionFailures = 0
                                    networkFailures = 0
                                    if (!muted) {
                                        state = VoiceCallState.LISTENING
                                        scheduleListen(50L)
                                    }
                                }
                                VoiceCallState.LISTENING -> Unit
                            }
                        }
                    )
                    Spacer(Modifier.height(AionSpacing.Xxl))
                    Text(
                        status,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.SemiBold,
                        textAlign = TextAlign.Center
                    )
                    if (helper.isNotBlank()) {
                        Spacer(Modifier.height(AionSpacing.Sm))
                        Text(
                            helper,
                            modifier = Modifier.fillMaxWidth().padding(horizontal = AionSpacing.Md),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center
                        )
                    }
                    val transcriptText = when {
                        partialText.isNotBlank() -> partialText
                        state == VoiceCallState.SPEAKING && lastAssistantTranscript.isNotBlank() -> lastAssistantTranscript
                        else -> ""
                    }
                    val transcriptSpeaker = if (partialText.isNotBlank()) "أنت" else "AION"
                    if (transcriptText.isNotBlank()) {
                        Spacer(Modifier.height(AionSpacing.Lg))
                        Surface(
                            shape = androidx.compose.foundation.shape.RoundedCornerShape(AionRadii.Card),
                            color = AionColors.Surface,
                            border = BorderStroke(1.dp, AionColors.Border)
                        ) {
                            Column(
                                modifier = Modifier.padding(horizontal = AionSpacing.Lg, vertical = AionSpacing.Md),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    transcriptSpeaker,
                                    style = MaterialTheme.typography.labelMedium,
                                    color = if (transcriptSpeaker == "AION") activityAccent(state) else AionColors.TextTertiary,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Spacer(Modifier.height(AionSpacing.Xs))
                                Text(
                                    transcriptText,
                                    style = MaterialTheme.typography.bodyLarge,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    textAlign = TextAlign.Center,
                                    maxLines = 5
                                )
                            }
                        }
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        onClick = onMinimize,
                        shape = CircleShape,
                        color = AionColors.SurfaceRaised,
                        modifier = Modifier.size(58.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(Icons.Outlined.Keyboard, contentDescription = "العودة للكتابة")
                        }
                    }

                    Surface(
                        onClick = {
                            AionHaptics.tap(hapticView)
                            onMutedChanged(!muted)
                        },
                        shape = CircleShape,
                        color = if (muted) AionColors.Error.copy(alpha = 0.16f) else AionColors.SurfaceRaised,
                        modifier = Modifier.size(58.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                if (muted) Icons.Outlined.MicOff else Icons.Outlined.Mic,
                                contentDescription = if (muted) "تشغيل الميكروفون" else "كتم الميكروفون"
                            )
                        }
                    }

                    Surface(
                        onClick = {
                            stopAudio()
                            if (isSending) onStop()
                            onDismiss()
                        },
                        shape = CircleShape,
                        color = AionColors.Error.copy(alpha = 0.82f),
                        modifier = Modifier.size(68.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(Icons.Outlined.CallEnd, contentDescription = "إنهاء AION Live", tint = Color.White, modifier = Modifier.size(30.dp))
                        }
                    }

                    AnimatedVisibility(visible = state == VoiceCallState.SPEAKING || isSending) {
                        Surface(
                            onClick = {
                                when {
                                    state == VoiceCallState.SPEAKING -> interruptAssistantAndListen()
                                    isSending -> {
                                        onStop()
                                        if (!muted) scheduleListen(220L)
                                    }
                                }
                            },
                            shape = CircleShape,
                            color = AionColors.SurfaceRaised,
                            modifier = Modifier.size(58.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    Icons.Outlined.Stop,
                                    contentDescription = if (state == VoiceCallState.SPEAKING) "مقاطعة AION" else "إيقاف الرد"
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AionVoiceOrb(
    state: VoiceCallState,
    liveLevel: Float,
    pulseScale: Float,
    glowAlpha: Float,
    status: String,
    onClick: () -> Unit
) {
    val accent = activityAccent(state)
    Box(
        modifier = Modifier
            .size(176.dp)
            .scale(pulseScale)
            .background(accent.copy(alpha = glowAlpha), CircleShape)
            .semantics {
                contentDescription = "AION Live"
                stateDescription = status
            }
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Surface(
            shape = CircleShape,
            color = AionColors.SurfaceRaised,
            border = BorderStroke(1.dp + (liveLevel * 1.2f).dp, accent.copy(alpha = 0.46f + liveLevel * 0.44f)),
            modifier = Modifier.size(118.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                AionLiveMark(state = state, level = liveLevel, large = true)
            }
        }
    }
}

@Composable
private fun AionLiveMark(
    state: VoiceCallState,
    level: Float,
    large: Boolean
) {
    val accent = activityAccent(state)
    val isActivityAnimated = state == VoiceCallState.THINKING ||
        state == VoiceCallState.READING_FILES ||
        state == VoiceCallState.SEARCHING ||
        state == VoiceCallState.COMPARING ||
        state == VoiceCallState.WRITING ||
        state == VoiceCallState.RECONNECTING ||
        state == VoiceCallState.INITIALIZING
    val effectiveMotion = if (isActivityAnimated) {
        val transition = rememberInfiniteTransition(label = "aion-live-mark")
        val value by transition.animateFloat(
            initialValue = 0f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(
                animation = tween(
                    durationMillis = when (state) {
                        VoiceCallState.SEARCHING -> 1_100
                        VoiceCallState.RECONNECTING -> 900
                        else -> 1_700
                    }
                ),
                repeatMode = RepeatMode.Restart
            ),
            label = "aion-live-mark-motion"
        )
        value
    } else 0f
    val markSize = if (large) 64.dp else 28.dp
    Canvas(modifier = Modifier.size(markSize)) {
        val w = size.width
        val h = size.height
        val stroke = if (large) 4.2f else 2.3f
        val soft = accent.copy(alpha = 0.62f)

        when (state) {
            VoiceCallState.LISTENING,
            VoiceCallState.SPEAKING -> {
                val bases = floatArrayOf(0.42f, 0.72f, 0.55f, 0.82f, 0.46f)
                val gap = w / 8f
                val barWidth = if (large) w * 0.055f else w * 0.07f
                bases.forEachIndexed { index, base ->
                    val x = gap * (index + 2)
                    val reactive = if (level > 0.02f) level * (0.30f + base * 0.70f) else if (index == 2) 0.08f else 0.02f
                    val barHeight = h * (0.18f + base * 0.30f + reactive * 0.42f)
                    drawRoundRect(
                        color = if (index == 2) accent else soft,
                        topLeft = Offset(x - barWidth / 2f, h / 2f - barHeight / 2f),
                        size = Size(barWidth, barHeight),
                        cornerRadius = androidx.compose.ui.geometry.CornerRadius(barWidth, barWidth)
                    )
                }
            }

            VoiceCallState.THINKING -> {
                val radius = w * 0.27f
                val dot = w * 0.07f
                repeat(3) { index ->
                    val angle = ((effectiveMotion * 360f) + index * 120f) * (Math.PI / 180.0)
                    val x = w / 2f + kotlin.math.cos(angle).toFloat() * radius
                    val y = h / 2f + kotlin.math.sin(angle).toFloat() * radius
                    drawCircle(if (index == 0) accent else soft, dot, Offset(x, y))
                }
                drawCircle(accent.copy(alpha = 0.20f), w * 0.10f, center)
            }

            VoiceCallState.SEARCHING -> {
                drawArc(
                    color = accent,
                    startAngle = -70f + effectiveMotion * 360f,
                    sweepAngle = 245f,
                    useCenter = false,
                    topLeft = Offset(w * 0.16f, h * 0.16f),
                    size = Size(w * 0.68f, h * 0.68f),
                    style = Stroke(width = stroke, cap = StrokeCap.Round)
                )
                val angle = ((effectiveMotion * 360f) - 70f) * (Math.PI / 180.0)
                val r = w * 0.34f
                drawCircle(
                    color = AionColors.ExternalSoft,
                    radius = w * 0.055f,
                    center = Offset(
                        w / 2f + kotlin.math.cos(angle).toFloat() * r,
                        h / 2f + kotlin.math.sin(angle).toFloat() * r
                    )
                )
            }

            VoiceCallState.READING_FILES -> {
                val left = w * 0.24f
                val top = h * 0.16f
                val docW = w * 0.52f
                val docH = h * 0.68f
                drawRoundRect(
                    color = soft,
                    topLeft = Offset(left, top),
                    size = Size(docW, docH),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(w * 0.06f, w * 0.06f),
                    style = Stroke(width = stroke)
                )
                repeat(3) { index ->
                    val y = top + docH * (0.30f + index * 0.18f)
                    drawLine(accent.copy(alpha = 0.70f), Offset(left + docW * 0.18f, y), Offset(left + docW * 0.78f, y), stroke, StrokeCap.Round)
                }
                val scanY = top + docH * (0.18f + effectiveMotion * 0.64f)
                drawLine(AionColors.ExternalSoft, Offset(left + docW * 0.08f, scanY), Offset(left + docW * 0.92f, scanY), stroke * 0.75f, StrokeCap.Round)
            }

            VoiceCallState.COMPARING -> {
                val y1 = h * 0.34f
                val y2 = h * 0.66f
                drawLine(soft, Offset(w * 0.18f, y1), Offset(w * 0.44f, y1), stroke, StrokeCap.Round)
                drawLine(accent, Offset(w * 0.56f, y1), Offset(w * 0.82f, y1), stroke, StrokeCap.Round)
                drawLine(accent, Offset(w * 0.18f, y2), Offset(w * 0.44f, y2), stroke, StrokeCap.Round)
                drawLine(soft, Offset(w * 0.56f, y2), Offset(w * 0.82f, y2), stroke, StrokeCap.Round)
                val bridgeAlpha = 0.35f + 0.45f * kotlin.math.abs(0.5f - effectiveMotion) * 2f
                drawLine(accent.copy(alpha = bridgeAlpha), Offset(w * 0.46f, y1), Offset(w * 0.54f, y2), stroke * 0.75f, StrokeCap.Round)
                drawLine(accent.copy(alpha = bridgeAlpha), Offset(w * 0.46f, y2), Offset(w * 0.54f, y1), stroke * 0.75f, StrokeCap.Round)
            }

            VoiceCallState.WRITING -> {
                repeat(3) { index ->
                    val y = h * (0.30f + index * 0.20f)
                    val end = if (index == 2) w * (0.48f + effectiveMotion * 0.30f) else w * (0.72f - index * 0.08f)
                    drawLine(
                        color = if (index == 2) accent else soft,
                        start = Offset(w * 0.20f, y),
                        end = Offset(end, y),
                        strokeWidth = stroke,
                        cap = StrokeCap.Round
                    )
                }
            }

            VoiceCallState.RECONNECTING,
            VoiceCallState.INITIALIZING -> {
                drawArc(
                    color = accent,
                    startAngle = effectiveMotion * 360f,
                    sweepAngle = 210f,
                    useCenter = false,
                    topLeft = Offset(w * 0.18f, h * 0.18f),
                    size = Size(w * 0.64f, h * 0.64f),
                    style = Stroke(width = stroke, cap = StrokeCap.Round)
                )
                drawCircle(soft, w * 0.055f, center)
            }

            VoiceCallState.ERROR -> {
                drawCircle(accent.copy(alpha = 0.16f), w * 0.31f, center)
                drawLine(accent, Offset(w / 2f, h * 0.30f), Offset(w / 2f, h * 0.57f), stroke * 1.1f, StrokeCap.Round)
                drawCircle(accent, w * 0.045f, Offset(w / 2f, h * 0.70f))
            }
        }
    }
}

private fun VoiceCallState.toLivePhase(): AionLivePhase = when (this) {
    VoiceCallState.INITIALIZING -> AionLivePhase.INITIALIZING
    VoiceCallState.LISTENING -> AionLivePhase.LISTENING
    VoiceCallState.THINKING -> AionLivePhase.THINKING
    VoiceCallState.READING_FILES -> AionLivePhase.READING_FILES
    VoiceCallState.SEARCHING -> AionLivePhase.SEARCHING
    VoiceCallState.COMPARING -> AionLivePhase.COMPARING
    VoiceCallState.WRITING -> AionLivePhase.WRITING
    VoiceCallState.SPEAKING -> AionLivePhase.SPEAKING
    VoiceCallState.RECONNECTING -> AionLivePhase.RECONNECTING
    VoiceCallState.ERROR -> AionLivePhase.ERROR
}

private fun activityAccent(state: VoiceCallState): Color = when (state) {
    VoiceCallState.SEARCHING -> AionColors.External
    VoiceCallState.ERROR -> AionColors.Error
    else -> AionColors.Intelligence
}

internal fun configureNaturalTts(engine: TextToSpeech, locale: Locale): Boolean {
    // كل خطوة اختيارية. بعض محركات TTS على أجهزة OEM لا تنفذ جميع الخصائص
    // القياسية بصورة سليمة؛ فشل تحسين واحد يجب ألا يغلق التطبيق أو المكالمة.
    val selectedLocale = runCatching {
        val available = engine.isLanguageAvailable(locale) >= TextToSpeech.LANG_AVAILABLE
        if (available) locale else Locale.forLanguageTag(locale.language.ifBlank { "ar" })
    }.getOrDefault(locale)

    val languageResult = runCatching { engine.setLanguage(selectedLocale) }
        .getOrDefault(TextToSpeech.LANG_NOT_SUPPORTED)

    runCatching {
        engine.setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ASSISTANT)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build()
        )
    }
    runCatching { engine.setSpeechRate(if (selectedLocale.language == "ar") 0.94f else 0.97f) }
    runCatching { engine.setPitch(1.0f) }

    runCatching {
        val bestVoice = engine.voices
            ?.asSequence()
            ?.filter { it.locale.language == selectedLocale.language }
            ?.maxByOrNull { voice ->
                (voice.quality * 100) - (voice.latency * 6) + if (voice.isNetworkConnectionRequired) 12 else 0
            }
        if (bestVoice != null) engine.voice = bestVoice
    }

    return languageResult != TextToSpeech.LANG_MISSING_DATA &&
        languageResult != TextToSpeech.LANG_NOT_SUPPORTED
}

private fun speechRecognizerSafeDestroy(recognizer: SpeechRecognizer?) {
    recognizer?.cancel()
    recognizer?.destroy()
}
