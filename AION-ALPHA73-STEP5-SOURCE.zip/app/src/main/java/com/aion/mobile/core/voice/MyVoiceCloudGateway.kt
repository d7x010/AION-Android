package com.aion.mobile.core.voice

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.BufferedReader
import java.io.DataOutputStream
import java.io.File
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID

data class MyVoiceEnrollmentResult(
    val token: String,
    val label: String,
    val requiresVerification: Boolean
)

class MyVoiceCloudGateway {
    suspend fun create(
        endpoint: String,
        sample: File,
        displayName: String,
        enrollmentSecret: String,
        consent: Boolean
    ): MyVoiceEnrollmentResult = withContext(Dispatchers.IO) {
        require(consent) { "الموافقة الصريحة مطلوبة قبل إنشاء الصوت الشخصي." }
        require(MyVoicePolicy.sampleReady(sample)) { "العينة الصوتية غير صالحة أو أقصر من الحد المطلوب." }
        val cleanEndpoint = endpoint.trim().trimEnd('/')
        require(cleanEndpoint.startsWith("https://")) { "عنوان AION Cloud غير صالح." }
        require(enrollmentSecret.trim().length >= 16) { "رمز إعداد My Voice غير صالح." }

        val boundary = "----AionVoice${UUID.randomUUID()}"
        val connection = (URL("$cleanEndpoint/v1/voice/my-voice").openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            doOutput = true
            connectTimeout = 20_000
            readTimeout = 90_000
            useCaches = false
            setChunkedStreamingMode(64 * 1024)
            setRequestProperty("Accept", "application/json")
            setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
            setRequestProperty("X-Aion-Client", "AION-Android/alpha7.3")
            setRequestProperty("X-Aion-Voice-Enrollment", enrollmentSecret.trim())
        }

        fun DataOutputStream.field(name: String, value: String) {
            writeBytes("--$boundary\r\n")
            writeBytes("Content-Disposition: form-data; name=\"$name\"\r\n\r\n")
            write(value.toByteArray(Charsets.UTF_8))
            writeBytes("\r\n")
        }

        try {
            DataOutputStream(connection.outputStream).use { out ->
                out.field("name", MyVoicePolicy.normalizedName(displayName))
                out.field("consent", "self")
                out.writeBytes("--$boundary\r\n")
                out.writeBytes("Content-Disposition: form-data; name=\"sample\"; filename=\"aion-my-voice.wav\"\r\n")
                out.writeBytes("Content-Type: audio/wav\r\n\r\n")
                sample.inputStream().use { it.copyTo(out) }
                out.writeBytes("\r\n--$boundary--\r\n")
            }
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val raw = stream?.let { input ->
                BufferedReader(InputStreamReader(input, Charsets.UTF_8)).use { it.readText() }
            }.orEmpty()
            val body = runCatching { JSONObject(raw) }.getOrNull()
            if (code !in 200..299) {
                throw IllegalStateException(body?.optString("error").orEmpty().ifBlank { "تعذر إنشاء My Voice." })
            }
            val token = body?.optString("token").orEmpty().trim()
            if (token.isBlank()) throw IllegalStateException("الخادم لم يُرجع اعتماد My Voice صالحًا.")
            MyVoiceEnrollmentResult(
                token = token,
                label = body?.optString("label").orEmpty().ifBlank { "صوتي" }.take(48),
                requiresVerification = body?.optBoolean("requiresVerification", false) == true
            )
        } finally {
            connection.disconnect()
        }
    }

    suspend fun delete(endpoint: String, token: String): Boolean = withContext(Dispatchers.IO) {
        val cleanEndpoint = endpoint.trim().trimEnd('/')
        if (!cleanEndpoint.startsWith("https://") || token.isBlank()) return@withContext false
        val connection = (URL("$cleanEndpoint/v1/voice/my-voice").openConnection() as HttpURLConnection).apply {
            requestMethod = "DELETE"
            connectTimeout = 15_000
            readTimeout = 30_000
            useCaches = false
            setRequestProperty("Accept", "application/json")
            setRequestProperty("X-Aion-Client", "AION-Android/alpha7.3")
            setRequestProperty("X-Aion-My-Voice", token)
        }
        try {
            connection.responseCode in 200..299
        } finally {
            connection.disconnect()
        }
    }
}
